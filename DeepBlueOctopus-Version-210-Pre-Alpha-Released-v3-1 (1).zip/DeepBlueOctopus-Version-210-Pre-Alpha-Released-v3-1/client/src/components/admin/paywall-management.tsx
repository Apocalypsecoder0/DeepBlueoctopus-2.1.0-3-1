import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import {
  Shield,
  User,
  CreditCard,
  Settings,
  Search,
  Filter,
  UserCheck,
  UserX,
  Crown,
  Lock,
  Unlock,
  DollarSign,
  Calendar,
  Mail,
  Phone,
  AlertTriangle,
  CheckCircle,
  Clock,
  Trash2,
  Edit,
  Plus,
  Download,
  Upload
} from 'lucide-react';

interface User {
  id: string;
  username: string;
  email: string;
  subscription: 'free' | 'gold' | 'platinum' | 'enterprise';
  status: 'active' | 'suspended' | 'pending' | 'cancelled';
  paywallStatus: 'enabled' | 'disabled' | 'bypass';
  registrationDate: string;
  lastActive: string;
  totalProjects: number;
  storageUsed: string;
  aiRequestsUsed: number;
  billingAmount: number;
  paymentMethod: string;
  notes: string;
}

interface PaywallRule {
  id: string;
  name: string;
  description: string;
  userGroup: 'all' | 'free' | 'paid' | 'specific';
  action: 'block' | 'allow' | 'redirect';
  features: string[];
  enabled: boolean;
  createdDate: string;
  lastModified: string;
}

const PaywallManagement: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [paywallRules, setPaywallRules] = useState<PaywallRule[]>([]);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterSubscription, setFilterSubscription] = useState<string>('all');
  const [showAddRule, setShowAddRule] = useState(false);
  const [selectedRule, setSelectedRule] = useState<PaywallRule | null>(null);
  const [bulkAction, setBulkAction] = useState<string>('');
  const { toast } = useToast();

  // Mock data for demonstration
  useEffect(() => {
    const mockUsers: User[] = [
      {
        id: '1',
        username: 'john_developer',
        email: 'john@example.com',
        subscription: 'gold',
        status: 'active',
        paywallStatus: 'enabled',
        registrationDate: '2025-01-15',
        lastActive: '2025-07-07',
        totalProjects: 12,
        storageUsed: '2.3GB',
        aiRequestsUsed: 450,
        billingAmount: 19.99,
        paymentMethod: 'Credit Card',
        notes: 'Premium user, excellent payment history'
      },
      {
        id: '2',
        username: 'sarah_designer',
        email: 'sarah@example.com',
        subscription: 'free',
        status: 'active',
        paywallStatus: 'enabled',
        registrationDate: '2025-03-22',
        lastActive: '2025-07-06',
        totalProjects: 3,
        storageUsed: '45MB',
        aiRequestsUsed: 23,
        billingAmount: 0,
        paymentMethod: 'None',
        notes: 'Potential upgrade candidate'
      },
      {
        id: '3',
        username: 'mike_startup',
        email: 'mike@startup.com',
        subscription: 'platinum',
        status: 'active',
        paywallStatus: 'bypass',
        registrationDate: '2024-11-08',
        lastActive: '2025-07-07',
        totalProjects: 28,
        storageUsed: '8.7GB',
        aiRequestsUsed: 1200,
        billingAmount: 49.99,
        paymentMethod: 'Corporate Card',
        notes: 'Enterprise trial user, bypass enabled for testing'
      },
      {
        id: '4',
        username: 'alex_student',
        email: 'alex@university.edu',
        subscription: 'free',
        status: 'suspended',
        paywallStatus: 'disabled',
        registrationDate: '2025-06-01',
        lastActive: '2025-06-15',
        totalProjects: 1,
        storageUsed: '12MB',
        aiRequestsUsed: 5,
        billingAmount: 0,
        paymentMethod: 'None',
        notes: 'Account suspended for terms violation'
      }
    ];

    const mockRules: PaywallRule[] = [
      {
        id: '1',
        name: 'Free Tier Limitations',
        description: 'Standard limitations for free tier users',
        userGroup: 'free',
        action: 'block',
        features: ['Advanced AI', 'Game Engine Export', 'Collaboration'],
        enabled: true,
        createdDate: '2025-01-01',
        lastModified: '2025-07-01'
      },
      {
        id: '2',
        name: 'Premium Feature Access',
        description: 'Allow all premium features for paid users',
        userGroup: 'paid',
        action: 'allow',
        features: ['All Features'],
        enabled: true,
        createdDate: '2025-01-01',
        lastModified: '2025-07-01'
      },
      {
        id: '3',
        name: 'Beta User Bypass',
        description: 'Special access for beta testers',
        userGroup: 'specific',
        action: 'allow',
        features: ['Beta Features', 'Advanced Tools'],
        enabled: true,
        createdDate: '2025-06-01',
        lastModified: '2025-07-01'
      }
    ];

    setUsers(mockUsers);
    setPaywallRules(mockRules);
  }, []);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || user.status === filterStatus;
    const matchesSubscription = filterSubscription === 'all' || user.subscription === filterSubscription;
    
    return matchesSearch && matchesStatus && matchesSubscription;
  });

  const handleUserPaywallToggle = async (userId: string, newStatus: 'enabled' | 'disabled' | 'bypass') => {
    try {
      setUsers(prev => prev.map(user => 
        user.id === userId ? { ...user, paywallStatus: newStatus } : user
      ));
      
      toast({
        title: "Paywall Status Updated",
        description: `User paywall status changed to ${newStatus}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update paywall status",
        variant: "destructive",
      });
    }
  };

  const handleBulkPaywallAction = async () => {
    if (!bulkAction || selectedUsers.length === 0) return;

    try {
      setUsers(prev => prev.map(user => 
        selectedUsers.includes(user.id) 
          ? { ...user, paywallStatus: bulkAction as 'enabled' | 'disabled' | 'bypass' }
          : user
      ));

      toast({
        title: "Bulk Action Completed",
        description: `Updated paywall status for ${selectedUsers.length} users`,
      });

      setSelectedUsers([]);
      setBulkAction('');
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to execute bulk action",
        variant: "destructive",
      });
    }
  };

  const handleCreatePaywallRule = async (ruleData: Partial<PaywallRule>) => {
    try {
      const newRule: PaywallRule = {
        id: Date.now().toString(),
        name: ruleData.name || '',
        description: ruleData.description || '',
        userGroup: ruleData.userGroup || 'all',
        action: ruleData.action || 'block',
        features: ruleData.features || [],
        enabled: true,
        createdDate: new Date().toISOString().split('T')[0],
        lastModified: new Date().toISOString().split('T')[0]
      };

      setPaywallRules(prev => [...prev, newRule]);
      setShowAddRule(false);

      toast({
        title: "Paywall Rule Created",
        description: "New paywall rule has been created successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create paywall rule",
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status: string, type: 'user' | 'paywall') => {
    if (type === 'user') {
      const variants: Record<string, string> = {
        active: 'bg-green-500',
        suspended: 'bg-red-500',
        pending: 'bg-yellow-500',
        cancelled: 'bg-gray-500'
      };
      return <Badge className={variants[status] || 'bg-gray-500'}>{status}</Badge>;
    } else {
      const variants: Record<string, string> = {
        enabled: 'bg-blue-500',
        disabled: 'bg-red-500',
        bypass: 'bg-green-500'
      };
      return <Badge className={variants[status] || 'bg-gray-500'}>{status}</Badge>;
    }
  };

  const getSubscriptionIcon = (subscription: string) => {
    switch (subscription) {
      case 'free': return <User className="w-4 h-4" />;
      case 'gold': return <CreditCard className="w-4 h-4 text-yellow-500" />;
      case 'platinum': return <Crown className="w-4 h-4 text-purple-500" />;
      case 'enterprise': return <Shield className="w-4 h-4 text-blue-500" />;
      default: return <User className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Paywall Management</h2>
          <p className="text-muted-foreground">Manage user access and subscription paywalls</p>
        </div>
        <Button 
          onClick={() => setShowAddRule(true)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Rule
        </Button>
      </div>

      <Tabs defaultValue="users" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="users">User Management</TabsTrigger>
          <TabsTrigger value="rules">Paywall Rules</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                User Paywall Controls
              </CardTitle>
              <CardDescription>
                Manage individual user paywall settings and subscription access
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Filters and Search */}
              <div className="flex flex-wrap gap-4 items-center">
                <div className="flex-1 min-w-[300px]">
                  <Label htmlFor="search">Search Users</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="search"
                      placeholder="Search by username or email..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="status-filter">Status Filter</Label>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="suspended">Suspended</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="subscription-filter">Subscription Filter</Label>
                  <Select value={filterSubscription} onValueChange={setFilterSubscription}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Plans</SelectItem>
                      <SelectItem value="free">Free</SelectItem>
                      <SelectItem value="gold">Gold</SelectItem>
                      <SelectItem value="platinum">Platinum</SelectItem>
                      <SelectItem value="enterprise">Enterprise</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Bulk Actions */}
              {selectedUsers.length > 0 && (
                <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                  <span className="text-sm font-medium">
                    {selectedUsers.length} users selected
                  </span>
                  <Select value={bulkAction} onValueChange={setBulkAction}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Bulk Action" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="enabled">Enable Paywall</SelectItem>
                      <SelectItem value="disabled">Disable Paywall</SelectItem>
                      <SelectItem value="bypass">Grant Bypass</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button 
                    onClick={handleBulkPaywallAction}
                    disabled={!bulkAction}
                    size="sm"
                  >
                    Apply Action
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setSelectedUsers([])}
                  >
                    Clear Selection
                  </Button>
                </div>
              )}

              {/* Users Table */}
              <div className="border rounded-lg overflow-hidden">
                <div className="max-h-[600px] overflow-auto">
                  <table className="w-full">
                    <thead className="bg-muted sticky top-0">
                      <tr>
                        <th className="p-3 text-left">
                          <input
                            type="checkbox"
                            checked={selectedUsers.length === filteredUsers.length && filteredUsers.length > 0}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedUsers(filteredUsers.map(u => u.id));
                              } else {
                                setSelectedUsers([]);
                              }
                            }}
                          />
                        </th>
                        <th className="p-3 text-left font-medium">User</th>
                        <th className="p-3 text-left font-medium">Subscription</th>
                        <th className="p-3 text-left font-medium">Status</th>
                        <th className="p-3 text-left font-medium">Paywall</th>
                        <th className="p-3 text-left font-medium">Usage</th>
                        <th className="p-3 text-left font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredUsers.map((user) => (
                        <tr key={user.id} className="border-t hover:bg-muted/50">
                          <td className="p-3">
                            <input
                              type="checkbox"
                              checked={selectedUsers.includes(user.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedUsers(prev => [...prev, user.id]);
                                } else {
                                  setSelectedUsers(prev => prev.filter(id => id !== user.id));
                                }
                              }}
                            />
                          </td>
                          <td className="p-3">
                            <div className="space-y-1">
                              <div className="font-medium flex items-center gap-2">
                                {getSubscriptionIcon(user.subscription)}
                                {user.username}
                              </div>
                              <div className="text-sm text-muted-foreground">{user.email}</div>
                              <div className="text-xs text-muted-foreground">
                                Joined: {new Date(user.registrationDate).toLocaleDateString()}
                              </div>
                            </div>
                          </td>
                          <td className="p-3">
                            <div className="space-y-1">
                              <Badge variant="outline" className="capitalize">
                                {user.subscription}
                              </Badge>
                              {user.billingAmount > 0 && (
                                <div className="text-sm text-green-600 font-medium">
                                  ${user.billingAmount}/month
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="p-3">
                            {getStatusBadge(user.status, 'user')}
                          </td>
                          <td className="p-3">
                            <div className="space-y-2">
                              {getStatusBadge(user.paywallStatus, 'paywall')}
                              <Select
                                value={user.paywallStatus}
                                onValueChange={(value: 'enabled' | 'disabled' | 'bypass') => 
                                  handleUserPaywallToggle(user.id, value)
                                }
                              >
                                <SelectTrigger className="w-[120px] h-8">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="enabled">
                                    <div className="flex items-center gap-2">
                                      <Lock className="w-3 h-3" />
                                      Enabled
                                    </div>
                                  </SelectItem>
                                  <SelectItem value="disabled">
                                    <div className="flex items-center gap-2">
                                      <Unlock className="w-3 h-3" />
                                      Disabled
                                    </div>
                                  </SelectItem>
                                  <SelectItem value="bypass">
                                    <div className="flex items-center gap-2">
                                      <CheckCircle className="w-3 h-3" />
                                      Bypass
                                    </div>
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </td>
                          <td className="p-3">
                            <div className="text-sm space-y-1">
                              <div>{user.totalProjects} projects</div>
                              <div>{user.storageUsed} storage</div>
                              <div>{user.aiRequestsUsed} AI requests</div>
                            </div>
                          </td>
                          <td className="p-3">
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline">
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button size="sm" variant="outline">
                                <Mail className="w-3 h-3" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rules" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Paywall Rules
              </CardTitle>
              <CardDescription>
                Configure automatic paywall rules for different user groups
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                {paywallRules.map((rule) => (
                  <div key={rule.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <h4 className="font-medium">{rule.name}</h4>
                        <p className="text-sm text-muted-foreground">{rule.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch 
                          checked={rule.enabled}
                          onCheckedChange={(checked) => {
                            setPaywallRules(prev => prev.map(r => 
                              r.id === rule.id ? { ...r, enabled: checked } : r
                            ));
                          }}
                        />
                        <Button size="sm" variant="outline">
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <span className="text-muted-foreground">Group:</span>
                        <Badge variant="outline">{rule.userGroup}</Badge>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-muted-foreground">Action:</span>
                        <Badge variant={rule.action === 'allow' ? 'default' : 'destructive'}>
                          {rule.action}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-muted-foreground">Features:</span>
                        <span>{rule.features.join(', ')}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Users</p>
                    <p className="text-2xl font-bold">{users.length}</p>
                  </div>
                  <User className="w-8 h-8 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Paid Users</p>
                    <p className="text-2xl font-bold">
                      {users.filter(u => u.subscription !== 'free').length}
                    </p>
                  </div>
                  <CreditCard className="w-8 h-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Bypass Users</p>
                    <p className="text-2xl font-bold">
                      {users.filter(u => u.paywallStatus === 'bypass').length}
                    </p>
                  </div>
                  <CheckCircle className="w-8 h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Revenue</p>
                    <p className="text-2xl font-bold">
                      ${users.reduce((sum, u) => sum + u.billingAmount, 0).toFixed(2)}
                    </p>
                  </div>
                  <DollarSign className="w-8 h-8 text-yellow-500" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PaywallManagement;