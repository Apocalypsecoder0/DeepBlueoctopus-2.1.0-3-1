import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { SoundButton } from "@/components/ui/sound-system";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  FileText, 
  Code, 
  Database, 
  Globe, 
  Package, 
  Terminal,
  Braces,
  FileCode,
  Settings,
  Zap,
  Monitor,
  Smartphone,
  Layers,
  FileImage,
  FileAudio,
  FileVideo,
  Archive
} from "lucide-react";

interface LanguageFileCreatorProps {
  isOpen: boolean;
  onClose: () => void;
}

interface LanguageTemplate {
  id: string;
  name: string;
  extension: string;
  category: string;
  icon: any;
  color: string;
  template: string;
  description: string;
  features: string[];
}

const languageTemplates: LanguageTemplate[] = [
  // Web Development
  {
    id: "javascript",
    name: "JavaScript",
    extension: ".js",
    category: "Web Development",
    icon: Code,
    color: "text-yellow-400",
    template: `// JavaScript file
console.log("Hello, World!");

// Your code here
`,
    description: "Dynamic programming language for web development",
    features: ["Dynamic Typing", "ES6+", "Node.js", "Web APIs"]
  },
  {
    id: "typescript",
    name: "TypeScript",
    extension: ".ts",
    category: "Web Development",
    icon: Code,
    color: "text-blue-400",
    template: `// TypeScript file
interface Greeting {
  message: string;
}

const greeting: Greeting = {
  message: "Hello, World!"
};

console.log(greeting.message);

// Your code here
`,
    description: "Typed superset of JavaScript",
    features: ["Static Typing", "IntelliSense", "ES6+", "Compile-time Checks"]
  },
  {
    id: "html",
    name: "HTML",
    extension: ".html",
    category: "Web Development",
    icon: Globe,
    color: "text-orange-400",
    template: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Hello, World!</h1>
    <!-- Your content here -->
</body>
</html>`,
    description: "Markup language for web pages",
    features: ["Semantic Elements", "HTML5", "Accessibility", "SEO"]
  },
  {
    id: "css",
    name: "CSS",
    extension: ".css",
    category: "Web Development",
    icon: FileCode,
    color: "text-blue-300",
    template: `/* CSS Stylesheet */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f0f0f0;
}

h1 {
    color: #333;
    text-align: center;
}

/* Your styles here */
`,
    description: "Stylesheet language for web design",
    features: ["Flexbox", "Grid", "Animations", "Responsive Design"]
  },
  {
    id: "scss",
    name: "SCSS",
    extension: ".scss",
    category: "Web Development",
    icon: FileCode,
    color: "text-pink-400",
    template: `// SCSS Stylesheet
$primary-color: #007bff;
$font-size: 16px;

@mixin button-style {
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

body {
  font-size: $font-size;
  color: $primary-color;
}

.button {
  @include button-style;
  background-color: $primary-color;
  color: white;
}

// Your styles here
`,
    description: "CSS preprocessor with advanced features",
    features: ["Variables", "Mixins", "Nesting", "Functions"]
  },

  // Backend Development
  {
    id: "python",
    name: "Python",
    extension: ".py",
    category: "Backend Development",
    icon: Code,
    color: "text-green-400",
    template: `#!/usr/bin/env python3
"""
Python script
"""

def main():
    print("Hello, World!")
    # Your code here

if __name__ == "__main__":
    main()
`,
    description: "High-level programming language",
    features: ["Dynamic Typing", "Libraries", "AI/ML", "Web Frameworks"]
  },
  {
    id: "java",
    name: "Java",
    extension: ".java",
    category: "Backend Development",
    icon: Package,
    color: "text-red-400",
    template: `public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        // Your code here
    }
}
`,
    description: "Object-oriented programming language",
    features: ["Static Typing", "JVM", "Enterprise", "Cross-platform"]
  },
  {
    id: "csharp",
    name: "C#",
    extension: ".cs",
    category: "Backend Development",
    icon: Package,
    color: "text-purple-400",
    template: `using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            // Your code here
        }
    }
}
`,
    description: "Modern object-oriented language",
    features: ["Static Typing", ".NET", "Cross-platform", "Memory Safe"]
  },
  {
    id: "php",
    name: "PHP",
    extension: ".php",
    category: "Backend Development",
    icon: Code,
    color: "text-purple-300",
    template: `<?php
echo "Hello, World!";

// Your code here
?>
`,
    description: "Server-side scripting language",
    features: ["Dynamic Typing", "Web Development", "Frameworks", "Database Integration"]
  },
  {
    id: "ruby",
    name: "Ruby",
    extension: ".rb",
    category: "Backend Development",
    icon: Code,
    color: "text-red-300",
    template: `#!/usr/bin/env ruby
puts "Hello, World!"

# Your code here
`,
    description: "Dynamic programming language",
    features: ["Object-oriented", "Elegant Syntax", "Rails Framework", "Metaprogramming"]
  },

  // Systems Programming
  {
    id: "c",
    name: "C",
    extension: ".c",
    category: "Systems Programming",
    icon: Terminal,
    color: "text-gray-400",
    template: `#include <stdio.h>

int main() {
    printf("Hello, World!\\n");
    // Your code here
    return 0;
}
`,
    description: "Low-level systems programming language",
    features: ["Performance", "Memory Control", "System Programming", "Portable"]
  },
  {
    id: "cpp",
    name: "C++",
    extension: ".cpp",
    category: "Systems Programming",
    icon: Terminal,
    color: "text-blue-500",
    template: `#include <iostream>

int main() {
    std::cout << "Hello, World!" << std::endl;
    // Your code here
    return 0;
}
`,
    description: "Object-oriented systems programming language",
    features: ["Performance", "OOP", "STL", "Game Development"]
  },
  {
    id: "rust",
    name: "Rust",
    extension: ".rs",
    category: "Systems Programming",
    icon: Package,
    color: "text-orange-500",
    template: `fn main() {
    println!("Hello, World!");
    // Your code here
}
`,
    description: "Memory-safe systems programming language",
    features: ["Memory Safety", "Performance", "Concurrency", "Zero-cost Abstractions"]
  },
  {
    id: "go",
    name: "Go",
    extension: ".go",
    category: "Systems Programming",
    icon: Globe,
    color: "text-cyan-400",
    template: `package main

import "fmt"

func main() {
    fmt.Println("Hello, World!")
    // Your code here
}
`,
    description: "Fast and simple programming language",
    features: ["Concurrency", "Fast Compilation", "Simple Syntax", "Network Programming"]
  },

  // Mobile Development
  {
    id: "swift",
    name: "Swift",
    extension: ".swift",
    category: "Mobile Development",
    icon: Smartphone,
    color: "text-orange-400",
    template: `import Foundation

print("Hello, World!")

// Your code here
`,
    description: "Apple's programming language for iOS",
    features: ["Type Safety", "iOS Development", "Performance", "Modern Syntax"]
  },
  {
    id: "kotlin",
    name: "Kotlin",
    extension: ".kt",
    category: "Mobile Development",
    icon: Smartphone,
    color: "text-purple-500",
    template: `fun main() {
    println("Hello, World!")
    // Your code here
}
`,
    description: "Modern language for Android development",
    features: ["Interoperability", "Null Safety", "Android", "Multiplatform"]
  },
  {
    id: "dart",
    name: "Dart",
    extension: ".dart",
    category: "Mobile Development",
    icon: Smartphone,
    color: "text-blue-600",
    template: `void main() {
  print('Hello, World!');
  // Your code here
}
`,
    description: "Language for Flutter development",
    features: ["Flutter", "Cross-platform", "Hot Reload", "Strong Typing"]
  },

  // Scripting & Automation
  {
    id: "bash",
    name: "Bash",
    extension: ".sh",
    category: "Scripting & Automation",
    icon: Terminal,
    color: "text-gray-300",
    template: `#!/bin/bash
echo "Hello, World!"

# Your script here
`,
    description: "Unix shell scripting language",
    features: ["System Administration", "Automation", "File Operations", "Process Control"]
  },
  {
    id: "powershell",
    name: "PowerShell",
    extension: ".ps1",
    category: "Scripting & Automation",
    icon: Terminal,
    color: "text-blue-400",
    template: `# PowerShell script
Write-Host "Hello, World!"

# Your script here
`,
    description: "Windows automation framework",
    features: ["Object-oriented", "Windows Administration", "Cross-platform", "Cmdlets"]
  },

  // Data & Configuration
  {
    id: "json",
    name: "JSON",
    extension: ".json",
    category: "Data & Configuration",
    icon: Braces,
    color: "text-yellow-300",
    template: `{
  "name": "example",
  "version": "1.0.0",
  "description": "A JSON configuration file",
  "data": {
    "message": "Hello, World!"
  }
}
`,
    description: "JavaScript Object Notation",
    features: ["Data Exchange", "Configuration", "APIs", "Lightweight"]
  },
  {
    id: "yaml",
    name: "YAML",
    extension: ".yaml",
    category: "Data & Configuration",
    icon: Settings,
    color: "text-green-300",
    template: `# YAML configuration file
name: example
version: 1.0.0
description: A YAML configuration file

data:
  message: "Hello, World!"
  items:
    - item1
    - item2
    - item3
`,
    description: "Human-readable data serialization",
    features: ["Configuration", "CI/CD", "Docker", "Kubernetes"]
  },
  {
    id: "xml",
    name: "XML",
    extension: ".xml",
    category: "Data & Configuration",
    icon: FileCode,
    color: "text-orange-300",
    template: `<?xml version="1.0" encoding="UTF-8"?>
<root>
    <message>Hello, World!</message>
    <!-- Your XML content here -->
</root>
`,
    description: "Extensible Markup Language",
    features: ["Data Exchange", "Configuration", "Web Services", "Document Structure"]
  },
  {
    id: "sql",
    name: "SQL",
    extension: ".sql",
    category: "Data & Configuration",
    icon: Database,
    color: "text-cyan-300",
    template: `-- SQL Query
SELECT 'Hello, World!' as message;

-- Your queries here
`,
    description: "Structured Query Language",
    features: ["Database Queries", "Data Manipulation", "Joins", "Transactions"]
  },

  // Documentation
  {
    id: "markdown",
    name: "Markdown",
    extension: ".md",
    category: "Documentation",
    icon: FileText,
    color: "text-gray-400",
    template: `# Hello, World!

This is a **markdown** file.

## Features

- Easy to write
- Easy to read
- Widely supported

## Code Example

\`\`\`javascript
console.log("Hello, World!");
\`\`\`

Your content here...
`,
    description: "Lightweight markup language",
    features: ["Documentation", "README files", "Static Sites", "Easy Syntax"]
  },
  {
    id: "text",
    name: "Plain Text",
    extension: ".txt",
    category: "Documentation",
    icon: FileText,
    color: "text-gray-500",
    template: `Hello, World!

Your text content here...
`,
    description: "Plain text file",
    features: ["Simple", "Universal", "No Formatting", "Lightweight"]
  }
];

const categories = Array.from(new Set(languageTemplates.map(lang => lang.category)));

export function LanguageFileCreator({ isOpen, onClose }: LanguageFileCreatorProps) {
  const [fileName, setFileName] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageTemplate | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchTerm, setSearchTerm] = useState("");
  const { createProject, addFile } = useIDEState();

  const filteredLanguages = languageTemplates.filter(lang => {
    const matchesCategory = selectedCategory === "All" || lang.category === selectedCategory;
    const matchesSearch = searchTerm === "" || 
      lang.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lang.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleLanguageSelect = (language: LanguageTemplate) => {
    setSelectedLanguage(language);
    if (!fileName) {
      setFileName(`untitled${language.extension}`);
    } else if (!fileName.includes('.')) {
      setFileName(`${fileName}${language.extension}`);
    } else {
      // Replace extension
      const nameWithoutExt = fileName.substring(0, fileName.lastIndexOf('.'));
      setFileName(`${nameWithoutExt}${language.extension}`);
    }
  };

  const handleCreateFile = () => {
    if (!fileName || !selectedLanguage) return;

    const fileContent = selectedLanguage.template;
    
    addFile({
      name: fileName,
      content: fileContent,
      language: selectedLanguage.id,
      path: `/${fileName}`,
      projectId: 1,
      isDirectory: false
    });

    // Reset form
    setFileName("");
    setSelectedLanguage(null);
    setSearchTerm("");
    setSelectedCategory("All");
    onClose();
  };

  const getLanguageIcon = (language: LanguageTemplate) => {
    const IconComponent = language.icon;
    return <IconComponent className={`h-5 w-5 ${language.color}`} />;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Create New File with Language Template
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
          {/* Left Panel - Language Selection */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex flex-col sm:flex-row gap-2">
              <Input
                placeholder="Search languages..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-1"
              />
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="All">All Categories</SelectItem>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <ScrollArea className="h-96">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {filteredLanguages.map(language => (
                  <TooltipWrapper 
                    key={language.id}
                    title={language.name}
                    content={language.description}
                    type="info"
                  >
                    <Card 
                      className={`cursor-pointer transition-all hover:shadow-md ${
                        selectedLanguage?.id === language.id 
                          ? 'ring-2 ring-blue-500 bg-blue-50 dark:bg-blue-950' 
                          : 'hover:bg-gray-50 dark:hover:bg-gray-800'
                      }`}
                      onClick={() => handleLanguageSelect(language)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          {getLanguageIcon(language)}
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium truncate">{language.name}</h3>
                            <p className="text-sm text-gray-500 truncate">{language.extension}</p>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {language.category}
                          </Badge>
                        </div>
                        <div className="mt-2 flex flex-wrap gap-1">
                          {language.features.slice(0, 2).map(feature => (
                            <Badge key={feature} variant="secondary" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </TooltipWrapper>
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* Right Panel - File Configuration */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">File Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="fileName">File Name</Label>
                  <Input
                    id="fileName"
                    value={fileName}
                    onChange={(e) => setFileName(e.target.value)}
                    placeholder="Enter file name..."
                    className="mt-1"
                  />
                </div>

                {selectedLanguage && (
                  <div className="space-y-3">
                    <Separator />
                    
                    <div className="flex items-center gap-2">
                      {getLanguageIcon(selectedLanguage)}
                      <div>
                        <h4 className="font-medium">{selectedLanguage.name}</h4>
                        <p className="text-sm text-gray-500">{selectedLanguage.description}</p>
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm font-medium">Features</Label>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedLanguage.features.map(feature => (
                          <Badge key={feature} variant="outline" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm font-medium">Template Preview</Label>
                      <ScrollArea className="h-32 mt-1">
                        <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded border">
                          {selectedLanguage.template.substring(0, 200)}
                          {selectedLanguage.template.length > 200 && '...'}
                        </pre>
                      </ScrollArea>
                    </div>
                  </div>
                )}

                <Separator />

                <div className="flex gap-2">
                  <SoundButton
                    onClick={handleCreateFile}
                    disabled={!fileName || !selectedLanguage}
                    className="flex-1"
                    soundType="success"
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Create File
                  </SoundButton>
                  <SoundButton
                    onClick={onClose}
                    className="px-4"
                    soundType="click"
                  >
                    Cancel
                  </SoundButton>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}