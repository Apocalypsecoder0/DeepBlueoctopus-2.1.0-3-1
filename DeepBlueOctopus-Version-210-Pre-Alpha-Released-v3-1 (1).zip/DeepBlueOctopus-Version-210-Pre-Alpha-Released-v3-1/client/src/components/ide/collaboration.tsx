import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Users, 
  Share2, 
  Video, 
  Mic, 
  MessageSquare, 
  Screen, 
  UserPlus, 
  Settings, 
  Clock, 
  Eye, 
  Edit,
  Send,
  Phone,
  PhoneOff,
  MicOff,
  VideoOff,
  ScreenShare,
  ScreenShareOff,
  Volume2,
  VolumeX,
  Copy,
  Link,
  Globe,
  Lock,
  Unlock,
  Star,
  MoreHorizontal,
  Activity,
  Download,
  RefreshCw
} from "lucide-react";

interface CollaborationProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Collaborator {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: 'owner' | 'editor' | 'viewer';
  status: 'online' | 'away' | 'offline';
  lastActivity: string;
  currentFile?: string;
  cursor?: {
    line: number;
    column: number;
  };
}

interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  message: string;
  timestamp: string;
  type: 'message' | 'system' | 'file-share';
}

interface ShareLink {
  id: string;
  url: string;
  permissions: 'view' | 'edit' | 'admin';
  expiresAt?: string;
  isPublic: boolean;
  uses: number;
  maxUses?: number;
}

export default function Collaboration({ isOpen, onClose }: CollaborationProps) {
  const [activeTab, setActiveTab] = useState("session");
  const [chatMessage, setChatMessage] = useState("");
  const [shareUrl, setShareUrl] = useState("");
  const [inviteEmail, setInviteEmail] = useState("");
  const [videoCallActive, setVideoCallActive] = useState(false);
  const [micMuted, setMicMuted] = useState(false);
  const [videoMuted, setVideoMuted] = useState(false);
  const [screenSharing, setScreenSharing] = useState(false);

  const [collaborators] = useState<Collaborator[]>([
    {
      id: "1",
      name: "Alice Johnson",
      email: "alice@example.com",
      avatar: "/avatars/alice.jpg",
      role: "owner",
      status: "online",
      lastActivity: "Just now",
      currentFile: "main.tsx",
      cursor: { line: 45, column: 12 }
    },
    {
      id: "2",
      name: "Bob Smith",
      email: "bob@example.com", 
      avatar: "/avatars/bob.jpg",
      role: "editor",
      status: "online",
      lastActivity: "2 minutes ago",
      currentFile: "components/ui/button.tsx",
      cursor: { line: 23, column: 8 }
    },
    {
      id: "3",
      name: "Carol Davis",
      email: "carol@example.com",
      avatar: "/avatars/carol.jpg",
      role: "viewer",
      status: "away",
      lastActivity: "15 minutes ago"
    },
    {
      id: "4",
      name: "David Wilson",
      email: "david@example.com",
      avatar: "/avatars/david.jpg",
      role: "editor",
      status: "offline",
      lastActivity: "1 hour ago"
    }
  ]);

  const [chatMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      userId: "2",
      userName: "Bob Smith",
      message: "Hey everyone! I've finished the button component. Can someone review it?",
      timestamp: "16:05:23",
      type: "message"
    },
    {
      id: "2",
      userId: "system",
      userName: "System",
      message: "Carol Davis joined the session",
      timestamp: "16:03:15",
      type: "system"
    },
    {
      id: "3",
      userId: "1",
      userName: "Alice Johnson",
      message: "Great work on the styling! The animations look smooth.",
      timestamp: "16:02:10",
      type: "message"
    },
    {
      id: "4",
      userId: "2",
      userName: "Bob Smith",
      message: "Thanks! I also shared the design file in the project folder.",
      timestamp: "16:01:45",
      type: "file-share"
    }
  ]);

  const [shareLinks] = useState<ShareLink[]>([
    {
      id: "1",
      url: "https://deepblue.dev/share/abc123",
      permissions: "edit",
      expiresAt: "2025-01-08",
      isPublic: false,
      uses: 3,
      maxUses: 10
    },
    {
      id: "2",
      url: "https://deepblue.dev/share/xyz789",
      permissions: "view",
      isPublic: true,
      uses: 15
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online": return "bg-green-500";
      case "away": return "bg-yellow-500";
      case "offline": return "bg-gray-500";
      default: return "bg-gray-500";
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case "owner": return "bg-purple-500/20 text-purple-300";
      case "editor": return "bg-blue-500/20 text-blue-300";
      case "viewer": return "bg-gray-500/20 text-gray-300";
      default: return "bg-gray-500/20 text-gray-300";
    }
  };

  const sendChatMessage = () => {
    if (!chatMessage.trim()) return;
    console.log("Sending message:", chatMessage);
    setChatMessage("");
  };

  const inviteCollaborator = () => {
    if (!inviteEmail.trim()) return;
    console.log("Inviting collaborator:", inviteEmail);
    setInviteEmail("");
  };

  const toggleVideoCall = () => {
    setVideoCallActive(!videoCallActive);
    console.log("Video call:", !videoCallActive ? "started" : "ended");
  };

  const toggleMic = () => {
    setMicMuted(!micMuted);
    console.log("Microphone:", !micMuted ? "muted" : "unmuted");
  };

  const toggleVideo = () => {
    setVideoMuted(!videoMuted);
    console.log("Video:", !videoMuted ? "disabled" : "enabled");
  };

  const toggleScreenShare = () => {
    setScreenSharing(!screenSharing);
    console.log("Screen sharing:", !screenSharing ? "started" : "stopped");
  };

  const copyShareLink = (url: string) => {
    navigator.clipboard.writeText(url);
    console.log("Copied share link:", url);
  };

  const createShareLink = (permissions: string) => {
    console.log("Creating share link with permissions:", permissions);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-blue-500" />
            Real-Time Collaboration
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="grid grid-cols-5 w-full flex-shrink-0">
            <TabsTrigger value="session">Live Session</TabsTrigger>
            <TabsTrigger value="chat">Chat</TabsTrigger>
            <TabsTrigger value="video">Video Call</TabsTrigger>
            <TabsTrigger value="sharing">Share & Invite</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="session" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              {/* Active Collaborators */}
              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">Active Collaborators</CardTitle>
                      <CardDescription>
                        {collaborators.filter(c => c.status === 'online').length} online of {collaborators.length} total
                      </CardDescription>
                    </div>
                    <Button size="sm" variant="outline">
                      <UserPlus className="h-4 w-4 mr-1" />
                      Invite
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden">
                  <ScrollArea className="h-full">
                    <div className="space-y-3">
                      {collaborators.map((collaborator) => (
                        <div key={collaborator.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-accent/50 border">
                          <div className="relative">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={collaborator.avatar} alt={collaborator.name} />
                              <AvatarFallback>
                                {collaborator.name.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-background ${getStatusColor(collaborator.status)}`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-medium truncate">{collaborator.name}</span>
                              <Badge className={getRoleColor(collaborator.role)}>{collaborator.role}</Badge>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {collaborator.currentFile ? (
                                <div className="flex items-center gap-1">
                                  <Edit className="h-3 w-3" />
                                  <span className="truncate">{collaborator.currentFile}</span>
                                  {collaborator.cursor && (
                                    <span className="text-xs">:{collaborator.cursor.line}:{collaborator.cursor.column}</span>
                                  )}
                                </div>
                              ) : (
                                <div className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  {collaborator.lastActivity}
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-1">
                            {collaborator.status === 'online' && (
                              <Button size="sm" variant="ghost">
                                <Video className="h-4 w-4" />
                              </Button>
                            )}
                            <Button size="sm" variant="ghost">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Session Activity */}
              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <CardTitle className="text-base">Session Activity</CardTitle>
                  <CardDescription>Real-time collaboration events</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden">
                  <ScrollArea className="h-full">
                    <div className="space-y-3">
                      <div className="flex items-start gap-3 p-2 rounded">
                        <Activity className="h-4 w-4 text-green-400 mt-1" />
                        <div className="flex-1">
                          <div className="text-sm">
                            <span className="font-medium">Bob Smith</span> edited{" "}
                            <span className="text-blue-400">components/ui/button.tsx</span>
                          </div>
                          <div className="text-xs text-muted-foreground">2 minutes ago</div>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3 p-2 rounded">
                        <Users className="h-4 w-4 text-blue-400 mt-1" />
                        <div className="flex-1">
                          <div className="text-sm">
                            <span className="font-medium">Carol Davis</span> joined the session
                          </div>
                          <div className="text-xs text-muted-foreground">15 minutes ago</div>
                        </div>
                      </div>

                      <div className="flex items-start gap-3 p-2 rounded">
                        <Video className="h-4 w-4 text-purple-400 mt-1" />
                        <div className="flex-1">
                          <div className="text-sm">
                            <span className="font-medium">Alice Johnson</span> started screen sharing
                          </div>
                          <div className="text-xs text-muted-foreground">20 minutes ago</div>
                        </div>
                      </div>

                      <div className="flex items-start gap-3 p-2 rounded">
                        <Download className="h-4 w-4 text-yellow-400 mt-1" />
                        <div className="flex-1">
                          <div className="text-sm">
                            <span className="font-medium">Bob Smith</span> shared{" "}
                            <span className="text-blue-400">design-assets.zip</span>
                          </div>
                          <div className="text-xs text-muted-foreground">35 minutes ago</div>
                        </div>
                      </div>

                      <div className="flex items-start gap-3 p-2 rounded">
                        <RefreshCw className="h-4 w-4 text-green-400 mt-1" />
                        <div className="flex-1">
                          <div className="text-sm">
                            Session started by <span className="font-medium">Alice Johnson</span>
                          </div>
                          <div className="text-xs text-muted-foreground">1 hour ago</div>
                        </div>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="chat" className="flex-1 overflow-hidden">
            <Card className="h-full flex flex-col">
              <CardHeader className="flex-shrink-0">
                <CardTitle className="text-base">Team Chat</CardTitle>
                <CardDescription>Communicate with your team in real-time</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 overflow-hidden flex flex-col">
                {/* Chat Messages */}
                <ScrollArea className="flex-1 mb-4">
                  <div className="space-y-3">
                    {chatMessages.map((message) => (
                      <div key={message.id} className={`flex gap-3 ${message.type === 'system' ? 'justify-center' : ''}`}>
                        {message.type !== 'system' && (
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="text-xs">
                              {message.userName.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                        )}
                        <div className={`flex-1 ${message.type === 'system' ? 'text-center' : ''}`}>
                          {message.type === 'system' ? (
                            <div className="text-xs text-muted-foreground bg-muted/50 rounded px-3 py-1 inline-block">
                              {message.message}
                            </div>
                          ) : (
                            <>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium text-sm">{message.userName}</span>
                                <span className="text-xs text-muted-foreground">{message.timestamp}</span>
                                {message.type === 'file-share' && (
                                  <Badge variant="outline" className="text-xs">File</Badge>
                                )}
                              </div>
                              <div className="text-sm bg-muted/30 rounded p-2">
                                {message.message}
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                {/* Chat Input */}
                <div className="flex gap-2">
                  <Input
                    placeholder="Type a message..."
                    value={chatMessage}
                    onChange={(e) => setChatMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && sendChatMessage()}
                    className="flex-1"
                  />
                  <Button onClick={sendChatMessage} disabled={!chatMessage.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="video" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              {/* Video Call Interface */}
              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <CardTitle className="text-base">Video Conference</CardTitle>
                  <CardDescription>
                    {videoCallActive ? "Call in progress" : "Start a video call with your team"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  {videoCallActive ? (
                    <div className="flex-1 bg-gray-900 rounded-lg flex items-center justify-center mb-4">
                      <div className="text-center text-white">
                        <Video className="h-12 w-12 mx-auto mb-2" />
                        <p>Video call active</p>
                        <p className="text-sm text-gray-400">
                          {collaborators.filter(c => c.status === 'online').length} participants
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1 bg-muted/20 rounded-lg flex items-center justify-center mb-4 border-2 border-dashed border-muted">
                      <div className="text-center text-muted-foreground">
                        <Video className="h-12 w-12 mx-auto mb-2" />
                        <p>No active video call</p>
                      </div>
                    </div>
                  )}

                  {/* Call Controls */}
                  <div className="flex items-center justify-center gap-2">
                    <Button
                      variant={videoCallActive ? "destructive" : "default"}
                      onClick={toggleVideoCall}
                    >
                      {videoCallActive ? (
                        <>
                          <PhoneOff className="h-4 w-4 mr-2" />
                          End Call
                        </>
                      ) : (
                        <>
                          <Phone className="h-4 w-4 mr-2" />
                          Start Call
                        </>
                      )}
                    </Button>
                    
                    {videoCallActive && (
                      <>
                        <Button
                          variant={micMuted ? "destructive" : "outline"}
                          size="sm"
                          onClick={toggleMic}
                        >
                          {micMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                        </Button>
                        
                        <Button
                          variant={videoMuted ? "destructive" : "outline"}
                          size="sm"
                          onClick={toggleVideo}
                        >
                          {videoMuted ? <VideoOff className="h-4 w-4" /> : <Video className="h-4 w-4" />}
                        </Button>
                        
                        <Button
                          variant={screenSharing ? "default" : "outline"}
                          size="sm"
                          onClick={toggleScreenShare}
                        >
                          {screenSharing ? <ScreenShareOff className="h-4 w-4" /> : <ScreenShare className="h-4 w-4" />}
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Participants */}
              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <CardTitle className="text-base">Call Participants</CardTitle>
                  <CardDescription>Manage video call participants</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden">
                  <ScrollArea className="h-full">
                    <div className="space-y-2">
                      {collaborators.filter(c => c.status === 'online').map((collaborator) => (
                        <div key={collaborator.id} className="flex items-center gap-3 p-2 rounded hover:bg-accent/50">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback>
                              {collaborator.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="font-medium text-sm">{collaborator.name}</div>
                            <div className="text-xs text-muted-foreground">{collaborator.role}</div>
                          </div>
                          <div className="flex items-center gap-1">
                            <Mic className="h-3 w-3 text-green-400" />
                            <Video className="h-3 w-3 text-blue-400" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="sharing" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              {/* Invite Collaborators */}
              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <CardTitle className="text-base">Invite Collaborators</CardTitle>
                  <CardDescription>Add team members to this project</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Email Address</label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Enter email address..."
                        value={inviteEmail}
                        onChange={(e) => setInviteEmail(e.target.value)}
                        className="flex-1"
                      />
                      <Button onClick={inviteCollaborator} disabled={!inviteEmail.trim()}>
                        <UserPlus className="h-4 w-4 mr-1" />
                        Invite
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Permission Level</label>
                    <Select defaultValue="editor">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="viewer">Viewer - Can view only</SelectItem>
                        <SelectItem value="editor">Editor - Can edit and comment</SelectItem>
                        <SelectItem value="admin">Admin - Full access</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <h4 className="font-medium">Quick Share</h4>
                    <div className="space-y-2">
                      <Button 
                        variant="outline" 
                        className="w-full justify-start" 
                        onClick={() => createShareLink('view')}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Create View-Only Link
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={() => createShareLink('edit')}
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Create Editor Link
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Share Links */}
              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <CardTitle className="text-base">Active Share Links</CardTitle>
                  <CardDescription>Manage project share links</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden">
                  <ScrollArea className="h-full">
                    <div className="space-y-3">
                      {shareLinks.map((link) => (
                        <div key={link.id} className="p-3 border rounded">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {link.isPublic ? (
                                <Globe className="h-4 w-4 text-blue-400" />
                              ) : (
                                <Lock className="h-4 w-4 text-gray-400" />
                              )}
                              <Badge variant="outline" className="text-xs">
                                {link.permissions}
                              </Badge>
                            </div>
                            <Button size="sm" variant="ghost" onClick={() => copyShareLink(link.url)}>
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                          
                          <div className="text-sm text-muted-foreground space-y-1">
                            <div className="font-mono bg-muted/50 p-2 rounded text-xs truncate">
                              {link.url}
                            </div>
                            <div className="flex items-center justify-between text-xs">
                              <span>Uses: {link.uses}{link.maxUses ? `/${link.maxUses}` : ''}</span>
                              {link.expiresAt && <span>Expires: {link.expiresAt}</span>}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="flex-1 overflow-hidden">
            <ScrollArea className="h-full">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Collaboration Preferences</CardTitle>
                    <CardDescription>Configure how collaboration features work</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Show live cursors</span>
                        <p className="text-sm text-muted-foreground">Display other users' cursors in real-time</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Auto-save changes</span>
                        <p className="text-sm text-muted-foreground">Automatically save changes when collaborating</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Show activity notifications</span>
                        <p className="text-sm text-muted-foreground">Get notified when others join or make changes</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Video & Audio Settings</CardTitle>
                    <CardDescription>Configure video call preferences</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Default audio input</label>
                      <Select defaultValue="default">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="default">Default - Built-in Microphone</SelectItem>
                          <SelectItem value="usb">USB Headset</SelectItem>
                          <SelectItem value="bluetooth">Bluetooth Device</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Video quality</label>
                      <Select defaultValue="hd">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sd">SD (480p)</SelectItem>
                          <SelectItem value="hd">HD (720p)</SelectItem>
                          <SelectItem value="fhd">Full HD (1080p)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Auto-mute when joining</span>
                        <p className="text-sm text-muted-foreground">Start with microphone muted</p>
                      </div>
                      <Switch />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Privacy & Security</CardTitle>
                    <CardDescription>Manage privacy and security settings</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Require authentication for sharing</span>
                        <p className="text-sm text-muted-foreground">Users must sign in to access shared content</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Default link expiration</label>
                      <Select defaultValue="7days">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1day">1 day</SelectItem>
                          <SelectItem value="7days">7 days</SelectItem>
                          <SelectItem value="30days">30 days</SelectItem>
                          <SelectItem value="never">Never expire</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}