import { useState, useRef, useEffect } from "react";
import * as monaco from "monaco-editor";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  MousePointer2, 
  Type, 
  Highlighter, 
  Search, 
  Replace,
  RotateCcw,
  RotateCw,
  Copy,
  Scissors,
  Clipboard
} from "lucide-react";

interface MultiCursorEditorProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MultiCursorEditor({ isOpen, onClose }: MultiCursorEditorProps) {
  const [cursors, setCursors] = useState<Array<{id: number, line: number, column: number}>>([]);
  const [selections, setSelections] = useState<Array<{id: number, startLine: number, startColumn: number, endLine: number, endColumn: number}>>([]);
  const [findText, setFindText] = useState("");
  const [replaceText, setReplaceText] = useState("");
  const [caseSensitive, setCaseSensitive] = useState(false);
  const [wholeWord, setWholeWord] = useState(false);
  const [useRegex, setUseRegex] = useState(false);
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const multiCursorFeatures = [
    { 
      name: "Add Cursor Above", 
      shortcut: "Ctrl+Alt+↑", 
      icon: <MousePointer2 className="w-4 h-4" />,
      action: () => addCursorAbove()
    },
    { 
      name: "Add Cursor Below", 
      shortcut: "Ctrl+Alt+↓", 
      icon: <MousePointer2 className="w-4 h-4" />,
      action: () => addCursorBelow()
    },
    { 
      name: "Select All Occurrences", 
      shortcut: "Ctrl+Shift+L", 
      icon: <Highlighter className="w-4 h-4" />,
      action: () => selectAllOccurrences()
    },
    { 
      name: "Add Selection to Next Find Match", 
      shortcut: "Ctrl+D", 
      icon: <Search className="w-4 h-4" />,
      action: () => addSelectionToNextMatch()
    },
    { 
      name: "Column Selection Mode", 
      shortcut: "Shift+Alt+Drag", 
      icon: <Type className="w-4 h-4" />,
      action: () => toggleColumnSelection()
    }
  ];

  const editingActions = [
    { 
      name: "Duplicate Line", 
      shortcut: "Shift+Alt+↓", 
      icon: <Copy className="w-4 h-4" />,
      action: () => duplicateLines()
    },
    { 
      name: "Move Line Up", 
      shortcut: "Alt+↑", 
      icon: <RotateCcw className="w-4 h-4" />,
      action: () => moveLinesUp()
    },
    { 
      name: "Move Line Down", 
      shortcut: "Alt+↓", 
      icon: <RotateCw className="w-4 h-4" />,
      action: () => moveLinesDown()
    },
    { 
      name: "Delete Line", 
      shortcut: "Ctrl+Shift+K", 
      icon: <Scissors className="w-4 h-4" />,
      action: () => deleteLines()
    },
    { 
      name: "Copy Lines", 
      shortcut: "Ctrl+C", 
      icon: <Clipboard className="w-4 h-4" />,
      action: () => copyLines()
    }
  ];

  useEffect(() => {
    if (isOpen && containerRef.current) {
      initializeEditor();
    }
    return () => {
      if (editorRef.current) {
        editorRef.current.dispose();
      }
    };
  }, [isOpen]);

  const initializeEditor = () => {
    if (containerRef.current) {
      editorRef.current = monaco.editor.create(containerRef.current, {
        value: `// Multi-cursor editing demonstration
function example() {
  const item1 = "first";
  const item2 = "second";  
  const item3 = "third";
  
  console.log(item1);
  console.log(item2);
  console.log(item3);
  
  return [item1, item2, item3];
}

// Try these multi-cursor operations:
// 1. Place cursor on "item" and press Ctrl+D to select next occurrence
// 2. Use Ctrl+Alt+↓ to add cursor below
// 3. Hold Alt and click to place multiple cursors
// 4. Select text and press Ctrl+Shift+L to select all occurrences`,
        language: 'javascript',
        theme: 'vs-dark',
        fontSize: 14,
        lineNumbers: 'on',
        minimap: { enabled: true },
        wordWrap: 'on',
        multiCursorModifier: 'alt',
        multiCursorMergeOverlapping: true,
        selectionHighlight: true,
        occurrencesHighlight: true,
      });

      // Add event listeners for cursor changes
      editorRef.current.onDidChangeCursorSelection(() => {
        updateCursorsAndSelections();
      });

      editorRef.current.onDidChangeCursorPosition(() => {
        updateCursorsAndSelections();
      });
    }
  };

  const updateCursorsAndSelections = () => {
    if (!editorRef.current) return;

    const selections = editorRef.current.getSelections();
    if (selections) {
      const newCursors = selections.map((selection, index) => ({
        id: index,
        line: selection.positionLineNumber,
        column: selection.positionColumn
      }));
      setCursors(newCursors);

      const newSelections = selections.map((selection, index) => ({
        id: index,
        startLine: selection.startLineNumber,
        startColumn: selection.startColumn,
        endLine: selection.endLineNumber,
        endColumn: selection.endColumn
      }));
      setSelections(newSelections);
    }
  };

  const addCursorAbove = () => {
    if (editorRef.current) {
      editorRef.current.trigger('keyboard', 'editor.action.insertCursorAbove', {});
    }
  };

  const addCursorBelow = () => {
    if (editorRef.current) {
      editorRef.current.trigger('keyboard', 'editor.action.insertCursorBelow', {});
    }
  };

  const selectAllOccurrences = () => {
    if (editorRef.current) {
      editorRef.current.trigger('keyboard', 'editor.action.selectHighlights', {});
    }
  };

  const addSelectionToNextMatch = () => {
    if (editorRef.current) {
      editorRef.current.trigger('keyboard', 'editor.action.addSelectionToNextFindMatch', {});
    }
  };

  const toggleColumnSelection = () => {
    if (editorRef.current) {
      editorRef.current.trigger('keyboard', 'editor.action.columnSelect', {});
    }
  };

  const duplicateLines = () => {
    if (editorRef.current) {
      editorRef.current.trigger('keyboard', 'editor.action.copyLinesDownAction', {});
    }
  };

  const moveLinesUp = () => {
    if (editorRef.current) {
      editorRef.current.trigger('keyboard', 'editor.action.moveLinesUpAction', {});
    }
  };

  const moveLinesDown = () => {
    if (editorRef.current) {
      editorRef.current.trigger('keyboard', 'editor.action.moveLinesDownAction', {});
    }
  };

  const deleteLines = () => {
    if (editorRef.current) {
      editorRef.current.trigger('keyboard', 'editor.action.deleteLines', {});
    }
  };

  const copyLines = () => {
    if (editorRef.current) {
      editorRef.current.trigger('keyboard', 'editor.action.clipboardCopyAction', {});
    }
  };

  const performFindReplace = () => {
    if (editorRef.current && findText) {
      const model = editorRef.current.getModel();
      if (model) {
        const matches = model.findMatches(
          findText,
          true,
          useRegex,
          caseSensitive,
          wholeWord ? '\\b' : null,
          false
        );
        
        if (matches.length > 0) {
          const selections = matches.map(match => match.range);
          editorRef.current.setSelections(selections);
          
          if (replaceText) {
            editorRef.current.executeEdits('replace-all', 
              matches.map(match => ({
                range: match.range,
                text: replaceText
              }))
            );
          }
        }
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-900 border border-gray-700 rounded-lg w-[95vw] h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <MousePointer2 className="w-6 h-6 text-blue-400" />
            <div>
              <h2 className="text-lg font-semibold text-white">Multi-Cursor Editor</h2>
              <p className="text-sm text-gray-400">Advanced text editing with multiple cursors</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            ✕
          </Button>
        </div>

        {/* Content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Editor Panel */}
          <div className="flex-1 flex flex-col">
            {/* Toolbar */}
            <div className="flex items-center justify-between p-3 bg-gray-800 border-b border-gray-700">
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{cursors.length} Cursor{cursors.length !== 1 ? 's' : ''}</Badge>
                <Badge variant="secondary">{selections.length} Selection{selections.length !== 1 ? 's' : ''}</Badge>
              </div>
              
              {/* Find/Replace */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Find..."
                  value={findText}
                  onChange={(e) => setFindText(e.target.value)}
                  className="px-3 py-1 bg-gray-700 border border-gray-600 rounded text-sm text-white w-32"
                />
                <input
                  type="text"
                  placeholder="Replace..."
                  value={replaceText}
                  onChange={(e) => setReplaceText(e.target.value)}
                  className="px-3 py-1 bg-gray-700 border border-gray-600 rounded text-sm text-white w-32"
                />
                <Button size="sm" onClick={performFindReplace}>
                  <Replace className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Editor */}
            <div ref={containerRef} className="flex-1" />
          </div>

          {/* Controls Panel */}
          <div className="w-80 bg-gray-800 border-l border-gray-700 flex flex-col">
            <div className="p-4">
              <h3 className="text-sm font-semibold text-white mb-3">Multi-Cursor Controls</h3>
              
              <ScrollArea className="h-96">
                <div className="space-y-3">
                  {multiCursorFeatures.map((feature, index) => (
                    <div key={index} className="space-y-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={feature.action}
                        className="w-full justify-start text-left"
                      >
                        {feature.icon}
                        <span className="ml-2">{feature.name}</span>
                      </Button>
                      <p className="text-xs text-gray-400 ml-6">{feature.shortcut}</p>
                    </div>
                  ))}
                  
                  <Separator className="my-4" />
                  
                  <h4 className="text-sm font-semibold text-white mb-2">Line Operations</h4>
                  {editingActions.map((action, index) => (
                    <div key={index} className="space-y-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={action.action}
                        className="w-full justify-start text-left"
                      >
                        {action.icon}
                        <span className="ml-2">{action.name}</span>
                      </Button>
                      <p className="text-xs text-gray-400 ml-6">{action.shortcut}</p>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>

            {/* Status */}
            <div className="p-4 border-t border-gray-700">
              <h4 className="text-sm font-semibold text-white mb-2">Cursor Status</h4>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {cursors.map((cursor) => (
                  <div key={cursor.id} className="text-xs text-gray-400">
                    Cursor {cursor.id + 1}: Line {cursor.line}, Col {cursor.column}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}