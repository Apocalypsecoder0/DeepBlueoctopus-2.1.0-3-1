import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { 
  Smartphone, Tablet, Monitor, Code, Package, Download,
  Play, Settings, Eye, FileText, Zap, Users,
  Bot, Wifi, Globe, Cpu, Database, Shield
} from "lucide-react";

interface MobileFrameworkProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Framework {
  id: string;
  name: string;
  description: string;
  platforms: string[];
  languages: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  popularity: number;
  features: string[];
}

export default function MobileFramework({ isOpen, onClose }: MobileFrameworkProps) {
  const [activeTab, setActiveTab] = useState("frameworks");
  const [selectedFramework, setSelectedFramework] = useState<string>("");
  const [projectName, setProjectName] = useState("");
  const [targetPlatforms, setTargetPlatforms] = useState<string[]>([]);

  const frameworks: Framework[] = [
    {
      id: "react-native",
      name: "React Native",
      description: "Build native mobile apps using React and JavaScript",
      platforms: ["iOS", "Android"],
      languages: ["JavaScript", "TypeScript"],
      difficulty: "intermediate",
      popularity: 95,
      features: ["Cross-platform", "Hot Reload", "Native Performance", "Large Community"]
    },
    {
      id: "flutter",
      name: "Flutter",
      description: "Google's UI toolkit for building natively compiled applications",
      platforms: ["iOS", "Android", "Web", "Desktop"],
      languages: ["Dart"],
      difficulty: "intermediate",
      popularity: 90,
      features: ["Single Codebase", "Fast Development", "Expressive UI", "Native Performance"]
    },
    {
      id: "ionic",
      name: "Ionic",
      description: "Build cross-platform mobile apps with web technologies",
      platforms: ["iOS", "Android", "Web", "Desktop"],
      languages: ["HTML", "CSS", "JavaScript", "TypeScript"],
      difficulty: "beginner",
      popularity: 75,
      features: ["Web Technologies", "PWA Support", "Native Plugins", "Easy Learning"]
    },
    {
      id: "xamarin",
      name: "Xamarin",
      description: "Microsoft's framework for cross-platform mobile development",
      platforms: ["iOS", "Android", "Windows"],
      languages: ["C#", ".NET"],
      difficulty: "advanced",
      popularity: 65,
      features: ["Native API Access", "Code Sharing", "Enterprise Ready", "Visual Studio Integration"]
    },
    {
      id: "cordova",
      name: "Apache Cordova",
      description: "Platform for building native mobile apps using HTML, CSS and JavaScript",
      platforms: ["iOS", "Android", "Windows"],
      languages: ["HTML", "CSS", "JavaScript"],
      difficulty: "beginner",
      popularity: 60,
      features: ["Plugin Ecosystem", "Web Technologies", "Cross-platform", "Open Source"]
    },
    {
      id: "native-script",
      name: "NativeScript",
      description: "Open source framework for building truly native mobile apps",
      platforms: ["iOS", "Android"],
      languages: ["JavaScript", "TypeScript", "Angular", "Vue"],
      difficulty: "intermediate",
      popularity: 55,
      features: ["Direct API Access", "Native UI", "Angular/Vue Support", "Code Sharing"]
    }
  ];

  const templates = [
    {
      name: "Social Media App",
      description: "Complete social media application with user authentication, posts, and messaging",
      framework: "react-native",
      features: ["User Registration", "Photo Sharing", "Real-time Chat", "Push Notifications"]
    },
    {
      name: "E-Commerce Store",
      description: "Mobile shopping app with product catalog, cart, and payment integration",
      framework: "flutter",
      features: ["Product Catalog", "Shopping Cart", "Payment Gateway", "Order Tracking"]
    },
    {
      name: "News Reader",
      description: "News aggregation app with offline reading and personalization",
      framework: "ionic",
      features: ["Article Feed", "Offline Reading", "Bookmarks", "Category Filters"]
    },
    {
      name: "Fitness Tracker",
      description: "Health and fitness app with workout tracking and progress monitoring",
      framework: "xamarin",
      features: ["Workout Logging", "Progress Charts", "Goal Setting", "Health Integration"]
    }
  ];

  const selectedFrameworkData = frameworks.find(f => f.id === selectedFramework);

  const generateProject = () => {
    if (!selectedFramework || !projectName) return;
    
    // Mock project generation
    console.log(`Generating ${selectedFramework} project: ${projectName}`);
    alert(`Project "${projectName}" created successfully with ${selectedFrameworkData?.name}!`);
  };

  const deployToDevice = () => {
    if (!selectedFramework) return;
    
    console.log(`Deploying to device with ${selectedFramework}`);
    alert("Deployment started! Check the terminal for progress.");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl w-full h-[85vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Smartphone className="h-5 w-5" />
            Mobile Application Framework
          </DialogTitle>
          <DialogDescription>
            Professional mobile app development with React Native, Flutter, Ionic, and more
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="frameworks">Frameworks</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="development">Development</TabsTrigger>
            <TabsTrigger value="testing">Testing</TabsTrigger>
            <TabsTrigger value="deployment">Deployment</TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-auto">
            <TabsContent value="frameworks" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {frameworks.map((framework) => (
                  <Card 
                    key={framework.id} 
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      selectedFramework === framework.id ? 'ring-2 ring-blue-500' : ''
                    }`}
                    onClick={() => setSelectedFramework(framework.id)}
                  >
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{framework.name}</CardTitle>
                        <Badge variant={framework.difficulty === 'beginner' ? 'default' : 
                                framework.difficulty === 'intermediate' ? 'secondary' : 'destructive'}>
                          {framework.difficulty}
                        </Badge>
                      </div>
                      <CardDescription>{framework.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm font-medium">Platforms</Label>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {framework.platforms.map((platform) => (
                              <Badge key={platform} variant="outline" className="text-xs">
                                {platform}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <Label className="text-sm font-medium">Languages</Label>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {framework.languages.map((lang) => (
                              <Badge key={lang} variant="secondary" className="text-xs">
                                {lang}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <Label className="text-sm font-medium">Popularity</Label>
                          <Progress value={framework.popularity} className="mt-1" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {selectedFrameworkData && (
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Selected: {selectedFrameworkData.name}</CardTitle>
                    <CardDescription>Framework Details & Features</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold mb-2">Key Features</h4>
                        <ul className="space-y-1">
                          {selectedFrameworkData.features.map((feature, index) => (
                            <li key={index} className="flex items-center gap-2 text-sm">
                              <Zap className="h-3 w-3 text-green-500" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="project-name">Project Name</Label>
                          <Input
                            id="project-name"
                            value={projectName}
                            onChange={(e) => setProjectName(e.target.value)}
                            placeholder="Enter project name"
                            className="mt-1"
                          />
                        </div>
                        
                        <Button 
                          onClick={generateProject}
                          disabled={!projectName}
                          className="w-full"
                        >
                          <Package className="h-4 w-4 mr-2" />
                          Create Project
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="templates" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {templates.map((template, index) => (
                  <Card key={index} className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{template.name}</CardTitle>
                        <Badge variant="outline">
                          {frameworks.find(f => f.id === template.framework)?.name}
                        </Badge>
                      </div>
                      <CardDescription>{template.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm font-medium">Included Features</Label>
                          <ul className="mt-1 space-y-1">
                            {template.features.map((feature, idx) => (
                              <li key={idx} className="flex items-center gap-2 text-sm">
                                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                                {feature}
                              </li>
                            ))}
                          </ul>
                        </div>
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={() => {
                            setSelectedFramework(template.framework);
                            setActiveTab("frameworks");
                          }}
                        >
                          Use Template
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="development" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Code className="h-5 w-5" />
                      Development Tools
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <Eye className="h-4 w-4 mr-2" />
                      Live Preview
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Zap className="h-4 w-4 mr-2" />
                      Hot Reload
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="h-4 w-4 mr-2" />
                      Code Generator
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Settings className="h-4 w-4 mr-2" />
                      Project Settings
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Database className="h-5 w-5" />
                      Backend Integration
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="firebase">Firebase</Label>
                      <Switch id="firebase" />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="aws">AWS Amplify</Label>
                      <Switch id="aws" />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="supabase">Supabase</Label>
                      <Switch id="supabase" />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="api">Custom API</Label>
                      <Switch id="api" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Device Emulator</CardTitle>
                  <CardDescription>Test your app on different devices and screen sizes</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4">
                    <Button variant="outline" className="flex-1">
                      <Smartphone className="h-4 w-4 mr-2" />
                      Phone Preview
                    </Button>
                    <Button variant="outline" className="flex-1">
                      <Tablet className="h-4 w-4 mr-2" />
                      Tablet Preview
                    </Button>
                    <Button variant="outline" className="flex-1">
                      <Monitor className="h-4 w-4 mr-2" />
                      Desktop Preview
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="testing" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Unit Testing</CardTitle>
                    <CardDescription>Test individual components and functions</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button variant="outline" className="w-full">
                      <Play className="h-4 w-4 mr-2" />
                      Run Unit Tests
                    </Button>
                    <div className="text-sm space-y-1">
                      <div className="flex justify-between">
                        <span>Test Coverage:</span>
                        <span className="font-semibold">85%</span>
                      </div>
                      <Progress value={85} />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Integration Testing</CardTitle>
                    <CardDescription>Test app functionality end-to-end</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button variant="outline" className="w-full">
                      <Users className="h-4 w-4 mr-2" />
                      Run E2E Tests
                    </Button>
                    <div className="text-sm space-y-1">
                      <div className="flex justify-between">
                        <span>Tests Passed:</span>
                        <span className="font-semibold text-green-600">23/25</span>
                      </div>
                      <Progress value={92} />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Device Testing</CardTitle>
                  <CardDescription>Test on real devices and simulators</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <Button variant="outline">
                      <Bot className="h-4 w-4 mr-2" />
                      Android Emulator
                    </Button>
                    <Button variant="outline">
                      <Wifi className="h-4 w-4 mr-2" />
                      iOS Simulator
                    </Button>
                    <Button variant="outline">
                      <Smartphone className="h-4 w-4 mr-2" />
                      Real Device
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="deployment" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>App Store Deployment</CardTitle>
                    <CardDescription>Deploy to official app stores</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button className="w-full">
                      <Wifi className="h-4 w-4 mr-2" />
                      Deploy to App Store
                    </Button>
                    <Button className="w-full">
                      <Bot className="h-4 w-4 mr-2" />
                      Deploy to Google Play
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Globe className="h-4 w-4 mr-2" />
                      Deploy as PWA
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Build Configuration</CardTitle>
                    <CardDescription>Configure build settings and environment</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <Label htmlFor="build-type">Build Type</Label>
                      <Select>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select build type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="debug">Debug</SelectItem>
                          <SelectItem value="release">Release</SelectItem>
                          <SelectItem value="production">Production</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="minify">Minify Code</Label>
                      <Switch id="minify" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="obfuscate">Code Obfuscation</Label>
                      <Switch id="obfuscate" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Performance Optimization</CardTitle>
                  <CardDescription>Optimize your app for better performance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <Button variant="outline">
                      <Cpu className="h-4 w-4 mr-2" />
                      Bundle Analyzer
                    </Button>
                    <Button variant="outline">
                      <Zap className="h-4 w-4 mr-2" />
                      Performance Profiler
                    </Button>
                    <Button variant="outline">
                      <Shield className="h-4 w-4 mr-2" />
                      Security Scan
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}