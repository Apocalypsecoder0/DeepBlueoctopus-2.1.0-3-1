import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import { SoundButton } from "@/components/ui/sound-system";
import { 
  X, 
  Save, 
  Download, 
  Upload, 
  Undo, 
  Redo, 
  Grid3X3, 
  Circle, 
  Square, 
  Triangle,
  Minus,
  Move,
  RotateCcw,
  Scale,
  Copy,
  Scissors,
  Eye,
  EyeOff,
  Layers,
  Ruler,
  Compass,
  Pen,
  Eraser,
  MousePointer2,
  Box,
  Cylinder,
  CircleDot,
  Cone,
  Zap,
  Settings,
  Palette,
  FileText,
  Printer,
  Share2,
  Archive,
  FolderOpen,
  Plus,
  Trash2,
  RotateCw,
  FlipHorizontal,
  FlipVertical,
  AlignLeft,
  AlignCenter,
  AlignRight
} from "lucide-react";

interface AutoCADBlueprintProps {
  isOpen: boolean;
  onClose: () => void;
}

interface DrawingElement {
  id: string;
  type: 'line' | 'circle' | 'rectangle' | 'triangle' | 'text' | 'dimension' | 'arc' | 'polyline' | 'spline' | 'hatch' | 'block' | 'point';
  layer: string;
  properties: {
    x: number;
    y: number;
    z?: number;
    width?: number;
    height?: number;
    radius?: number;
    color: string;
    lineWeight: number;
    lineType: string;
    fillPattern?: string;
    text?: string;
    fontSize?: number;
    rotation?: number;
    scale?: number;
  };
  visible: boolean;
  locked: boolean;
}

interface Layer {
  id: string;
  name: string;
  color: string;
  visible: boolean;
  locked: boolean;
  lineWeight: number;
  lineType: string;
}

interface BlueprintProject {
  id: string;
  name: string;
  type: '1D' | '2D' | '3D';
  elements: DrawingElement[];
  layers: Layer[];
  units: 'mm' | 'cm' | 'm' | 'in' | 'ft';
  scale: number;
  gridSize: number;
  snapToGrid: boolean;
  created: Date;
  modified: Date;
}

export default function AutoCADBlueprintSystem({ isOpen, onClose }: AutoCADBlueprintProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [selectedTool, setSelectedTool] = useState('select');
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [currentProject, setCurrentProject] = useState<BlueprintProject | null>(null);
  const [projects, setProjects] = useState<BlueprintProject[]>([]);
  const [drawingMode, setDrawingMode] = useState<'1D' | '2D' | '3D'>('2D');
  const [gridVisible, setGridVisible] = useState(true);
  const [snapEnabled, setSnapEnabled] = useState(true);
  const [zoom, setZoom] = useState([100]);
  const [rotation, setRotation] = useState([0]);
  const [showLayers, setShowLayers] = useState(false);
  const [showProperties, setShowProperties] = useState(false);
  const [activeLayer, setActiveLayer] = useState('Layer1');
  const [exportFormat, setExportFormat] = useState('dwg');
  const [measurementMode, setMeasurementMode] = useState(false);
  const [annotations, setAnnotations] = useState<any[]>([]);

  const tools = {
    select: { icon: MousePointer2, name: 'Select', category: 'selection' },
    line: { icon: Minus, name: 'Line', category: 'draw' },
    circle: { icon: Circle, name: 'Circle', category: 'draw' },
    rectangle: { icon: Square, name: 'Rectangle', category: 'draw' },
    triangle: { icon: Triangle, name: 'Triangle', category: 'draw' },
    text: { icon: FileText, name: 'Text', category: 'annotation' },
    dimension: { icon: Ruler, name: 'Dimension', category: 'annotation' },
    arc: { icon: Compass, name: 'Arc', category: 'draw' },
    polyline: { icon: Pen, name: 'Polyline', category: 'draw' },
    move: { icon: Move, name: 'Move', category: 'modify' },
    rotate: { icon: RotateCcw, name: 'Rotate', category: 'modify' },
    scale: { icon: Scale, name: 'Scale', category: 'modify' },
    copy: { icon: Copy, name: 'Copy', category: 'modify' },
    erase: { icon: Eraser, name: 'Erase', category: 'modify' },
    // 3D Tools
    box: { icon: Box, name: 'Box', category: '3d' },
    cylinder: { icon: Cylinder, name: 'Cylinder', category: '3d' },
    sphere: { icon: CircleDot, name: 'Sphere', category: '3d' },
    cone: { icon: Cone, name: 'Cone', category: '3d' }
  };

  const lineTypes = ['Solid', 'Dashed', 'Dotted', 'DashDot', 'Center', 'Hidden', 'Phantom'];
  const units = ['mm', 'cm', 'm', 'in', 'ft'];
  const exportFormats = ['dwg', 'dxf', 'pdf', 'svg', 'png', 'jpg', 'step', 'iges'];

  useEffect(() => {
    if (isOpen && !currentProject) {
      createNewProject();
    }
  }, [isOpen]);

  useEffect(() => {
    if (canvasRef.current) {
      drawCanvas();
    }
  }, [currentProject, gridVisible, zoom, rotation, drawingMode]);

  const createNewProject = () => {
    const newProject: BlueprintProject = {
      id: `project-${Date.now()}`,
      name: `Blueprint ${projects.length + 1}`,
      type: drawingMode,
      elements: [],
      layers: [
        {
          id: 'layer1',
          name: 'Layer1',
          color: '#ffffff',
          visible: true,
          locked: false,
          lineWeight: 1,
          lineType: 'Solid'
        },
        {
          id: 'layer2',
          name: 'Dimensions',
          color: '#ffff00',
          visible: true,
          locked: false,
          lineWeight: 0.5,
          lineType: 'Solid'
        },
        {
          id: 'layer3',
          name: 'Construction',
          color: '#808080',
          visible: true,
          locked: false,
          lineWeight: 0.25,
          lineType: 'Dashed'
        }
      ],
      units: 'mm',
      scale: 1,
      gridSize: 10,
      snapToGrid: true,
      created: new Date(),
      modified: new Date()
    };

    setCurrentProject(newProject);
    setProjects(prev => [...prev, newProject]);
  };

  const drawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Set up coordinate system
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.scale(zoom[0] / 100, zoom[0] / 100);
    ctx.rotate((rotation[0] * Math.PI) / 180);

    // Draw grid
    if (gridVisible && currentProject) {
      drawGrid(ctx);
    }

    // Draw elements
    if (currentProject) {
      currentProject.elements.forEach(element => {
        if (element.visible) {
          drawElement(ctx, element);
        }
      });
    }

    // Draw coordinate system indicator
    drawCoordinateSystem(ctx);

    ctx.restore();
  };

  const drawGrid = (ctx: CanvasRenderingContext2D) => {
    if (!currentProject) return;

    const gridSize = currentProject.gridSize * (zoom[0] / 100);
    const canvasSize = 1000; // Large enough to cover rotated canvas

    ctx.strokeStyle = 'rgba(64, 224, 255, 0.2)';
    ctx.lineWidth = 0.5;

    // Vertical lines
    for (let x = -canvasSize; x <= canvasSize; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, -canvasSize);
      ctx.lineTo(x, canvasSize);
      ctx.stroke();
    }

    // Horizontal lines
    for (let y = -canvasSize; y <= canvasSize; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(-canvasSize, y);
      ctx.lineTo(canvasSize, y);
      ctx.stroke();
    }

    // Origin marker
    ctx.strokeStyle = 'rgba(64, 224, 255, 0.8)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-10, 0);
    ctx.lineTo(10, 0);
    ctx.moveTo(0, -10);
    ctx.lineTo(0, 10);
    ctx.stroke();
  };

  const drawElement = (ctx: CanvasRenderingContext2D, element: DrawingElement) => {
    const { properties } = element;
    
    ctx.strokeStyle = properties.color;
    ctx.lineWidth = properties.lineWeight;
    ctx.fillStyle = properties.color;

    // Set line dash pattern based on line type
    switch (properties.lineType) {
      case 'Dashed':
        ctx.setLineDash([10, 5]);
        break;
      case 'Dotted':
        ctx.setLineDash([2, 3]);
        break;
      case 'DashDot':
        ctx.setLineDash([10, 5, 2, 5]);
        break;
      default:
        ctx.setLineDash([]);
    }

    ctx.save();
    ctx.translate(properties.x, properties.y);
    if (properties.rotation) {
      ctx.rotate((properties.rotation * Math.PI) / 180);
    }
    if (properties.scale) {
      ctx.scale(properties.scale, properties.scale);
    }

    switch (element.type) {
      case 'line':
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(properties.width || 100, properties.height || 0);
        ctx.stroke();
        break;

      case 'circle':
        ctx.beginPath();
        ctx.arc(0, 0, properties.radius || 50, 0, 2 * Math.PI);
        ctx.stroke();
        if (properties.fillPattern) {
          ctx.fill();
        }
        break;

      case 'rectangle':
        const width = properties.width || 100;
        const height = properties.height || 60;
        ctx.beginPath();
        ctx.rect(-width/2, -height/2, width, height);
        ctx.stroke();
        if (properties.fillPattern) {
          ctx.fill();
        }
        break;

      case 'text':
        if (properties.text) {
          ctx.font = `${properties.fontSize || 12}px Arial`;
          ctx.fillText(properties.text, 0, 0);
        }
        break;

      case 'dimension':
        // Draw dimension line with arrows
        const dimLength = properties.width || 100;
        ctx.beginPath();
        ctx.moveTo(-dimLength/2, 0);
        ctx.lineTo(dimLength/2, 0);
        ctx.stroke();
        
        // Draw arrows
        ctx.beginPath();
        ctx.moveTo(-dimLength/2, 0);
        ctx.lineTo(-dimLength/2 + 10, -5);
        ctx.lineTo(-dimLength/2 + 10, 5);
        ctx.closePath();
        ctx.fill();
        
        ctx.beginPath();
        ctx.moveTo(dimLength/2, 0);
        ctx.lineTo(dimLength/2 - 10, -5);
        ctx.lineTo(dimLength/2 - 10, 5);
        ctx.closePath();
        ctx.fill();
        
        // Draw dimension text
        ctx.font = '12px Arial';
        ctx.fillText(`${dimLength}${currentProject?.units || 'mm'}`, 0, -15);
        break;
    }

    ctx.restore();
  };

  const drawCoordinateSystem = (ctx: CanvasRenderingContext2D) => {
    if (drawingMode === '3D') {
      ctx.strokeStyle = '#ff0000';
      ctx.lineWidth = 2;
      
      // X axis (red)
      ctx.beginPath();
      ctx.moveTo(-400, 350);
      ctx.lineTo(-350, 350);
      ctx.stroke();
      ctx.fillStyle = '#ff0000';
      ctx.fillText('X', -340, 345);
      
      // Y axis (green)
      ctx.strokeStyle = '#00ff00';
      ctx.beginPath();
      ctx.moveTo(-400, 350);
      ctx.lineTo(-400, 300);
      ctx.stroke();
      ctx.fillStyle = '#00ff00';
      ctx.fillText('Y', -405, 295);
      
      // Z axis (blue)
      ctx.strokeStyle = '#0000ff';
      ctx.beginPath();
      ctx.moveTo(-400, 350);
      ctx.lineTo(-375, 325);
      ctx.stroke();
      ctx.fillStyle = '#0000ff';
      ctx.fillText('Z', -370, 320);
    }
  };

  const addElement = (type: string) => {
    if (!currentProject) return;

    const newElement: DrawingElement = {
      id: `element-${Date.now()}`,
      type: type as any,
      layer: activeLayer,
      properties: {
        x: Math.random() * 200 - 100,
        y: Math.random() * 200 - 100,
        z: drawingMode === '3D' ? Math.random() * 100 : undefined,
        width: type === 'rectangle' ? 100 : type === 'line' ? 100 : undefined,
        height: type === 'rectangle' ? 60 : type === 'line' ? 0 : undefined,
        radius: type === 'circle' ? 50 : undefined,
        color: currentProject.layers.find(l => l.id === activeLayer)?.color || '#ffffff',
        lineWeight: 1,
        lineType: 'Solid',
        text: type === 'text' ? 'Sample Text' : undefined,
        fontSize: type === 'text' ? 12 : undefined
      },
      visible: true,
      locked: false
    };

    setCurrentProject(prev => prev ? {
      ...prev,
      elements: [...prev.elements, newElement],
      modified: new Date()
    } : null);
  };

  const exportProject = () => {
    if (!currentProject) return;

    const exportData = {
      project: currentProject,
      format: exportFormat,
      timestamp: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentProject.name}.${exportFormat}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <Card className="w-[95vw] h-[95vh] max-w-none max-h-none bg-[var(--ide-surface)] border-[var(--ide-border)]">
        <CardHeader className="flex flex-row items-center justify-between py-3 px-4 border-b border-[var(--ide-border)]">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Box className="h-5 w-5 text-[var(--ide-accent)]" />
              <h2 className="text-lg font-semibold text-[var(--ide-text)]">AutoCAD Blueprint System</h2>
            </div>
            
            <Tabs value={drawingMode} onValueChange={(value: any) => setDrawingMode(value)}>
              <TabsList className="grid w-48 grid-cols-3">
                <TabsTrigger value="1D">1D</TabsTrigger>
                <TabsTrigger value="2D">2D</TabsTrigger>
                <TabsTrigger value="3D">3D</TabsTrigger>
              </TabsList>
            </Tabs>

            {currentProject && (
              <Badge variant="outline" className="text-[var(--ide-text)]">
                {currentProject.name} - {currentProject.type} - {currentProject.units}
              </Badge>
            )}
          </div>

          <div className="flex items-center gap-2">
            <TooltipWrapper
              title="Save Project"
              content="Save the current blueprint project with all layers and elements"
              type="feature"
            >
              <SoundButton variant="outline" size="sm">
                <Save className="h-4 w-4" />
              </SoundButton>
            </TooltipWrapper>

            <TooltipWrapper
              title="Export Blueprint"
              content="Export blueprint in various formats: DWG, DXF, PDF, SVG, PNG"
              type="feature"
            >
              <SoundButton variant="outline" size="sm" onClick={exportProject}>
                <Download className="h-4 w-4" />
              </SoundButton>
            </TooltipWrapper>

            <SoundButton variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </SoundButton>
          </div>
        </CardHeader>

        <CardContent className="p-0 h-full">
          <div className="flex h-full">
            {/* Tool Palette */}
            <div className="w-64 border-r border-[var(--ide-border)] bg-[var(--ide-surface-secondary)] flex flex-col">
              <Tabs defaultValue="tools" className="h-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="tools">Tools</TabsTrigger>
                  <TabsTrigger value="layers">Layers</TabsTrigger>
                  <TabsTrigger value="props">Props</TabsTrigger>
                  <TabsTrigger value="export">Export</TabsTrigger>
                </TabsList>

                <TabsContent value="tools" className="flex-1 p-4 space-y-4">
                  <div className="space-y-3">
                    <h4 className="text-sm font-medium text-[var(--ide-text)]">Selection Tools</h4>
                    <div className="grid grid-cols-3 gap-2">
                      {Object.entries(tools).filter(([_, tool]) => tool.category === 'selection').map(([key, tool]) => {
                        const Icon = tool.icon;
                        return (
                          <TooltipWrapper key={key} title={tool.name} content={`Use ${tool.name} tool`} type="tip">
                            <SoundButton
                              variant={selectedTool === key ? "default" : "outline"}
                              size="sm"
                              onClick={() => setSelectedTool(key)}
                              className="h-10 w-10 p-0"
                            >
                              <Icon className="h-4 w-4" />
                            </SoundButton>
                          </TooltipWrapper>
                        );
                      })}
                    </div>

                    <h4 className="text-sm font-medium text-[var(--ide-text)]">Drawing Tools</h4>
                    <div className="grid grid-cols-3 gap-2">
                      {Object.entries(tools).filter(([_, tool]) => tool.category === 'draw').map(([key, tool]) => {
                        const Icon = tool.icon;
                        return (
                          <TooltipWrapper key={key} title={tool.name} content={`Draw ${tool.name.toLowerCase()}`} type="tip">
                            <SoundButton
                              variant={selectedTool === key ? "default" : "outline"}
                              size="sm"
                              onClick={() => {
                                setSelectedTool(key);
                                addElement(key);
                              }}
                              className="h-10 w-10 p-0"
                            >
                              <Icon className="h-4 w-4" />
                            </SoundButton>
                          </TooltipWrapper>
                        );
                      })}
                    </div>

                    <h4 className="text-sm font-medium text-[var(--ide-text)]">Annotation Tools</h4>
                    <div className="grid grid-cols-3 gap-2">
                      {Object.entries(tools).filter(([_, tool]) => tool.category === 'annotation').map(([key, tool]) => {
                        const Icon = tool.icon;
                        return (
                          <TooltipWrapper key={key} title={tool.name} content={`Add ${tool.name.toLowerCase()}`} type="tip">
                            <SoundButton
                              variant={selectedTool === key ? "default" : "outline"}
                              size="sm"
                              onClick={() => {
                                setSelectedTool(key);
                                addElement(key);
                              }}
                              className="h-10 w-10 p-0"
                            >
                              <Icon className="h-4 w-4" />
                            </SoundButton>
                          </TooltipWrapper>
                        );
                      })}
                    </div>

                    <h4 className="text-sm font-medium text-[var(--ide-text)]">Modify Tools</h4>
                    <div className="grid grid-cols-3 gap-2">
                      {Object.entries(tools).filter(([_, tool]) => tool.category === 'modify').map(([key, tool]) => {
                        const Icon = tool.icon;
                        return (
                          <TooltipWrapper key={key} title={tool.name} content={`${tool.name} selected elements`} type="tip">
                            <SoundButton
                              variant={selectedTool === key ? "default" : "outline"}
                              size="sm"
                              onClick={() => setSelectedTool(key)}
                              className="h-10 w-10 p-0"
                            >
                              <Icon className="h-4 w-4" />
                            </SoundButton>
                          </TooltipWrapper>
                        );
                      })}
                    </div>

                    {drawingMode === '3D' && (
                      <>
                        <h4 className="text-sm font-medium text-[var(--ide-text)]">3D Tools</h4>
                        <div className="grid grid-cols-3 gap-2">
                          {Object.entries(tools).filter(([_, tool]) => tool.category === '3d').map(([key, tool]) => {
                            const Icon = tool.icon;
                            return (
                              <TooltipWrapper key={key} title={tool.name} content={`Create 3D ${tool.name.toLowerCase()}`} type="tip">
                                <SoundButton
                                  variant={selectedTool === key ? "default" : "outline"}
                                  size="sm"
                                  onClick={() => {
                                    setSelectedTool(key);
                                    addElement(key);
                                  }}
                                  className="h-10 w-10 p-0"
                                >
                                  <Icon className="h-4 w-4" />
                                </SoundButton>
                              </TooltipWrapper>
                            );
                          })}
                        </div>
                      </>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="layers" className="flex-1 p-4 space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-medium text-[var(--ide-text)]">Layers</h4>
                      <SoundButton size="sm" variant="outline">
                        <Plus className="h-3 w-3" />
                      </SoundButton>
                    </div>

                    <ScrollArea className="h-64">
                      {currentProject?.layers.map(layer => (
                        <div key={layer.id} className={`flex items-center gap-2 p-2 rounded cursor-pointer hover:bg-[var(--ide-surface)] ${
                          activeLayer === layer.id ? 'bg-[var(--ide-accent)]/20' : ''
                        }`} onClick={() => setActiveLayer(layer.id)}>
                          <SoundButton size="sm" variant="ghost" className="h-6 w-6 p-0">
                            {layer.visible ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                          </SoundButton>
                          <div className="flex-1">
                            <div className="text-sm text-[var(--ide-text)]">{layer.name}</div>
                            <div className="text-xs text-[var(--ide-text-secondary)]">
                              {layer.lineType} • {layer.lineWeight}mm
                            </div>
                          </div>
                          <div 
                            className="w-4 h-4 rounded border"
                            style={{ backgroundColor: layer.color }}
                          />
                        </div>
                      ))}
                    </ScrollArea>
                  </div>
                </TabsContent>

                <TabsContent value="props" className="flex-1 p-4 space-y-4">
                  <div className="space-y-4">
                    <h4 className="text-sm font-medium text-[var(--ide-text)]">Drawing Properties</h4>
                    
                    <div className="space-y-3">
                      <div>
                        <Label className="text-xs text-[var(--ide-text-secondary)]">Units</Label>
                        <Select defaultValue="mm">
                          <SelectTrigger className="h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {units.map(unit => (
                              <SelectItem key={unit} value={unit}>{unit}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label className="text-xs text-[var(--ide-text-secondary)]">Grid Size</Label>
                        <Input 
                          type="number" 
                          defaultValue="10" 
                          className="h-8"
                        />
                      </div>

                      <div className="flex items-center gap-2">
                        <input type="checkbox" checked={gridVisible} onChange={(e) => setGridVisible(e.target.checked)} />
                        <Label className="text-xs text-[var(--ide-text-secondary)]">Show Grid</Label>
                      </div>

                      <div className="flex items-center gap-2">
                        <input type="checkbox" checked={snapEnabled} onChange={(e) => setSnapEnabled(e.target.checked)} />
                        <Label className="text-xs text-[var(--ide-text-secondary)]">Snap to Grid</Label>
                      </div>

                      <div>
                        <Label className="text-xs text-[var(--ide-text-secondary)]">Zoom: {zoom[0]}%</Label>
                        <Slider
                          value={zoom}
                          onValueChange={setZoom}
                          min={10}
                          max={500}
                          step={10}
                          className="mt-2"
                        />
                      </div>

                      <div>
                        <Label className="text-xs text-[var(--ide-text-secondary)]">Rotation: {rotation[0]}°</Label>
                        <Slider
                          value={rotation}
                          onValueChange={setRotation}
                          min={-180}
                          max={180}
                          step={1}
                          className="mt-2"
                        />
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="export" className="flex-1 p-4 space-y-4">
                  <div className="space-y-4">
                    <h4 className="text-sm font-medium text-[var(--ide-text)]">Export Options</h4>
                    
                    <div>
                      <Label className="text-xs text-[var(--ide-text-secondary)]">Format</Label>
                      <Select value={exportFormat} onValueChange={setExportFormat}>
                        <SelectTrigger className="h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {exportFormats.map(format => (
                            <SelectItem key={format} value={format}>{format.toUpperCase()}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <SoundButton className="w-full" onClick={exportProject}>
                        <Download className="h-4 w-4 mr-2" />
                        Export Blueprint
                      </SoundButton>
                      
                      <SoundButton variant="outline" className="w-full">
                        <Printer className="h-4 w-4 mr-2" />
                        Print Preview
                      </SoundButton>
                      
                      <SoundButton variant="outline" className="w-full">
                        <Share2 className="h-4 w-4 mr-2" />
                        Share Project
                      </SoundButton>
                      
                      <SoundButton variant="outline" className="w-full">
                        <Archive className="h-4 w-4 mr-2" />
                        Create Archive
                      </SoundButton>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Drawing Canvas */}
            <div className="flex-1 relative bg-[var(--ide-background)]">
              {/* Top Toolbar */}
              <div className="absolute top-0 left-0 right-0 bg-[var(--ide-surface)] border-b border-[var(--ide-border)] p-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <SoundButton size="sm" variant="outline">
                      <Undo className="h-3 w-3" />
                    </SoundButton>
                    <SoundButton size="sm" variant="outline">
                      <Redo className="h-3 w-3" />
                    </SoundButton>
                    <Separator orientation="vertical" className="h-6" />
                    <SoundButton size="sm" variant={gridVisible ? "default" : "outline"} onClick={() => setGridVisible(!gridVisible)}>
                      <Grid3X3 className="h-3 w-3" />
                    </SoundButton>
                    <SoundButton size="sm" variant={measurementMode ? "default" : "outline"} onClick={() => setMeasurementMode(!measurementMode)}>
                      <Ruler className="h-3 w-3" />
                    </SoundButton>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[var(--ide-text-secondary)]">
                      Elements: {currentProject?.elements.length || 0}
                    </span>
                    <Separator orientation="vertical" className="h-4" />
                    <span className="text-xs text-[var(--ide-text-secondary)]">
                      Tool: {tools[selectedTool as keyof typeof tools]?.name || 'Unknown'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Canvas */}
              <canvas
                ref={canvasRef}
                width={800}
                height={600}
                className="absolute top-12 left-0 w-full h-[calc(100%-3rem)] border-none cursor-crosshair"
                style={{ 
                  background: drawingMode === '3D' 
                    ? 'linear-gradient(135deg, #0a0f1a 0%, #1a2332 100%)' 
                    : '#0a0f1a'
                }}
              />

              {/* Status Bar */}
              <div className="absolute bottom-0 left-0 right-0 bg-[var(--ide-surface)] border-t border-[var(--ide-border)] p-2">
                <div className="flex items-center justify-between text-xs text-[var(--ide-text-secondary)]">
                  <div className="flex items-center gap-4">
                    <span>Coordinates: X: 0, Y: 0{drawingMode === '3D' ? ', Z: 0' : ''}</span>
                    <span>Scale: 1:{currentProject?.scale || 1}</span>
                    <span>Grid: {currentProject?.gridSize || 10}{currentProject?.units || 'mm'}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span>Snap: {snapEnabled ? 'ON' : 'OFF'}</span>
                    <span>Layer: {currentProject?.layers.find(l => l.id === activeLayer)?.name || 'Layer1'}</span>
                    <span>{drawingMode} Mode</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}