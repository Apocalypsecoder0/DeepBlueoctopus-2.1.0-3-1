import React, { useState, useCallback, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useIDEState } from "@/hooks/use-ide-state";
import { useToast } from "@/hooks/use-toast";
import { 
  GitCompare, ArrowLeftRight, Eye, EyeOff,
  Plus, Minus, FileText, Settings, RotateCcw,
  Download, Copy, ChevronLeft, ChevronRight
} from "lucide-react";

interface DiffViewerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface DiffLine {
  type: 'added' | 'removed' | 'unchanged' | 'modified';
  leftLineNumber?: number;
  rightLineNumber?: number;
  leftContent: string;
  rightContent: string;
  isExpanded: boolean;
}

interface DiffStats {
  additions: number;
  deletions: number;
  modifications: number;
  unchanged: number;
  totalLines: number;
}

export default function DiffViewer({ isOpen, onClose }: DiffViewerProps) {
  const [leftFileId, setLeftFileId] = useState<number | null>(null);
  const [rightFileId, setRightFileId] = useState<number | null>(null);
  const [diffLines, setDiffLines] = useState<DiffLine[]>([]);
  const [diffStats, setDiffStats] = useState<DiffStats>({
    additions: 0,
    deletions: 0,
    modifications: 0,
    unchanged: 0,
    totalLines: 0
  });
  const [showUnchanged, setShowUnchanged] = useState(false);
  const [sideBySide, setSideBySide] = useState(true);
  const [highlightWhitespace, setHighlightWhitespace] = useState(false);
  const [contextLines, setContextLines] = useState(3);

  const { files } = useIDEState();
  const { toast } = useToast();

  const calculateDiff = useCallback((leftContent: string, rightContent: string) => {
    const leftLines = leftContent.split('\n');
    const rightLines = rightContent.split('\n');
    const diff: DiffLine[] = [];
    let stats: DiffStats = {
      additions: 0,
      deletions: 0,
      modifications: 0,
      unchanged: 0,
      totalLines: 0
    };

    // Simple line-by-line diff algorithm
    const maxLines = Math.max(leftLines.length, rightLines.length);
    let leftIndex = 0;
    let rightIndex = 0;

    for (let i = 0; i < maxLines; i++) {
      const leftLine = leftIndex < leftLines.length ? leftLines[leftIndex] : '';
      const rightLine = rightIndex < rightLines.length ? rightLines[rightIndex] : '';

      if (leftLine === rightLine) {
        // Lines are identical
        diff.push({
          type: 'unchanged',
          leftLineNumber: leftIndex + 1,
          rightLineNumber: rightIndex + 1,
          leftContent: leftLine,
          rightContent: rightLine,
          isExpanded: false
        });
        stats.unchanged++;
        leftIndex++;
        rightIndex++;
      } else if (leftIndex >= leftLines.length) {
        // Only right side has content (addition)
        diff.push({
          type: 'added',
          rightLineNumber: rightIndex + 1,
          leftContent: '',
          rightContent: rightLine,
          isExpanded: false
        });
        stats.additions++;
        rightIndex++;
      } else if (rightIndex >= rightLines.length) {
        // Only left side has content (deletion)
        diff.push({
          type: 'removed',
          leftLineNumber: leftIndex + 1,
          leftContent: leftLine,
          rightContent: '',
          isExpanded: false
        });
        stats.deletions++;
        leftIndex++;
      } else {
        // Lines are different (modification)
        diff.push({
          type: 'modified',
          leftLineNumber: leftIndex + 1,
          rightLineNumber: rightIndex + 1,
          leftContent: leftLine,
          rightContent: rightLine,
          isExpanded: false
        });
        stats.modifications++;
        leftIndex++;
        rightIndex++;
      }
    }

    stats.totalLines = diff.length;
    setDiffLines(diff);
    setDiffStats(stats);
  }, []);

  const handleCompareFiles = useCallback(() => {
    if (!leftFileId || !rightFileId) {
      toast({
        title: "Files not selected",
        description: "Please select both files to compare",
        variant: "destructive",
      });
      return;
    }

    const leftFile = files?.find(f => f.id === leftFileId);
    const rightFile = files?.find(f => f.id === rightFileId);

    if (!leftFile || !rightFile) {
      toast({
        title: "Files not found",
        description: "Selected files could not be found",
        variant: "destructive",
      });
      return;
    }

    calculateDiff(leftFile.content, rightFile.content);
    
    toast({
      title: "Comparison complete",
      description: `Found ${diffStats.additions} additions, ${diffStats.deletions} deletions`,
    });
  }, [leftFileId, rightFileId, files, calculateDiff, diffStats, toast]);

  const handleSwapFiles = useCallback(() => {
    const temp = leftFileId;
    setLeftFileId(rightFileId);
    setRightFileId(temp);
  }, [leftFileId, rightFileId]);

  const handleCopyDiff = useCallback(() => {
    const diffText = diffLines.map(line => {
      const prefix = line.type === 'added' ? '+' : line.type === 'removed' ? '-' : ' ';
      return `${prefix} ${line.rightContent || line.leftContent}`;
    }).join('\n');

    navigator.clipboard.writeText(diffText);
    toast({
      title: "Diff copied",
      description: "Diff content copied to clipboard",
    });
  }, [diffLines, toast]);

  const getLineBackgroundColor = (type: string) => {
    switch (type) {
      case 'added':
        return 'bg-green-50 dark:bg-green-900/20 border-l-4 border-green-500';
      case 'removed':
        return 'bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500';
      case 'modified':
        return 'bg-yellow-50 dark:bg-yellow-900/20 border-l-4 border-yellow-500';
      default:
        return 'bg-white dark:bg-gray-800';
    }
  };

  const getLineIcon = (type: string) => {
    switch (type) {
      case 'added':
        return <Plus className="w-3 h-3 text-green-600" />;
      case 'removed':
        return <Minus className="w-3 h-3 text-red-600" />;
      case 'modified':
        return <GitCompare className="w-3 h-3 text-yellow-600" />;
      default:
        return null;
    }
  };

  const filteredDiffLines = showUnchanged 
    ? diffLines 
    : diffLines.filter(line => line.type !== 'unchanged');

  const availableFiles = files?.filter(f => !f.isDirectory) || [];

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitCompare className="w-5 h-5" />
            File Diff Viewer
            {diffLines.length > 0 && (
              <div className="flex gap-2">
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  +{diffStats.additions}
                </Badge>
                <Badge variant="secondary" className="bg-red-100 text-red-800">
                  -{diffStats.deletions}
                </Badge>
                <Badge variant="outline">
                  {diffStats.modifications} modified
                </Badge>
              </div>
            )}
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex flex-col space-y-4">
          {/* File Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <FileText className="w-4 h-4" />
                File Selection
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <label className="text-sm font-medium block mb-2">Left File (Original)</label>
                  <Select
                    value={leftFileId?.toString() || ''}
                    onValueChange={(value) => setLeftFileId(parseInt(value))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select original file" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableFiles.map(file => (
                        <SelectItem key={file.id} value={file.id.toString()}>
                          {file.name} ({file.path})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex flex-col items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSwapFiles}
                    disabled={!leftFileId || !rightFileId}
                  >
                    <ArrowLeftRight className="w-4 h-4" />
                  </Button>
                  <span className="text-xs text-gray-500">Swap</span>
                </div>

                <div className="flex-1">
                  <label className="text-sm font-medium block mb-2">Right File (Modified)</label>
                  <Select
                    value={rightFileId?.toString() || ''}
                    onValueChange={(value) => setRightFileId(parseInt(value))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select modified file" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableFiles.map(file => (
                        <SelectItem key={file.id} value={file.id.toString()}>
                          {file.name} ({file.path})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  onClick={handleCompareFiles}
                  disabled={!leftFileId || !rightFileId}
                  className="mt-6"
                >
                  <GitCompare className="w-4 h-4 mr-2" />
                  Compare
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Diff Options */}
          {diffLines.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Diff Options
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={showUnchanged}
                        onChange={(e) => setShowUnchanged(e.target.checked)}
                        className="rounded"
                      />
                      <span className="text-sm">Show unchanged lines</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={sideBySide}
                        onChange={(e) => setSideBySide(e.target.checked)}
                        className="rounded"
                      />
                      <span className="text-sm">Side-by-side view</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={highlightWhitespace}
                        onChange={(e) => setHighlightWhitespace(e.target.checked)}
                        className="rounded"
                      />
                      <span className="text-sm">Highlight whitespace</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleCopyDiff}
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy Diff
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Diff Content */}
          {diffLines.length > 0 && (
            <Card className="flex-1">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Comparison Results</CardTitle>
                  <div className="flex items-center gap-4">
                    <div className="text-sm text-gray-500">
                      {filteredDiffLines.length} of {diffStats.totalLines} lines shown
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        <div className="w-3 h-3 bg-green-500 rounded" />
                        <span className="text-xs">Added ({diffStats.additions})</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-3 h-3 bg-red-500 rounded" />
                        <span className="text-xs">Removed ({diffStats.deletions})</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-3 h-3 bg-yellow-500 rounded" />
                        <span className="text-xs">Modified ({diffStats.modifications})</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-1">
                    {filteredDiffLines.map((line, index) => (
                      <div
                        key={index}
                        className={`flex ${getLineBackgroundColor(line.type)} p-2 text-sm font-mono`}
                      >
                        <div className="flex items-center gap-2 w-16 text-gray-500 text-xs">
                          {getLineIcon(line.type)}
                          <span>{line.leftLineNumber || '·'}</span>
                          <span>{line.rightLineNumber || '·'}</span>
                        </div>
                        
                        {sideBySide ? (
                          <div className="flex flex-1">
                            <div className="flex-1 pr-2">
                              <code className={line.type === 'removed' ? 'bg-red-100 dark:bg-red-900/30' : ''}>
                                {line.leftContent}
                              </code>
                            </div>
                            <div className="w-px bg-gray-300" />
                            <div className="flex-1 pl-2">
                              <code className={line.type === 'added' ? 'bg-green-100 dark:bg-green-900/30' : ''}>
                                {line.rightContent}
                              </code>
                            </div>
                          </div>
                        ) : (
                          <div className="flex-1">
                            <code>
                              {line.type === 'removed' && '- '}
                              {line.type === 'added' && '+ '}
                              {line.rightContent || line.leftContent}
                            </code>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          )}

          {/* Empty State */}
          {diffLines.length === 0 && (
            <Card className="flex-1">
              <CardContent className="flex flex-col items-center justify-center h-64 text-center">
                <GitCompare className="w-12 h-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium mb-2">No Comparison Yet</h3>
                <p className="text-gray-500 mb-4">
                  Select two files and click Compare to see the differences
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}