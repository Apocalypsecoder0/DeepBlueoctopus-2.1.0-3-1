import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { 
  MousePointer2, 
  Target, 
  Copy, 
  Edit3, 
  Layers, 
  Zap,
  Settings,
  Eye,
  BarChart3,
  ArrowRight,
  Plus,
  Minus
} from "lucide-react";

interface MultipleCursorsProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Cursor {
  id: string;
  line: number;
  column: number;
  selection?: { start: number; end: number };
  isActive: boolean;
}

interface CursorOperation {
  type: 'insert' | 'delete' | 'select' | 'move';
  text?: string;
  direction?: 'up' | 'down' | 'left' | 'right';
  amount?: number;
}

export default function MultipleCursors({ isOpen, onClose }: MultipleCursorsProps) {
  const [cursors, setCursors] = useState<Cursor[]>([
    { id: '1', line: 1, column: 1, isActive: true },
    { id: '2', line: 5, column: 10, isActive: true },
    { id: '3', line: 8, column: 5, isActive: true },
  ]);

  const [settings, setSettings] = useState({
    maxCursors: [50],
    cursorBlink: true,
    syncScrolling: true,
    smartSelection: true,
    autoIndent: true,
    highlightMatches: true,
    animationSpeed: [200],
    selectionRadius: [3],
  });

  const [currentOperation, setCurrentOperation] = useState<CursorOperation | null>(null);
  const [operationHistory, setOperationHistory] = useState<CursorOperation[]>([]);
  
  const [sampleCode, setSampleCode] = useState(`function processUsers(users) {
    const results = [];
    
    for (let i = 0; i < users.length; i++) {
        const user = users[i];
        const processed = {
            id: user.id,
            name: user.name,
            email: user.email,
            active: user.status === 'active'
        };
        results.push(processed);
    }
    
    return results;
}

const userList = [
    { id: 1, name: 'Alice', email: 'alice@example.com', status: 'active' },
    { id: 2, name: 'Bob', email: 'bob@example.com', status: 'inactive' },
    { id: 3, name: 'Charlie', email: 'charlie@example.com', status: 'active' }
];`);

  const [features, setFeatures] = useState({
    blockEditing: true,
    columnSelection: true,
    regexSelection: true,
    smartDuplication: true,
    synchronizedEditing: true,
    ghostCursors: true,
  });

  const [statistics, setStatistics] = useState({
    activeCursors: cursors.filter(c => c.isActive).length,
    totalOperations: 156,
    averageEditTime: '2.3s',
    efficiency: 78,
  });

  useEffect(() => {
    // Update active cursors count
    setStatistics(prev => ({
      ...prev,
      activeCursors: cursors.filter(c => c.isActive).length,
    }));
  }, [cursors]);

  const addCursor = (line: number, column: number) => {
    if (cursors.length >= settings.maxCursors[0]) return;
    
    const newCursor: Cursor = {
      id: `cursor-${Date.now()}`,
      line,
      column,
      isActive: true,
    };
    
    setCursors(prev => [...prev, newCursor]);
  };

  const removeCursor = (id: string) => {
    setCursors(prev => prev.filter(cursor => cursor.id !== id));
  };

  const toggleCursor = (id: string) => {
    setCursors(prev => prev.map(cursor => 
      cursor.id === id ? { ...cursor, isActive: !cursor.isActive } : cursor
    ));
  };

  const executeOperation = (operation: CursorOperation) => {
    setCurrentOperation(operation);
    setOperationHistory(prev => [...prev.slice(-19), operation]);
    
    // Simulate operation execution
    setTimeout(() => {
      setCurrentOperation(null);
      setStatistics(prev => ({
        ...prev,
        totalOperations: prev.totalOperations + 1,
      }));
    }, settings.animationSpeed[0]);
  };

  const selectAllOccurrences = (text: string) => {
    const lines = sampleCode.split('\n');
    const newCursors: Cursor[] = [];
    
    lines.forEach((line, lineIndex) => {
      let columnIndex = 0;
      while ((columnIndex = line.indexOf(text, columnIndex)) !== -1) {
        newCursors.push({
          id: `occurrence-${lineIndex}-${columnIndex}`,
          line: lineIndex + 1,
          column: columnIndex + 1,
          selection: { start: columnIndex, end: columnIndex + text.length },
          isActive: true,
        });
        columnIndex += text.length;
      }
    });
    
    setCursors(newCursors);
  };

  const createColumnSelection = (startLine: number, endLine: number, column: number) => {
    const newCursors: Cursor[] = [];
    for (let line = startLine; line <= endLine; line++) {
      newCursors.push({
        id: `column-${line}-${column}`,
        line,
        column,
        isActive: true,
      });
    }
    setCursors(newCursors);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="w-[95vw] h-[95vh] bg-background rounded-lg border shadow-lg relative">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-2">
            <MousePointer2 className="h-6 w-6 text-blue-500" />
            <div>
              <h2 className="text-xl font-bold">Multiple Cursors Enhanced</h2>
              <p className="text-sm text-muted-foreground">Advanced multi-selection operations and cursor management</p>
            </div>
          </div>
          <Button onClick={onClose} variant="outline" size="sm">
            Close
          </Button>
        </div>

        <div className="flex h-[calc(100%-80px)]">
          <div className="flex-1 p-4 overflow-auto">
            <Tabs defaultValue="cursors" className="h-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="cursors">Cursor Management</TabsTrigger>
                <TabsTrigger value="operations">Operations</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
                <TabsTrigger value="advanced">Advanced Features</TabsTrigger>
              </TabsList>

              <TabsContent value="cursors" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {/* Active Cursors */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Target className="h-4 w-4" />
                        Active Cursors ({cursors.filter(c => c.isActive).length})
                      </CardTitle>
                      <CardDescription>
                        Manage and configure multiple cursor positions
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 max-h-64 overflow-auto">
                        {cursors.map((cursor) => (
                          <div key={cursor.id} className="flex items-center justify-between p-2 border rounded">
                            <div className="flex items-center gap-2">
                              <Switch
                                checked={cursor.isActive}
                                onCheckedChange={() => toggleCursor(cursor.id)}
                                size="sm"
                              />
                              <span className="text-sm font-mono">
                                Line {cursor.line}, Col {cursor.column}
                              </span>
                              {cursor.selection && (
                                <Badge variant="secondary" className="text-xs">
                                  Selected: {cursor.selection.end - cursor.selection.start} chars
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-1">
                              <Badge variant={cursor.isActive ? "default" : "outline"} className="text-xs">
                                {cursor.isActive ? "Active" : "Inactive"}
                              </Badge>
                              <Button 
                                size="sm" 
                                variant="ghost"
                                onClick={() => removeCursor(cursor.id)}
                                className="h-6 w-6 p-0"
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                      
                      <div className="flex gap-2 mt-4">
                        <Button 
                          size="sm" 
                          onClick={() => addCursor(Math.floor(Math.random() * 20) + 1, Math.floor(Math.random() * 50) + 1)}
                          disabled={cursors.length >= settings.maxCursors[0]}
                        >
                          <Plus className="h-3 w-3 mr-1" />
                          Add Cursor
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => setCursors([])}
                        >
                          Clear All
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Code Preview with Cursors */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Eye className="h-4 w-4" />
                        Code Preview
                      </CardTitle>
                      <CardDescription>
                        Visualize cursor positions in code
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-muted p-4 rounded-lg border relative">
                        <pre className="text-sm font-mono whitespace-pre-wrap leading-relaxed">
                          {sampleCode.split('\n').map((line, lineIndex) => (
                            <div key={lineIndex} className="relative">
                              <span className="text-muted-foreground text-xs w-8 inline-block">
                                {lineIndex + 1}
                              </span>
                              {line.split('').map((char, charIndex) => {
                                const cursor = cursors.find(c => 
                                  c.line === lineIndex + 1 && 
                                  c.column === charIndex + 1 && 
                                  c.isActive
                                );
                                if (cursor) {
                                  return (
                                    <span
                                      key={charIndex}
                                      className="relative"
                                    >
                                      <span 
                                        className="absolute w-0.5 h-5 bg-blue-500 animate-pulse"
                                        style={{ left: '-1px', top: '0' }}
                                      />
                                      {char}
                                    </span>
                                  );
                                }
                                return <span key={charIndex}>{char}</span>;
                              })}
                            </div>
                          ))}
                        </pre>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Statistics */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-4 w-4" />
                      Cursor Statistics
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">{statistics.activeCursors}</div>
                        <div className="text-sm text-muted-foreground">Active Cursors</div>
                      </div>
                      <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">{statistics.totalOperations}</div>
                        <div className="text-sm text-muted-foreground">Total Operations</div>
                      </div>
                      <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">{statistics.averageEditTime}</div>
                        <div className="text-sm text-muted-foreground">Avg Edit Time</div>
                      </div>
                      <div className="text-center p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                        <div className="text-2xl font-bold text-orange-600">{statistics.efficiency}%</div>
                        <div className="text-sm text-muted-foreground">Efficiency</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="operations" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Edit3 className="h-4 w-4" />
                        Quick Operations
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-2 gap-2">
                        <Button 
                          size="sm" 
                          onClick={() => executeOperation({ type: 'insert', text: 'TODO: ' })}
                        >
                          Insert Text
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => executeOperation({ type: 'delete', amount: 1 })}
                        >
                          Delete Char
                        </Button>
                        <Button 
                          size="sm" 
                          onClick={() => executeOperation({ type: 'move', direction: 'right', amount: 1 })}
                        >
                          Move Right
                        </Button>
                        <Button 
                          size="sm" 
                          onClick={() => executeOperation({ type: 'move', direction: 'down', amount: 1 })}
                        >
                          Move Down
                        </Button>
                      </div>
                      
                      <div className="space-y-2">
                        <Input 
                          placeholder="Find text to select all occurrences..."
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && e.currentTarget.value) {
                              selectAllOccurrences(e.currentTarget.value);
                            }
                          }}
                        />
                        <div className="grid grid-cols-2 gap-2">
                          <Button 
                            size="sm"
                            onClick={() => createColumnSelection(1, 10, 5)}
                          >
                            Column Select
                          </Button>
                          <Button 
                            size="sm"
                            variant="outline"
                            onClick={() => selectAllOccurrences('user')}
                          >
                            Select "user"
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Layers className="h-4 w-4" />
                        Operation History
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 max-h-64 overflow-auto">
                        {operationHistory.slice(-10).map((op, index) => (
                          <div key={index} className="flex items-center gap-2 p-2 bg-muted rounded text-sm">
                            <ArrowRight className="h-3 w-3" />
                            <span className="capitalize">{op.type}</span>
                            {op.text && <Badge variant="secondary">{op.text}</Badge>}
                            {op.direction && <Badge variant="outline">{op.direction}</Badge>}
                            {op.amount && <span className="text-muted-foreground">×{op.amount}</span>}
                          </div>
                        ))}
                        {operationHistory.length === 0 && (
                          <p className="text-muted-foreground text-sm text-center py-4">
                            No operations performed yet
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {currentOperation && (
                  <Alert>
                    <Zap className="h-4 w-4" />
                    <AlertDescription>
                      Executing {currentOperation.type} operation across {statistics.activeCursors} cursors...
                    </AlertDescription>
                  </Alert>
                )}
              </TabsContent>

              <TabsContent value="settings" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Settings className="h-4 w-4" />
                        Cursor Settings
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          Max Cursors: {settings.maxCursors[0]}
                        </label>
                        <Slider
                          value={settings.maxCursors}
                          onValueChange={(value) => 
                            setSettings(prev => ({ ...prev, maxCursors: value }))
                          }
                          max={100}
                          min={1}
                          step={1}
                          className="w-full"
                        />
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          Animation Speed: {settings.animationSpeed[0]}ms
                        </label>
                        <Slider
                          value={settings.animationSpeed}
                          onValueChange={(value) => 
                            setSettings(prev => ({ ...prev, animationSpeed: value }))
                          }
                          max={1000}
                          min={50}
                          step={50}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          Selection Radius: {settings.selectionRadius[0]} lines
                        </label>
                        <Slider
                          value={settings.selectionRadius}
                          onValueChange={(value) => 
                            setSettings(prev => ({ ...prev, selectionRadius: value }))
                          }
                          max={10}
                          min={1}
                          step={1}
                          className="w-full"
                        />
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Behavior Settings</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Cursor Blink</label>
                        <Switch
                          checked={settings.cursorBlink}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, cursorBlink: checked }))
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Sync Scrolling</label>
                        <Switch
                          checked={settings.syncScrolling}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, syncScrolling: checked }))
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Smart Selection</label>
                        <Switch
                          checked={settings.smartSelection}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, smartSelection: checked }))
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Auto Indent</label>
                        <Switch
                          checked={settings.autoIndent}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, autoIndent: checked }))
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Highlight Matches</label>
                        <Switch
                          checked={settings.highlightMatches}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, highlightMatches: checked }))
                          }
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="advanced" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Zap className="h-4 w-4" />
                        Advanced Features
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {Object.entries(features).map(([key, value]) => (
                        <div key={key} className="flex items-center justify-between">
                          <label className="text-sm font-medium capitalize">
                            {key.replace(/([A-Z])/g, ' $1').trim()}
                          </label>
                          <Switch
                            checked={value}
                            onCheckedChange={(checked) => 
                              setFeatures(prev => ({ ...prev, [key]: checked }))
                            }
                          />
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Copy className="h-4 w-4" />
                        Keyboard Shortcuts
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Add Cursor Above</span>
                          <Badge variant="outline">Ctrl+Alt+Up</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Add Cursor Below</span>
                          <Badge variant="outline">Ctrl+Alt+Down</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Select All Occurrences</span>
                          <Badge variant="outline">Ctrl+Shift+L</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Add Next Occurrence</span>
                          <Badge variant="outline">Ctrl+D</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Column Selection</span>
                          <Badge variant="outline">Shift+Alt+Drag</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Escape Multiple Cursors</span>
                          <Badge variant="outline">Escape</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}