import React, { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Box, Circle, Package, Layers, Gamepad2, 
  Camera, Mic, Video, Image, Palette, Volume2,
  Settings, Play, Pause, Square, RotateCcw,
  Move3D, RotateCw, Maximize, Grid3X3, Eye,
  Sun, Lightbulb, Zap, Download, Upload,
  Save, FolderOpen, Plus, Trash2, Copy,
  Undo, Redo, ZoomIn, ZoomOut, Monitor,
  Smartphone, Tablet, Tv, Code, FileCode,
  Wrench, Hammer, Paintbrush, Music,
  Film, Headphones, Mic2, Speaker
} from "lucide-react";

interface GameDevelopmentStudioProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SceneObject {
  id: string;
  type: 'cube' | 'sphere' | 'cylinder' | 'plane' | 'light' | 'camera';
  name: string;
  position: { x: number; y: number; z: number };
  rotation: { x: number; y: number; z: number };
  scale: { x: number; y: number; z: number };
  material: string;
  visible: boolean;
}

interface Material {
  id: string;
  name: string;
  type: 'standard' | 'pbr' | 'unlit' | 'toon';
  color: string;
  metallic: number;
  roughness: number;
  emission: string;
  texture?: string;
}

interface AudioClip {
  id: string;
  name: string;
  type: 'music' | 'sfx' | 'voice' | 'ambient';
  duration: number;
  volume: number;
  loop: boolean;
  url?: string;
}

interface Animation {
  id: string;
  name: string;
  target: string;
  property: string;
  keyframes: { time: number; value: any }[];
  duration: number;
  loop: boolean;
}

export function GameDevelopmentStudio({ isOpen, onClose }: GameDevelopmentStudioProps) {
  const [activeTab, setActiveTab] = useState('scene');
  const [selectedObject, setSelectedObject] = useState<string | null>(null);
  const [sceneObjects, setSceneObjects] = useState<SceneObject[]>([
    {
      id: '1',
      type: 'cube',
      name: 'Default Cube',
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      material: 'default',
      visible: true
    }
  ]);
  
  const [materials, setMaterials] = useState<Material[]>([
    {
      id: 'default',
      name: 'Default Material',
      type: 'standard',
      color: '#ffffff',
      metallic: 0,
      roughness: 0.5,
      emission: '#000000'
    }
  ]);

  const [audioClips, setAudioClips] = useState<AudioClip[]>([
    {
      id: '1',
      name: 'Background Music',
      type: 'music',
      duration: 120,
      volume: 0.7,
      loop: true
    }
  ]);

  const [animations, setAnimations] = useState<Animation[]>([
    {
      id: '1',
      name: 'Rotate Cube',
      target: '1',
      property: 'rotation.y',
      keyframes: [
        { time: 0, value: 0 },
        { time: 1, value: 360 }
      ],
      duration: 2,
      loop: true
    }
  ]);

  const [renderSettings, setRenderSettings] = useState({
    quality: 'high',
    shadows: true,
    lighting: 'dynamic',
    antiAliasing: true,
    postProcessing: true,
    resolution: '1920x1080',
    frameRate: 60
  });

  const [audioSettings, setAudioSettings] = useState({
    masterVolume: 80,
    musicVolume: 70,
    sfxVolume: 85,
    voiceVolume: 90,
    spatialAudio: true,
    reverbEnabled: true,
    compressionEnabled: false
  });

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalTime, setTotalTime] = useState(100);

  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) {
        // Simple 3D scene visualization
        ctx.fillStyle = '#1a1a1a';
        ctx.fillRect(0, 0, 600, 400);
        
        // Grid
        ctx.strokeStyle = '#333';
        ctx.lineWidth = 1;
        for (let i = 0; i <= 600; i += 50) {
          ctx.beginPath();
          ctx.moveTo(i, 0);
          ctx.lineTo(i, 400);
          ctx.stroke();
        }
        for (let i = 0; i <= 400; i += 50) {
          ctx.beginPath();
          ctx.moveTo(0, i);
          ctx.lineTo(600, i);
          ctx.stroke();
        }
        
        // Objects
        sceneObjects.forEach((obj, index) => {
          if (!obj.visible) return;
          
          const x = 300 + obj.position.x * 50;
          const y = 200 - obj.position.z * 50;
          const size = 30 * obj.scale.x;
          
          ctx.fillStyle = obj.type === 'cube' ? '#4f46e5' : 
                         obj.type === 'sphere' ? '#ef4444' : '#10b981';
          
          if (obj.type === 'cube') {
            ctx.fillRect(x - size/2, y - size/2, size, size);
          } else if (obj.type === 'sphere') {
            ctx.beginPath();
            ctx.arc(x, y, size/2, 0, Math.PI * 2);
            ctx.fill();
          }
          
          // Selection highlight
          if (selectedObject === obj.id) {
            ctx.strokeStyle = '#fbbf24';
            ctx.lineWidth = 2;
            ctx.strokeRect(x - size/2 - 2, y - size/2 - 2, size + 4, size + 4);
          }
        });
      }
    }
  }, [sceneObjects, selectedObject]);

  const addObject = (type: SceneObject['type']) => {
    const newObject: SceneObject = {
      id: Date.now().toString(),
      type,
      name: `${type.charAt(0).toUpperCase() + type.slice(1)} ${sceneObjects.length + 1}`,
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      material: 'default',
      visible: true
    };
    setSceneObjects([...sceneObjects, newObject]);
  };

  const deleteObject = (id: string) => {
    setSceneObjects(sceneObjects.filter(obj => obj.id !== id));
    if (selectedObject === id) {
      setSelectedObject(null);
    }
  };

  const updateObjectProperty = (id: string, property: string, value: any) => {
    setSceneObjects(sceneObjects.map(obj => {
      if (obj.id === id) {
        const keys = property.split('.');
        if (keys.length === 2) {
          return {
            ...obj,
            [keys[0]]: {
              ...obj[keys[0] as keyof SceneObject],
              [keys[1]]: value
            }
          };
        } else {
          return { ...obj, [property]: value };
        }
      }
      return obj;
    }));
  };

  const addMaterial = () => {
    const newMaterial: Material = {
      id: Date.now().toString(),
      name: `Material ${materials.length + 1}`,
      type: 'standard',
      color: '#ffffff',
      metallic: 0,
      roughness: 0.5,
      emission: '#000000'
    };
    setMaterials([...materials, newMaterial]);
  };

  const exportScene = () => {
    const sceneData = {
      objects: sceneObjects,
      materials,
      audioClips,
      animations,
      renderSettings,
      audioSettings
    };
    
    const blob = new Blob([JSON.stringify(sceneData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'game_scene.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const selectedObj = sceneObjects.find(obj => obj.id === selectedObject);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] w-full h-[90vh] max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Gamepad2 className="h-5 w-5" />
            Game Development Studio - Unreal Engine Style
          </DialogTitle>
        </DialogHeader>

        <div className="flex h-full gap-2">
          {/* Left Panel - Tools and Objects */}
          <div className="w-80 flex flex-col gap-2">
            <Card className="flex-1">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Layers className="h-4 w-4" />
                  Scene Outliner
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex gap-1">
                  <Button size="sm" onClick={() => addObject('cube')} variant="outline">
                    <Box className="h-3 w-3 mr-1" />
                    Cube
                  </Button>
                  <Button size="sm" onClick={() => addObject('sphere')} variant="outline">
                    <Circle className="h-3 w-3 mr-1" />
                    Sphere
                  </Button>
                  <Button size="sm" onClick={() => addObject('cylinder')} variant="outline">
                    <Package className="h-3 w-3 mr-1" />
                    Cylinder
                  </Button>
                </div>
                
                <ScrollArea className="h-40">
                  {sceneObjects.map((obj) => (
                    <div 
                      key={obj.id}
                      className={`flex items-center gap-2 p-2 cursor-pointer rounded ${
                        selectedObject === obj.id ? 'bg-blue-100 dark:bg-blue-900' : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                      }`}
                      onClick={() => setSelectedObject(obj.id)}
                    >
                      <Switch 
                        checked={obj.visible}
                        onCheckedChange={(checked) => updateObjectProperty(obj.id, 'visible', checked)}
                        size="sm"
                      />
                      <span className="text-sm flex-1">{obj.name}</span>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteObject(obj.id);
                        }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Object Properties */}
            {selectedObj && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Properties - {selectedObj.name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <Label className="text-xs">Name</Label>
                    <Input 
                      value={selectedObj.name}
                      onChange={(e) => updateObjectProperty(selectedObj.id, 'name', e.target.value)}
                      className="h-8"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-xs">Position</Label>
                    <div className="grid grid-cols-3 gap-1">
                      <Input 
                        type="number"
                        placeholder="X"
                        value={selectedObj.position.x}
                        onChange={(e) => updateObjectProperty(selectedObj.id, 'position.x', parseFloat(e.target.value) || 0)}
                        className="h-8 text-xs"
                      />
                      <Input 
                        type="number"
                        placeholder="Y"
                        value={selectedObj.position.y}
                        onChange={(e) => updateObjectProperty(selectedObj.id, 'position.y', parseFloat(e.target.value) || 0)}
                        className="h-8 text-xs"
                      />
                      <Input 
                        type="number"
                        placeholder="Z"
                        value={selectedObj.position.z}
                        onChange={(e) => updateObjectProperty(selectedObj.id, 'position.z', parseFloat(e.target.value) || 0)}
                        className="h-8 text-xs"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">Scale</Label>
                    <div className="grid grid-cols-3 gap-1">
                      <Input 
                        type="number"
                        step="0.1"
                        placeholder="X"
                        value={selectedObj.scale.x}
                        onChange={(e) => updateObjectProperty(selectedObj.id, 'scale.x', parseFloat(e.target.value) || 1)}
                        className="h-8 text-xs"
                      />
                      <Input 
                        type="number"
                        step="0.1"
                        placeholder="Y"
                        value={selectedObj.scale.y}
                        onChange={(e) => updateObjectProperty(selectedObj.id, 'scale.y', parseFloat(e.target.value) || 1)}
                        className="h-8 text-xs"
                      />
                      <Input 
                        type="number"
                        step="0.1"
                        placeholder="Z"
                        value={selectedObj.scale.z}
                        onChange={(e) => updateObjectProperty(selectedObj.id, 'scale.z', parseFloat(e.target.value) || 1)}
                        className="h-8 text-xs"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Center Panel - 3D Viewport */}
          <div className="flex-1 flex flex-col">
            <div className="flex items-center gap-2 mb-2">
              <div className="flex gap-1">
                <Button size="sm" variant={isPlaying ? "default" : "outline"} onClick={() => setIsPlaying(!isPlaying)}>
                  {isPlaying ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
                </Button>
                <Button size="sm" variant="outline" onClick={() => setCurrentTime(0)}>
                  <Square className="h-3 w-3" />
                </Button>
                <Button size="sm" variant="outline">
                  <RotateCcw className="h-3 w-3" />
                </Button>
              </div>
              
              <Separator orientation="vertical" className="h-6" />
              
              <div className="flex gap-1">
                <Button size="sm" variant="outline">
                  <Move3D className="h-3 w-3" />
                </Button>
                <Button size="sm" variant="outline">
                  <RotateCw className="h-3 w-3" />
                </Button>
                <Button size="sm" variant="outline">
                  <Maximize className="h-3 w-3" />
                </Button>
              </div>

              <Separator orientation="vertical" className="h-6" />

              <Badge variant="secondary">Frame: {Math.floor(currentTime * 60)}</Badge>
              <Badge variant="secondary">FPS: {renderSettings.frameRate}</Badge>
            </div>

            <Card className="flex-1">
              <CardContent className="p-2 h-full">
                <canvas 
                  ref={canvasRef}
                  width={600}
                  height={400}
                  className="border rounded w-full h-full bg-gray-900"
                  style={{ maxHeight: '400px' }}
                />
              </CardContent>
            </Card>

            {/* Timeline */}
            <Card className="mt-2">
              <CardContent className="p-2">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Label className="text-xs">Timeline</Label>
                    <Slider
                      value={[currentTime]}
                      onValueChange={(value) => setCurrentTime(value[0])}
                      max={totalTime}
                      step={0.1}
                      className="flex-1"
                    />
                    <span className="text-xs font-mono">{currentTime.toFixed(1)}s</span>
                  </div>
                  
                  <div className="grid grid-cols-4 gap-1 text-xs">
                    {animations.map((anim) => (
                      <Badge key={anim.id} variant="outline" className="text-xs">
                        {anim.name}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Settings and Controls */}
          <div className="w-80">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
              <TabsList className="grid grid-cols-4 w-full">
                <TabsTrigger value="scene" className="text-xs">Scene</TabsTrigger>
                <TabsTrigger value="materials" className="text-xs">Materials</TabsTrigger>
                <TabsTrigger value="audio" className="text-xs">Audio</TabsTrigger>
                <TabsTrigger value="render" className="text-xs">Render</TabsTrigger>
              </TabsList>

              <TabsContent value="scene" className="h-full mt-2">
                <Card className="h-full">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Settings className="h-4 w-4" />
                      Scene Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Environment</Label>
                      <Select defaultValue="sky">
                        <SelectTrigger className="h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sky">Sky</SelectItem>
                          <SelectItem value="gradient">Gradient</SelectItem>
                          <SelectItem value="hdri">HDRI</SelectItem>
                          <SelectItem value="solid">Solid Color</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-xs">Lighting</Label>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline" className="flex-1">
                          <Sun className="h-3 w-3 mr-1" />
                          Sun
                        </Button>
                        <Button size="sm" variant="outline" className="flex-1">
                          <Lightbulb className="h-3 w-3 mr-1" />
                          Point
                        </Button>
                        <Button size="sm" variant="outline" className="flex-1">
                          <Zap className="h-3 w-3 mr-1" />
                          Spot
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-xs">Grid</Label>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-xs">Wireframe</Label>
                        <Switch />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-xs">Shadows</Label>
                        <Switch defaultChecked />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-xs">Camera Controls</Label>
                      <div className="grid grid-cols-2 gap-1">
                        <Button size="sm" variant="outline">
                          <Camera className="h-3 w-3 mr-1" />
                          Perspective
                        </Button>
                        <Button size="sm" variant="outline">
                          <Eye className="h-3 w-3 mr-1" />
                          Orthographic
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="materials" className="h-full mt-2">
                <Card className="h-full">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Palette className="h-4 w-4" />
                      Materials
                      <Button size="sm" variant="outline" onClick={addMaterial} className="ml-auto">
                        <Plus className="h-3 w-3" />
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-60">
                      {materials.map((material) => (
                        <div key={material.id} className="p-2 border rounded mb-2">
                          <div className="flex items-center gap-2 mb-2">
                            <div 
                              className="w-4 h-4 rounded border"
                              style={{ backgroundColor: material.color }}
                            />
                            <span className="text-xs font-medium">{material.name}</span>
                          </div>
                          
                          <div className="space-y-1">
                            <div>
                              <Label className="text-xs">Type</Label>
                              <Select value={material.type}>
                                <SelectTrigger className="h-6 text-xs">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="standard">Standard</SelectItem>
                                  <SelectItem value="pbr">PBR</SelectItem>
                                  <SelectItem value="unlit">Unlit</SelectItem>
                                  <SelectItem value="toon">Toon</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            
                            <div>
                              <Label className="text-xs">Metallic: {material.metallic}</Label>
                              <Slider
                                value={[material.metallic]}
                                max={1}
                                step={0.01}
                                className="h-2"
                              />
                            </div>
                            
                            <div>
                              <Label className="text-xs">Roughness: {material.roughness}</Label>
                              <Slider
                                value={[material.roughness]}
                                max={1}
                                step={0.01}
                                className="h-2"
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="audio" className="h-full mt-2">
                <Card className="h-full">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Volume2 className="h-4 w-4" />
                      Audio System
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Master Volume: {audioSettings.masterVolume}%</Label>
                      <Slider
                        value={[audioSettings.masterVolume]}
                        onValueChange={(value) => setAudioSettings({...audioSettings, masterVolume: value[0]})}
                        max={100}
                        className="h-2"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-xs">Music Volume: {audioSettings.musicVolume}%</Label>
                      <Slider
                        value={[audioSettings.musicVolume]}
                        onValueChange={(value) => setAudioSettings({...audioSettings, musicVolume: value[0]})}
                        max={100}
                        className="h-2"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-xs">SFX Volume: {audioSettings.sfxVolume}%</Label>
                      <Slider
                        value={[audioSettings.sfxVolume]}
                        onValueChange={(value) => setAudioSettings({...audioSettings, sfxVolume: value[0]})}
                        max={100}
                        className="h-2"
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-xs">Spatial Audio</Label>
                        <Switch 
                          checked={audioSettings.spatialAudio}
                          onCheckedChange={(checked) => setAudioSettings({...audioSettings, spatialAudio: checked})}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-xs">Reverb</Label>
                        <Switch 
                          checked={audioSettings.reverbEnabled}
                          onCheckedChange={(checked) => setAudioSettings({...audioSettings, reverbEnabled: checked})}
                        />
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Label className="text-xs">Audio Clips</Label>
                        <Button size="sm" variant="outline" className="ml-auto">
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                      
                      <ScrollArea className="h-32">
                        {audioClips.map((clip) => (
                          <div key={clip.id} className="flex items-center gap-2 p-1 border rounded mb-1">
                            <div className="flex-1">
                              <div className="text-xs font-medium">{clip.name}</div>
                              <div className="text-xs text-gray-500">{clip.type} • {clip.duration}s</div>
                            </div>
                            <div className="flex gap-1">
                              <Button size="sm" variant="ghost">
                                <Play className="h-3 w-3" />
                              </Button>
                              <Button size="sm" variant="ghost">
                                <Volume2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </ScrollArea>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="render" className="h-full mt-2">
                <Card className="h-full">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Monitor className="h-4 w-4" />
                      Render Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Quality</Label>
                      <Select value={renderSettings.quality} onValueChange={(value) => setRenderSettings({...renderSettings, quality: value})}>
                        <SelectTrigger className="h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="ultra">Ultra</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-xs">Resolution</Label>
                      <Select value={renderSettings.resolution} onValueChange={(value) => setRenderSettings({...renderSettings, resolution: value})}>
                        <SelectTrigger className="h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1280x720">720p HD</SelectItem>
                          <SelectItem value="1920x1080">1080p FHD</SelectItem>
                          <SelectItem value="2560x1440">1440p QHD</SelectItem>
                          <SelectItem value="3840x2160">4K UHD</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-xs">Frame Rate: {renderSettings.frameRate} FPS</Label>
                      <Slider
                        value={[renderSettings.frameRate]}
                        onValueChange={(value) => setRenderSettings({...renderSettings, frameRate: value[0]})}
                        min={30}
                        max={120}
                        step={30}
                        className="h-2"
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-xs">Shadows</Label>
                        <Switch 
                          checked={renderSettings.shadows}
                          onCheckedChange={(checked) => setRenderSettings({...renderSettings, shadows: checked})}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-xs">Anti-Aliasing</Label>
                        <Switch 
                          checked={renderSettings.antiAliasing}
                          onCheckedChange={(checked) => setRenderSettings({...renderSettings, antiAliasing: checked})}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-xs">Post Processing</Label>
                        <Switch 
                          checked={renderSettings.postProcessing}
                          onCheckedChange={(checked) => setRenderSettings({...renderSettings, postProcessing: checked})}
                        />
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <Label className="text-xs">Export Platforms</Label>
                      <div className="grid grid-cols-2 gap-1">
                        <Button size="sm" variant="outline">
                          <Monitor className="h-3 w-3 mr-1" />
                          PC
                        </Button>
                        <Button size="sm" variant="outline">
                          <Smartphone className="h-3 w-3 mr-1" />
                          Mobile
                        </Button>
                        <Button size="sm" variant="outline">
                          <Tv className="h-3 w-3 mr-1" />
                          Console
                        </Button>
                        <Button size="sm" variant="outline">
                          <Code className="h-3 w-3 mr-1" />
                          Web
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Bottom Toolbar */}
        <div className="flex items-center gap-2 pt-2 border-t">
          <Button size="sm" variant="outline" onClick={exportScene}>
            <Download className="h-3 w-3 mr-1" />
            Export Scene
          </Button>
          <Button size="sm" variant="outline">
            <Upload className="h-3 w-3 mr-1" />
            Import
          </Button>
          <Button size="sm" variant="outline">
            <Save className="h-3 w-3 mr-1" />
            Save
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <Button size="sm" variant="outline">
            <Undo className="h-3 w-3" />
          </Button>
          <Button size="sm" variant="outline">
            <Redo className="h-3 w-3" />
          </Button>
          <div className="flex-1" />
          <Badge variant="secondary">Objects: {sceneObjects.length}</Badge>
          <Badge variant="secondary">Materials: {materials.length}</Badge>
          <Badge variant="secondary">Audio: {audioClips.length}</Badge>
        </div>
      </DialogContent>
    </Dialog>
  );
}