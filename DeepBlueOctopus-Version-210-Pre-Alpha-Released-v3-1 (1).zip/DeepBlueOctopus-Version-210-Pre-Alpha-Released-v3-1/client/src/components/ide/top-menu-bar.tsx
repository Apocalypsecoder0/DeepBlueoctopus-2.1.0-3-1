import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { useIDEState } from "@/hooks/use-ide-state";
import OctopusLogo from "@/components/ui/octopus-logo";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import { SoundControl } from "@/components/ui/sound-system";
import { ThemeSelector, useTheme } from "@/components/ui/theme-system";
import { Palette, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import AboutDialog from "./about-dialog";
import UMLDesigner from "./uml-designer";
import MobileFramework from "./mobile-framework";
import GameEngine from "./game-engine";
import AIAssistant from "./ai-assistant";
import AdvancedDebugger from "./advanced-debugger";
import VersionControl from "./version-control";
import WorkspaceManager from "./workspace-manager";
import ObjectStudio from "./object-studio";
import AudioVideoEditor from "./audio-video-editor";
import MathematicsLibrary from "./mathematics-library";
import SystemAccountManager from "./account-manager";
import AuthDialog from "@/components/auth/auth-dialog";
import UserAccountManager from "@/components/auth/account-manager";
import UpdateSystem from "./update-system";
import ErrorLoggingSystem from "./error-logging-system";
import SubscriptionManager from "./subscription-manager";
import FileManager from "./file-manager";
import AutoCADBlueprintSystem from "./autocad-blueprint";
import CodeStylingSystem from "./code-styling-system";
import ServerManagement from "./server-management";
import PluginManager from "./plugin-manager";
import PluginMarketplace from "./plugin-marketplace";
import GitHubIntegration from "./github-integration";
import MissionSystem from "./mission-system";
import DatabaseManager from "./database-manager";
import PlatformSupport from "./platform-support";
import PerformanceMonitor from "./performance-monitor";
import CodeFormatter from "./code-formatter";
import PackageManager from "./package-manager";
import LanguageServer from "./language-server";
import DeployManager from "./deploy-manager";
import DeveloperToolkit from "./developer-toolkit";
import DocumentationGenerator from "./documentation-generator";
import WriteTool from "./write-tool";
import MultiCursorEditor from "./multi-cursor-editor";
import IDELogicSystem from "./ide-logic-system";
import SubMenuManager from "./sub-menu-manager";
import CodeFoldingSystem from "./code-folding-system";
import IntelliSenseSystem from "./intellisense-system";
import MultiTerminalSystem from "./multi-terminal-system";
import RealTimeCollaboration from "./real-time-collaboration";
import EnhancedFileExplorer from "./enhanced-file-explorer";
import ExtensionsPanel from "./extensions-panel";
import Collaboration from "./collaboration";
import SyntaxHighlightingSystem from "./syntax-highlighting-system";
import TestingFramework from "./testing-framework";
import CodeAnalysisSystem from "./code-analysis-system";
import FileOperationsManager from "./file-operations-manager";
import DatabaseSchemaDesigner from "./database-schema-designer";
import RestApiClient from "./rest-api-client";
import AdvancedTextEditor from "./advanced-text-editor";
import AdvancedFileSystem from "./advanced-file-system";
import AdvancedViewSystem from "./advanced-view-system";
import AdvancedEditSystem from "./advanced-edit-system";
import AdvancedServerSystem from "./advanced-server-system";
import FunctionDiagnosticSystem from "./function-diagnostic-system";
import AdvancedEditorFeatures from "./advanced-editor-features";
import { LanguageFileCreator } from "./language-file-creator";
import SoundSettings from "@/components/ui/sound-settings";
import AdvancedLanguageSupport from "./advanced-language-support";
import CloudStorageSystem from "./cloud-storage-system";
import EnhancedDeveloperToolkit from "./enhanced-developer-toolkit";
import { CodePreview } from "./code-preview";
import { GameDevelopmentStudio } from "./game-development-studio";
import { AutoFileLoader } from "./auto-file-loader";
import NodeJSCompiler from "./nodejs-compiler";
import TypeScriptCompiler from "./typescript-compiler";
import TextEditor from "./text-editor";
import MissingFeaturesSystem from "./missing-features-system";
import FunctionDiagnostics from "./function-diagnostics";
import DockerIntegration from "./docker-integration";
import PerformanceMonitoring from "./performance-monitoring";
import { VisualEditor } from "./visual-editor";
import BracketMatching from "./bracket-matching";
import MultipleCursors from "./multiple-cursors";
import CodeNavigation from "./code-navigation";
import EnhancedAutocomplete from "./enhanced-autocomplete";
import CodeRefactoring from "./code-refactoring";
import PWAServiceWorker from "./pwa-service-worker";
import StatePersistence from "./state-persistence";
import ErrorBoundary from "./error-boundary";
import AccessibilityManager from "./accessibility-manager";
import MobileResponsive from "./mobile-responsive";
import SmartCodeSuggestions from "./smart-code-suggestions";
import ImportExportManager from "./import-export-manager";


export default function TopMenuBar() {
  const { createNewFile, saveCurrentFile, openFile, refreshAllFiles } = useIDEState();
  const [showAbout, setShowAbout] = useState(false);
  const [showGameEngine, setShowGameEngine] = useState(false);
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  const [showSoundSettings, setShowSoundSettings] = useState(false);
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [showDebugger, setShowDebugger] = useState(false);
  const [showVersionControl, setShowVersionControl] = useState(false);
  const [showWorkspaceManager, setShowWorkspaceManager] = useState(false);
  const [showObjectStudio, setShowObjectStudio] = useState(false);
  const [showAudioVideoEditor, setShowAudioVideoEditor] = useState(false);
  const [showMathematicsLibrary, setShowMathematicsLibrary] = useState(false);
  const [showAccountManager, setShowAccountManager] = useState(false);
  const [showUpdateSystem, setShowUpdateSystem] = useState(false);
  const [showErrorLogging, setShowErrorLogging] = useState(false);
  const [showAutoCADBlueprint, setShowAutoCADBlueprint] = useState(false);
  const [showCodeStyling, setShowCodeStyling] = useState(false);
  const [showServerManagement, setShowServerManagement] = useState(false);
  const [showFileManager, setShowFileManager] = useState(false);
  const [showSubscriptionManager, setShowSubscriptionManager] = useState(false);
  const [showPluginManager, setShowPluginManager] = useState(false);
  const [showLanguageSupport, setShowLanguageSupport] = useState(false);
  const [showMissingFeatures, setShowMissingFeatures] = useState(false);
  const [showFunctionDiagnostics, setShowFunctionDiagnostics] = useState(false);
  const [showDockerIntegration, setShowDockerIntegration] = useState(false);
  const [showPluginMarketplace, setShowPluginMarketplace] = useState(false);
  const [showPerformanceMonitoring, setShowPerformanceMonitoring] = useState(false);
  const [showAdvancedEditorFeatures, setShowAdvancedEditorFeatures] = useState(false);
  const [showCloudStorage, setShowCloudStorage] = useState(false);
  const [showEnhancedDevToolkit, setShowEnhancedDevToolkit] = useState(false);
  const [showGitHubIntegration, setShowGitHubIntegration] = useState(false);
  const [showMissionSystem, setShowMissionSystem] = useState(false);
  const [showDatabaseManager, setShowDatabaseManager] = useState(false);
  const [showPerformanceMonitor, setShowPerformanceMonitor] = useState(false);
  const [showCodeFormatter, setShowCodeFormatter] = useState(false);
  const [showPackageManager, setShowPackageManager] = useState(false);
  const [showLanguageServer, setShowLanguageServer] = useState(false);
  const [showDeployManager, setShowDeployManager] = useState(false);
  const [showDeveloperToolkit, setShowDeveloperToolkit] = useState(false);
  const [showDocumentationGenerator, setShowDocumentationGenerator] = useState(false);
  const [showWriteTool, setShowWriteTool] = useState(false);
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const [showUserAccountManager, setShowUserAccountManager] = useState(false);
  const [showPlatformSupport, setShowPlatformSupport] = useState(false);
  const [showMultiCursorEditor, setShowMultiCursorEditor] = useState(false);
  const [showCodeFolding, setShowCodeFolding] = useState(false);
  const [showIntelliSense, setShowIntelliSense] = useState(false);
  const [showMultiTerminal, setShowMultiTerminal] = useState(false);
  const [showCollaboration, setShowCollaboration] = useState(false);
  const [showEnhancedFileExplorer, setShowEnhancedFileExplorer] = useState(false);
  const [showExtensionsPanel, setShowExtensionsPanel] = useState(false);
  const [showSyntaxHighlighting, setShowSyntaxHighlighting] = useState(false);
  const [showTestingFramework, setShowTestingFramework] = useState(false);
  const [showCodeAnalysis, setShowCodeAnalysis] = useState(false);
  const [showFileOperations, setShowFileOperations] = useState(false);
  const [showDatabaseDesigner, setShowDatabaseDesigner] = useState(false);
  const [showRestApiClient, setShowRestApiClient] = useState(false);
  const [showAdvancedTextEditor, setShowAdvancedTextEditor] = useState(false);
  const [showAdvancedFileSystem, setShowAdvancedFileSystem] = useState(false);
  const [showAdvancedViewSystem, setShowAdvancedViewSystem] = useState(false);
  const [showAdvancedEditSystem, setShowAdvancedEditSystem] = useState(false);
  const [showAdvancedServerSystem, setShowAdvancedServerSystem] = useState(false);
  const [showIDELogicSystem, setShowIDELogicSystem] = useState(false);
  const [showSubMenuManager, setShowSubMenuManager] = useState(false);
  const [showCodePreview, setShowCodePreview] = useState(false);
  const [showGameStudio, setShowGameStudio] = useState(false);
  const [showUMLDesigner, setShowUMLDesigner] = useState(false);
  const [showMobileFramework, setShowMobileFramework] = useState(false);
  const [showLanguageFileCreator, setShowLanguageFileCreator] = useState(false);
  const [showNodeJSCompiler, setShowNodeJSCompiler] = useState(false);
  const [showTypeScriptCompiler, setShowTypeScriptCompiler] = useState(false);
  const [showTextEditor, setShowTextEditor] = useState(false);
  const [showVisualEditor, setShowVisualEditor] = useState(false);
  const [showBracketMatching, setShowBracketMatching] = useState(false);
  const [showMultipleCursors, setShowMultipleCursors] = useState(false);
  const [showCodeNavigation, setShowCodeNavigation] = useState(false);
  const [showEnhancedAutocomplete, setShowEnhancedAutocomplete] = useState(false);
  const [showCodeRefactoring, setShowCodeRefactoring] = useState(false);
  
  // PWA and Advanced Features
  const [showPWAServiceWorker, setShowPWAServiceWorker] = useState(false);
  const [showStatePersistence, setShowStatePersistence] = useState(false);
  const [showAccessibilityManager, setShowAccessibilityManager] = useState(false);
  const [showMobileResponsive, setShowMobileResponsive] = useState(false);
  const [showSmartCodeSuggestions, setShowSmartCodeSuggestions] = useState(false);
  const [showImportExportManager, setShowImportExportManager] = useState(false);

  const [currentUser, setCurrentUser] = useState<any>(null);
  const { currentTheme } = useTheme();

  const menuItems = [
    {
      label: "File",
      items: [
        { label: "New File", action: () => setShowLanguageFileCreator(true), shortcut: "Ctrl+N" },
        { label: "New Project", action: () => { document.dispatchEvent(new CustomEvent('ide:new-project')); console.log("New Project created"); }, shortcut: "Ctrl+Shift+N" },
        { label: "Open File", action: () => { document.dispatchEvent(new CustomEvent('ide:open-file')); console.log("Open File dialog triggered"); }, shortcut: "Ctrl+O" },
        { label: "Open Folder", action: () => { document.dispatchEvent(new CustomEvent('ide:open-folder')); console.log("Open Folder dialog triggered"); }, shortcut: "Ctrl+K Ctrl+O" },
        { label: "File Manager", action: () => setShowFileManager(true), shortcut: "Ctrl+Shift+E" },
        { label: "Enhanced File Explorer", action: () => setShowEnhancedFileExplorer(true), shortcut: "Ctrl+Alt+E" },
        { label: "Save", action: () => saveCurrentFile(), shortcut: "Ctrl+S" },
        { label: "Save As", action: () => { document.dispatchEvent(new CustomEvent('ide:save-as')); console.log("Save As dialog opened"); }, shortcut: "Ctrl+Shift+S" },
        { label: "Save All", action: () => { document.dispatchEvent(new CustomEvent('ide:save-all')); console.log("All files saved"); }, shortcut: "Ctrl+K S" },
        { label: "Refresh Files", action: () => refreshAllFiles(), shortcut: "F5" },
        { label: "Import/Export Manager", action: () => setShowImportExportManager(true), shortcut: "Ctrl+Shift+I" },
        { label: "Export Project", action: () => { document.dispatchEvent(new CustomEvent('ide:export-project')); console.log("Project export initiated"); } },
        { label: "Platform Support", action: () => setShowPlatformSupport(true), shortcut: "Ctrl+Shift+P" },
        { label: "Project Settings", action: () => { document.dispatchEvent(new CustomEvent('ide:project-settings')); console.log("Project Settings opened"); } },
        { label: "Close Tab", action: () => { document.dispatchEvent(new CustomEvent('ide:close-tab')); console.log("Tab closed"); }, shortcut: "Ctrl+W" },
        { label: "Close All Tabs", action: () => { document.dispatchEvent(new CustomEvent('ide:close-all-tabs')); console.log("All tabs closed"); }, shortcut: "Ctrl+Shift+W" },
      ]
    },
    {
      label: "Edit", 
      items: [
        { label: "Undo", action: () => { document.execCommand('undo'); console.log("Undo executed"); }, shortcut: "Ctrl+Z" },
        { label: "Redo", action: () => { document.execCommand('redo'); console.log("Redo executed"); }, shortcut: "Ctrl+Y" },
        { label: "Cut", action: () => { document.execCommand('cut'); console.log("Cut executed"); }, shortcut: "Ctrl+X" },
        { label: "Copy", action: () => { document.execCommand('copy'); console.log("Copy executed"); }, shortcut: "Ctrl+C" },
        { label: "Paste", action: () => { document.execCommand('paste'); console.log("Paste executed"); }, shortcut: "Ctrl+V" },
        { label: "Select All", action: () => { document.execCommand('selectAll'); console.log("Select All executed"); }, shortcut: "Ctrl+A" },
        { label: "Find", action: () => { document.dispatchEvent(new CustomEvent('ide:show-find')); console.log("Find dialog opened"); }, shortcut: "Ctrl+F" },
        { label: "Replace", action: () => { document.dispatchEvent(new CustomEvent('ide:show-replace')); console.log("Replace dialog opened"); }, shortcut: "Ctrl+H" },
        { label: "Find in Files", action: () => { document.dispatchEvent(new CustomEvent('ide:show-search')); console.log("Find in Files activated"); }, shortcut: "Ctrl+Shift+F" },
        { label: "Go to Line", action: () => { document.dispatchEvent(new CustomEvent('ide:goto-line')); console.log("Go to Line dialog opened"); }, shortcut: "Ctrl+G" },
        { label: "Format Document", action: () => { document.dispatchEvent(new CustomEvent('ide:format-document')); console.log("Document formatted"); }, shortcut: "Shift+Alt+F" },
        { label: "Toggle Comment", action: () => { document.dispatchEvent(new CustomEvent('ide:toggle-comment')); console.log("Comments toggled"); }, shortcut: "Ctrl+/" },
        { label: "Indent", action: () => { document.dispatchEvent(new CustomEvent('ide:indent')); console.log("Text indented"); }, shortcut: "Tab" },
        { label: "Outdent", action: () => { document.dispatchEvent(new CustomEvent('ide:outdent')); console.log("Text outdented"); }, shortcut: "Shift+Tab" },
        { label: "Multi-Cursor Editor", action: () => setShowMultiCursorEditor(true), shortcut: "Ctrl+Alt+M" },
        { label: "Code Folding", action: () => setShowCodeFolding(true), shortcut: "Ctrl+Shift+[" },
        { label: "IntelliSense", action: () => setShowIntelliSense(true), shortcut: "Ctrl+Space" },
        { label: "Syntax Highlighting", action: () => setShowSyntaxHighlighting(true), shortcut: "Ctrl+K Ctrl+H" },
        { label: "Testing Framework", action: () => setShowTestingFramework(true), shortcut: "Ctrl+Shift+T" },
        { label: "Code Analysis", action: () => setShowCodeAnalysis(true), shortcut: "Ctrl+Shift+A" },
        { label: "File Operations Manager", action: () => setShowFileOperations(true), shortcut: "Ctrl+Alt+F" },
        { label: "Database Schema Designer", action: () => setShowDatabaseDesigner(true), shortcut: "Ctrl+Alt+D" },
        { label: "REST API Client", action: () => setShowRestApiClient(true), shortcut: "Ctrl+Alt+R" },
        { label: "Advanced Text Editor", action: () => setShowAdvancedTextEditor(true), shortcut: "Ctrl+Alt+T" },
        { label: "Advanced File System", action: () => setShowAdvancedFileSystem(true), shortcut: "Ctrl+Alt+E" },
        { label: "Advanced View System", action: () => setShowAdvancedViewSystem(true), shortcut: "Ctrl+Alt+V" },
        { label: "Advanced Edit System", action: () => setShowAdvancedEditSystem(true), shortcut: "Ctrl+Alt+I" },
        { label: "Advanced Server System", action: () => setShowAdvancedServerSystem(true), shortcut: "Ctrl+Alt+S" },
      ]
    },
    {
      label: "View",
      items: [
        { label: "Explorer", action: () => { document.dispatchEvent(new CustomEvent('ide:toggle-sidebar')); console.log("Explorer toggled"); }, shortcut: "Ctrl+Shift+E" },
        { label: "Search", action: () => { document.dispatchEvent(new CustomEvent('ide:show-search')); console.log("Search panel opened"); }, shortcut: "Ctrl+Shift+F" },
        { label: "Source Control", action: () => setShowVersionControl(true), shortcut: "Ctrl+Shift+G" },
        { label: "Debug Console", action: () => setShowDebugger(true), shortcut: "Ctrl+Shift+D" },
        { label: "Extensions", action: () => setShowExtensionsPanel(true), shortcut: "Ctrl+Shift+X" },
        { label: "Terminal", action: () => { document.dispatchEvent(new CustomEvent('ide:toggle-terminal')); console.log("Terminal toggled"); }, shortcut: "Ctrl+`" },
        { label: "Command Palette", action: () => { document.dispatchEvent(new CustomEvent('ide:show-command-palette')); console.log("Command Palette opened"); }, shortcut: "Ctrl+Shift+P" },
        { label: "Toggle Sidebar", action: () => { document.dispatchEvent(new CustomEvent('ide:toggle-sidebar')); console.log("Sidebar toggled"); }, shortcut: "Ctrl+B" },
        { label: "AI Assistant", action: () => setShowAIAssistant(true), shortcut: "Ctrl+I" },
        { label: "Multi-Terminal", action: () => setShowMultiTerminal(true), shortcut: "Ctrl+Shift+`" },
        { label: "Collaboration", action: () => setShowCollaboration(true), shortcut: "Ctrl+Shift+C" },
        { label: "Zoom In", action: () => { document.body.style.zoom = (parseFloat(document.body.style.zoom || '1') + 0.1).toString(); console.log("Zoomed in"); }, shortcut: "Ctrl+=" },
        { label: "Zoom Out", action: () => { document.body.style.zoom = Math.max(0.5, parseFloat(document.body.style.zoom || '1') - 0.1).toString(); console.log("Zoomed out"); }, shortcut: "Ctrl+-" },
        { label: "Reset Zoom", action: () => { document.body.style.zoom = '1'; console.log("Zoom reset"); }, shortcut: "Ctrl+0" },
      ]
    },
    {
      label: "Run",
      items: [
        { label: "Run Code", action: () => { document.dispatchEvent(new CustomEvent('ide:run-code')); console.log("Code execution started"); }, shortcut: "F5" },
        { label: "Debug Code", action: () => { setShowDebugger(true); console.log("Debug mode activated"); }, shortcut: "Ctrl+F5" },
        { label: "Run Terminal Command", action: () => { document.dispatchEvent(new CustomEvent('ide:focus-terminal')); console.log("Terminal focused for command"); }, shortcut: "Ctrl+Shift+T" },
        { label: "Build Project", action: () => { document.dispatchEvent(new CustomEvent('ide:build-project')); console.log("Project build initiated"); }, shortcut: "Ctrl+Shift+B" },
        { label: "Test Project", action: () => { document.dispatchEvent(new CustomEvent('ide:test-project')); console.log("Project tests started"); }, shortcut: "Ctrl+Shift+T" },
        { label: "Toggle Breakpoint", action: () => { document.dispatchEvent(new CustomEvent('ide:toggle-breakpoint')); console.log("Breakpoint toggled"); }, shortcut: "F9" },
        { label: "Step Over", action: () => { document.dispatchEvent(new CustomEvent('ide:step-over')); console.log("Step over executed"); }, shortcut: "F10" },
        { label: "Step Into", action: () => { document.dispatchEvent(new CustomEvent('ide:step-into')); console.log("Step into executed"); }, shortcut: "F11" },
        { label: "Step Out", action: () => { document.dispatchEvent(new CustomEvent('ide:step-out')); console.log("Step out executed"); }, shortcut: "Shift+F11" },
        { label: "Stop Debugging", action: () => { document.dispatchEvent(new CustomEvent('ide:stop-debug')); console.log("Debugging stopped"); }, shortcut: "Shift+F5" },
      ]
    },
    {
      label: "Tools",
      items: [
        { label: "AI Assistant", action: () => { setShowAIAssistant(true); console.log("AI Assistant opened"); }, shortcut: "Ctrl+I" },
        { label: "Text Editor", action: () => { setShowTextEditor(true); console.log("Text Editor opened"); }, shortcut: "Ctrl+Shift+E" },
        { label: "Visual Editor", action: () => { setShowVisualEditor(true); console.log("Visual Editor opened"); }, shortcut: "Ctrl+Shift+V" },
        { type: "separator" },
        { label: "Bracket Matching", action: () => { setShowBracketMatching(true); console.log("Bracket Matching opened"); }, shortcut: "Ctrl+B" },
        { label: "Multiple Cursors", action: () => { setShowMultipleCursors(true); console.log("Multiple Cursors opened"); }, shortcut: "Ctrl+Alt+C" },
        { label: "Code Navigation", action: () => { setShowCodeNavigation(true); console.log("Code Navigation opened"); }, shortcut: "F12" },
        { label: "Enhanced Auto-complete", action: () => { setShowEnhancedAutocomplete(true); console.log("Enhanced Auto-complete opened"); }, shortcut: "Ctrl+Space" },
        { label: "Code Refactoring", action: () => { setShowCodeRefactoring(true); console.log("Code Refactoring opened"); }, shortcut: "Ctrl+Shift+R" },
        { label: "Node.js Compiler", action: () => { setShowNodeJSCompiler(true); console.log("Node.js Compiler opened"); }, shortcut: "Ctrl+Shift+J" },
        { label: "TypeScript Compiler", action: () => { setShowTypeScriptCompiler(true); console.log("TypeScript Compiler opened"); }, shortcut: "Ctrl+Shift+T" },
        { label: "Advanced Debugger", action: () => { setShowDebugger(true); console.log("Advanced Debugger opened"); }, shortcut: "F5" },
        { label: "Version Control", action: () => { setShowVersionControl(true); console.log("Version Control opened"); }, shortcut: "Ctrl+Shift+G" },
        { label: "GitHub Integration", action: () => { setShowGitHubIntegration(true); console.log("GitHub Integration opened"); }, shortcut: "Ctrl+Shift+H" },
        { label: "Mission System", action: () => { setShowMissionSystem(true); console.log("Mission System opened"); }, shortcut: "Ctrl+Alt+M" },
        { label: "UML Designer", action: () => { setShowUMLDesigner(true); console.log("UML Designer opened"); }, shortcut: "Ctrl+Shift+U" },
        { label: "Mobile Framework", action: () => { setShowMobileFramework(true); console.log("Mobile Framework opened"); }, shortcut: "Ctrl+Shift+F" },
        { label: "Game Engine", action: () => { setShowGameEngine(true); console.log("Game Engine opened"); }, shortcut: "Ctrl+Alt+G" },
        { label: "Workspace Manager", action: () => { setShowWorkspaceManager(true); console.log("Workspace Manager opened"); }, shortcut: "Ctrl+Shift+W" },
        { label: "2D/3D Object Studio", action: () => { setShowObjectStudio(true); console.log("Object Studio opened"); }, shortcut: "Ctrl+Shift+O" },
        { label: "Audio/Video Editor", action: () => { setShowAudioVideoEditor(true); console.log("Audio/Video Editor opened"); }, shortcut: "Ctrl+Shift+A" },
        { label: "Mathematics Library", action: () => { setShowMathematicsLibrary(true); console.log("Mathematics Library opened"); }, shortcut: "Ctrl+Shift+M" },
        { label: "Plugin Manager", action: () => { setShowPluginManager(true); console.log("Plugin Manager opened"); }, shortcut: "Ctrl+Shift+P" },
        { label: "Plugin Marketplace", action: () => { setShowPluginMarketplace(true); console.log("Plugin Marketplace opened"); }, shortcut: "Ctrl+Alt+P" },
        { label: "Categorized Toolbar", action: () => { console.log("Categorized Toolbar toggled"); }, shortcut: "Ctrl+Alt+T" },
        { label: "AutoCAD Blueprint System", action: () => { setShowAutoCADBlueprint(true); console.log("AutoCAD Blueprint opened"); }, shortcut: "Ctrl+Alt+B" },
        { label: "Code Styling System", action: () => { setShowCodeStyling(true); console.log("Code Styling System opened"); }, shortcut: "Ctrl+Alt+S" },
        { label: "Update System", action: () => { setShowUpdateSystem(true); console.log("Update System opened"); }, shortcut: "Ctrl+Shift+U" },
        { label: "Error Logging", action: () => { setShowErrorLogging(true); console.log("Error Logging opened"); }, shortcut: "Ctrl+Shift+E" },
        { label: "Subscription Manager", action: () => { setShowSubscriptionManager(true); console.log("Subscription Manager opened"); }, shortcut: "Ctrl+Shift+S" },
        { label: "Database Manager", action: () => { setShowDatabaseManager(true); console.log("Database Manager opened"); }, shortcut: "Ctrl+Shift+D" },
        { label: "Code Formatter", action: () => { setShowCodeFormatter(true); console.log("Code Formatter opened"); }, shortcut: "Shift+Alt+F" },
        { label: "Package Manager", action: () => { setShowPackageManager(true); console.log("Package Manager opened"); }, shortcut: "Ctrl+Shift+N" },
        { label: "Performance Monitor", action: () => { setShowPerformanceMonitor(true); console.log("Performance Monitor opened"); }, shortcut: "Ctrl+Shift+R" },
        { label: "Language Server", action: () => { setShowLanguageServer(true); console.log("Language Server opened"); }, shortcut: "Ctrl+Shift+L" },
        { label: "Deploy Manager", action: () => { setShowDeployManager(true); console.log("Deploy Manager opened"); }, shortcut: "Ctrl+Shift+Y" },
        { label: "Developer Toolkit", action: () => { setShowDeveloperToolkit(true); console.log("Developer Toolkit opened"); }, shortcut: "Ctrl+Alt+T" },
        { label: "Documentation Generator", action: () => { setShowDocumentationGenerator(true); console.log("Documentation Generator opened"); }, shortcut: "Ctrl+Alt+D" },
        { label: "Write Tool", action: () => { setShowWriteTool(true); console.log("Write Tool opened"); }, shortcut: "Ctrl+Alt+W" },
        { label: "IDE Logic System", action: () => { setShowIDELogicSystem(true); console.log("IDE Logic System opened"); }, shortcut: "Ctrl+Alt+I" },
        { label: "Sub-Menu Manager", action: () => { setShowSubMenuManager(true); console.log("Sub-Menu Manager opened"); }, shortcut: "Ctrl+Alt+L" },
        { label: "Code Preview", action: () => { setShowCodePreview(true); console.log("Code Preview opened"); }, shortcut: "Ctrl+Alt+P" },
        { label: "Game Development Studio", action: () => { setShowGameStudio(true); console.log("Game Development Studio opened"); }, shortcut: "Ctrl+Alt+G" },
        { label: "Missing Features Audit", action: () => { setShowMissingFeatures(true); console.log("Missing Features Audit opened"); }, shortcut: "Ctrl+Shift+M" },
        { label: "Function Diagnostics", action: () => { setShowFunctionDiagnostics(true); console.log("Function Diagnostics opened"); }, shortcut: "Ctrl+Shift+X" },
        { label: "Advanced Editor Features", action: () => { setShowAdvancedEditorFeatures(true); console.log("Advanced Editor Features opened"); }, shortcut: "Ctrl+Shift+A" },
        { type: 'separator' },
        { label: "Docker Integration", action: () => { setShowDockerIntegration(true); console.log("Docker Integration opened"); }, shortcut: "Ctrl+Alt+D" },
        { label: "Plugin Marketplace", action: () => { setShowPluginMarketplace(true); console.log("Plugin Marketplace opened"); }, shortcut: "Ctrl+Alt+P" },
        { label: "Performance Monitoring", action: () => { setShowPerformanceMonitoring(true); console.log("Performance Monitoring opened"); }, shortcut: "Ctrl+Alt+R" },
        { type: 'separator' },
        { label: "PWA Service Worker", action: () => { setShowPWAServiceWorker(true); console.log("PWA Service Worker opened"); }, shortcut: "Ctrl+Alt+W" },
        { label: "State Persistence", action: () => { setShowStatePersistence(true); console.log("State Persistence opened"); }, shortcut: "Ctrl+Alt+S" },
        { label: "Accessibility Manager", action: () => { setShowAccessibilityManager(true); console.log("Accessibility Manager opened"); }, shortcut: "Ctrl+Alt+A" },
        { label: "Mobile Responsive", action: () => { setShowMobileResponsive(true); console.log("Mobile Responsive opened"); }, shortcut: "Ctrl+Alt+M" },
        { label: "Smart Code Suggestions", action: () => { setShowSmartCodeSuggestions(true); console.log("Smart Code Suggestions opened"); }, shortcut: "Ctrl+Alt+I" },
      ]
    },
    {
      label: "Server",
      items: [
        { label: "Server Management", action: () => setShowServerManagement(true), shortcut: "Ctrl+Alt+M" },
        { label: "Start Development Server", action: () => { document.dispatchEvent(new CustomEvent('ide:start-dev-server')); console.log("Development server starting..."); }, shortcut: "Ctrl+Alt+D" },
        { label: "Deploy to Production", action: () => { setShowDeployManager(true); console.log("Deploy manager opened"); }, shortcut: "Ctrl+Alt+P" },
        { label: "Database Console", action: () => { setShowDatabaseManager(true); console.log("Database console opened"); }, shortcut: "Ctrl+Alt+B" },
        { label: "Web View Preview", action: () => { window.open(window.location.origin, "_blank"); console.log("Preview opened in new tab"); }, shortcut: "Ctrl+Alt+W" },
        { label: "Server Logs", action: () => { document.dispatchEvent(new CustomEvent('ide:show-server-logs')); console.log("Server logs displayed"); }, shortcut: "Ctrl+Alt+L" },
        { label: "Performance Metrics", action: () => { setShowPerformanceMonitor(true); console.log("Performance monitor opened"); } },
        { label: "API Documentation", action: () => { document.dispatchEvent(new CustomEvent('ide:show-api-docs')); console.log("API documentation opened"); } },
      ]
    },
    {
      label: "Window",
      items: [
        { label: "New Window", action: () => { window.open(window.location.href, "_blank"); console.log("New window opened"); }, shortcut: "Ctrl+Shift+N" },
        { label: "Close Window", action: () => { window.close(); console.log("Window close attempted"); }, shortcut: "Ctrl+Shift+W" },
        { label: "Split Editor", action: () => { document.dispatchEvent(new CustomEvent('ide:split-editor')); console.log("Split editor activated"); }, shortcut: "Ctrl+\\" },
        { label: "Switch Window", action: () => { document.dispatchEvent(new CustomEvent('ide:switch-window')); console.log("Window switching activated"); }, shortcut: "Alt+Tab" },
        { label: "Previous Tab", action: () => { document.dispatchEvent(new CustomEvent('ide:previous-tab')); console.log("Previous tab selected"); }, shortcut: "Ctrl+PageUp" },
        { label: "Next Tab", action: () => { document.dispatchEvent(new CustomEvent('ide:next-tab')); console.log("Next tab selected"); }, shortcut: "Ctrl+PageDown" },
        { label: "Fullscreen", action: () => { document.documentElement.requestFullscreen(); console.log("Fullscreen mode activated"); }, shortcut: "F11" },
        { label: "Developer Tools", action: () => { console.log("Use F12 to open browser developer tools"); }, shortcut: "F12" },
      ]
    },
    {
      label: "Help",
      items: [
        { label: "Welcome Guide", action: () => document.dispatchEvent(new CustomEvent('ide:show-welcome')) },
        { label: "Show All Commands", action: () => document.dispatchEvent(new CustomEvent('ide:show-command-palette')), shortcut: "Ctrl+Shift+P" },
        { label: "Keyboard Shortcuts", action: () => document.dispatchEvent(new CustomEvent('ide:show-shortcuts')), shortcut: "Ctrl+K Ctrl+S" },
        { label: "AI Assistant", action: () => setShowAIAssistant(true), shortcut: "Ctrl+I" },
        { label: "Documentation", action: () => window.open("https://docs.deepblue-octopus.dev", "_blank") },
        { label: "Community Forum", action: () => window.open("https://community.deepblue-octopus.dev", "_blank") },
        { label: "Video Tutorials", action: () => window.open("https://learn.deepblue-octopus.dev", "_blank") },
        { label: "Report Issue", action: () => window.open("https://github.com/apocalypsecode0/deepblue-octopus/issues", "_blank") },
        { label: "Feature Request", action: () => window.open("https://github.com/apocalypsecode0/deepblue-octopus/discussions", "_blank") },
        { label: "Release Notes", action: () => setShowUpdateSystem(true) },
        { label: "Check for Updates", action: () => setShowUpdateSystem(true) },
        { label: "Contact Support", action: () => window.open("mailto:stephend8846@gmail.com", "_blank") },
        { label: "About DeepBlue:Octopus", action: () => setShowAbout(true) },
      ]
    }
  ];

  return (
    <>
      <div className="ide-panel border-b ide-border h-10 flex items-center px-4 text-sm">
        <div className="flex space-x-6">
          {menuItems.map((menu) => (
            <DropdownMenu key={menu.label}>
              <DropdownMenuTrigger className="cursor-pointer hover:bg-[var(--ide-bg)] px-2 py-1 rounded transition-colors">
                {menu.label}
              </DropdownMenuTrigger>
              <DropdownMenuContent className="ide-panel border-[var(--ide-border)]">
                {menu.items.map((item, index) => (
                  item.type === 'separator' ? (
                    <DropdownMenuSeparator key={`separator-${index}`} />
                  ) : (
                    <DropdownMenuItem
                      key={item.label || `item-${index}`}
                      onClick={item.action}
                      className="text-[var(--ide-text)] hover:bg-[var(--ide-bg)] cursor-pointer flex justify-between"
                    >
                      <span>{item.label}</span>
                      {item.shortcut && (
                        <span className="text-[var(--ide-text-secondary)] text-xs ml-4">
                          {item.shortcut}
                        </span>
                      )}
                    </DropdownMenuItem>
                  )
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          ))}
        </div>
        <div className="ml-auto flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <TooltipWrapper
              title="Theme Selection"
              content="Switch between different themes including Deep Blue Octopus, Dark Professional, Light, Forest, Neon Cyber, and Fire Dragon"
              type="feature"
            >
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowThemeSelector(true)}
                className="text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)] p-1"
              >
                <Palette className="h-4 w-4" />
              </Button>
            </TooltipWrapper>
            
            <TooltipWrapper
              title="Sound Control"
              content="Enable/disable sound effects and adjust volume settings for IDE interactions"
              type="feature"
            >
              <SoundControl />
            </TooltipWrapper>
          </div>

          <div className="flex items-center space-x-4">
            {currentUser ? (
              <TooltipWrapper
                title="Account Management"
                content="Manage user profile, preferences, security settings, and view statistics"
                type="feature"
              >
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowUserAccountManager(true)}
                  className="text-blue-200 hover:bg-blue-800/50 hover:text-blue-100"
                >
                  <div className="h-4 w-4 mr-2 rounded-full bg-blue-500 flex items-center justify-center text-xs text-white">
                    {currentUser.firstName ? currentUser.firstName[0] : currentUser.username[0]}
                  </div>
                  {currentUser.firstName ? `${currentUser.firstName} ${currentUser.lastName}` : currentUser.username}
                </Button>
              </TooltipWrapper>
            ) : (
              <TooltipWrapper
                title="Login to IDE"
                content="Access your projects, settings, and advanced features"
                type="feature"
              >
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowAuthDialog(true)}
                  className="text-blue-200 hover:bg-blue-800/50 hover:text-blue-100"
                >
                  <div className="h-4 w-4 mr-2 rounded-full bg-gray-500 flex items-center justify-center text-xs text-white">?</div>
                  Login
                </Button>
              </TooltipWrapper>
            )}

            <TooltipWrapper
              title="DeepBlue:Octopus IDE"
              content="Professional web-based development environment with comprehensive language support, game engine, and advanced tools"
              type="info"
            >
              <div className="flex items-center space-x-2">
                <OctopusLogo size={20} animated={true} />
                <span className="ide-text-secondary font-semibold">DeepBlue:Octopus v1.5</span>
              </div>
            </TooltipWrapper>
          </div>
        </div>
      </div>

      {/* Dialog Components */}
      <AboutDialog 
        isOpen={showAbout} 
        onClose={() => setShowAbout(false)} 
      />
      <UMLDesigner 
        isOpen={showUMLDesigner} 
        onClose={() => setShowUMLDesigner(false)} 
      />
      <MobileFramework 
        isOpen={showMobileFramework} 
        onClose={() => setShowMobileFramework(false)} 
      />
      <GameEngine 
        isOpen={showGameEngine} 
        onClose={() => setShowGameEngine(false)} 
      />
      
      {showThemeSelector && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <ThemeSelector onClose={() => setShowThemeSelector(false)} />
        </div>
      )}
      
      <SoundSettings 
        isOpen={showSoundSettings} 
        onClose={() => setShowSoundSettings(false)} 
      />
      
      <AIAssistant
        isOpen={showAIAssistant}
        onClose={() => setShowAIAssistant(false)}
      />
      
      {showNodeJSCompiler && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="w-[95vw] h-[95vh] bg-background rounded-lg border shadow-lg">
            <NodeJSCompiler />
            <button
              onClick={() => setShowNodeJSCompiler(false)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-red-500 text-white hover:bg-red-600 flex items-center justify-center"
            >
              ×
            </button>
          </div>
        </div>
      )}

      {showTypeScriptCompiler && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="w-[95vw] h-[95vh] bg-background rounded-lg border shadow-lg relative">
            <TypeScriptCompiler />
            <button
              onClick={() => setShowTypeScriptCompiler(false)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-red-500 text-white hover:bg-red-600 flex items-center justify-center z-10"
            >
              ×
            </button>
          </div>
        </div>
      )}

      {showTextEditor && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="w-[95vw] h-[95vh] bg-background rounded-lg border shadow-lg relative">
            <TextEditor />
            <button
              onClick={() => setShowTextEditor(false)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-red-500 text-white hover:bg-red-600 flex items-center justify-center z-10"
            >
              ×
            </button>
          </div>
        </div>
      )}

      <VisualEditor
        isOpen={showVisualEditor}
        onClose={() => setShowVisualEditor(false)}
      />

      {showMissingFeatures && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="w-[95vw] h-[95vh] bg-background rounded-lg border shadow-lg relative">
            <MissingFeaturesSystem />
            <button
              onClick={() => setShowMissingFeatures(false)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-red-500 text-white hover:bg-red-600 flex items-center justify-center z-10"
            >
              ×
            </button>
          </div>
        </div>
      )}

      {showFunctionDiagnostics && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="w-[95vw] h-[95vh] bg-background rounded-lg border shadow-lg relative">
            <FunctionDiagnostics />
            <button
              onClick={() => setShowFunctionDiagnostics(false)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-red-500 text-white hover:bg-red-600 flex items-center justify-center z-10"
            >
              ×
            </button>
          </div>
        </div>
      )}
      
      <AdvancedDebugger
        isOpen={showDebugger}
        onClose={() => setShowDebugger(false)}
      />
      
      <UMLDesigner
        isOpen={showUMLDesigner}
        onClose={() => setShowUMLDesigner(false)}
      />
      
      <MobileFramework
        isOpen={showMobileFramework}
        onClose={() => setShowMobileFramework(false)}
      />
      
      <VersionControl
        isOpen={showVersionControl}
        onClose={() => setShowVersionControl(false)}
      />
      
      <WorkspaceManager
        isOpen={showWorkspaceManager}
        onClose={() => setShowWorkspaceManager(false)}
      />
      
      <ObjectStudio
        isOpen={showObjectStudio}
        onClose={() => setShowObjectStudio(false)}
      />
      
      <AudioVideoEditor
        isOpen={showAudioVideoEditor}
        onClose={() => setShowAudioVideoEditor(false)}
      />
      
      <MathematicsLibrary
        isOpen={showMathematicsLibrary}
        onClose={() => setShowMathematicsLibrary(false)}
      />
      
      <SystemAccountManager
        isOpen={showAccountManager}
        onClose={() => setShowAccountManager(false)}
      />
      
      <UpdateSystem
        isOpen={showUpdateSystem}
        onClose={() => setShowUpdateSystem(false)}
      />
      
      <ErrorLoggingSystem
        isOpen={showErrorLogging}
        onClose={() => setShowErrorLogging(false)}
      />
      
      <SubscriptionManager
        isOpen={showSubscriptionManager}
        onClose={() => setShowSubscriptionManager(false)}
      />
      
      <FileManager
        isOpen={showFileManager}
        onClose={() => setShowFileManager(false)}
      />
      
      <AutoCADBlueprintSystem
        isOpen={showAutoCADBlueprint}
        onClose={() => setShowAutoCADBlueprint(false)}
      />
      
      <CodeStylingSystem
        isOpen={showCodeStyling}
        onClose={() => setShowCodeStyling(false)}
      />
      
      <ServerManagement
        isOpen={showServerManagement}
        onClose={() => setShowServerManagement(false)}
      />
      
      <PluginManager
        isOpen={showPluginManager}
        onClose={() => setShowPluginManager(false)}
      />

      <PluginMarketplace
        isOpen={showPluginMarketplace}
        onClose={() => setShowPluginMarketplace(false)}
      />
      
      <GitHubIntegration
        isOpen={showGitHubIntegration}
        onClose={() => setShowGitHubIntegration(false)}
      />
      
      <MissionSystem
        isOpen={showMissionSystem}
        onClose={() => setShowMissionSystem(false)}
      />
      
      <DatabaseManager
        isOpen={showDatabaseManager}
        onClose={() => setShowDatabaseManager(false)}
      />
      
      <PerformanceMonitor
        isOpen={showPerformanceMonitor}
        onClose={() => setShowPerformanceMonitor(false)}
      />
      
      <CodeFormatter
        isOpen={showCodeFormatter}
        onClose={() => setShowCodeFormatter(false)}
      />
      
      <PackageManager
        isOpen={showPackageManager}
        onClose={() => setShowPackageManager(false)}
      />
      
      <LanguageServer
        isOpen={showLanguageServer}
        onClose={() => setShowLanguageServer(false)}
      />
      
      <DeployManager
        isOpen={showDeployManager}
        onClose={() => setShowDeployManager(false)}
      />
      
      <DeveloperToolkit
        isOpen={showDeveloperToolkit}
        onClose={() => setShowDeveloperToolkit(false)}
      />
      
      <DocumentationGenerator
        isOpen={showDocumentationGenerator}
        onClose={() => setShowDocumentationGenerator(false)}
      />
      
      <WriteTool
        isOpen={showWriteTool}
        onClose={() => setShowWriteTool(false)}
      />
      
      <PlatformSupport
        isOpen={showPlatformSupport}
        onClose={() => setShowPlatformSupport(false)}
      />
      
      <AuthDialog
        isOpen={showAuthDialog}
        onClose={() => setShowAuthDialog(false)}
        onAuthSuccess={(user) => {
          setCurrentUser(user);
          setShowAuthDialog(false);
        }}
      />
      
      {currentUser && (
        <UserAccountManager
          isOpen={showUserAccountManager}
          onClose={() => setShowUserAccountManager(false)}
          currentUser={currentUser}
          onSignOut={() => {
            setCurrentUser(null);
            setShowUserAccountManager(false);
          }}
        />
      )}

      <MultiCursorEditor 
        isOpen={showMultiCursorEditor}
        onClose={() => setShowMultiCursorEditor(false)}
      />
      
      <CodeFoldingSystem 
        isOpen={showCodeFolding}
        onClose={() => setShowCodeFolding(false)}
      />
      
      <IntelliSenseSystem 
        isOpen={showIntelliSense}
        onClose={() => setShowIntelliSense(false)}
      />
      
      <MultiTerminalSystem 
        isOpen={showMultiTerminal}
        onClose={() => setShowMultiTerminal(false)}
      />
      
      <RealTimeCollaboration 
        isOpen={showCollaboration}
        onClose={() => setShowCollaboration(false)}
      />

      <EnhancedFileExplorer
        isOpen={showEnhancedFileExplorer}
        onClose={() => setShowEnhancedFileExplorer(false)}
      />

      <ExtensionsPanel
        isOpen={showExtensionsPanel}
        onClose={() => setShowExtensionsPanel(false)}
      />

      <Collaboration
        isOpen={showCollaboration}
        onClose={() => setShowCollaboration(false)}
      />

      <SyntaxHighlightingSystem
        isOpen={showSyntaxHighlighting}
        onClose={() => setShowSyntaxHighlighting(false)}
      />

      <TestingFramework
        isOpen={showTestingFramework}
        onClose={() => setShowTestingFramework(false)}
      />

      <CodeAnalysisSystem
        isOpen={showCodeAnalysis}
        onClose={() => setShowCodeAnalysis(false)}
      />

      <FileOperationsManager
        isOpen={showFileOperations}
        onClose={() => setShowFileOperations(false)}
      />

      <DatabaseSchemaDesigner
        isOpen={showDatabaseDesigner}
        onClose={() => setShowDatabaseDesigner(false)}
      />

      <RestApiClient
        isOpen={showRestApiClient}
        onClose={() => setShowRestApiClient(false)}
      />

      <AdvancedTextEditor
        isOpen={showAdvancedTextEditor}
        onClose={() => setShowAdvancedTextEditor(false)}
      />

      <AdvancedFileSystem
        isOpen={showAdvancedFileSystem}
        onClose={() => setShowAdvancedFileSystem(false)}
      />

      <AdvancedViewSystem
        isOpen={showAdvancedViewSystem}
        onClose={() => setShowAdvancedViewSystem(false)}
      />

      <AdvancedEditSystem
        isOpen={showAdvancedEditSystem}
        onClose={() => setShowAdvancedEditSystem(false)}
      />

      <AdvancedServerSystem
        isOpen={showAdvancedServerSystem}
        onClose={() => setShowAdvancedServerSystem(false)}
      />

      <IDELogicSystem
        isOpen={showIDELogicSystem}
        onClose={() => setShowIDELogicSystem(false)}
      />

      <SubMenuManager
        isOpen={showSubMenuManager}
        onClose={() => setShowSubMenuManager(false)}
      />

      <CodePreview
        isOpen={showCodePreview}
        onClose={() => setShowCodePreview(false)}
      />

      <GameDevelopmentStudio
        isOpen={showGameStudio}
        onClose={() => setShowGameStudio(false)}
      />

      <GitHubIntegration
        isOpen={showGitHubIntegration}
        onClose={() => setShowGitHubIntegration(false)}
      />

      <MissingFeaturesSystem 
        isOpen={showMissingFeatures}
        onClose={() => setShowMissingFeatures(false)}
      />

      <FunctionDiagnosticSystem 
        isOpen={showFunctionDiagnostics}
        onClose={() => setShowFunctionDiagnostics(false)}
      />

      <AdvancedEditorFeatures 
        isOpen={showAdvancedEditorFeatures}
        onClose={() => setShowAdvancedEditorFeatures(false)}
      />

      <LanguageFileCreator 
        isOpen={showLanguageFileCreator}
        onClose={() => setShowLanguageFileCreator(false)}
      />

      <AutoFileLoader onFileOpen={openFile} />

      <DockerIntegration 
        isOpen={showDockerIntegration}
        onClose={() => setShowDockerIntegration(false)}
      />

      <PluginMarketplace 
        isOpen={showPluginMarketplace}
        onClose={() => setShowPluginMarketplace(false)}
      />

      <PerformanceMonitoring 
        isOpen={showPerformanceMonitoring}
        onClose={() => setShowPerformanceMonitoring(false)}
      />

      <VisualEditor 
        isOpen={showVisualEditor}
        onClose={() => setShowVisualEditor(false)}
      />

      <BracketMatching 
        isOpen={showBracketMatching}
        onClose={() => setShowBracketMatching(false)}
      />

      <MultipleCursors 
        isOpen={showMultipleCursors}
        onClose={() => setShowMultipleCursors(false)}
      />

      <CodeNavigation 
        isOpen={showCodeNavigation}
        onClose={() => setShowCodeNavigation(false)}
      />

      <EnhancedAutocomplete 
        isOpen={showEnhancedAutocomplete}
        onClose={() => setShowEnhancedAutocomplete(false)}
      />

      <CodeRefactoring 
        isOpen={showCodeRefactoring}
        onClose={() => setShowCodeRefactoring(false)}
      />

      {/* PWA and Advanced Features */}
      <PWAServiceWorker 
        isOpen={showPWAServiceWorker}
        onClose={() => setShowPWAServiceWorker(false)}
      />

      <StatePersistence 
        isOpen={showStatePersistence}
        onClose={() => setShowStatePersistence(false)}
      />

      <AccessibilityManager 
        isOpen={showAccessibilityManager}
        onClose={() => setShowAccessibilityManager(false)}
      />

      <MobileResponsive 
        isOpen={showMobileResponsive}
        onClose={() => setShowMobileResponsive(false)}
      />

      <SmartCodeSuggestions 
        isOpen={showSmartCodeSuggestions}
        onClose={() => setShowSmartCodeSuggestions(false)}
      />
      
      <ImportExportManager 
        isOpen={showImportExportManager}
        onClose={() => setShowImportExportManager(false)}
      />
    </>
  );
}
