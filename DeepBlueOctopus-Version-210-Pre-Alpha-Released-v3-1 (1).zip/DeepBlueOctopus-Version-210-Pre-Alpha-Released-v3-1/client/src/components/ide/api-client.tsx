import React, { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { 
  Send, Plus, Save, Folder, Globe, Code, 
  Clock, CheckCircle, XCircle, Copy, Download,
  Settings, Eye, Edit, Trash2, Play
} from "lucide-react";

interface APIClientProps {
  isOpen: boolean;
  onClose: () => void;
}

interface APIRequest {
  id: string;
  name: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  url: string;
  headers: Record<string, string>;
  body: string;
  params: Record<string, string>;
  auth: {
    type: 'none' | 'bearer' | 'basic' | 'apikey';
    token?: string;
    username?: string;
    password?: string;
    key?: string;
    value?: string;
  };
  environment: string;
  collection: string;
  lastRun?: Date;
}

interface APIResponse {
  status: number;
  statusText: string;
  headers: Record<string, string>;
  body: string;
  time: number;
  size: number;
  timestamp: Date;
}

interface Collection {
  id: string;
  name: string;
  description: string;
  requests: APIRequest[];
}

interface Environment {
  id: string;
  name: string;
  variables: Record<string, string>;
  isActive: boolean;
}

export default function APIClient({ isOpen, onClose }: APIClientProps) {
  const [collections, setCollections] = useState<Collection[]>([
    {
      id: '1',
      name: 'User API',
      description: 'User management endpoints',
      requests: [
        {
          id: '1',
          name: 'Get Users',
          method: 'GET',
          url: '{{baseUrl}}/api/users',
          headers: { 'Content-Type': 'application/json' },
          body: '',
          params: { limit: '10', offset: '0' },
          auth: { type: 'bearer', token: '{{authToken}}' },
          environment: 'development',
          collection: '1',
          lastRun: new Date(Date.now() - 2 * 60 * 60 * 1000)
        },
        {
          id: '2',
          name: 'Create User',
          method: 'POST',
          url: '{{baseUrl}}/api/users',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: "John Doe",
            email: "john@example.com",
            role: "user"
          }, null, 2),
          params: {},
          auth: { type: 'bearer', token: '{{authToken}}' },
          environment: 'development',
          collection: '1'
        }
      ]
    }
  ]);

  const [environments, setEnvironments] = useState<Environment[]>([
    {
      id: '1',
      name: 'Development',
      variables: {
        baseUrl: 'http://localhost:3000',
        authToken: 'dev_token_123'
      },
      isActive: true
    },
    {
      id: '2',
      name: 'Production',
      variables: {
        baseUrl: 'https://api.example.com',
        authToken: 'prod_token_456'
      },
      isActive: false
    }
  ]);

  const [selectedRequest, setSelectedRequest] = useState<APIRequest | null>(null);
  const [currentResponse, setCurrentResponse] = useState<APIResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [requestHistory, setRequestHistory] = useState<Array<{ request: APIRequest; response: APIResponse }>>([]);

  const { toast } = useToast();

  const activeEnvironment = environments.find(env => env.isActive);

  const replaceVariables = useCallback((text: string, variables: Record<string, string>) => {
    return text.replace(/\{\{(\w+)\}\}/g, (match, key) => variables[key] || match);
  }, []);

  const sendRequest = useCallback(async () => {
    if (!selectedRequest || !activeEnvironment) return;

    setIsLoading(true);
    const startTime = Date.now();

    try {
      // Replace environment variables
      const url = replaceVariables(selectedRequest.url, activeEnvironment.variables);
      const headers = { ...selectedRequest.headers };

      // Apply authentication
      if (selectedRequest.auth.type === 'bearer' && selectedRequest.auth.token) {
        headers['Authorization'] = `Bearer ${replaceVariables(selectedRequest.auth.token, activeEnvironment.variables)}`;
      } else if (selectedRequest.auth.type === 'basic' && selectedRequest.auth.username && selectedRequest.auth.password) {
        const credentials = btoa(`${selectedRequest.auth.username}:${selectedRequest.auth.password}`);
        headers['Authorization'] = `Basic ${credentials}`;
      } else if (selectedRequest.auth.type === 'apikey' && selectedRequest.auth.key && selectedRequest.auth.value) {
        headers[selectedRequest.auth.key] = selectedRequest.auth.value;
      }

      // Simulate API request
      await new Promise(resolve => setTimeout(resolve, Math.random() * 2000 + 500));

      const endTime = Date.now();
      const responseTime = endTime - startTime;

      // Generate mock response based on request
      const mockResponse: APIResponse = {
        status: selectedRequest.method === 'POST' ? 201 : 200,
        statusText: selectedRequest.method === 'POST' ? 'Created' : 'OK',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': '234',
          'Server': 'nginx/1.18.0'
        },
        body: selectedRequest.method === 'GET' 
          ? JSON.stringify({
              users: [
                { id: 1, name: "John Doe", email: "john@example.com" },
                { id: 2, name: "Jane Smith", email: "jane@example.com" }
              ],
              total: 2
            }, null, 2)
          : JSON.stringify({
              id: 3,
              name: "John Doe",
              email: "john@example.com",
              createdAt: new Date().toISOString()
            }, null, 2),
        time: responseTime,
        size: 234,
        timestamp: new Date()
      };

      setCurrentResponse(mockResponse);
      setRequestHistory(prev => [{ request: selectedRequest, response: mockResponse }, ...prev.slice(0, 19)]);

      // Update last run time
      setCollections(prev => prev.map(collection => ({
        ...collection,
        requests: collection.requests.map(req => 
          req.id === selectedRequest.id ? { ...req, lastRun: new Date() } : req
        )
      })));

      toast({
        title: "Request completed",
        description: `${selectedRequest.method} ${url} - ${mockResponse.status} ${mockResponse.statusText}`,
      });

    } catch (error) {
      const errorResponse: APIResponse = {
        status: 500,
        statusText: 'Internal Server Error',
        headers: {},
        body: JSON.stringify({ error: 'Network error occurred' }, null, 2),
        time: Date.now() - startTime,
        size: 0,
        timestamp: new Date()
      };

      setCurrentResponse(errorResponse);
      
      toast({
        title: "Request failed",
        description: "Network error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [selectedRequest, activeEnvironment, replaceVariables, toast]);

  const saveRequest = useCallback(() => {
    if (!selectedRequest) return;

    // Update existing request or create new one
    setCollections(prev => prev.map(collection => 
      collection.id === selectedRequest.collection
        ? {
            ...collection,
            requests: collection.requests.find(r => r.id === selectedRequest.id)
              ? collection.requests.map(r => r.id === selectedRequest.id ? selectedRequest : r)
              : [...collection.requests, selectedRequest]
          }
        : collection
    ));

    toast({
      title: "Request saved",
      description: `${selectedRequest.name} has been saved`,
    });
  }, [selectedRequest, toast]);

  const createNewRequest = useCallback(() => {
    const newRequest: APIRequest = {
      id: Date.now().toString(),
      name: 'New Request',
      method: 'GET',
      url: 'https://api.example.com/',
      headers: { 'Content-Type': 'application/json' },
      body: '',
      params: {},
      auth: { type: 'none' },
      environment: activeEnvironment?.id || '1',
      collection: collections[0]?.id || '1'
    };

    setSelectedRequest(newRequest);
  }, [activeEnvironment, collections]);

  const exportCollection = useCallback((collectionId: string) => {
    const collection = collections.find(c => c.id === collectionId);
    if (!collection) return;

    const exportData = {
      collection,
      environments,
      exportedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${collection.name.toLowerCase().replace(/\s+/g, '-')}-collection.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Collection exported",
      description: `${collection.name} has been exported`,
    });
  }, [collections, environments, toast]);

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return 'text-green-600';
    if (status >= 300 && status < 400) return 'text-blue-600';
    if (status >= 400 && status < 500) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getMethodColor = (method: string) => {
    switch (method) {
      case 'GET': return 'bg-green-100 text-green-800';
      case 'POST': return 'bg-blue-100 text-blue-800';
      case 'PUT': return 'bg-yellow-100 text-yellow-800';
      case 'DELETE': return 'bg-red-100 text-red-800';
      case 'PATCH': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5" />
            API Client & Testing
            <Badge variant="outline">
              {activeEnvironment?.name}
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex gap-4">
          {/* Sidebar */}
          <div className="w-80 space-y-4">
            {/* Collections */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Collections</span>
                  <Button size="sm" onClick={createNewRequest}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="space-y-2">
                    {collections.map((collection) => (
                      <div key={collection.id} className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{collection.name}</span>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => exportCollection(collection.id)}
                          >
                            <Download className="w-3 h-3" />
                          </Button>
                        </div>
                        <div className="ml-4 space-y-1">
                          {collection.requests.map((request) => (
                            <div
                              key={request.id}
                              className={`flex items-center gap-2 p-2 rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 ${
                                selectedRequest?.id === request.id ? 'bg-blue-50 dark:bg-blue-950' : ''
                              }`}
                              onClick={() => setSelectedRequest(request)}
                            >
                              <Badge className={`${getMethodColor(request.method)} text-xs`}>
                                {request.method}
                              </Badge>
                              <span className="text-sm truncate">{request.name}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Environments */}
            <Card>
              <CardHeader>
                <CardTitle>Environments</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {environments.map((env) => (
                    <div
                      key={env.id}
                      className={`flex items-center justify-between p-2 rounded cursor-pointer ${
                        env.isActive ? 'bg-green-50 dark:bg-green-950 border border-green-200' : 'hover:bg-gray-50 dark:hover:bg-gray-800'
                      }`}
                      onClick={() => {
                        setEnvironments(prev => prev.map(e => ({ ...e, isActive: e.id === env.id })));
                      }}
                    >
                      <span className="font-medium">{env.name}</span>
                      {env.isActive && <CheckCircle className="w-4 h-4 text-green-600" />}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* History */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-32">
                  <div className="space-y-2">
                    {requestHistory.slice(0, 5).map((item, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 text-sm border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800"
                        onClick={() => setSelectedRequest(item.request)}
                      >
                        <div>
                          <Badge className={`${getMethodColor(item.request.method)} text-xs mr-1`}>
                            {item.request.method}
                          </Badge>
                          <span className="truncate">{item.request.name}</span>
                        </div>
                        <span className={getStatusColor(item.response.status)}>
                          {item.response.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1 space-y-4">
            {selectedRequest ? (
              <>
                {/* Request Builder */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <Input
                        value={selectedRequest.name}
                        onChange={(e) => setSelectedRequest(prev => prev ? { ...prev, name: e.target.value } : null)}
                        className="font-medium text-lg border-none p-0 h-auto"
                      />
                      <div className="flex gap-2">
                        <Button onClick={saveRequest} variant="outline" size="sm">
                          <Save className="w-4 h-4 mr-1" />
                          Save
                        </Button>
                        <Button onClick={sendRequest} disabled={isLoading}>
                          <Send className="w-4 h-4 mr-1" />
                          {isLoading ? 'Sending...' : 'Send'}
                        </Button>
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Method and URL */}
                      <div className="flex gap-2">
                        <select
                          value={selectedRequest.method}
                          onChange={(e) => setSelectedRequest(prev => prev ? { ...prev, method: e.target.value as any } : null)}
                          className="px-3 py-2 border rounded-md w-32"
                        >
                          <option value="GET">GET</option>
                          <option value="POST">POST</option>
                          <option value="PUT">PUT</option>
                          <option value="DELETE">DELETE</option>
                          <option value="PATCH">PATCH</option>
                        </select>
                        <Input
                          value={selectedRequest.url}
                          onChange={(e) => setSelectedRequest(prev => prev ? { ...prev, url: e.target.value } : null)}
                          placeholder="https://api.example.com/endpoint"
                          className="flex-1"
                        />
                      </div>

                      <Tabs defaultValue="headers">
                        <TabsList>
                          <TabsTrigger value="headers">Headers</TabsTrigger>
                          <TabsTrigger value="body">Body</TabsTrigger>
                          <TabsTrigger value="params">Params</TabsTrigger>
                          <TabsTrigger value="auth">Auth</TabsTrigger>
                        </TabsList>

                        <TabsContent value="headers" className="mt-4">
                          <Textarea
                            value={JSON.stringify(selectedRequest.headers, null, 2)}
                            onChange={(e) => {
                              try {
                                const headers = JSON.parse(e.target.value);
                                setSelectedRequest(prev => prev ? { ...prev, headers } : null);
                              } catch {}
                            }}
                            placeholder="Headers (JSON format)"
                            rows={4}
                          />
                        </TabsContent>

                        <TabsContent value="body" className="mt-4">
                          <Textarea
                            value={selectedRequest.body}
                            onChange={(e) => setSelectedRequest(prev => prev ? { ...prev, body: e.target.value } : null)}
                            placeholder="Request body"
                            rows={6}
                          />
                        </TabsContent>

                        <TabsContent value="params" className="mt-4">
                          <Textarea
                            value={JSON.stringify(selectedRequest.params, null, 2)}
                            onChange={(e) => {
                              try {
                                const params = JSON.parse(e.target.value);
                                setSelectedRequest(prev => prev ? { ...prev, params } : null);
                              } catch {}
                            }}
                            placeholder="Query parameters (JSON format)"
                            rows={4}
                          />
                        </TabsContent>

                        <TabsContent value="auth" className="mt-4">
                          <div className="space-y-3">
                            <select
                              value={selectedRequest.auth.type}
                              onChange={(e) => setSelectedRequest(prev => prev ? { 
                                ...prev, 
                                auth: { ...prev.auth, type: e.target.value as any }
                              } : null)}
                              className="w-full px-3 py-2 border rounded-md"
                            >
                              <option value="none">No Auth</option>
                              <option value="bearer">Bearer Token</option>
                              <option value="basic">Basic Auth</option>
                              <option value="apikey">API Key</option>
                            </select>

                            {selectedRequest.auth.type === 'bearer' && (
                              <Input
                                value={selectedRequest.auth.token || ''}
                                onChange={(e) => setSelectedRequest(prev => prev ? {
                                  ...prev,
                                  auth: { ...prev.auth, token: e.target.value }
                                } : null)}
                                placeholder="Bearer token"
                              />
                            )}

                            {selectedRequest.auth.type === 'basic' && (
                              <div className="grid grid-cols-2 gap-2">
                                <Input
                                  value={selectedRequest.auth.username || ''}
                                  onChange={(e) => setSelectedRequest(prev => prev ? {
                                    ...prev,
                                    auth: { ...prev.auth, username: e.target.value }
                                  } : null)}
                                  placeholder="Username"
                                />
                                <Input
                                  type="password"
                                  value={selectedRequest.auth.password || ''}
                                  onChange={(e) => setSelectedRequest(prev => prev ? {
                                    ...prev,
                                    auth: { ...prev.auth, password: e.target.value }
                                  } : null)}
                                  placeholder="Password"
                                />
                              </div>
                            )}

                            {selectedRequest.auth.type === 'apikey' && (
                              <div className="grid grid-cols-2 gap-2">
                                <Input
                                  value={selectedRequest.auth.key || ''}
                                  onChange={(e) => setSelectedRequest(prev => prev ? {
                                    ...prev,
                                    auth: { ...prev.auth, key: e.target.value }
                                  } : null)}
                                  placeholder="Key name"
                                />
                                <Input
                                  value={selectedRequest.auth.value || ''}
                                  onChange={(e) => setSelectedRequest(prev => prev ? {
                                    ...prev,
                                    auth: { ...prev.auth, value: e.target.value }
                                  } : null)}
                                  placeholder="Key value"
                                />
                              </div>
                            )}
                          </div>
                        </TabsContent>
                      </Tabs>
                    </div>
                  </CardContent>
                </Card>

                {/* Response */}
                {currentResponse && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>Response</span>
                        <div className="flex items-center gap-4 text-sm">
                          <span className={getStatusColor(currentResponse.status)}>
                            {currentResponse.status} {currentResponse.statusText}
                          </span>
                          <span className="text-gray-500">{currentResponse.time}ms</span>
                          <span className="text-gray-500">{currentResponse.size}B</span>
                          <Button variant="ghost" size="sm">
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Tabs defaultValue="body">
                        <TabsList>
                          <TabsTrigger value="body">Body</TabsTrigger>
                          <TabsTrigger value="headers">Headers</TabsTrigger>
                        </TabsList>

                        <TabsContent value="body" className="mt-4">
                          <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-md">
                            <pre className="text-sm overflow-auto max-h-64">
                              {currentResponse.body}
                            </pre>
                          </div>
                        </TabsContent>

                        <TabsContent value="headers" className="mt-4">
                          <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-md">
                            <pre className="text-sm">
                              {JSON.stringify(currentResponse.headers, null, 2)}
                            </pre>
                          </div>
                        </TabsContent>
                      </Tabs>
                    </CardContent>
                  </Card>
                )}
              </>
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center h-64">
                  <Globe className="w-12 h-12 text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Request Selected</h3>
                  <p className="text-gray-500 text-center mb-4">
                    Select a request from the sidebar or create a new one
                  </p>
                  <Button onClick={createNewRequest}>
                    <Plus className="w-4 h-4 mr-2" />
                    New Request
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}