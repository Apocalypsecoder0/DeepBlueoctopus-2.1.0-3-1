import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Sparkles, 
  Brain, 
  Target, 
  Zap, 
  Settings, 
  Code2, 
  FileText,
  Lightbulb,
  TrendingUp,
  Clock,
  Star
} from "lucide-react";

interface EnhancedAutocompleteProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Suggestion {
  text: string;
  type: 'function' | 'variable' | 'class' | 'method' | 'property' | 'keyword' | 'snippet';
  confidence: number;
  description?: string;
  documentation?: string;
  insertText?: string;
  source: 'ai' | 'static' | 'dynamic' | 'learned';
}

interface AIContext {
  language: string;
  currentFunction?: string;
  variables: string[];
  imports: string[];
  recentPatterns: string[];
}

export default function EnhancedAutocomplete({ isOpen, onClose }: EnhancedAutocompleteProps) {
  const [suggestions, setSuggestions] = useState<Suggestion[]>([
    {
      text: 'useState',
      type: 'function',
      confidence: 95,
      description: 'React hook for state management',
      documentation: 'Returns a stateful value and a function to update it',
      insertText: 'useState(${1:initialState})',
      source: 'ai'
    },
    {
      text: 'useEffect',
      type: 'function',
      confidence: 92,
      description: 'React hook for side effects',
      documentation: 'Synchronize a component with an external system',
      insertText: 'useEffect(() => {\n  ${1:// effect}\n}, [${2:dependencies}])',
      source: 'ai'
    },
    {
      text: 'async',
      type: 'keyword',
      confidence: 88,
      description: 'Declares an asynchronous function',
      insertText: 'async ',
      source: 'static'
    },
    {
      text: 'map',
      type: 'method',
      confidence: 85,
      description: 'Creates a new array with results of calling function',
      insertText: 'map((${1:item}) => ${2:item})',
      source: 'dynamic'
    }
  ]);

  const [settings, setSettings] = useState({
    enableAI: true,
    enableContextAware: true,
    enableSnippets: true,
    enableDocumentation: true,
    enableFuzzyMatch: true,
    enableLearning: true,
    suggestionDelay: [150],
    maxSuggestions: [10],
    confidenceThreshold: [50],
    prioritizeRecent: true,
    autoImport: true,
    smartBraces: true,
  });

  const [aiContext, setAiContext] = useState<AIContext>({
    language: 'typescript',
    currentFunction: 'handleSubmit',
    variables: ['user', 'data', 'loading', 'error'],
    imports: ['React', 'useState', 'useEffect'],
    recentPatterns: ['useState', 'fetch', 'map', 'filter']
  });

  const [statistics, setStatistics] = useState({
    totalSuggestions: 1247,
    acceptedSuggestions: 892,
    rejectedSuggestions: 355,
    averageConfidence: 87,
    learningProgress: 73,
    aiRequestsToday: 156
  });

  const [currentInput, setCurrentInput] = useState('');
  const [filteredSuggestions, setFilteredSuggestions] = useState<Suggestion[]>([]);

  useEffect(() => {
    // Filter suggestions based on current input
    const filtered = suggestions.filter(suggestion => {
      if (!currentInput) return true;
      
      if (settings.enableFuzzyMatch) {
        return suggestion.text.toLowerCase().includes(currentInput.toLowerCase()) ||
               suggestion.description?.toLowerCase().includes(currentInput.toLowerCase());
      } else {
        return suggestion.text.toLowerCase().startsWith(currentInput.toLowerCase());
      }
    }).filter(suggestion => suggestion.confidence >= settings.confidenceThreshold[0])
    .sort((a, b) => {
      if (settings.prioritizeRecent && aiContext.recentPatterns.includes(a.text)) return -1;
      if (settings.prioritizeRecent && aiContext.recentPatterns.includes(b.text)) return 1;
      return b.confidence - a.confidence;
    }).slice(0, settings.maxSuggestions[0]);

    setFilteredSuggestions(filtered);
  }, [currentInput, suggestions, settings]);

  const generateAISuggestions = async () => {
    // Simulate AI-powered suggestions based on context
    const aiSuggestions: Suggestion[] = [
      {
        text: 'handleUserSubmit',
        type: 'function',
        confidence: 94,
        description: 'AI suggested function based on current context',
        insertText: 'const handleUserSubmit = async (${1:userData}) => {\n  ${2:// implementation}\n}',
        source: 'ai'
      },
      {
        text: 'validateInput',
        type: 'function',
        confidence: 89,
        description: 'AI suggested validation function',
        insertText: 'const validateInput = (${1:input}) => {\n  return ${2:input.length > 0};\n}',
        source: 'ai'
      },
      {
        text: 'setLoading',
        type: 'function',
        confidence: 92,
        description: 'State setter based on detected useState pattern',
        insertText: 'setLoading(${1:true})',
        source: 'ai'
      }
    ];

    setSuggestions(prev => [...prev, ...aiSuggestions]);
    setStatistics(prev => ({
      ...prev,
      aiRequestsToday: prev.aiRequestsToday + 1,
      totalSuggestions: prev.totalSuggestions + aiSuggestions.length
    }));
  };

  const acceptSuggestion = (suggestion: Suggestion) => {
    setStatistics(prev => ({
      ...prev,
      acceptedSuggestions: prev.acceptedSuggestions + 1
    }));
    
    // Add to recent patterns if not already there
    if (!aiContext.recentPatterns.includes(suggestion.text)) {
      setAiContext(prev => ({
        ...prev,
        recentPatterns: [suggestion.text, ...prev.recentPatterns.slice(0, 9)]
      }));
    }
  };

  const getTypeIcon = (type: Suggestion['type']) => {
    switch (type) {
      case 'function': return <Code2 className="h-3 w-3 text-blue-500" />;
      case 'variable': return <Target className="h-3 w-3 text-green-500" />;
      case 'class': return <FileText className="h-3 w-3 text-purple-500" />;
      case 'method': return <Zap className="h-3 w-3 text-orange-500" />;
      case 'property': return <Settings className="h-3 w-3 text-gray-500" />;
      case 'keyword': return <Star className="h-3 w-3 text-red-500" />;
      case 'snippet': return <Lightbulb className="h-3 w-3 text-yellow-500" />;
      default: return <Code2 className="h-3 w-3" />;
    }
  };

  const getSourceColor = (source: Suggestion['source']) => {
    switch (source) {
      case 'ai': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      case 'static': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'dynamic': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'learned': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="w-[95vw] h-[95vh] bg-background rounded-lg border shadow-lg relative">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-blue-500" />
            <div>
              <h2 className="text-xl font-bold">Enhanced Auto-complete</h2>
              <p className="text-sm text-muted-foreground">Context-aware suggestions with AI assistance</p>
            </div>
          </div>
          <Button onClick={onClose} variant="outline" size="sm">
            Close
          </Button>
        </div>

        <div className="flex h-[calc(100%-80px)]">
          <div className="flex-1 p-4 overflow-auto">
            <Tabs defaultValue="suggestions" className="h-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="suggestions">Live Suggestions</TabsTrigger>
                <TabsTrigger value="ai">AI Context</TabsTrigger>
                <TabsTrigger value="settings">Configuration</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
              </TabsList>

              <TabsContent value="suggestions" className="space-y-4">
                {/* Input Simulation */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Code2 className="h-4 w-4" />
                      Live Autocomplete Demo
                    </CardTitle>
                    <CardDescription>
                      Type to see context-aware suggestions
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <Input
                        placeholder="Start typing code..."
                        value={currentInput}
                        onChange={(e) => setCurrentInput(e.target.value)}
                        className="font-mono"
                      />
                      
                      {filteredSuggestions.length > 0 && (
                        <div className="border rounded-lg bg-muted/50 p-2">
                          <div className="text-sm font-medium mb-2">Suggestions:</div>
                          <ScrollArea className="max-h-64">
                            <div className="space-y-1">
                              {filteredSuggestions.map((suggestion, index) => (
                                <div 
                                  key={index}
                                  className="flex items-center justify-between p-2 bg-background rounded border hover:bg-muted cursor-pointer"
                                  onClick={() => acceptSuggestion(suggestion)}
                                >
                                  <div className="flex items-center gap-2">
                                    {getTypeIcon(suggestion.type)}
                                    <div>
                                      <div className="font-mono text-sm">{suggestion.text}</div>
                                      {suggestion.description && (
                                        <div className="text-xs text-muted-foreground">
                                          {suggestion.description}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Badge className={getSourceColor(suggestion.source)} variant="secondary">
                                      {suggestion.source}
                                    </Badge>
                                    <div className="text-xs text-muted-foreground">
                                      {suggestion.confidence}%
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </ScrollArea>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Top Suggestions */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4" />
                        Top Suggestions
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {suggestions.slice(0, 5).map((suggestion, index) => (
                          <div key={index} className="flex items-center justify-between p-2 border rounded">
                            <div className="flex items-center gap-2">
                              {getTypeIcon(suggestion.type)}
                              <span className="font-mono text-sm">{suggestion.text}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Progress value={suggestion.confidence} className="w-16" />
                              <span className="text-xs">{suggestion.confidence}%</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        Recent Patterns
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {aiContext.recentPatterns.map((pattern, index) => (
                          <div key={index} className="flex items-center gap-2 p-2 bg-muted rounded">
                            <span className="font-mono text-sm">{pattern}</span>
                            <Badge variant="outline" className="text-xs">
                              Recent
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="ai" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Brain className="h-4 w-4" />
                        AI Context Analysis
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <label className="text-sm font-medium">Current Language</label>
                        <div className="mt-1 p-2 bg-muted rounded font-mono text-sm">
                          {aiContext.language}
                        </div>
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium">Current Function</label>
                        <div className="mt-1 p-2 bg-muted rounded font-mono text-sm">
                          {aiContext.currentFunction || 'None detected'}
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Available Variables</label>
                        <div className="mt-1 flex flex-wrap gap-1">
                          {aiContext.variables.map((variable, index) => (
                            <Badge key={index} variant="outline" className="font-mono">
                              {variable}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Imports</label>
                        <div className="mt-1 flex flex-wrap gap-1">
                          {aiContext.imports.map((imp, index) => (
                            <Badge key={index} variant="secondary" className="font-mono">
                              {imp}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <Button onClick={generateAISuggestions} className="w-full">
                        <Sparkles className="h-4 w-4 mr-2" />
                        Generate AI Suggestions
                      </Button>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Lightbulb className="h-4 w-4" />
                        Smart Features
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">AI-Powered Suggestions</label>
                        <Switch
                          checked={settings.enableAI}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, enableAI: checked }))
                          }
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Context Awareness</label>
                        <Switch
                          checked={settings.enableContextAware}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, enableContextAware: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Code Snippets</label>
                        <Switch
                          checked={settings.enableSnippets}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, enableSnippets: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Auto Import</label>
                        <Switch
                          checked={settings.autoImport}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, autoImport: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Smart Braces</label>
                        <Switch
                          checked={settings.smartBraces}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, smartBraces: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Learning Mode</label>
                        <Switch
                          checked={settings.enableLearning}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, enableLearning: checked }))
                          }
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="settings" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Settings className="h-4 w-4" />
                        Performance Settings
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          Suggestion Delay: {settings.suggestionDelay[0]}ms
                        </label>
                        <Slider
                          value={settings.suggestionDelay}
                          onValueChange={(value) => 
                            setSettings(prev => ({ ...prev, suggestionDelay: value }))
                          }
                          max={1000}
                          min={0}
                          step={50}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          Max Suggestions: {settings.maxSuggestions[0]}
                        </label>
                        <Slider
                          value={settings.maxSuggestions}
                          onValueChange={(value) => 
                            setSettings(prev => ({ ...prev, maxSuggestions: value }))
                          }
                          max={20}
                          min={1}
                          step={1}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          Confidence Threshold: {settings.confidenceThreshold[0]}%
                        </label>
                        <Slider
                          value={settings.confidenceThreshold}
                          onValueChange={(value) => 
                            setSettings(prev => ({ ...prev, confidenceThreshold: value }))
                          }
                          max={100}
                          min={0}
                          step={5}
                          className="w-full"
                        />
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Feature Toggles</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Documentation Preview</label>
                        <Switch
                          checked={settings.enableDocumentation}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, enableDocumentation: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Fuzzy Matching</label>
                        <Switch
                          checked={settings.enableFuzzyMatch}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, enableFuzzyMatch: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Prioritize Recent</label>
                        <Switch
                          checked={settings.prioritizeRecent}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, prioritizeRecent: checked }))
                          }
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="analytics" className="space-y-4">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">{statistics.totalSuggestions}</div>
                        <div className="text-sm text-muted-foreground">Total Suggestions</div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">{statistics.acceptedSuggestions}</div>
                        <div className="text-sm text-muted-foreground">Accepted</div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">{statistics.averageConfidence}%</div>
                        <div className="text-sm text-muted-foreground">Avg Confidence</div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-orange-600">{statistics.aiRequestsToday}</div>
                        <div className="text-sm text-muted-foreground">AI Requests Today</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Acceptance Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Accepted Suggestions</span>
                        <span className="text-sm font-medium">
                          {Math.round((statistics.acceptedSuggestions / statistics.totalSuggestions) * 100)}%
                        </span>
                      </div>
                      <Progress 
                        value={(statistics.acceptedSuggestions / statistics.totalSuggestions) * 100} 
                        className="w-full"
                      />
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Learning Progress</span>
                        <span className="text-sm font-medium">{statistics.learningProgress}%</span>
                      </div>
                      <Progress value={statistics.learningProgress} className="w-full" />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}