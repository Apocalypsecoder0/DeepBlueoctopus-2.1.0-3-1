import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  Smartphone, Tablet, Monitor, RotateCcw, 
  Hand, Navigation,
  ZoomIn, ZoomOut, Layout, Grid,
  CheckCircle, AlertCircle, Settings,
  Maximize2, Minimize2, MoreHorizontal
} from "lucide-react";

interface MobileResponsiveProps {
  isOpen: boolean;
  onClose: () => void;
}

interface DevicePreset {
  name: string;
  width: number;
  height: number;
  pixelRatio: number;
  userAgent: string;
  type: 'mobile' | 'tablet' | 'desktop';
}

interface TouchSettings {
  swipeGestures: boolean;
  pinchZoom: boolean;
  longPress: boolean;
  doubleTap: boolean;
  gestureTimeout: number;
  touchThreshold: number;
}

interface LayoutSettings {
  mobileLayout: string;
  tabletLayout: string;
  orientation: 'portrait' | 'landscape' | 'auto';
  collapseSidebar: boolean;
  responsiveMenus: boolean;
  adaptiveText: boolean;
}

export default function MobileResponsive({ isOpen, onClose }: MobileResponsiveProps) {
  const [currentDevice, setCurrentDevice] = useState<DevicePreset>({
    name: 'Desktop',
    width: 1920,
    height: 1080,
    pixelRatio: 1,
    userAgent: 'desktop',
    type: 'desktop'
  });

  const [touchSettings, setTouchSettings] = useState<TouchSettings>({
    swipeGestures: true,
    pinchZoom: false,
    longPress: true,
    doubleTap: true,
    gestureTimeout: 300,
    touchThreshold: 10
  });

  const [layoutSettings, setLayoutSettings] = useState<LayoutSettings>({
    mobileLayout: 'stacked',
    tabletLayout: 'sidebar',
    orientation: 'auto',
    collapseSidebar: true,
    responsiveMenus: true,
    adaptiveText: true
  });

  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [zoom, setZoom] = useState([100]);

  const devicePresets: DevicePreset[] = [
    {
      name: 'iPhone 14 Pro',
      width: 393,
      height: 852,
      pixelRatio: 3,
      userAgent: 'iPhone',
      type: 'mobile'
    },
    {
      name: 'iPhone 14 Pro Max',
      width: 430,
      height: 932,
      pixelRatio: 3,
      userAgent: 'iPhone',
      type: 'mobile'
    },
    {
      name: 'Samsung Galaxy S23',
      width: 360,
      height: 780,
      pixelRatio: 3,
      userAgent: 'Android',
      type: 'mobile'
    },
    {
      name: 'iPad Pro 12.9"',
      width: 1024,
      height: 1366,
      pixelRatio: 2,
      userAgent: 'iPad',
      type: 'tablet'
    },
    {
      name: 'iPad Air',
      width: 820,
      height: 1180,
      pixelRatio: 2,
      userAgent: 'iPad',
      type: 'tablet'
    },
    {
      name: 'Surface Pro',
      width: 912,
      height: 1368,
      pixelRatio: 2,
      userAgent: 'Windows',
      type: 'tablet'
    },
    {
      name: 'MacBook Pro 13"',
      width: 1280,
      height: 800,
      pixelRatio: 2,
      userAgent: 'Mac',
      type: 'desktop'
    },
    {
      name: 'Desktop 1080p',
      width: 1920,
      height: 1080,
      pixelRatio: 1,
      userAgent: 'desktop',
      type: 'desktop'
    }
  ];

  const { toast } = useToast();

  useEffect(() => {
    // Load saved settings
    const savedTouch = localStorage.getItem('mobile-touch-settings');
    const savedLayout = localStorage.getItem('mobile-layout-settings');
    
    if (savedTouch) {
      try {
        setTouchSettings(JSON.parse(savedTouch));
      } catch (error) {
        console.error('Error loading touch settings:', error);
      }
    }
    
    if (savedLayout) {
      try {
        setLayoutSettings(JSON.parse(savedLayout));
      } catch (error) {
        console.error('Error loading layout settings:', error);
      }
    }

    // Detect current viewport
    detectCurrentViewport();
    
    // Add touch event listeners
    setupTouchHandlers();
    
    return () => {
      // Cleanup touch handlers
      removeTouchHandlers();
    };
  }, []);

  useEffect(() => {
    // Save settings when they change
    localStorage.setItem('mobile-touch-settings', JSON.stringify(touchSettings));
    localStorage.setItem('mobile-layout-settings', JSON.stringify(layoutSettings));
    
    // Apply responsive settings
    applyResponsiveSettings();
  }, [touchSettings, layoutSettings]);

  const detectCurrentViewport = () => {
    const width = window.innerWidth;
    const height = window.innerHeight;
    const pixelRatio = window.devicePixelRatio || 1;
    
    // Find closest matching preset
    const closest = devicePresets.reduce((prev, curr) => {
      const prevDiff = Math.abs(prev.width - width) + Math.abs(prev.height - height);
      const currDiff = Math.abs(curr.width - width) + Math.abs(curr.height - height);
      return currDiff < prevDiff ? curr : prev;
    });
    
    setCurrentDevice(closest);
  };

  const applyResponsiveSettings = () => {
    const root = document.documentElement;
    
    // Apply layout settings based on viewport
    const width = window.innerWidth;
    
    if (width <= 768) {
      // Mobile layout
      root.classList.add('mobile-layout');
      root.classList.remove('tablet-layout', 'desktop-layout');
      
      if (layoutSettings.collapseSidebar) {
        root.classList.add('sidebar-collapsed');
      }
    } else if (width <= 1024) {
      // Tablet layout
      root.classList.add('tablet-layout');
      root.classList.remove('mobile-layout', 'desktop-layout');
    } else {
      // Desktop layout
      root.classList.add('desktop-layout');
      root.classList.remove('mobile-layout', 'tablet-layout');
      root.classList.remove('sidebar-collapsed');
    }
    
    // Touch settings
    if (touchSettings.swipeGestures) {
      root.classList.add('swipe-enabled');
    } else {
      root.classList.remove('swipe-enabled');
    }
    
    // Responsive text
    if (layoutSettings.adaptiveText) {
      root.style.setProperty('--responsive-text-scale', width <= 768 ? '0.9' : '1');
    }
  };

  const setupTouchHandlers = () => {
    if (!touchSettings.swipeGestures) return;
    
    let startX = 0;
    let startY = 0;
    let startTime = 0;
    
    const handleTouchStart = (e: TouchEvent) => {
      const touch = e.touches[0];
      startX = touch.clientX;
      startY = touch.clientY;
      startTime = Date.now();
    };
    
    const handleTouchEnd = (e: TouchEvent) => {
      const touch = e.changedTouches[0];
      const endX = touch.clientX;
      const endY = touch.clientY;
      const endTime = Date.now();
      
      const deltaX = endX - startX;
      const deltaY = endY - startY;
      const deltaTime = endTime - startTime;
      
      // Check for swipe gesture
      if (deltaTime < touchSettings.gestureTimeout && 
          Math.abs(deltaX) > touchSettings.touchThreshold) {
        
        if (deltaX > 0) {
          // Swipe right - show sidebar
          document.dispatchEvent(new CustomEvent('swipe-right'));
        } else {
          // Swipe left - hide sidebar
          document.dispatchEvent(new CustomEvent('swipe-left'));
        }
      }
    };
    
    document.addEventListener('touchstart', handleTouchStart, { passive: true });
    document.addEventListener('touchend', handleTouchEnd, { passive: true });
  };

  const removeTouchHandlers = () => {
    // Remove event listeners
    document.removeEventListener('touchstart', setupTouchHandlers);
    document.removeEventListener('touchend', setupTouchHandlers);
  };

  const previewDevice = (device: DevicePreset) => {
    setCurrentDevice(device);
    setIsPreviewMode(true);
    
    // Apply preview styles
    const root = document.documentElement;
    root.style.setProperty('--preview-width', `${device.width}px`);
    root.style.setProperty('--preview-height', `${device.height}px`);
    root.style.setProperty('--preview-scale', `${zoom[0] / 100}`);
    root.classList.add('device-preview');
    
    toast({
      title: "Device Preview",
      description: `Previewing ${device.name} (${device.width}x${device.height})`,
    });
  };

  const exitPreview = () => {
    setIsPreviewMode(false);
    
    const root = document.documentElement;
    root.classList.remove('device-preview');
    root.style.removeProperty('--preview-width');
    root.style.removeProperty('--preview-height');
    root.style.removeProperty('--preview-scale');
  };

  const rotateDevice = () => {
    setCurrentDevice(prev => ({
      ...prev,
      width: prev.height,
      height: prev.width
    }));
  };

  const updateTouchSetting = <K extends keyof TouchSettings>(
    key: K, 
    value: TouchSettings[K]
  ) => {
    setTouchSettings(prev => ({ ...prev, [key]: value }));
  };

  const updateLayoutSetting = <K extends keyof LayoutSettings>(
    key: K, 
    value: LayoutSettings[K]
  ) => {
    setLayoutSettings(prev => ({ ...prev, [key]: value }));
  };

  const getDeviceIcon = (type: DevicePreset['type']) => {
    switch (type) {
      case 'mobile':
        return <Smartphone className="h-4 w-4" />;
      case 'tablet':
        return <Tablet className="h-4 w-4" />;
      case 'desktop':
        return <Monitor className="h-4 w-4" />;
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Smartphone className="h-5 w-5" />
            Mobile Responsiveness & Touch Interface
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="preview" className="flex-1">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="preview">Device Preview</TabsTrigger>
            <TabsTrigger value="touch">Touch Settings</TabsTrigger>
            <TabsTrigger value="layout">Layout</TabsTrigger>
            <TabsTrigger value="optimization">Optimization</TabsTrigger>
          </TabsList>

          <TabsContent value="preview" className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  {getDeviceIcon(currentDevice.type)}
                  <span className="font-medium">{currentDevice.name}</span>
                  <Badge variant="outline">
                    {currentDevice.width} × {currentDevice.height}
                  </Badge>
                </div>
                {isPreviewMode && (
                  <Badge variant="default" className="bg-blue-500">
                    Preview Mode
                  </Badge>
                )}
              </div>
              
              <div className="flex items-center gap-2">
                {isPreviewMode && (
                  <>
                    <Button variant="outline" size="sm" onClick={rotateDevice}>
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                    <div className="flex items-center gap-2">
                      <Label className="text-sm">Zoom:</Label>
                      <div className="w-24">
                        <Slider
                          value={zoom}
                          onValueChange={setZoom}
                          max={150}
                          min={25}
                          step={25}
                        />
                      </div>
                      <span className="text-sm">{zoom[0]}%</span>
                    </div>
                  </>
                )}
                <Button 
                  onClick={isPreviewMode ? exitPreview : () => previewDevice(currentDevice)}
                  variant={isPreviewMode ? "destructive" : "default"}
                >
                  {isPreviewMode ? 'Exit Preview' : 'Preview'}
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {devicePresets.map((device) => (
                <Card 
                  key={device.name} 
                  className={`cursor-pointer transition-colors ${
                    currentDevice.name === device.name ? 'ring-2 ring-blue-500' : ''
                  }`}
                  onClick={() => previewDevice(device)}
                >
                  <CardContent className="p-4 text-center">
                    <div className="flex justify-center mb-2">
                      {getDeviceIcon(device.type)}
                    </div>
                    <div className="text-sm font-medium">{device.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {device.width} × {device.height}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {device.pixelRatio}x DPR
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Current Viewport Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Width:</span> {window.innerWidth}px
                  </div>
                  <div>
                    <span className="font-medium">Height:</span> {window.innerHeight}px
                  </div>
                  <div>
                    <span className="font-medium">Device Pixel Ratio:</span> {window.devicePixelRatio}
                  </div>
                  <div>
                    <span className="font-medium">Touch Support:</span> {'ontouchstart' in window ? 'Yes' : 'No'}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="touch" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Hand className="h-4 w-4" />
                  Touch Gestures
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Swipe Gestures</Label>
                      <p className="text-xs text-muted-foreground">Navigate with swipe gestures</p>
                    </div>
                    <Switch
                      checked={touchSettings.swipeGestures}
                      onCheckedChange={(value) => updateTouchSetting('swipeGestures', value)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Pinch to Zoom</Label>
                      <p className="text-xs text-muted-foreground">Zoom editor with pinch gesture</p>
                    </div>
                    <Switch
                      checked={touchSettings.pinchZoom}
                      onCheckedChange={(value) => updateTouchSetting('pinchZoom', value)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Long Press</Label>
                      <p className="text-xs text-muted-foreground">Context menus on long press</p>
                    </div>
                    <Switch
                      checked={touchSettings.longPress}
                      onCheckedChange={(value) => updateTouchSetting('longPress', value)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Double Tap</Label>
                      <p className="text-xs text-muted-foreground">Quick actions on double tap</p>
                    </div>
                    <Switch
                      checked={touchSettings.doubleTap}
                      onCheckedChange={(value) => updateTouchSetting('doubleTap', value)}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label>Gesture Timeout: {touchSettings.gestureTimeout}ms</Label>
                    <Slider
                      value={[touchSettings.gestureTimeout]}
                      onValueChange={([value]) => updateTouchSetting('gestureTimeout', value)}
                      max={1000}
                      min={100}
                      step={50}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label>Touch Threshold: {touchSettings.touchThreshold}px</Label>
                    <Slider
                      value={[touchSettings.touchThreshold]}
                      onValueChange={([value]) => updateTouchSetting('touchThreshold', value)}
                      max={50}
                      min={5}
                      step={5}
                      className="mt-2"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Touch Interactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span>Swipe Right:</span>
                    <span className="text-muted-foreground">Show sidebar</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Swipe Left:</span>
                    <span className="text-muted-foreground">Hide sidebar</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Long Press:</span>
                    <span className="text-muted-foreground">Context menu</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Double Tap:</span>
                    <span className="text-muted-foreground">Quick select</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pinch:</span>
                    <span className="text-muted-foreground">Zoom editor</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="layout" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Layout className="h-4 w-4" />
                  Responsive Layout Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Mobile Layout</Label>
                    <Select
                      value={layoutSettings.mobileLayout}
                      onValueChange={(value) => updateLayoutSetting('mobileLayout', value)}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="stacked">Stacked</SelectItem>
                        <SelectItem value="tabs">Tabs</SelectItem>
                        <SelectItem value="drawer">Drawer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Tablet Layout</Label>
                    <Select
                      value={layoutSettings.tabletLayout}
                      onValueChange={(value) => updateLayoutSetting('tabletLayout', value)}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sidebar">Sidebar</SelectItem>
                        <SelectItem value="split">Split View</SelectItem>
                        <SelectItem value="stacked">Stacked</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Auto-collapse Sidebar</Label>
                      <p className="text-xs text-muted-foreground">Hide sidebar on small screens</p>
                    </div>
                    <Switch
                      checked={layoutSettings.collapseSidebar}
                      onCheckedChange={(value) => updateLayoutSetting('collapseSidebar', value)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Responsive Menus</Label>
                      <p className="text-xs text-muted-foreground">Adapt menus for touch</p>
                    </div>
                    <Switch
                      checked={layoutSettings.responsiveMenus}
                      onCheckedChange={(value) => updateLayoutSetting('responsiveMenus', value)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Adaptive Text</Label>
                      <p className="text-xs text-muted-foreground">Scale text for readability</p>
                    </div>
                    <Switch
                      checked={layoutSettings.adaptiveText}
                      onCheckedChange={(value) => updateLayoutSetting('adaptiveText', value)}
                    />
                  </div>
                </div>

                <div>
                  <Label>Orientation</Label>
                  <Select
                    value={layoutSettings.orientation}
                    onValueChange={(value: any) => updateLayoutSetting('orientation', value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto</SelectItem>
                      <SelectItem value="portrait">Portrait</SelectItem>
                      <SelectItem value="landscape">Landscape</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="optimization" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Mobile Performance Optimization</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2 flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Touch-Optimized
                      </h4>
                      <ul className="text-sm space-y-1 text-muted-foreground">
                        <li>• 44px minimum touch targets</li>
                        <li>• Gesture navigation support</li>
                        <li>• Touch-friendly scrolling</li>
                        <li>• Haptic feedback integration</li>
                      </ul>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2 flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Performance
                      </h4>
                      <ul className="text-sm space-y-1 text-muted-foreground">
                        <li>• Lazy loading components</li>
                        <li>• Optimized bundle splitting</li>
                        <li>• Reduced DOM complexity</li>
                        <li>• Efficient re-rendering</li>
                      </ul>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2 flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Responsive Design
                      </h4>
                      <ul className="text-sm space-y-1 text-muted-foreground">
                        <li>• Fluid grid system</li>
                        <li>• Flexible typography</li>
                        <li>• Adaptive layouts</li>
                        <li>• Device-specific optimizations</li>
                      </ul>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2 flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Accessibility
                      </h4>
                      <ul className="text-sm space-y-1 text-muted-foreground">
                        <li>• Screen reader compatibility</li>
                        <li>• Voice control support</li>
                        <li>• High contrast options</li>
                        <li>• Focus management</li>
                      </ul>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <h4 className="font-medium mb-2">Best Practices Applied</h4>
                    <div className="text-sm space-y-2 text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        <span>Progressive Web App (PWA) compatible</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        <span>Viewport meta tag configured</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        <span>Touch event handling optimized</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        <span>CSS media queries for all breakpoints</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}