import { useState, useEffect, useRef, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SoundButton } from "@/components/ui/sound-system";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import {
  Box,
  Circle,
  Cylinder,
  Triangle,
  Palette,
  RotateCcw,
  Move3D,
  ZoomIn,
  ZoomOut,
  Eye,
  EyeOff,
  Layers,
  Grid3X3,
  Sun,
  Moon,
  Settings,
  Camera,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Download,
  Upload,
  Save,
  Undo,
  Redo,
  Copy,
  Trash2,
  Plus,
  Minus,
  RotateCw,
  Scale,
  Maximize,
  Lock
} from "lucide-react";

interface ObjectStudioProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Transform {
  position: { x: number; y: number; z: number };
  rotation: { x: number; y: number; z: number };
  scale: { x: number; y: number; z: number };
}

interface Material {
  id: string;
  name: string;
  color: string;
  metallic: number;
  roughness: number;
  emission: number;
  opacity: number;
  texture?: string;
}

interface SceneObject {
  id: string;
  name: string;
  type: '2d' | '3d';
  primitive: string;
  transform: Transform;
  material: Material;
  visible: boolean;
  locked: boolean;
  children: string[];
  parentId?: string;
}

interface Camera {
  position: { x: number; y: number; z: number };
  target: { x: number; y: number; z: number };
  fov: number;
  near: number;
  far: number;
}

interface RenderSettings {
  quality: 'low' | 'medium' | 'high' | 'ultra';
  shadows: boolean;
  reflections: boolean;
  antialiasing: boolean;
  bloom: boolean;
  wireframe: boolean;
  showGrid: boolean;
  showAxes: boolean;
  backgroundColor: string;
}

export default function ObjectStudio({ isOpen, onClose }: ObjectStudioProps) {
  const [activeTab, setActiveTab] = useState('scene');
  const [selectedObject, setSelectedObject] = useState<SceneObject | null>(null);
  const [sceneObjects, setSceneObjects] = useState<SceneObject[]>([]);
  const [camera, setCamera] = useState<Camera>({
    position: { x: 0, y: 5, z: 10 },
    target: { x: 0, y: 0, z: 0 },
    fov: 75,
    near: 0.1,
    far: 1000
  });
  const [renderSettings, setRenderSettings] = useState<RenderSettings>({
    quality: 'medium',
    shadows: true,
    reflections: false,
    antialiasing: true,
    bloom: false,
    wireframe: false,
    showGrid: true,
    showAxes: true,
    backgroundColor: '#1a1a2e'
  });
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentFrame, setCurrentFrame] = useState(0);
  const [totalFrames, setTotalFrames] = useState(240);
  const [viewMode, setViewMode] = useState<'perspective' | 'orthographic' | 'top' | 'front' | 'side'>('perspective');
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  const primitives2D = [
    { name: 'Rectangle', icon: '▭', type: 'rectangle' },
    { name: 'Circle', icon: '●', type: 'circle' },
    { name: 'Triangle', icon: '▲', type: 'triangle' },
    { name: 'Polygon', icon: '⬟', type: 'polygon' },
    { name: 'Line', icon: '—', type: 'line' },
    { name: 'Bezier', icon: '〰', type: 'bezier' }
  ];

  const primitives3D = [
    { name: 'Cube', icon: <Box className="h-4 w-4" />, type: 'cube' },
    { name: 'Sphere', icon: <Circle className="h-4 w-4" />, type: 'sphere' },
    { name: 'Cylinder', icon: <Cylinder className="h-4 w-4" />, type: 'cylinder' },
    { name: 'Cone', icon: <Triangle className="h-4 w-4" />, type: 'cone' },
    { name: 'Plane', icon: '▢', type: 'plane' },
    { name: 'Torus', icon: '◯', type: 'torus' }
  ];

  const materials: Material[] = [
    {
      id: 'default',
      name: 'Default',
      color: '#4a90e2',
      metallic: 0,
      roughness: 0.5,
      emission: 0,
      opacity: 1
    },
    {
      id: 'metal',
      name: 'Metal',
      color: '#c0c0c0',
      metallic: 1,
      roughness: 0.1,
      emission: 0,
      opacity: 1
    },
    {
      id: 'glass',
      name: 'Glass',
      color: '#ffffff',
      metallic: 0,
      roughness: 0,
      emission: 0,
      opacity: 0.3
    },
    {
      id: 'emissive',
      name: 'Emissive',
      color: '#ff6b35',
      metallic: 0,
      roughness: 0.5,
      emission: 1,
      opacity: 1
    }
  ];

  const createObject = useCallback((type: '2d' | '3d', primitive: string) => {
    const newObject: SceneObject = {
      id: Date.now().toString(),
      name: `${primitive}_${sceneObjects.length + 1}`,
      type,
      primitive,
      transform: {
        position: { x: 0, y: 0, z: 0 },
        rotation: { x: 0, y: 0, z: 0 },
        scale: { x: 1, y: 1, z: 1 }
      },
      material: materials[0],
      visible: true,
      locked: false,
      children: []
    };
    
    setSceneObjects([...sceneObjects, newObject]);
    setSelectedObject(newObject);
  }, [sceneObjects, materials]);

  const updateObjectTransform = useCallback((objectId: string, property: keyof Transform, axis: 'x' | 'y' | 'z', value: number) => {
    setSceneObjects(objects => 
      objects.map(obj => 
        obj.id === objectId 
          ? { ...obj, transform: { ...obj.transform, [property]: { ...obj.transform[property], [axis]: value } } }
          : obj
      )
    );
    
    if (selectedObject?.id === objectId) {
      setSelectedObject(prev => prev ? {
        ...prev,
        transform: { ...prev.transform, [property]: { ...prev.transform[property], [axis]: value } }
      } : null);
    }
  }, [selectedObject]);

  const deleteObject = useCallback((objectId: string) => {
    setSceneObjects(objects => objects.filter(obj => obj.id !== objectId));
    if (selectedObject?.id === objectId) {
      setSelectedObject(null);
    }
  }, [selectedObject]);

  const duplicateObject = useCallback((objectId: string) => {
    const original = sceneObjects.find(obj => obj.id === objectId);
    if (original) {
      const duplicate: SceneObject = {
        ...original,
        id: Date.now().toString(),
        name: `${original.name}_copy`,
        transform: {
          ...original.transform,
          position: {
            x: original.transform.position.x + 2,
            y: original.transform.position.y,
            z: original.transform.position.z
          }
        }
      };
      setSceneObjects([...sceneObjects, duplicate]);
    }
  }, [sceneObjects]);

  // Simple 2D/3D renderer
  const renderScene = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = renderSettings.backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw grid if enabled
    if (renderSettings.showGrid) {
      ctx.strokeStyle = '#333';
      ctx.lineWidth = 1;
      const gridSize = 20;
      
      for (let x = 0; x <= canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      
      for (let y = 0; y <= canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }
    }

    // Draw axes if enabled
    if (renderSettings.showAxes) {
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      
      ctx.lineWidth = 2;
      
      // X axis (red)
      ctx.strokeStyle = '#ff0000';
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(centerX + 100, centerY);
      ctx.stroke();
      
      // Y axis (green)
      ctx.strokeStyle = '#00ff00';
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(centerX, centerY - 100);
      ctx.stroke();
      
      // Z axis (blue) - represented as diagonal
      ctx.strokeStyle = '#0000ff';
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(centerX + 50, centerY + 50);
      ctx.stroke();
    }

    // Render objects
    sceneObjects.forEach(obj => {
      if (!obj.visible) return;

      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const x = centerX + obj.transform.position.x * 20;
      const y = centerY - obj.transform.position.y * 20;

      ctx.fillStyle = obj.material.color;
      ctx.strokeStyle = obj === selectedObject ? '#ffff00' : obj.material.color;
      ctx.lineWidth = obj === selectedObject ? 3 : 1;

      if (obj.type === '2d') {
        switch (obj.primitive) {
          case 'rectangle':
            const width = 40 * obj.transform.scale.x;
            const height = 30 * obj.transform.scale.y;
            ctx.fillRect(x - width/2, y - height/2, width, height);
            ctx.strokeRect(x - width/2, y - height/2, width, height);
            break;
          case 'circle':
            const radius = 20 * obj.transform.scale.x;
            ctx.beginPath();
            ctx.arc(x, y, radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
            break;
          case 'triangle':
            const size = 30 * obj.transform.scale.x;
            ctx.beginPath();
            ctx.moveTo(x, y - size);
            ctx.lineTo(x - size, y + size);
            ctx.lineTo(x + size, y + size);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
            break;
        }
      } else {
        // 3D objects (simplified 2D representation)
        switch (obj.primitive) {
          case 'cube':
            const cubeSize = 30 * obj.transform.scale.x;
            // Draw cube as isometric projection
            ctx.fillRect(x - cubeSize/2, y - cubeSize/2, cubeSize, cubeSize);
            ctx.strokeRect(x - cubeSize/2, y - cubeSize/2, cubeSize, cubeSize);
            // Add depth lines
            ctx.strokeStyle = '#888';
            ctx.beginPath();
            ctx.moveTo(x + cubeSize/2, y - cubeSize/2);
            ctx.lineTo(x + cubeSize/2 + 10, y - cubeSize/2 - 10);
            ctx.lineTo(x - cubeSize/2 + 10, y - cubeSize/2 - 10);
            ctx.lineTo(x - cubeSize/2, y - cubeSize/2);
            ctx.moveTo(x + cubeSize/2, y + cubeSize/2);
            ctx.lineTo(x + cubeSize/2 + 10, y + cubeSize/2 - 10);
            ctx.moveTo(x + cubeSize/2 + 10, y - cubeSize/2 - 10);
            ctx.lineTo(x + cubeSize/2 + 10, y + cubeSize/2 - 10);
            ctx.stroke();
            break;
          case 'sphere':
            const sphereRadius = 20 * obj.transform.scale.x;
            ctx.beginPath();
            ctx.arc(x, y, sphereRadius, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
            // Add highlight for 3D effect
            ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
            ctx.beginPath();
            ctx.arc(x - 8, y - 8, sphereRadius * 0.3, 0, Math.PI * 2);
            ctx.fill();
            break;
        }
      }
    });
  }, [sceneObjects, selectedObject, renderSettings]);

  useEffect(() => {
    renderScene();
  }, [renderScene]);

  const playAnimation = () => {
    if (isPlaying) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      const animate = () => {
        setCurrentFrame(frame => {
          const nextFrame = frame >= totalFrames ? 0 : frame + 1;
          return nextFrame;
        });
        animationRef.current = requestAnimationFrame(animate);
      };
      animate();
    }
  };

  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] h-[95vh] bg-gradient-to-br from-purple-950 via-slate-900 to-purple-900 border-purple-700">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-purple-100 flex items-center gap-2">
            <Box className="h-6 w-6 text-purple-400" />
            2D/3D Object Studio
          </DialogTitle>
        </DialogHeader>

        <div className="flex h-full gap-4">
          {/* Left Sidebar - Tools & Objects */}
          <div className="w-80 space-y-4">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid grid-cols-3 bg-purple-900/30">
                <TabsTrigger value="scene" className="text-xs">Scene</TabsTrigger>
                <TabsTrigger value="materials" className="text-xs">Materials</TabsTrigger>
                <TabsTrigger value="render" className="text-xs">Render</TabsTrigger>
              </TabsList>

              <TabsContent value="scene" className="space-y-4">
                {/* Primitives */}
                <Card className="bg-purple-900/30 border-purple-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-purple-100 text-sm">Add Objects</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <Label className="text-purple-200 text-xs">2D Shapes</Label>
                      <div className="grid grid-cols-3 gap-1 mt-1">
                        {primitives2D.map((primitive) => (
                          <TooltipWrapper key={primitive.type} title={`Add ${primitive.name}`} type="action">
                            <SoundButton
                              size="sm"
                              variant="outline"
                              className="h-8 text-xs border-purple-600 text-purple-300 hover:bg-purple-800/30"
                              onClick={() => createObject('2d', primitive.type)}
                            >
                              <span className="text-lg">{primitive.icon}</span>
                            </SoundButton>
                          </TooltipWrapper>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-purple-200 text-xs">3D Objects</Label>
                      <div className="grid grid-cols-3 gap-1 mt-1">
                        {primitives3D.map((primitive) => (
                          <TooltipWrapper key={primitive.type} title={`Add ${primitive.name}`} type="action">
                            <SoundButton
                              size="sm"
                              variant="outline"
                              className="h-8 text-xs border-purple-600 text-purple-300 hover:bg-purple-800/30"
                              onClick={() => createObject('3d', primitive.type)}
                            >
                              {primitive.icon}
                            </SoundButton>
                          </TooltipWrapper>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Scene Hierarchy */}
                <Card className="bg-purple-900/30 border-purple-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-purple-100 text-sm flex items-center justify-between">
                      Scene Objects
                      <Badge variant="secondary" className="bg-purple-700/50 text-purple-200">
                        {sceneObjects.length}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-48">
                      <div className="space-y-1">
                        {sceneObjects.map((obj) => (
                          <div
                            key={obj.id}
                            className={`flex items-center justify-between p-2 rounded cursor-pointer transition-colors ${
                              selectedObject?.id === obj.id
                                ? 'bg-purple-700/50 border border-purple-500'
                                : 'bg-purple-800/30 hover:bg-purple-700/30'
                            }`}
                            onClick={() => setSelectedObject(obj)}
                          >
                            <div className="flex items-center gap-2">
                              <div className="flex items-center gap-1">
                                {obj.visible ? (
                                  <Eye className="h-3 w-3 text-purple-300" />
                                ) : (
                                  <EyeOff className="h-3 w-3 text-purple-500" />
                                )}
                                {obj.locked && <Lock className="h-3 w-3 text-purple-500" />}
                              </div>
                              <span className="text-purple-100 text-xs">{obj.name}</span>
                              <Badge className="text-xs bg-purple-600/50 text-purple-200">
                                {obj.type}
                              </Badge>
                            </div>
                            <div className="flex gap-1">
                              <TooltipWrapper title="Duplicate" type="action">
                                <SoundButton
                                  size="sm"
                                  variant="ghost"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    duplicateObject(obj.id);
                                  }}
                                >
                                  <Copy className="h-3 w-3" />
                                </SoundButton>
                              </TooltipWrapper>
                              <TooltipWrapper title="Delete" type="warning">
                                <SoundButton
                                  size="sm"
                                  variant="ghost"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    deleteObject(obj.id);
                                  }}
                                >
                                  <Trash2 className="h-3 w-3" />
                                </SoundButton>
                              </TooltipWrapper>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="materials" className="space-y-4">
                <Card className="bg-purple-900/30 border-purple-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-purple-100 text-sm">Material Library</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {materials.map((material) => (
                      <div
                        key={material.id}
                        className="flex items-center justify-between p-2 bg-purple-800/30 rounded cursor-pointer hover:bg-purple-700/30"
                        onClick={() => {
                          if (selectedObject) {
                            setSelectedObject({ ...selectedObject, material });
                            setSceneObjects(objects =>
                              objects.map(obj =>
                                obj.id === selectedObject.id ? { ...obj, material } : obj
                              )
                            );
                          }
                        }}
                      >
                        <div className="flex items-center gap-2">
                          <div
                            className="w-4 h-4 rounded border border-purple-500"
                            style={{ backgroundColor: material.color }}
                          />
                          <span className="text-purple-100 text-xs">{material.name}</span>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="render" className="space-y-4">
                <Card className="bg-purple-900/30 border-purple-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-purple-100 text-sm">Render Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="text-purple-200 text-xs">Quality</Label>
                        <Select
                          value={renderSettings.quality}
                          onValueChange={(value: RenderSettings['quality']) =>
                            setRenderSettings({ ...renderSettings, quality: value })
                          }
                        >
                          <SelectTrigger className="w-24 h-7 bg-purple-800/30 border-purple-600 text-purple-100">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="ultra">Ultra</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label className="text-purple-200 text-xs">Shadows</Label>
                        <Switch
                          checked={renderSettings.shadows}
                          onCheckedChange={(checked) =>
                            setRenderSettings({ ...renderSettings, shadows: checked })
                          }
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label className="text-purple-200 text-xs">Grid</Label>
                        <Switch
                          checked={renderSettings.showGrid}
                          onCheckedChange={(checked) =>
                            setRenderSettings({ ...renderSettings, showGrid: checked })
                          }
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label className="text-purple-200 text-xs">Axes</Label>
                        <Switch
                          checked={renderSettings.showAxes}
                          onCheckedChange={(checked) =>
                            setRenderSettings({ ...renderSettings, showAxes: checked })
                          }
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label className="text-purple-200 text-xs">Wireframe</Label>
                        <Switch
                          checked={renderSettings.wireframe}
                          onCheckedChange={(checked) =>
                            setRenderSettings({ ...renderSettings, wireframe: checked })
                          }
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Center - Viewport */}
          <div className="flex-1 flex flex-col">
            {/* Viewport Header */}
            <div className="flex items-center justify-between p-3 bg-purple-900/30 rounded-t-lg border border-purple-700">
              <div className="flex items-center gap-2">
                <Select value={viewMode} onValueChange={(value: any) => setViewMode(value)}>
                  <SelectTrigger className="w-32 bg-purple-800/30 border-purple-600 text-purple-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="perspective">Perspective</SelectItem>
                    <SelectItem value="orthographic">Orthographic</SelectItem>
                    <SelectItem value="top">Top View</SelectItem>
                    <SelectItem value="front">Front View</SelectItem>
                    <SelectItem value="side">Side View</SelectItem>
                  </SelectContent>
                </Select>
                
                <Separator orientation="vertical" className="h-6 bg-purple-600" />
                
                <div className="flex gap-1">
                  <TooltipWrapper title="Reset View" type="action">
                    <SoundButton size="sm" variant="outline" className="border-purple-600 text-purple-300">
                      <RotateCcw className="h-4 w-4" />
                    </SoundButton>
                  </TooltipWrapper>
                  <TooltipWrapper title="Frame Selected" type="action">
                    <SoundButton size="sm" variant="outline" className="border-purple-600 text-purple-300">
                      <Maximize className="h-4 w-4" />
                    </SoundButton>
                  </TooltipWrapper>
                  <TooltipWrapper title="Toggle Grid" type="action">
                    <SoundButton 
                      size="sm" 
                      variant={renderSettings.showGrid ? "default" : "outline"}
                      className="border-purple-600 text-purple-300"
                      onClick={() => setRenderSettings({...renderSettings, showGrid: !renderSettings.showGrid})}
                    >
                      <Grid3X3 className="h-4 w-4" />
                    </SoundButton>
                  </TooltipWrapper>
                </div>
              </div>
              
              <div className="flex gap-1">
                <TooltipWrapper title="Render Image" type="action">
                  <SoundButton size="sm" className="bg-purple-600 hover:bg-purple-500">
                    <Camera className="h-4 w-4" />
                  </SoundButton>
                </TooltipWrapper>
                <TooltipWrapper title="Export Scene" type="action">
                  <SoundButton size="sm" variant="outline" className="border-purple-600 text-purple-300">
                    <Download className="h-4 w-4" />
                  </SoundButton>
                </TooltipWrapper>
              </div>
            </div>

            {/* Viewport Canvas */}
            <div className="flex-1 bg-purple-950/50 border-x border-b border-purple-700 rounded-b-lg relative overflow-hidden">
              <canvas
                ref={canvasRef}
                width={800}
                height={600}
                className="w-full h-full cursor-crosshair"
                style={{ imageRendering: 'pixelated' }}
              />
              
              {/* Viewport Overlay */}
              <div className="absolute top-2 left-2 text-purple-300 text-xs bg-purple-900/80 px-2 py-1 rounded">
                {viewMode} • {sceneObjects.length} objects • {renderSettings.quality} quality
              </div>
            </div>

            {/* Animation Controls */}
            <div className="flex items-center justify-between p-3 bg-purple-900/30 border border-purple-700 rounded-lg mt-2">
              <div className="flex items-center gap-2">
                <TooltipWrapper title="First Frame" type="action">
                  <SoundButton
                    size="sm"
                    variant="outline"
                    className="border-purple-600 text-purple-300"
                    onClick={() => setCurrentFrame(0)}
                  >
                    <SkipBack className="h-4 w-4" />
                  </SoundButton>
                </TooltipWrapper>
                
                <TooltipWrapper title={isPlaying ? "Pause" : "Play"} type="action">
                  <SoundButton
                    size="sm"
                    className="bg-purple-600 hover:bg-purple-500"
                    onClick={playAnimation}
                  >
                    {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </SoundButton>
                </TooltipWrapper>
                
                <TooltipWrapper title="Last Frame" type="action">
                  <SoundButton
                    size="sm"
                    variant="outline"
                    className="border-purple-600 text-purple-300"
                    onClick={() => setCurrentFrame(totalFrames)}
                  >
                    <SkipForward className="h-4 w-4" />
                  </SoundButton>
                </TooltipWrapper>
                
                <Separator orientation="vertical" className="h-6 bg-purple-600" />
                
                <div className="flex items-center gap-2 text-purple-300 text-xs">
                  <span>Frame:</span>
                  <Input
                    type="number"
                    value={currentFrame}
                    onChange={(e) => setCurrentFrame(parseInt(e.target.value) || 0)}
                    className="w-16 h-7 bg-purple-800/30 border-purple-600 text-purple-100 text-center"
                    min={0}
                    max={totalFrames}
                  />
                  <span>/ {totalFrames}</span>
                </div>
              </div>
              
              <div className="text-purple-300 text-xs">
                {isPlaying ? 'Playing' : 'Paused'} • 24 FPS
              </div>
            </div>
          </div>

          {/* Right Sidebar - Properties */}
          <div className="w-80 space-y-4">
            {selectedObject ? (
              <>
                <Card className="bg-purple-900/30 border-purple-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-purple-100 text-sm flex items-center gap-2">
                      <Settings className="h-4 w-4" />
                      Object Properties
                    </CardTitle>
                    <CardDescription className="text-purple-300 text-xs">
                      {selectedObject.name} ({selectedObject.primitive})
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Transform */}
                    <div className="space-y-3">
                      <Label className="text-purple-200 text-xs">Position</Label>
                      <div className="grid grid-cols-3 gap-2">
                        {(['x', 'y', 'z'] as const).map((axis) => (
                          <div key={axis} className="space-y-1">
                            <Label className="text-purple-300 text-xs uppercase">{axis}</Label>
                            <Input
                              type="number"
                              value={selectedObject.transform.position[axis]}
                              onChange={(e) => updateObjectTransform(
                                selectedObject.id,
                                'position',
                                axis,
                                parseFloat(e.target.value) || 0
                              )}
                              className="h-7 bg-purple-800/30 border-purple-600 text-purple-100 text-xs"
                              step={0.1}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <Label className="text-purple-200 text-xs">Rotation</Label>
                      <div className="grid grid-cols-3 gap-2">
                        {(['x', 'y', 'z'] as const).map((axis) => (
                          <div key={axis} className="space-y-1">
                            <Label className="text-purple-300 text-xs uppercase">{axis}</Label>
                            <Input
                              type="number"
                              value={selectedObject.transform.rotation[axis]}
                              onChange={(e) => updateObjectTransform(
                                selectedObject.id,
                                'rotation',
                                axis,
                                parseFloat(e.target.value) || 0
                              )}
                              className="h-7 bg-purple-800/30 border-purple-600 text-purple-100 text-xs"
                              step={1}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <Label className="text-purple-200 text-xs">Scale</Label>
                      <div className="grid grid-cols-3 gap-2">
                        {(['x', 'y', 'z'] as const).map((axis) => (
                          <div key={axis} className="space-y-1">
                            <Label className="text-purple-300 text-xs uppercase">{axis}</Label>
                            <Input
                              type="number"
                              value={selectedObject.transform.scale[axis]}
                              onChange={(e) => updateObjectTransform(
                                selectedObject.id,
                                'scale',
                                axis,
                                parseFloat(e.target.value) || 1
                              )}
                              className="h-7 bg-purple-800/30 border-purple-600 text-purple-100 text-xs"
                              step={0.1}
                              min={0.1}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <Separator className="bg-purple-700" />
                    
                    {/* Object Settings */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="text-purple-200 text-xs">Visible</Label>
                        <Switch
                          checked={selectedObject.visible}
                          onCheckedChange={(checked) => {
                            const updated = { ...selectedObject, visible: checked };
                            setSelectedObject(updated);
                            setSceneObjects(objects =>
                              objects.map(obj => obj.id === selectedObject.id ? updated : obj)
                            );
                          }}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label className="text-purple-200 text-xs">Locked</Label>
                        <Switch
                          checked={selectedObject.locked}
                          onCheckedChange={(checked) => {
                            const updated = { ...selectedObject, locked: checked };
                            setSelectedObject(updated);
                            setSceneObjects(objects =>
                              objects.map(obj => obj.id === selectedObject.id ? updated : obj)
                            );
                          }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Material Properties */}
                <Card className="bg-purple-900/30 border-purple-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-purple-100 text-sm flex items-center gap-2">
                      <Palette className="h-4 w-4" />
                      Material
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <Label className="text-purple-200 text-xs">Color</Label>
                      <div className="flex gap-2">
                        <input
                          type="color"
                          value={selectedObject.material.color}
                          onChange={(e) => {
                            const updated = {
                              ...selectedObject,
                              material: { ...selectedObject.material, color: e.target.value }
                            };
                            setSelectedObject(updated);
                            setSceneObjects(objects =>
                              objects.map(obj => obj.id === selectedObject.id ? updated : obj)
                            );
                          }}
                          className="w-8 h-7 rounded border border-purple-600"
                        />
                        <Input
                          value={selectedObject.material.color}
                          onChange={(e) => {
                            const updated = {
                              ...selectedObject,
                              material: { ...selectedObject.material, color: e.target.value }
                            };
                            setSelectedObject(updated);
                            setSceneObjects(objects =>
                              objects.map(obj => obj.id === selectedObject.id ? updated : obj)
                            );
                          }}
                          className="flex-1 h-7 bg-purple-800/30 border-purple-600 text-purple-100 text-xs"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label className="text-purple-200 text-xs">Metallic</Label>
                        <span className="text-purple-300 text-xs">{selectedObject.material.metallic}</span>
                      </div>
                      <Slider
                        value={[selectedObject.material.metallic]}
                        onValueChange={([value]) => {
                          const updated = {
                            ...selectedObject,
                            material: { ...selectedObject.material, metallic: value }
                          };
                          setSelectedObject(updated);
                          setSceneObjects(objects =>
                            objects.map(obj => obj.id === selectedObject.id ? updated : obj)
                          );
                        }}
                        max={1}
                        step={0.01}
                        className="w-full"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label className="text-purple-200 text-xs">Roughness</Label>
                        <span className="text-purple-300 text-xs">{selectedObject.material.roughness}</span>
                      </div>
                      <Slider
                        value={[selectedObject.material.roughness]}
                        onValueChange={([value]) => {
                          const updated = {
                            ...selectedObject,
                            material: { ...selectedObject.material, roughness: value }
                          };
                          setSelectedObject(updated);
                          setSceneObjects(objects =>
                            objects.map(obj => obj.id === selectedObject.id ? updated : obj)
                          );
                        }}
                        max={1}
                        step={0.01}
                        className="w-full"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label className="text-purple-200 text-xs">Opacity</Label>
                        <span className="text-purple-300 text-xs">{selectedObject.material.opacity}</span>
                      </div>
                      <Slider
                        value={[selectedObject.material.opacity]}
                        onValueChange={([value]) => {
                          const updated = {
                            ...selectedObject,
                            material: { ...selectedObject.material, opacity: value }
                          };
                          setSelectedObject(updated);
                          setSceneObjects(objects =>
                            objects.map(obj => obj.id === selectedObject.id ? updated : obj)
                          );
                        }}
                        max={1}
                        step={0.01}
                        className="w-full"
                      />
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="bg-purple-900/30 border-purple-700">
                <CardContent className="flex items-center justify-center h-64">
                  <div className="text-center text-purple-300">
                    <Box className="h-12 w-12 mx-auto mb-3 text-purple-500" />
                    <p className="text-sm">Select an object to edit properties</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}