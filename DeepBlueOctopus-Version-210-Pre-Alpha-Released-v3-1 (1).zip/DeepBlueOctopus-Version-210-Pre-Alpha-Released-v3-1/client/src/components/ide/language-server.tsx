import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { 
  Server, 
  Play, 
  Square, 
  RefreshCw, 
  Settings,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Clock,
  Zap,
  Code,
  FileText,
  Lightbulb,
  Search,
  BookOpen,
  Cpu,
  MemoryStick,
  Globe,
  Download,
  Upload
} from "lucide-react";

interface LanguageServerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface LanguageServerConfig {
  id: string;
  name: string;
  language: string;
  version: string;
  status: 'running' | 'stopped' | 'error' | 'installing';
  port?: number;
  features: {
    completion: boolean;
    diagnostics: boolean;
    hover: boolean;
    signatureHelp: boolean;
    references: boolean;
    formatting: boolean;
    codeActions: boolean;
    rename: boolean;
  };
  performance: {
    responseTime: number;
    memoryUsage: number;
    cpuUsage: number;
  };
}

interface DiagnosticMessage {
  file: string;
  line: number;
  column: number;
  severity: 'error' | 'warning' | 'info' | 'hint';
  message: string;
  source: string;
}

export default function LanguageServer({ isOpen, onClose }: LanguageServerProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('servers');
  const [servers, setServers] = useState<LanguageServerConfig[]>([]);
  const [diagnostics, setDiagnostics] = useState<DiagnosticMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [autoStart, setAutoStart] = useState(true);

  useEffect(() => {
    if (isOpen) {
      loadLanguageServers();
      loadDiagnostics();
    }
  }, [isOpen]);

  const loadLanguageServers = async () => {
    try {
      const response = await fetch('/api/language-servers');
      const data = await response.json();
      setServers(data);
    } catch (error) {
      console.error('Failed to load language servers:', error);
      // Load sample servers
      setServers([
        {
          id: 'typescript-ls',
          name: 'TypeScript Language Server',
          language: 'typescript',
          version: '3.3.4000',
          status: 'running',
          port: 6009,
          features: {
            completion: true,
            diagnostics: true,
            hover: true,
            signatureHelp: true,
            references: true,
            formatting: true,
            codeActions: true,
            rename: true
          },
          performance: {
            responseTime: 45,
            memoryUsage: 128,
            cpuUsage: 12
          }
        },
        {
          id: 'python-ls',
          name: 'Pylsp',
          language: 'python',
          version: '1.9.0',
          status: 'running',
          port: 6010,
          features: {
            completion: true,
            diagnostics: true,
            hover: true,
            signatureHelp: true,
            references: true,
            formatting: true,
            codeActions: false,
            rename: true
          },
          performance: {
            responseTime: 67,
            memoryUsage: 95,
            cpuUsage: 8
          }
        },
        {
          id: 'rust-analyzer',
          name: 'Rust Analyzer',
          language: 'rust',
          version: '0.3.1731',
          status: 'stopped',
          features: {
            completion: true,
            diagnostics: true,
            hover: true,
            signatureHelp: true,
            references: true,
            formatting: true,
            codeActions: true,
            rename: true
          },
          performance: {
            responseTime: 0,
            memoryUsage: 0,
            cpuUsage: 0
          }
        },
        {
          id: 'html-ls',
          name: 'HTML Language Server',
          language: 'html',
          version: '1.4.0',
          status: 'running',
          port: 6011,
          features: {
            completion: true,
            diagnostics: true,
            hover: true,
            signatureHelp: false,
            references: false,
            formatting: true,
            codeActions: false,
            rename: false
          },
          performance: {
            responseTime: 23,
            memoryUsage: 42,
            cpuUsage: 3
          }
        }
      ]);
    }
  };

  const loadDiagnostics = async () => {
    try {
      const response = await fetch('/api/language-servers/diagnostics');
      const data = await response.json();
      setDiagnostics(data);
    } catch (error) {
      console.error('Failed to load diagnostics:', error);
      // Load sample diagnostics
      setDiagnostics([
        {
          file: '/src/main.ts',
          line: 15,
          column: 8,
          severity: 'error',
          message: 'Type \'string\' is not assignable to type \'number\'.',
          source: 'typescript'
        },
        {
          file: '/src/utils.js',
          line: 23,
          column: 12,
          severity: 'warning',
          message: 'Variable \'result\' is declared but never used.',
          source: 'eslint'
        },
        {
          file: '/src/components/Button.tsx',
          line: 8,
          column: 5,
          severity: 'info',
          message: 'This component could be simplified using arrow function.',
          source: 'typescript'
        },
        {
          file: '/src/api.py',
          line: 42,
          column: 1,
          severity: 'error',
          message: 'Undefined variable \'response\'.',
          source: 'pylsp'
        }
      ]);
    }
  };

  const startServer = async (serverId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/language-servers/${serverId}/start`, {
        method: 'POST'
      });

      if (response.ok) {
        await loadLanguageServers();
        toast({
          title: "Server Started",
          description: "Language server has been started successfully.",
        });
      }
    } catch (error) {
      toast({
        title: "Start Failed",
        description: "Failed to start language server.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const stopServer = async (serverId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/language-servers/${serverId}/stop`, {
        method: 'POST'
      });

      if (response.ok) {
        await loadLanguageServers();
        toast({
          title: "Server Stopped",
          description: "Language server has been stopped.",
        });
      }
    } catch (error) {
      toast({
        title: "Stop Failed",
        description: "Failed to stop language server.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const restartServer = async (serverId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/language-servers/${serverId}/restart`, {
        method: 'POST'
      });

      if (response.ok) {
        await loadLanguageServers();
        toast({
          title: "Server Restarted",
          description: "Language server has been restarted.",
        });
      }
    } catch (error) {
      toast({
        title: "Restart Failed",
        description: "Failed to restart language server.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: LanguageServerConfig['status']) => {
    switch (status) {
      case 'running': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'stopped': return <XCircle className="w-4 h-4 text-gray-400" />;
      case 'error': return <XCircle className="w-4 h-4 text-red-400" />;
      case 'installing': return <Clock className="w-4 h-4 text-yellow-400" />;
      default: return <Server className="w-4 h-4 text-gray-400" />;
    }
  };

  const getSeverityIcon = (severity: DiagnosticMessage['severity']) => {
    switch (severity) {
      case 'error': return <XCircle className="w-4 h-4 text-red-400" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'info': return <Lightbulb className="w-4 h-4 text-blue-400" />;
      case 'hint': return <Lightbulb className="w-4 h-4 text-gray-400" />;
      default: return <FileText className="w-4 h-4 text-gray-400" />;
    }
  };

  const getSeverityColor = (severity: DiagnosticMessage['severity']) => {
    switch (severity) {
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'info': return 'text-blue-400';
      case 'hint': return 'text-gray-400';
      default: return 'text-white';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[95vh] bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <Server className="w-5 h-5" />
            Language Server Protocol
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800">
            <TabsTrigger value="servers">Servers</TabsTrigger>
            <TabsTrigger value="diagnostics">Diagnostics</TabsTrigger>
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="servers" className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Language Servers</h3>
              <div className="flex gap-2">
                <Button
                  onClick={loadLanguageServers}
                  variant="outline"
                  size="sm"
                  disabled={loading}
                >
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Install Server
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {servers.map((server) => (
                <Card key={server.id} className="bg-slate-800 border-slate-700">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(server.status)}
                        <CardTitle className="text-sm text-white">{server.name}</CardTitle>
                      </div>
                      <Badge className="bg-blue-600">
                        {server.language}
                      </Badge>
                    </div>
                    <CardDescription>
                      Version {server.version} {server.port && `• Port ${server.port}`}
                    </CardDescription>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    {server.status === 'running' && (
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div className="text-center">
                          <div className="flex items-center justify-center gap-1 mb-1">
                            <Clock className="w-3 h-3 text-blue-400" />
                            <span className="text-white">{server.performance.responseTime}ms</span>
                          </div>
                          <p className="text-xs text-slate-400">Response</p>
                        </div>
                        <div className="text-center">
                          <div className="flex items-center justify-center gap-1 mb-1">
                            <MemoryStick className="w-3 h-3 text-green-400" />
                            <span className="text-white">{server.performance.memoryUsage}MB</span>
                          </div>
                          <p className="text-xs text-slate-400">Memory</p>
                        </div>
                        <div className="text-center">
                          <div className="flex items-center justify-center gap-1 mb-1">
                            <Cpu className="w-3 h-3 text-yellow-400" />
                            <span className="text-white">{server.performance.cpuUsage}%</span>
                          </div>
                          <p className="text-xs text-slate-400">CPU</p>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-slate-400">Features:</span>
                      {Object.entries(server.features).filter(([, enabled]) => enabled).length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {Object.entries(server.features)
                            .filter(([, enabled]) => enabled)
                            .slice(0, 3)
                            .map(([feature]) => (
                              <Badge key={feature} variant="outline" className="text-xs">
                                {feature}
                              </Badge>
                            ))
                          }
                          {Object.entries(server.features).filter(([, enabled]) => enabled).length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{Object.entries(server.features).filter(([, enabled]) => enabled).length - 3}
                            </Badge>
                          )}
                        </div>
                      ) : (
                        <span className="text-slate-500">None active</span>
                      )}
                    </div>

                    <div className="flex gap-2">
                      {server.status === 'running' ? (
                        <>
                          <Button
                            onClick={() => stopServer(server.id)}
                            variant="outline"
                            size="sm"
                            disabled={loading}
                          >
                            <Square className="w-3 h-3 mr-1" />
                            Stop
                          </Button>
                          <Button
                            onClick={() => restartServer(server.id)}
                            variant="outline"
                            size="sm"
                            disabled={loading}
                          >
                            <RefreshCw className="w-3 h-3 mr-1" />
                            Restart
                          </Button>
                        </>
                      ) : (
                        <Button
                          onClick={() => startServer(server.id)}
                          size="sm"
                          className="bg-green-600 hover:bg-green-700"
                          disabled={loading}
                        >
                          <Play className="w-3 h-3 mr-1" />
                          Start
                        </Button>
                      )}
                      <Button variant="outline" size="sm">
                        <Settings className="w-3 h-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="diagnostics" className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Diagnostics</h3>
              <div className="flex gap-2">
                <Badge className="bg-red-600">
                  {diagnostics.filter(d => d.severity === 'error').length} errors
                </Badge>
                <Badge className="bg-yellow-600">
                  {diagnostics.filter(d => d.severity === 'warning').length} warnings
                </Badge>
                <Badge className="bg-blue-600">
                  {diagnostics.filter(d => d.severity === 'info').length} info
                </Badge>
              </div>
            </div>

            <ScrollArea className="h-96">
              <div className="space-y-2">
                {diagnostics.map((diagnostic, index) => (
                  <Card key={index} className="bg-slate-800 border-slate-700 hover:border-slate-600 transition-colors cursor-pointer">
                    <CardContent className="p-3">
                      <div className="flex items-start gap-3">
                        {getSeverityIcon(diagnostic.severity)}
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-white text-sm">
                              {diagnostic.file}
                            </span>
                            <span className="text-slate-400 text-xs">
                              Line {diagnostic.line}, Column {diagnostic.column}
                            </span>
                            <Badge variant="outline" className="text-xs">
                              {diagnostic.source}
                            </Badge>
                          </div>
                          <p className={`text-sm ${getSeverityColor(diagnostic.severity)}`}>
                            {diagnostic.message}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="features" className="flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { name: 'Code Completion', icon: Code, description: 'IntelliSense and auto-completion' },
                { name: 'Diagnostics', icon: AlertTriangle, description: 'Real-time error detection' },
                { name: 'Hover Information', icon: FileText, description: 'Symbol information on hover' },
                { name: 'Signature Help', icon: BookOpen, description: 'Function signature assistance' },
                { name: 'Go to References', icon: Search, description: 'Find all symbol references' },
                { name: 'Code Formatting', icon: Zap, description: 'Automatic code formatting' },
                { name: 'Code Actions', icon: Lightbulb, description: 'Quick fixes and refactoring' },
                { name: 'Symbol Rename', icon: Settings, description: 'Smart symbol renaming' }
              ].map((feature, index) => (
                <Card key={index} className="bg-slate-800 border-slate-700">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <feature.icon className="w-5 h-5 text-blue-400" />
                      <span className="font-medium text-white">{feature.name}</span>
                    </div>
                    <p className="text-sm text-slate-400 mb-3">{feature.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-500">
                        {servers.filter(s => s.status === 'running' && s.features[feature.name.toLowerCase().replace(/\s+/g, '') as keyof typeof s.features]).length} / {servers.length} servers
                      </span>
                      <Badge className="bg-green-600 text-xs">Active</Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="settings" className="flex-1">
            <div className="space-y-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">General Settings</CardTitle>
                  <CardDescription>
                    Configure global language server behavior
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white">Auto-start servers</Label>
                      <p className="text-sm text-slate-400">Automatically start language servers when opening files</p>
                    </div>
                    <Switch
                      checked={autoStart}
                      onCheckedChange={setAutoStart}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white">Show diagnostics</Label>
                      <p className="text-sm text-slate-400">Display error and warning indicators in the editor</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white">Enable completion</Label>
                      <p className="text-sm text-slate-400">Show code completion suggestions</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Performance Settings</CardTitle>
                  <CardDescription>
                    Optimize language server performance
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-white mb-2 block">Max memory per server (MB)</Label>
                    <Input
                      type="number"
                      defaultValue="512"
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                  
                  <div>
                    <Label className="text-white mb-2 block">Response timeout (ms)</Label>
                    <Input
                      type="number"
                      defaultValue="5000"
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}