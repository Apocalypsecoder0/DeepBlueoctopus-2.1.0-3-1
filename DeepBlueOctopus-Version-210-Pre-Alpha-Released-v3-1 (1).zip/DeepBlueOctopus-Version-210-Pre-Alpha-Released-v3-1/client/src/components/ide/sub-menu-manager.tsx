import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Menu, ChevronRight, Plus, Search, Settings, 
  FileText, Code, Terminal, Bug, GitBranch,
  Package, Shield, Monitor, Database, Cloud,
  Palette, Keyboard, Bell, User, HelpCircle,
  Zap, Layers, Grid, Eye, MousePointer
} from "lucide-react";

interface SubMenuManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface MenuItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  category: 'file' | 'edit' | 'view' | 'run' | 'tools' | 'help';
  shortcut?: string;
  enabled: boolean;
  submenu?: MenuItem[];
  action?: () => void;
  description: string;
}

interface MenuCategory {
  id: string;
  name: string;
  icon: React.ReactNode;
  items: MenuItem[];
  enabled: boolean;
}

export default function SubMenuManager({ isOpen, onClose }: SubMenuManagerProps) {
  const [activeTab, setActiveTab] = useState("overview");
  const [menuCategories, setMenuCategories] = useState<MenuCategory[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  useEffect(() => {
    initializeMenuSystem();
  }, []);

  const initializeMenuSystem = () => {
    const categories: MenuCategory[] = [
      {
        id: "file",
        name: "File",
        icon: <FileText className="h-4 w-4" />,
        enabled: true,
        items: [
          {
            id: "new-file",
            label: "New File",
            icon: <FileText className="h-4 w-4" />,
            category: "file",
            shortcut: "Ctrl+N",
            enabled: true,
            description: "Create a new file in the current project",
            submenu: [
              {
                id: "new-js",
                label: "JavaScript File",
                icon: <Code className="h-4 w-4" />,
                category: "file",
                enabled: true,
                description: "Create a new JavaScript file"
              },
              {
                id: "new-ts",
                label: "TypeScript File",
                icon: <Code className="h-4 w-4" />,
                category: "file",
                enabled: true,
                description: "Create a new TypeScript file"
              },
              {
                id: "new-html",
                label: "HTML File",
                icon: <Code className="h-4 w-4" />,
                category: "file",
                enabled: true,
                description: "Create a new HTML file"
              },
              {
                id: "new-css",
                label: "CSS File",
                icon: <Code className="h-4 w-4" />,
                category: "file",
                enabled: true,
                description: "Create a new CSS file"
              }
            ]
          },
          {
            id: "open-file",
            label: "Open File",
            icon: <FileText className="h-4 w-4" />,
            category: "file",
            shortcut: "Ctrl+O",
            enabled: true,
            description: "Open an existing file from the file system"
          },
          {
            id: "save-file",
            label: "Save",
            icon: <FileText className="h-4 w-4" />,
            category: "file",
            shortcut: "Ctrl+S",
            enabled: true,
            description: "Save the current file"
          },
          {
            id: "save-all",
            label: "Save All",
            icon: <FileText className="h-4 w-4" />,
            category: "file",
            shortcut: "Ctrl+Shift+S",
            enabled: true,
            description: "Save all open files"
          }
        ]
      },
      {
        id: "edit",
        name: "Edit",
        icon: <Code className="h-4 w-4" />,
        enabled: true,
        items: [
          {
            id: "undo",
            label: "Undo",
            icon: <Code className="h-4 w-4" />,
            category: "edit",
            shortcut: "Ctrl+Z",
            enabled: true,
            description: "Undo the last action"
          },
          {
            id: "redo",
            label: "Redo",
            icon: <Code className="h-4 w-4" />,
            category: "edit",
            shortcut: "Ctrl+Y",
            enabled: true,
            description: "Redo the last undone action"
          },
          {
            id: "find-replace",
            label: "Find and Replace",
            icon: <Search className="h-4 w-4" />,
            category: "edit",
            shortcut: "Ctrl+H",
            enabled: true,
            description: "Search and replace text in the current file",
            submenu: [
              {
                id: "find",
                label: "Find",
                icon: <Search className="h-4 w-4" />,
                category: "edit",
                shortcut: "Ctrl+F",
                enabled: true,
                description: "Find text in the current file"
              },
              {
                id: "find-in-files",
                label: "Find in Files",
                icon: <Search className="h-4 w-4" />,
                category: "edit",
                shortcut: "Ctrl+Shift+F",
                enabled: true,
                description: "Search across all files in the project"
              }
            ]
          },
          {
            id: "format-document",
            label: "Format Document",
            icon: <Code className="h-4 w-4" />,
            category: "edit",
            shortcut: "Shift+Alt+F",
            enabled: true,
            description: "Auto-format the current document"
          }
        ]
      },
      {
        id: "view",
        name: "View",
        icon: <Eye className="h-4 w-4" />,
        enabled: true,
        items: [
          {
            id: "command-palette",
            label: "Command Palette",
            icon: <Terminal className="h-4 w-4" />,
            category: "view",
            shortcut: "Ctrl+Shift+P",
            enabled: true,
            description: "Open the command palette for quick access to all commands"
          },
          {
            id: "explorer",
            label: "File Explorer",
            icon: <FileText className="h-4 w-4" />,
            category: "view",
            shortcut: "Ctrl+Shift+E",
            enabled: true,
            description: "Toggle the file explorer sidebar"
          },
          {
            id: "terminal-panel",
            label: "Terminal",
            icon: <Terminal className="h-4 w-4" />,
            category: "view",
            shortcut: "Ctrl+`",
            enabled: true,
            description: "Toggle the integrated terminal"
          },
          {
            id: "layout-options",
            label: "Layout",
            icon: <Grid className="h-4 w-4" />,
            category: "view",
            enabled: true,
            description: "Customize the IDE layout",
            submenu: [
              {
                id: "split-horizontal",
                label: "Split Horizontal",
                icon: <Grid className="h-4 w-4" />,
                category: "view",
                enabled: true,
                description: "Split the editor horizontally"
              },
              {
                id: "split-vertical",
                label: "Split Vertical",
                icon: <Grid className="h-4 w-4" />,
                category: "view",
                enabled: true,
                description: "Split the editor vertically"
              }
            ]
          }
        ]
      },
      {
        id: "run",
        name: "Run",
        icon: <Zap className="h-4 w-4" />,
        enabled: true,
        items: [
          {
            id: "run-file",
            label: "Run File",
            icon: <Zap className="h-4 w-4" />,
            category: "run",
            shortcut: "F5",
            enabled: true,
            description: "Execute the current file"
          },
          {
            id: "debug-file",
            label: "Debug File",
            icon: <Bug className="h-4 w-4" />,
            category: "run",
            shortcut: "F9",
            enabled: true,
            description: "Debug the current file with breakpoints"
          },
          {
            id: "build-project",
            label: "Build Project",
            icon: <Package className="h-4 w-4" />,
            category: "run",
            shortcut: "Ctrl+Shift+B",
            enabled: true,
            description: "Build the entire project"
          }
        ]
      },
      {
        id: "tools",
        name: "Tools",
        icon: <Settings className="h-4 w-4" />,
        enabled: true,
        items: [
          {
            id: "git-integration",
            label: "Git Integration",
            icon: <GitBranch className="h-4 w-4" />,
            category: "tools",
            shortcut: "Ctrl+Shift+G",
            enabled: true,
            description: "Version control with Git"
          },
          {
            id: "package-manager",
            label: "Package Manager",
            icon: <Package className="h-4 w-4" />,
            category: "tools",
            shortcut: "Ctrl+Shift+N",
            enabled: true,
            description: "Manage project dependencies"
          },
          {
            id: "database-manager",
            label: "Database Manager",
            icon: <Database className="h-4 w-4" />,
            category: "tools",
            shortcut: "Ctrl+Shift+D",
            enabled: true,
            description: "Manage database connections"
          },
          {
            id: "deployment",
            label: "Deploy Manager",
            icon: <Cloud className="h-4 w-4" />,
            category: "tools",
            shortcut: "Ctrl+Shift+Y",
            enabled: true,
            description: "Deploy applications to various platforms"
          }
        ]
      },
      {
        id: "help",
        name: "Help",
        icon: <HelpCircle className="h-4 w-4" />,
        enabled: true,
        items: [
          {
            id: "documentation",
            label: "Documentation",
            icon: <FileText className="h-4 w-4" />,
            category: "help",
            shortcut: "F1",
            enabled: true,
            description: "Access IDE documentation and guides"
          },
          {
            id: "keyboard-shortcuts",
            label: "Keyboard Shortcuts",
            icon: <Keyboard className="h-4 w-4" />,
            category: "help",
            enabled: true,
            description: "View all available keyboard shortcuts"
          },
          {
            id: "about",
            label: "About DeepBlue IDE",
            icon: <HelpCircle className="h-4 w-4" />,
            category: "help",
            enabled: true,
            description: "Information about DeepBlue IDE version and features"
          }
        ]
      }
    ];

    setMenuCategories(categories);
  };

  const toggleMenuItem = (categoryId: string, itemId: string) => {
    setMenuCategories(prev => prev.map(category => 
      category.id === categoryId 
        ? {
            ...category,
            items: category.items.map(item =>
              item.id === itemId
                ? { ...item, enabled: !item.enabled }
                : item
            )
          }
        : category
    ));
  };

  const toggleCategory = (categoryId: string) => {
    setMenuCategories(prev => prev.map(category =>
      category.id === categoryId
        ? { ...category, enabled: !category.enabled }
        : category
    ));
  };

  const filteredCategories = menuCategories.filter(category => {
    if (selectedCategory !== "all" && category.id !== selectedCategory) return false;
    if (!searchTerm) return true;
    
    return category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           category.items.some(item => 
             item.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
             item.description.toLowerCase().includes(searchTerm.toLowerCase())
           );
  });

  const getMenuStats = () => {
    const totalItems = menuCategories.reduce((acc, cat) => acc + cat.items.length, 0);
    const enabledItems = menuCategories.reduce((acc, cat) => 
      acc + cat.items.filter(item => item.enabled).length, 0
    );
    const totalShortcuts = menuCategories.reduce((acc, cat) => 
      acc + cat.items.filter(item => item.shortcut).length, 0
    );
    
    return { totalItems, enabledItems, totalShortcuts };
  };

  const stats = getMenuStats();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Menu className="h-5 w-5" />
            Sub-Menu System Manager
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 overflow-hidden">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
            <TabsTrigger value="shortcuts">Shortcuts</TabsTrigger>
            <TabsTrigger value="customization">Customization</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <ScrollArea className="flex-1 mt-4">
            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Menu Items</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stats.totalItems}</div>
                    <p className="text-xs text-muted-foreground">Across all categories</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Enabled Items</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-500">{stats.enabledItems}</div>
                    <p className="text-xs text-muted-foreground">Currently active</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Keyboard Shortcuts</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stats.totalShortcuts}</div>
                    <p className="text-xs text-muted-foreground">Available shortcuts</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Menu Categories</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{menuCategories.length}</div>
                    <p className="text-xs text-muted-foreground">Main categories</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Menu Structure</CardTitle>
                    <CardDescription>Overview of all menu categories and their items</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {menuCategories.map((category) => (
                        <div key={category.id} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {category.icon}
                            <span className="font-medium">{category.name}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{category.items.length} items</Badge>
                            <Badge 
                              variant={category.enabled ? "default" : "secondary"}
                              className="text-xs"
                            >
                              {category.enabled ? "Enabled" : "Disabled"}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                    <CardDescription>Common menu operations and shortcuts</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button className="w-full justify-start" variant="outline">
                      <Keyboard className="h-4 w-4 mr-2" />
                      View All Shortcuts (F1)
                    </Button>
                    <Button className="w-full justify-start" variant="outline">
                      <Terminal className="h-4 w-4 mr-2" />
                      Command Palette (Ctrl+Shift+P)
                    </Button>
                    <Button className="w-full justify-start" variant="outline">
                      <Settings className="h-4 w-4 mr-2" />
                      Customize Menus
                    </Button>
                    <Button className="w-full justify-start" variant="outline">
                      <FileText className="h-4 w-4 mr-2" />
                      Export Menu Configuration
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="categories" className="space-y-4">
              <div className="flex gap-4 items-center">
                <div className="flex-1">
                  <Input
                    placeholder="Search menu items..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="max-w-sm"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {menuCategories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-4">
                {filteredCategories.map((category) => (
                  <Card key={category.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {category.icon}
                          <CardTitle className="text-base">{category.name}</CardTitle>
                          <Badge variant="outline">{category.items.length} items</Badge>
                        </div>
                        <Switch
                          checked={category.enabled}
                          onCheckedChange={() => toggleCategory(category.id)}
                        />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {category.items.map((item) => (
                          <div key={item.id} className="flex items-center justify-between p-2 rounded border">
                            <div className="flex items-center gap-2">
                              {item.icon}
                              <span className="font-medium">{item.label}</span>
                              {item.shortcut && (
                                <Badge variant="secondary" className="text-xs">
                                  {item.shortcut}
                                </Badge>
                              )}
                              {item.submenu && (
                                <Badge variant="outline" className="text-xs">
                                  {item.submenu.length} subitems
                                </Badge>
                              )}
                            </div>
                            <Switch
                              checked={item.enabled}
                              onCheckedChange={() => toggleMenuItem(category.id, item.id)}
                            />
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="shortcuts" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Keyboard Shortcuts</CardTitle>
                  <CardDescription>All available keyboard shortcuts organized by category</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {menuCategories.map((category) => {
                      const shortcutItems = category.items.filter(item => item.shortcut);
                      if (shortcutItems.length === 0) return null;

                      return (
                        <div key={category.id}>
                          <h4 className="font-medium flex items-center gap-2 mb-3">
                            {category.icon}
                            {category.name}
                          </h4>
                          <div className="grid gap-2">
                            {shortcutItems.map((item) => (
                              <div key={item.id} className="flex justify-between items-center p-2 rounded border">
                                <div className="flex items-center gap-2">
                                  {item.icon}
                                  <span>{item.label}</span>
                                </div>
                                <Badge variant="outline">{item.shortcut}</Badge>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="customization" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Menu Customization</CardTitle>
                  <CardDescription>Customize menu appearance and behavior</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="showIcons">Show Menu Icons</Label>
                      <Switch id="showIcons" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="showShortcuts">Show Keyboard Shortcuts</Label>
                      <Switch id="showShortcuts" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="compactMode">Compact Menu Mode</Label>
                      <Switch id="compactMode" />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="autoHide">Auto-hide Disabled Items</Label>
                      <Switch id="autoHide" />
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <Label>Menu Animation Speed</Label>
                    <Select defaultValue="normal">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="slow">Slow</SelectItem>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="fast">Fast</SelectItem>
                        <SelectItem value="instant">Instant</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    <Label>Menu Theme</Label>
                    <Select defaultValue="system">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="system">System</SelectItem>
                        <SelectItem value="light">Light</SelectItem>
                        <SelectItem value="dark">Dark</SelectItem>
                        <SelectItem value="auto">Auto</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Menu System Settings</CardTitle>
                  <CardDescription>Advanced configuration options</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="enableTooltips">Enable Menu Tooltips</Label>
                      <Switch id="enableTooltips" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="enableSounds">Menu Sound Effects</Label>
                      <Switch id="enableSounds" />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="contextMenus">Enable Context Menus</Label>
                      <Switch id="contextMenus" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="menuHistory">Track Menu Usage</Label>
                      <Switch id="menuHistory" defaultChecked />
                    </div>
                  </div>

                  <Separator />

                  <div className="flex gap-2">
                    <Button>Save Settings</Button>
                    <Button variant="outline">Reset to Defaults</Button>
                    <Button variant="outline">Export Configuration</Button>
                    <Button variant="outline">Import Configuration</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}