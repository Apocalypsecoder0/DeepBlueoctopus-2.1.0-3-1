import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { SoundButton } from "@/components/ui/sound-system";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import {
  Package,
  Download,
  Upload,
  Search,
  Star,
  Heart,
  Trash2,
  Settings,
  Play,
  Pause,
  AlertCircle,
  CheckCircle,
  Clock,
  Code,
  Palette,
  Wrench,
  Database,
  Globe,
  Shield,
  Zap,
  Github,
  ExternalLink,
  RefreshCw,
  Filter,
  TrendingUp,
  Users,
  Award,
  Sparkles
} from "lucide-react";
import { pluginEngine } from "@/lib/plugin-engine";
import { PluginManifest, IPlugin } from "@shared/plugin-schema";

interface PluginManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface MarketplacePlugin {
  id: string;
  name: string;
  version: string;
  description: string;
  author: string;
  category: 'language' | 'theme' | 'utility' | 'debugging' | 'productivity' | 'game-dev' | 'database';
  downloads: number;
  rating: number;
  price: number;
  featured: boolean;
  tags: string[];
  screenshots: string[];
  size: string;
  lastUpdated: string;
  dependencies: string[];
  manifest: PluginManifest;
  code: string;
}

interface InstalledPlugin extends IPlugin {
  enabled: boolean;
  lastUsed?: string;
  size: string;
}

const mockMarketplacePlugins: MarketplacePlugin[] = [
  {
    id: 'advanced-js-linter',
    name: 'Advanced JavaScript Linter',
    version: '2.1.0',
    description: 'Enhanced ESLint integration with AI-powered suggestions and automatic fixes for JavaScript and TypeScript projects.',
    author: 'CodeCraft Studios',
    category: 'utility',
    downloads: 125000,
    rating: 4.8,
    price: 0,
    featured: true,
    tags: ['javascript', 'typescript', 'linting', 'ai'],
    screenshots: [],
    size: '2.3 MB',
    lastUpdated: '2024-12-15',
    dependencies: [],
    manifest: {
      id: 'advanced-js-linter',
      name: 'Advanced JavaScript Linter',
      version: '2.1.0',
      description: 'Enhanced ESLint integration with AI-powered suggestions',
      author: 'CodeCraft Studios',
      main: 'main.js',
      category: 'utility',
      activationEvents: ['onLanguage:javascript'],
      engines: { deepblue: '^1.0.0' },
      contributes: {
        commands: [
          { command: 'linter.fix', title: 'Fix All Issues' },
          { command: 'linter.analyze', title: 'Analyze Code Quality' }
        ]
      }
    },
    code: 'console.log("Advanced JS Linter Plugin");'
  },
  {
    id: 'ocean-theme-pack',
    name: 'Ocean Theme Pack',
    version: '1.5.2',
    description: 'Beautiful collection of ocean-inspired themes with dynamic colors and smooth animations.',
    author: 'DeepBlue Design',
    category: 'theme',
    downloads: 89000,
    rating: 4.9,
    price: 4.99,
    featured: true,
    tags: ['theme', 'ocean', 'blue', 'dark'],
    screenshots: [],
    size: '1.8 MB',
    lastUpdated: '2024-12-10',
    dependencies: [],
    manifest: {
      id: 'ocean-theme-pack',
      name: 'Ocean Theme Pack',
      version: '1.5.2',
      description: 'Beautiful collection of ocean-inspired themes',
      author: 'DeepBlue Design',
      main: 'themes.js',
      category: 'theme',
      activationEvents: ['*'],
      engines: { deepblue: '^1.0.0' },
      contributes: {
        themes: [
          { id: 'deep-ocean', label: 'Deep Ocean', uiTheme: 'vs-dark', path: './themes/deep-ocean.json' },
          { id: 'coral-reef', label: 'Coral Reef', uiTheme: 'vs-dark', path: './themes/coral-reef.json' }
        ]
      }
    },
    code: 'console.log("Ocean Theme Pack Plugin");'
  },
  {
    id: 'unity-game-tools',
    name: 'Unity Game Development Tools',
    version: '3.0.1',
    description: 'Comprehensive Unity integration with scene preview, asset management, and C# IntelliSense.',
    author: 'GameDev Pro',
    category: 'game-dev',
    downloads: 67000,
    rating: 4.7,
    price: 9.99,
    featured: false,
    tags: ['unity', 'game-dev', 'c#', 'assets'],
    screenshots: [],
    size: '5.2 MB',
    lastUpdated: '2024-12-08',
    dependencies: ['csharp-compiler'],
    manifest: {
      id: 'unity-game-tools',
      name: 'Unity Game Development Tools',
      version: '3.0.1',
      description: 'Comprehensive Unity integration',
      author: 'GameDev Pro',
      main: 'unity.js',
      category: 'game-dev',
      activationEvents: ['onLanguage:csharp'],
      engines: { deepblue: '^1.0.0' },
      contributes: {
        languages: [
          { id: 'csharp-unity', extensions: ['.cs'], aliases: ['C# (Unity)'] }
        ],
        commands: [
          { command: 'unity.build', title: 'Build Unity Project' },
          { command: 'unity.preview', title: 'Preview Scene' }
        ]
      }
    },
    code: 'console.log("Unity Game Tools Plugin");'
  },
  {
    id: 'sql-query-helper',
    name: 'SQL Query Helper',
    version: '1.8.0',
    description: 'Interactive SQL query builder with syntax highlighting, auto-completion, and database visualization.',
    author: 'DataBase Solutions',
    category: 'database',
    downloads: 43000,
    rating: 4.6,
    price: 0,
    featured: false,
    tags: ['sql', 'database', 'query', 'visualization'],
    screenshots: [],
    size: '3.1 MB',
    lastUpdated: '2024-12-12',
    dependencies: [],
    manifest: {
      id: 'sql-query-helper',
      name: 'SQL Query Helper',
      version: '1.8.0',
      description: 'Interactive SQL query builder',
      author: 'DataBase Solutions',
      main: 'sql.js',
      category: 'database',
      activationEvents: ['onLanguage:sql'],
      engines: { deepblue: '^1.0.0' },
      contributes: {
        languages: [
          { id: 'sql-enhanced', extensions: ['.sql'], aliases: ['SQL Enhanced'] }
        ]
      }
    },
    code: 'console.log("SQL Query Helper Plugin");'
  }
];

export default function PluginManager({ isOpen, onClose }: PluginManagerProps) {
  const [activeTab, setActiveTab] = useState('marketplace');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'downloads' | 'rating' | 'recent'>('downloads');
  const [installedPlugins, setInstalledPlugins] = useState<InstalledPlugin[]>([]);
  const [isInstalling, setIsInstalling] = useState<string | null>(null);
  const [installProgress, setInstallProgress] = useState(0);
  const [selectedPlugin, setSelectedPlugin] = useState<MarketplacePlugin | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadInstalledPlugins();
    }
  }, [isOpen]);

  const loadInstalledPlugins = async () => {
    try {
      const plugins = pluginEngine.getInstalledPlugins();
      const installed: InstalledPlugin[] = plugins.map(plugin => ({
        ...plugin,
        enabled: true,
        size: '1.2 MB',
        lastUsed: '2024-12-15'
      }));
      setInstalledPlugins(installed);
    } catch (error) {
      console.error('Failed to load installed plugins:', error);
    }
  };

  const filteredMarketplacePlugins = mockMarketplacePlugins
    .filter(plugin => {
      const matchesSearch = plugin.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          plugin.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          plugin.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesCategory = selectedCategory === 'all' || plugin.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'downloads': return b.downloads - a.downloads;
        case 'rating': return b.rating - a.rating;
        case 'recent': return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
        default: return 0;
      }
    });

  const installPlugin = async (plugin: MarketplacePlugin) => {
    setIsInstalling(plugin.id);
    setInstallProgress(0);

    try {
      // Simulate installation progress
      for (let i = 0; i <= 100; i += 10) {
        setInstallProgress(i);
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      const success = await pluginEngine.installPlugin(plugin.manifest, plugin.code);
      if (success) {
        await loadInstalledPlugins();
      }
    } catch (error) {
      console.error('Installation failed:', error);
    } finally {
      setIsInstalling(null);
      setInstallProgress(0);
    }
  };

  const uninstallPlugin = async (pluginId: string) => {
    try {
      const success = await pluginEngine.uninstallPlugin(pluginId);
      if (success) {
        await loadInstalledPlugins();
      }
    } catch (error) {
      console.error('Uninstallation failed:', error);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'language': return <Code className="h-4 w-4" />;
      case 'theme': return <Palette className="h-4 w-4" />;
      case 'utility': return <Wrench className="h-4 w-4" />;
      case 'debugging': return <AlertCircle className="h-4 w-4" />;
      case 'productivity': return <Zap className="h-4 w-4" />;
      case 'game-dev': return <Sparkles className="h-4 w-4" />;
      default: return <Package className="h-4 w-4" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl h-[80vh] bg-[var(--ide-bg)] border-[var(--ide-border)]">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-[var(--ide-text)] flex items-center gap-2">
            <Package className="h-6 w-6 text-blue-400" />
            DeepBlue Plugin Manager
            <Badge className="bg-blue-500/20 text-blue-300">Extensions</Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-1 gap-4">
          {/* Sidebar */}
          <div className="w-64 space-y-4">
            <Tabs value={activeTab} onValueChange={setActiveTab} orientation="vertical">
              <TabsList className="flex flex-col h-auto bg-[var(--ide-panel-bg)] p-1">
                <TabsTrigger value="marketplace" className="w-full justify-start gap-2">
                  <Globe className="h-4 w-4" />
                  Marketplace
                </TabsTrigger>
                <TabsTrigger value="installed" className="w-full justify-start gap-2">
                  <Download className="h-4 w-4" />
                  Installed ({installedPlugins.length})
                </TabsTrigger>
                <TabsTrigger value="develop" className="w-full justify-start gap-2">
                  <Code className="h-4 w-4" />
                  Develop
                </TabsTrigger>
                <TabsTrigger value="settings" className="w-full justify-start gap-2">
                  <Settings className="h-4 w-4" />
                  Settings
                </TabsTrigger>
              </TabsList>
            </Tabs>

            {activeTab === 'marketplace' && (
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-[var(--ide-text-secondary)]">Category</Label>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full mt-1 p-2 bg-[var(--ide-input-bg)] border border-[var(--ide-border)] rounded text-sm text-[var(--ide-text)]"
                  >
                    <option value="all">All Categories</option>
                    <option value="language">Languages</option>
                    <option value="theme">Themes</option>
                    <option value="utility">Utilities</option>
                    <option value="debugging">Debugging</option>
                    <option value="productivity">Productivity</option>
                    <option value="game-dev">Game Development</option>
                  </select>
                </div>

                <div>
                  <Label className="text-xs text-[var(--ide-text-secondary)]">Sort By</Label>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="w-full mt-1 p-2 bg-[var(--ide-input-bg)] border border-[var(--ide-border)] rounded text-sm text-[var(--ide-text)]"
                  >
                    <option value="downloads">Most Downloaded</option>
                    <option value="rating">Highest Rated</option>
                    <option value="recent">Recently Updated</option>
                  </select>
                </div>

                <div className="pt-2">
                  <h4 className="text-xs font-medium text-[var(--ide-text-secondary)] mb-2">Quick Filters</h4>
                  <div className="space-y-1">
                    <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                      <Star className="h-3 w-3 mr-2" />
                      Featured
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                      <Award className="h-3 w-3 mr-2" />
                      Top Rated
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                      <TrendingUp className="h-3 w-3 mr-2" />
                      Trending
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Main Content */}
          <div className="flex-1 flex flex-col">
            {/* Search Bar */}
            {activeTab === 'marketplace' && (
              <div className="flex items-center gap-2 mb-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-[var(--ide-text-secondary)]" />
                  <Input
                    placeholder="Search plugins..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-[var(--ide-input-bg)] border-[var(--ide-border)] text-[var(--ide-text)]"
                  />
                </div>
                <TooltipWrapper title="Refresh" content="Refresh plugin marketplace" type="tip">
                  <SoundButton variant="outline" size="sm">
                    <RefreshCw className="h-4 w-4" />
                  </SoundButton>
                </TooltipWrapper>
              </div>
            )}

            <ScrollArea className="flex-1">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                {/* Marketplace Tab */}
                <TabsContent value="marketplace" className="mt-0">
                  <div className="grid gap-4">
                    {filteredMarketplacePlugins.map((plugin) => (
                      <Card key={plugin.id} className="bg-[var(--ide-panel-bg)] border-[var(--ide-border)]">
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3">
                              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                                {getCategoryIcon(plugin.category)}
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <h3 className="font-semibold text-[var(--ide-text)]">{plugin.name}</h3>
                                  <Badge variant="outline" className="text-xs">
                                    v{plugin.version}
                                  </Badge>
                                  {plugin.featured && (
                                    <Badge className="bg-yellow-500/20 text-yellow-300 text-xs">
                                      Featured
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-sm text-[var(--ide-text-secondary)] mt-1">
                                  by {plugin.author}
                                </p>
                                <p className="text-sm text-[var(--ide-text-secondary)] mt-2">
                                  {plugin.description}
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="flex items-center gap-1 text-sm text-[var(--ide-text-secondary)]">
                                <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                                {plugin.rating}
                              </div>
                              <div className="text-xs text-[var(--ide-text-secondary)] mt-1">
                                {plugin.downloads.toLocaleString()} downloads
                              </div>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4 text-xs text-[var(--ide-text-secondary)]">
                              <span>Size: {plugin.size}</span>
                              <span>Updated: {plugin.lastUpdated}</span>
                              <div className="flex gap-1">
                                {plugin.tags.slice(0, 3).map(tag => (
                                  <Badge key={tag} variant="outline" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {plugin.price > 0 && (
                                <span className="text-sm font-medium text-green-400">
                                  ${plugin.price}
                                </span>
                              )}
                              {isInstalling === plugin.id ? (
                                <div className="flex items-center gap-2">
                                  <Progress value={installProgress} className="w-20 h-2" />
                                  <span className="text-xs">{installProgress}%</span>
                                </div>
                              ) : (
                                <TooltipWrapper title="Install" content="Install this plugin" type="tip">
                                  <SoundButton
                                    onClick={() => installPlugin(plugin)}
                                    size="sm"
                                    className="bg-blue-600 hover:bg-blue-700"
                                  >
                                    <Download className="h-4 w-4 mr-1" />
                                    Install
                                  </SoundButton>
                                </TooltipWrapper>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                {/* Installed Tab */}
                <TabsContent value="installed" className="mt-0">
                  <div className="space-y-4">
                    {installedPlugins.length === 0 ? (
                      <div className="text-center py-12">
                        <Package className="h-12 w-12 text-[var(--ide-text-secondary)] mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-[var(--ide-text)] mb-2">No Plugins Installed</h3>
                        <p className="text-[var(--ide-text-secondary)]">
                          Browse the marketplace to find and install plugins
                        </p>
                        <SoundButton
                          onClick={() => setActiveTab('marketplace')}
                          className="mt-4"
                        >
                          Browse Marketplace
                        </SoundButton>
                      </div>
                    ) : (
                      <div className="grid gap-3">
                        {installedPlugins.map((plugin) => (
                          <Card key={plugin.id} className="bg-[var(--ide-panel-bg)] border-[var(--ide-border)]">
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-blue-600 rounded-lg flex items-center justify-center">
                                    <CheckCircle className="h-5 w-5 text-white" />
                                  </div>
                                  <div>
                                    <h3 className="font-medium text-[var(--ide-text)]">{plugin.manifest.name}</h3>
                                    <p className="text-sm text-[var(--ide-text-secondary)]">
                                      v{plugin.manifest.version} • {plugin.size}
                                    </p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2">
                                  <TooltipWrapper title="Enable/Disable" content="Toggle plugin activation" type="tip">
                                    <Switch
                                      checked={plugin.enabled}
                                      onCheckedChange={(checked) => {
                                        setInstalledPlugins(prev =>
                                          prev.map(p => p.id === plugin.id ? { ...p, enabled: checked } : p)
                                        );
                                      }}
                                    />
                                  </TooltipWrapper>
                                  <TooltipWrapper title="Settings" content="Configure plugin settings" type="tip">
                                    <SoundButton variant="outline" size="sm">
                                      <Settings className="h-4 w-4" />
                                    </SoundButton>
                                  </TooltipWrapper>
                                  <TooltipWrapper title="Uninstall" content="Remove this plugin" type="warning">
                                    <SoundButton
                                      variant="outline"
                                      size="sm"
                                      onClick={() => uninstallPlugin(plugin.id)}
                                      className="text-red-400 hover:text-red-300"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </SoundButton>
                                  </TooltipWrapper>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </div>
                </TabsContent>

                {/* Develop Tab */}
                <TabsContent value="develop" className="mt-0">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold text-[var(--ide-text)] mb-4">Create New Plugin</h3>
                      <Card className="bg-[var(--ide-panel-bg)] border-[var(--ide-border)]">
                        <CardContent className="p-6 space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label>Plugin Name</Label>
                              <Input 
                                placeholder="My Awesome Plugin"
                                className="bg-[var(--ide-input-bg)] border-[var(--ide-border)]"
                              />
                            </div>
                            <div>
                              <Label>Version</Label>
                              <Input 
                                placeholder="1.0.0"
                                className="bg-[var(--ide-input-bg)] border-[var(--ide-border)]"
                              />
                            </div>
                          </div>
                          <div>
                            <Label>Description</Label>
                            <Textarea 
                              placeholder="Describe what your plugin does..."
                              className="bg-[var(--ide-input-bg)] border-[var(--ide-border)]"
                            />
                          </div>
                          <div>
                            <Label>Plugin Code</Label>
                            <Textarea 
                              placeholder="// Your plugin code here..."
                              className="font-mono bg-[var(--ide-input-bg)] border-[var(--ide-border)] h-32"
                            />
                          </div>
                          <div className="flex gap-2">
                            <SoundButton>
                              <Code className="h-4 w-4 mr-2" />
                              Create Plugin
                            </SoundButton>
                            <SoundButton variant="outline">
                              <Upload className="h-4 w-4 mr-2" />
                              Load from File
                            </SoundButton>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold text-[var(--ide-text)] mb-4">Plugin Templates</h3>
                      <div className="grid grid-cols-2 gap-4">
                        {[
                          { name: 'Language Support', desc: 'Add syntax highlighting for a new language', icon: Code },
                          { name: 'Custom Theme', desc: 'Create a custom color theme', icon: Palette },
                          { name: 'Code Snippet', desc: 'Add reusable code snippets', icon: Sparkles },
                          { name: 'Build Tool', desc: 'Integrate with external build tools', icon: Wrench }
                        ].map((template) => (
                          <Card key={template.name} className="bg-[var(--ide-panel-bg)] border-[var(--ide-border)] cursor-pointer hover:bg-[var(--ide-hover-bg)]">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-3">
                                <template.icon className="h-8 w-8 text-blue-400" />
                                <div>
                                  <h4 className="font-medium text-[var(--ide-text)]">{template.name}</h4>
                                  <p className="text-sm text-[var(--ide-text-secondary)]">{template.desc}</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  </div>
                </TabsContent>

                {/* Settings Tab */}
                <TabsContent value="settings" className="mt-0">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold text-[var(--ide-text)] mb-4">Plugin Manager Settings</h3>
                      <Card className="bg-[var(--ide-panel-bg)] border-[var(--ide-border)]">
                        <CardContent className="p-6 space-y-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <Label className="text-[var(--ide-text)]">Auto-update plugins</Label>
                              <p className="text-sm text-[var(--ide-text-secondary)]">
                                Automatically update plugins when new versions are available
                              </p>
                            </div>
                            <Switch defaultChecked />
                          </div>
                          <Separator />
                          <div className="flex items-center justify-between">
                            <div>
                              <Label className="text-[var(--ide-text)]">Show plugin recommendations</Label>
                              <p className="text-sm text-[var(--ide-text-secondary)]">
                                Display recommended plugins based on your usage
                              </p>
                            </div>
                            <Switch defaultChecked />
                          </div>
                          <Separator />
                          <div className="flex items-center justify-between">
                            <div>
                              <Label className="text-[var(--ide-text)]">Enable telemetry</Label>
                              <p className="text-sm text-[var(--ide-text-secondary)]">
                                Help improve plugins by sharing anonymous usage data
                              </p>
                            </div>
                            <Switch />
                          </div>
                          <Separator />
                          <div>
                            <Label className="text-[var(--ide-text)]">Plugin storage location</Label>
                            <div className="flex items-center gap-2 mt-2">
                              <Input 
                                value="~/.deepblue/plugins"
                                readOnly
                                className="bg-[var(--ide-input-bg)] border-[var(--ide-border)]"
                              />
                              <SoundButton variant="outline" size="sm">
                                Browse
                              </SoundButton>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold text-[var(--ide-text)] mb-4">Marketplace Settings</h3>
                      <Card className="bg-[var(--ide-panel-bg)] border-[var(--ide-border)]">
                        <CardContent className="p-6 space-y-4">
                          <div>
                            <Label className="text-[var(--ide-text)]">Marketplace URL</Label>
                            <Input 
                              value="https://marketplace.deepblue-ide.com"
                              className="bg-[var(--ide-input-bg)] border-[var(--ide-border)] mt-2"
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <div>
                              <Label className="text-[var(--ide-text)]">Check for updates daily</Label>
                              <p className="text-sm text-[var(--ide-text-secondary)]">
                                Check marketplace for plugin updates every day
                              </p>
                            </div>
                            <Switch defaultChecked />
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </ScrollArea>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}