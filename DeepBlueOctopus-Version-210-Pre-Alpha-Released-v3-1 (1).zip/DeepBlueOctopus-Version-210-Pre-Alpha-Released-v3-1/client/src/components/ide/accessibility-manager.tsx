import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  Eye, EyeOff, Volume2, VolumeX, Keyboard, 
  MousePointer, Contrast, Type, Focus,
  CheckCircle, AlertCircle, Settings, 
  Accessibility, Moon, Sun, Palette,
  ArrowUp, ArrowDown, ArrowLeft, ArrowRight
} from "lucide-react";

interface AccessibilityManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface AccessibilitySettings {
  // Visual
  highContrast: boolean;
  largeText: boolean;
  fontSize: number;
  reduceMotion: boolean;
  darkMode: boolean;
  colorBlindSupport: string;
  
  // Audio
  soundFeedback: boolean;
  screenReader: boolean;
  voiceVolume: number;
  
  // Motor
  keyboardNavigation: boolean;
  focusIndicators: boolean;
  clickTargetSize: number;
  mouseDwellTime: number;
  
  // Cognitive
  simpleMode: boolean;
  readingAssist: boolean;
  contextHelp: boolean;
}

interface AccessibilityCheck {
  id: string;
  name: string;
  description: string;
  status: 'pass' | 'warning' | 'fail';
  impact: 'low' | 'medium' | 'high' | 'critical';
  category: 'visual' | 'audio' | 'motor' | 'cognitive';
}

export default function AccessibilityManager({ isOpen, onClose }: AccessibilityManagerProps) {
  const [settings, setSettings] = useState<AccessibilitySettings>({
    // Visual
    highContrast: false,
    largeText: false,
    fontSize: 14,
    reduceMotion: false,
    darkMode: false,
    colorBlindSupport: 'none',
    
    // Audio
    soundFeedback: true,
    screenReader: false,
    voiceVolume: 50,
    
    // Motor
    keyboardNavigation: true,
    focusIndicators: true,
    clickTargetSize: 44,
    mouseDwellTime: 500,
    
    // Cognitive
    simpleMode: false,
    readingAssist: false,
    contextHelp: true
  });

  const [accessibilityChecks] = useState<AccessibilityCheck[]>([
    {
      id: 'color-contrast',
      name: 'Color Contrast',
      description: 'Text has sufficient contrast ratio (4.5:1 for normal text)',
      status: 'pass',
      impact: 'high',
      category: 'visual'
    },
    {
      id: 'alt-text',
      name: 'Alternative Text',
      description: 'Images have descriptive alt text',
      status: 'warning',
      impact: 'medium',
      category: 'visual'
    },
    {
      id: 'keyboard-focus',
      name: 'Keyboard Focus',
      description: 'All interactive elements are keyboard accessible',
      status: 'pass',
      impact: 'critical',
      category: 'motor'
    },
    {
      id: 'aria-labels',
      name: 'ARIA Labels',
      description: 'Interactive elements have proper ARIA labels',
      status: 'warning',
      impact: 'high',
      category: 'visual'
    },
    {
      id: 'heading-structure',
      name: 'Heading Structure',
      description: 'Headings follow logical hierarchy (h1-h6)',
      status: 'pass',
      impact: 'medium',
      category: 'cognitive'
    },
    {
      id: 'touch-targets',
      name: 'Touch Target Size',
      description: 'Touch targets are at least 44x44 pixels',
      status: 'pass',
      impact: 'medium',
      category: 'motor'
    }
  ]);

  const { toast } = useToast();

  useEffect(() => {
    // Load saved accessibility settings
    const saved = localStorage.getItem('accessibility-settings');
    if (saved) {
      try {
        setSettings(JSON.parse(saved));
      } catch (error) {
        console.error('Error loading accessibility settings:', error);
      }
    }

    // Apply initial accessibility features
    applyAccessibilitySettings();
  }, []);

  useEffect(() => {
    // Save settings whenever they change
    localStorage.setItem('accessibility-settings', JSON.stringify(settings));
    applyAccessibilitySettings();
  }, [settings]);

  const applyAccessibilitySettings = () => {
    const root = document.documentElement;
    
    // High contrast mode
    if (settings.highContrast) {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }
    
    // Large text
    if (settings.largeText) {
      root.style.fontSize = `${settings.fontSize + 4}px`;
    } else {
      root.style.fontSize = `${settings.fontSize}px`;
    }
    
    // Reduce motion
    if (settings.reduceMotion) {
      root.style.setProperty('--animation-duration', '0.01ms');
      root.style.setProperty('--transition-duration', '0.01ms');
    } else {
      root.style.removeProperty('--animation-duration');
      root.style.removeProperty('--transition-duration');
    }
    
    // Dark mode
    if (settings.darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    
    // Color blind support
    root.classList.remove('protanopia', 'deuteranopia', 'tritanopia');
    if (settings.colorBlindSupport !== 'none') {
      root.classList.add(settings.colorBlindSupport);
    }
    
    // Focus indicators
    if (settings.focusIndicators) {
      root.classList.add('enhanced-focus');
    } else {
      root.classList.remove('enhanced-focus');
    }
    
    // Click target size
    root.style.setProperty('--min-touch-size', `${settings.clickTargetSize}px`);
  };

  const updateSetting = <K extends keyof AccessibilitySettings>(
    key: K, 
    value: AccessibilitySettings[K]
  ) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const runAccessibilityAudit = () => {
    // In a real application, this would run actual accessibility tests
    toast({
      title: "Accessibility Audit Complete",
      description: "Found 2 warnings that can be improved",
    });
  };

  const enableKeyboardShortcuts = () => {
    const shortcuts = [
      { key: 'Alt+1', action: 'Jump to main content' },
      { key: 'Alt+2', action: 'Jump to navigation' },
      { key: 'Alt+3', action: 'Jump to sidebar' },
      { key: 'Tab', action: 'Navigate forward' },
      { key: 'Shift+Tab', action: 'Navigate backward' },
      { key: 'Enter/Space', action: 'Activate element' },
      { key: 'Escape', action: 'Close dialog/menu' }
    ];

    // Register keyboard event listeners
    const handleKeydown = (e: KeyboardEvent) => {
      if (e.altKey && e.key === '1') {
        const main = document.querySelector('main');
        if (main) main.focus();
        e.preventDefault();
      }
      // Add more shortcuts as needed
    };

    document.addEventListener('keydown', handleKeydown);
    
    return () => {
      document.removeEventListener('keydown', handleKeydown);
    };
  };

  const getStatusIcon = (status: AccessibilityCheck['status']) => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'warning':
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
      case 'fail':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getImpactColor = (impact: AccessibilityCheck['impact']) => {
    switch (impact) {
      case 'low':
        return 'text-green-600';
      case 'medium':
        return 'text-yellow-600';
      case 'high':
        return 'text-orange-600';
      case 'critical':
        return 'text-red-600';
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Accessibility className="h-5 w-5" />
            Accessibility Features & ARIA Support
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="settings" className="flex-1">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="audit">Audit</TabsTrigger>
            <TabsTrigger value="keyboard">Keyboard Nav</TabsTrigger>
            <TabsTrigger value="help">Help</TabsTrigger>
          </TabsList>

          <TabsContent value="settings" className="space-y-4">
            <ScrollArea className="h-96">
              <div className="space-y-6">
                {/* Visual Accessibility */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Eye className="h-4 w-4" />
                      Visual Accessibility
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label>High Contrast Mode</Label>
                          <p className="text-xs text-muted-foreground">Enhance color contrast for better visibility</p>
                        </div>
                        <Switch
                          checked={settings.highContrast}
                          onCheckedChange={(value) => updateSetting('highContrast', value)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Large Text</Label>
                          <p className="text-xs text-muted-foreground">Increase text size for readability</p>
                        </div>
                        <Switch
                          checked={settings.largeText}
                          onCheckedChange={(value) => updateSetting('largeText', value)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Reduce Motion</Label>
                          <p className="text-xs text-muted-foreground">Minimize animations and transitions</p>
                        </div>
                        <Switch
                          checked={settings.reduceMotion}
                          onCheckedChange={(value) => updateSetting('reduceMotion', value)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Dark Mode</Label>
                          <p className="text-xs text-muted-foreground">Use dark theme for reduced eye strain</p>
                        </div>
                        <Switch
                          checked={settings.darkMode}
                          onCheckedChange={(value) => updateSetting('darkMode', value)}
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <Label>Font Size: {settings.fontSize}px</Label>
                        <Slider
                          value={[settings.fontSize]}
                          onValueChange={([value]) => updateSetting('fontSize', value)}
                          max={24}
                          min={10}
                          step={1}
                          className="mt-2"
                        />
                      </div>

                      <div>
                        <Label>Color Blind Support</Label>
                        <Select
                          value={settings.colorBlindSupport}
                          onValueChange={(value) => updateSetting('colorBlindSupport', value)}
                        >
                          <SelectTrigger className="mt-2">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">None</SelectItem>
                            <SelectItem value="protanopia">Protanopia (Red-blind)</SelectItem>
                            <SelectItem value="deuteranopia">Deuteranopia (Green-blind)</SelectItem>
                            <SelectItem value="tritanopia">Tritanopia (Blue-blind)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Audio Accessibility */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Volume2 className="h-4 w-4" />
                      Audio Accessibility
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Sound Feedback</Label>
                          <p className="text-xs text-muted-foreground">Audio cues for actions</p>
                        </div>
                        <Switch
                          checked={settings.soundFeedback}
                          onCheckedChange={(value) => updateSetting('soundFeedback', value)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Screen Reader Support</Label>
                          <p className="text-xs text-muted-foreground">Optimize for screen readers</p>
                        </div>
                        <Switch
                          checked={settings.screenReader}
                          onCheckedChange={(value) => updateSetting('screenReader', value)}
                        />
                      </div>
                    </div>

                    <div>
                      <Label>Voice Volume: {settings.voiceVolume}%</Label>
                      <Slider
                        value={[settings.voiceVolume]}
                        onValueChange={([value]) => updateSetting('voiceVolume', value)}
                        max={100}
                        min={0}
                        step={5}
                        className="mt-2"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Motor Accessibility */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MousePointer className="h-4 w-4" />
                      Motor Accessibility
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Keyboard Navigation</Label>
                          <p className="text-xs text-muted-foreground">Navigate using keyboard only</p>
                        </div>
                        <Switch
                          checked={settings.keyboardNavigation}
                          onCheckedChange={(value) => updateSetting('keyboardNavigation', value)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Enhanced Focus Indicators</Label>
                          <p className="text-xs text-muted-foreground">Visible focus outlines</p>
                        </div>
                        <Switch
                          checked={settings.focusIndicators}
                          onCheckedChange={(value) => updateSetting('focusIndicators', value)}
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <Label>Click Target Size: {settings.clickTargetSize}px</Label>
                        <Slider
                          value={[settings.clickTargetSize]}
                          onValueChange={([value]) => updateSetting('clickTargetSize', value)}
                          max={60}
                          min={24}
                          step={2}
                          className="mt-2"
                        />
                      </div>

                      <div>
                        <Label>Mouse Dwell Time: {settings.mouseDwellTime}ms</Label>
                        <Slider
                          value={[settings.mouseDwellTime]}
                          onValueChange={([value]) => updateSetting('mouseDwellTime', value)}
                          max={2000}
                          min={100}
                          step={100}
                          className="mt-2"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Cognitive Accessibility */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Focus className="h-4 w-4" />
                      Cognitive Accessibility
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Simple Mode</Label>
                          <p className="text-xs text-muted-foreground">Simplified interface layout</p>
                        </div>
                        <Switch
                          checked={settings.simpleMode}
                          onCheckedChange={(value) => updateSetting('simpleMode', value)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Reading Assist</Label>
                          <p className="text-xs text-muted-foreground">Highlight current line</p>
                        </div>
                        <Switch
                          checked={settings.readingAssist}
                          onCheckedChange={(value) => updateSetting('readingAssist', value)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Context Help</Label>
                          <p className="text-xs text-muted-foreground">Show helpful tooltips</p>
                        </div>
                        <Switch
                          checked={settings.contextHelp}
                          onCheckedChange={(value) => updateSetting('contextHelp', value)}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="audit" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Accessibility Audit Results</h3>
              <Button onClick={runAccessibilityAudit}>
                <Settings className="h-4 w-4 mr-2" />
                Run Audit
              </Button>
            </div>

            <ScrollArea className="h-96">
              <div className="space-y-3">
                {accessibilityChecks.map((check) => (
                  <Card key={check.id} className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          {getStatusIcon(check.status)}
                          <h4 className="font-medium">{check.name}</h4>
                          <Badge variant="outline" className={getImpactColor(check.impact)}>
                            {check.impact}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{check.description}</p>
                      </div>
                      <Badge variant={check.status === 'pass' ? 'default' : check.status === 'warning' ? 'secondary' : 'destructive'}>
                        {check.status}
                      </Badge>
                    </div>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="keyboard" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Keyboard className="h-4 w-4" />
                  Keyboard Navigation Shortcuts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <h4 className="font-medium">Navigation</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <kbd className="px-2 py-1 bg-muted rounded">Tab</kbd>
                        <span>Next element</span>
                      </div>
                      <div className="flex justify-between">
                        <kbd className="px-2 py-1 bg-muted rounded">Shift+Tab</kbd>
                        <span>Previous element</span>
                      </div>
                      <div className="flex justify-between">
                        <kbd className="px-2 py-1 bg-muted rounded">Alt+1</kbd>
                        <span>Main content</span>
                      </div>
                      <div className="flex justify-between">
                        <kbd className="px-2 py-1 bg-muted rounded">Alt+2</kbd>
                        <span>Navigation</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-medium">Actions</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <kbd className="px-2 py-1 bg-muted rounded">Enter</kbd>
                        <span>Activate/Submit</span>
                      </div>
                      <div className="flex justify-between">
                        <kbd className="px-2 py-1 bg-muted rounded">Space</kbd>
                        <span>Select/Activate</span>
                      </div>
                      <div className="flex justify-between">
                        <kbd className="px-2 py-1 bg-muted rounded">Escape</kbd>
                        <span>Close/Cancel</span>
                      </div>
                      <div className="flex justify-between">
                        <kbd className="px-2 py-1 bg-muted rounded">Arrow Keys</kbd>
                        <span>Navigate lists/menus</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-muted rounded-lg">
                  <h4 className="font-medium mb-2">Focus Management</h4>
                  <p className="text-sm text-muted-foreground">
                    The IDE automatically manages focus for modal dialogs, dropdown menus, and navigation. 
                    Focus is trapped within modal dialogs and returns to the triggering element when closed.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="help" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Accessibility Resources</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium">Screen Readers</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      DeepBlue:Octopus IDE is compatible with popular screen readers including NVDA, JAWS, and VoiceOver.
                      All interactive elements have proper ARIA labels and roles.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-medium">Browser Support</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      Best accessibility support is available in modern browsers (Chrome 80+, Firefox 75+, Safari 13+, Edge 80+).
                    </p>
                  </div>

                  <div>
                    <h4 className="font-medium">Feedback</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      If you encounter accessibility issues or have suggestions for improvement, please contact our support team.
                    </p>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-2">Quick Setup</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    <Button variant="outline" size="sm" onClick={() => updateSetting('highContrast', true)}>
                      Enable High Contrast
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => updateSetting('largeText', true)}>
                      Enable Large Text
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => updateSetting('reduceMotion', true)}>
                      Reduce Motion
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => updateSetting('keyboardNavigation', true)}>
                      Keyboard Navigation
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}