import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  AlertTriangle,
  CheckCircle2,
  Clock,
  Code,
  Database,
  FileText,
  GitBranch,
  Hammer,
  Layers,
  Monitor,
  Package,
  Palette,
  Play,
  Search,
  Settings,
  Shield,
  Smartphone,
  Terminal,
  Upload,
  Users,
  Wrench,
  Zap,
  Target,
  TrendingUp,
  Calendar,
  Bug,
  Lightbulb,
  Star,
  ArrowRight,
  Filter,
  SortAsc,
  RefreshCw
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Feature {
  id: string;
  name: string;
  description: string;
  category: string;
  priority: 'high' | 'medium' | 'low';
  status: 'completed' | 'in-progress' | 'planned' | 'blocked';
  progress: number;
  estimatedHours: number;
  dependencies: string[];
  assignee?: string;
  dueDate?: string;
  tags: string[];
}

interface Category {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
  features: Feature[];
  completion: number;
}

const mockFeatures: Feature[] = [
  {
    id: 'syntax-highlighting',
    name: 'Real-time Syntax Error Highlighting',
    description: 'Monaco editor diagnostics showing errors and warnings in real-time',
    category: 'core',
    priority: 'high',
    status: 'completed',
    progress: 100,
    estimatedHours: 16,
    dependencies: [],
    assignee: 'Frontend Team',
    dueDate: '2025-07-14',
    tags: ['editor', 'diagnostics', 'typescript']
  },
  {
    id: 'drag-drop-upload',
    name: 'Drag & Drop File Upload',
    description: 'Comprehensive file upload system with progress tracking and metadata',
    category: 'core',
    priority: 'high',
    status: 'completed',
    progress: 100,
    estimatedHours: 24,
    dependencies: ['file-preview'],
    assignee: 'UI Team',
    dueDate: '2025-07-21',
    tags: ['files', 'upload', 'ux']
  },
  {
    id: 'auto-save',
    name: 'Auto-save Functionality',
    description: 'Automatic file saving with conflict resolution and recovery',
    category: 'core',
    priority: 'high',
    status: 'completed',
    progress: 100,
    estimatedHours: 20,
    dependencies: [],
    assignee: 'Backend Team',
    tags: ['files', 'persistence', 'reliability']
  },
  {
    id: 'file-preview',
    name: 'File Preview System',
    description: 'Preview images, videos, documents, and other file formats',
    category: 'core',
    priority: 'high',
    status: 'completed',
    progress: 100,
    estimatedHours: 32,
    dependencies: [],
    assignee: 'Frontend Team',
    dueDate: '2025-07-18',
    tags: ['files', 'preview', 'multimedia']
  },
  {
    id: 'collaboration',
    name: 'Real-time Collaboration',
    description: 'Multi-user editing with live cursors and chat',
    category: 'collaboration',
    priority: 'medium',
    status: 'completed',
    progress: 100,
    estimatedHours: 80,
    dependencies: ['websockets', 'user-management'],
    assignee: 'Full-stack Team',
    dueDate: '2025-08-15',
    tags: ['collaboration', 'websockets', 'realtime']
  },
  {
    id: 'split-editor',
    name: 'Split Screen Editor',
    description: 'Side-by-side file editing with sync options',
    category: 'editor',
    priority: 'medium',
    status: 'completed',
    progress: 100,
    estimatedHours: 28,
    dependencies: ['layout-system'],
    assignee: 'Frontend Team',
    dueDate: '2025-08-01',
    tags: ['editor', 'layout', 'productivity']
  },
  {
    id: 'api-client',
    name: 'REST API Client & Testing',
    description: 'Postman-like interface for API testing and documentation',
    category: 'tools',
    priority: 'medium',
    status: 'completed',
    progress: 100,
    estimatedHours: 60,
    dependencies: ['request-library'],
    assignee: 'Tools Team',
    dueDate: '2025-09-01',
    tags: ['api', 'testing', 'http']
  },
  {
    id: 'database-designer',
    name: 'Database Schema Designer',
    description: 'Visual database design tool with relationship mapping',
    category: 'database',
    priority: 'medium',
    status: 'completed',
    progress: 100,
    estimatedHours: 72,
    dependencies: ['database-connection'],
    assignee: 'Backend Team',
    dueDate: '2025-09-15',
    tags: ['database', 'schema', 'visual']
  },
  // Final 5% - Infrastructure Polish - NOW COMPLETED!
  {
    id: 'docker-integration',
    name: 'Docker Integration',
    description: 'Container management within IDE',
    category: 'infrastructure',
    priority: 'high',
    status: 'completed',
    progress: 100,
    estimatedHours: 48,
    dependencies: [],
    assignee: 'DevOps Team',
    dueDate: '2025-07-07',
    tags: ['docker', 'containers', 'devops']
  },
  {
    id: 'plugin-marketplace',
    name: 'Plugin Marketplace',
    description: 'Third-party extension system',
    category: 'infrastructure',
    priority: 'high',
    status: 'completed',
    progress: 100,
    estimatedHours: 96,
    dependencies: [],
    assignee: 'Architecture Team',
    dueDate: '2025-07-07',
    tags: ['plugins', 'marketplace', 'extensions']
  },
  {
    id: 'performance-monitoring',
    name: 'Performance Monitoring',
    description: 'Real-time system performance analysis',
    category: 'infrastructure',
    priority: 'high',
    status: 'completed',
    progress: 100,
    estimatedHours: 32,
    dependencies: [],
    assignee: 'Infrastructure Team',
    dueDate: '2025-07-07',
    tags: ['monitoring', 'performance', 'analytics']
  }
];

const categories: Category[] = [
  {
    id: 'core',
    name: 'Core IDE Functionality',
    icon: <Code className="h-5 w-5" />,
    color: 'bg-red-500',
    features: [],
    completion: 0
  },
  {
    id: 'editor',
    name: 'Editor Enhancements',
    icon: <FileText className="h-5 w-5" />,
    color: 'bg-blue-500',
    features: [],
    completion: 0
  },
  {
    id: 'tools',
    name: 'Development Tools',
    icon: <Wrench className="h-5 w-5" />,
    color: 'bg-green-500',
    features: [],
    completion: 0
  },
  {
    id: 'database',
    name: 'Database Tools',
    icon: <Database className="h-5 w-5" />,
    color: 'bg-purple-500',
    features: [],
    completion: 0
  },
  {
    id: 'collaboration',
    name: 'Collaboration',
    icon: <Users className="h-5 w-5" />,
    color: 'bg-orange-500',
    features: [],
    completion: 0
  },
  {
    id: 'deployment',
    name: 'DevOps & Deployment',
    icon: <Upload className="h-5 w-5" />,
    color: 'bg-teal-500',
    features: [],
    completion: 0
  },
  {
    id: 'infrastructure',
    name: 'Infrastructure & Performance',
    icon: <Settings className="h-5 w-5" />,
    color: 'bg-indigo-500',
    features: [],
    completion: 0
  }
];

export default function MissingFeaturesSystem() {
  const [activeTab, setActiveTab] = useState('overview');
  const [features, setFeatures] = useState<Feature[]>(mockFeatures);
  const [filteredFeatures, setFilteredFeatures] = useState<Feature[]>(mockFeatures);
  const [searchTerm, setSearchTerm] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('priority');
  const [categoriesWithFeatures, setCategoriesWithFeatures] = useState<Category[]>([]);

  const { toast } = useToast();

  useEffect(() => {
    // Group features by category and calculate completion
    const updatedCategories = categories.map(category => {
      const categoryFeatures = features.filter(f => f.category === category.id);
      const completion = categoryFeatures.length > 0 
        ? Math.round(categoryFeatures.reduce((sum, f) => sum + f.progress, 0) / categoryFeatures.length)
        : 0;
      
      return {
        ...category,
        features: categoryFeatures,
        completion
      };
    });
    setCategoriesWithFeatures(updatedCategories);
  }, [features]);

  useEffect(() => {
    // Apply filters and search
    let filtered = features;

    if (searchTerm) {
      filtered = filtered.filter(f => 
        f.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        f.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        f.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (priorityFilter !== 'all') {
      filtered = filtered.filter(f => f.priority === priorityFilter);
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(f => f.status === statusFilter);
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(f => f.category === selectedCategory);
    }

    // Sort features
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'priority':
          const priorityOrder = { high: 3, medium: 2, low: 1 };
          return priorityOrder[b.priority] - priorityOrder[a.priority];
        case 'progress':
          return b.progress - a.progress;
        case 'dueDate':
          if (!a.dueDate) return 1;
          if (!b.dueDate) return -1;
          return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        case 'name':
          return a.name.localeCompare(b.name);
        default:
          return 0;
      }
    });

    setFilteredFeatures(filtered);
  }, [features, searchTerm, priorityFilter, statusFilter, selectedCategory, sortBy]);

  const handleFeatureUpdate = (featureId: string, updates: Partial<Feature>) => {
    setFeatures(prev => prev.map(f => 
      f.id === featureId ? { ...f, ...updates } : f
    ));
    
    toast({
      title: 'Feature Updated',
      description: 'Feature status has been updated successfully',
    });
  };

  const getOverallProgress = () => {
    if (features.length === 0) return 0;
    return Math.round(features.reduce((sum, f) => sum + f.progress, 0) / features.length);
  };

  const getStatusCounts = () => {
    return {
      completed: features.filter(f => f.status === 'completed').length,
      inProgress: features.filter(f => f.status === 'in-progress').length,
      planned: features.filter(f => f.status === 'planned').length,
      blocked: features.filter(f => f.status === 'blocked').length
    };
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'medium': return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'low': return <Target className="h-4 w-4 text-green-500" />;
      default: return null;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'in-progress': return <Play className="h-4 w-4 text-blue-500" />;
      case 'planned': return <Calendar className="h-4 w-4 text-gray-500" />;
      case 'blocked': return <Bug className="h-4 w-4 text-red-500" />;
      default: return null;
    }
  };

  const statusCounts = getStatusCounts();
  const overallProgress = getOverallProgress();

  return (
    <div className="w-full h-full bg-background overflow-hidden">
      <div className="border-b p-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-orange-500/10 rounded-lg">
            <Lightbulb className="h-6 w-6 text-orange-500" />
          </div>
          <div>
            <h1 className="text-xl font-bold">Missing Features System</h1>
            <p className="text-sm text-muted-foreground">
              Track and manage feature development progress
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Badge variant="outline">
              {overallProgress}% Complete
            </Badge>
            <Badge variant="outline">
              {features.length} Total Features
            </Badge>
          </div>
        </div>
      </div>

      <div className="flex h-full">
        <div className="flex-1 overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
            <TabsList className="w-full justify-start border-b rounded-none h-12 bg-transparent">
              <TabsTrigger value="overview" className="gap-2">
                <TrendingUp className="h-4 w-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="features" className="gap-2">
                <FileText className="h-4 w-4" />
                Features
              </TabsTrigger>
              <TabsTrigger value="categories" className="gap-2">
                <Layers className="h-4 w-4" />
                Categories
              </TabsTrigger>
              <TabsTrigger value="progress" className="gap-2">
                <Target className="h-4 w-4" />
                Progress
              </TabsTrigger>
              <TabsTrigger value="roadmap" className="gap-2">
                <Calendar className="h-4 w-4" />
                Roadmap
              </TabsTrigger>
            </TabsList>

            <div className="p-4 h-full overflow-y-auto">
              <TabsContent value="overview" className="space-y-6 m-0">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Overall Progress</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{overallProgress}%</div>
                      <Progress value={overallProgress} className="mt-2" />
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                        Completed
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-green-600">{statusCounts.completed}</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Play className="h-4 w-4 text-blue-500" />
                        In Progress
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-blue-600">{statusCounts.inProgress}</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-gray-500" />
                        Planned
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-gray-600">{statusCounts.planned}</div>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Development Phases</CardTitle>
                    <CardDescription>
                      Implementation roadmap organized by priority
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                          <span className="font-medium">Phase 1: Core Stability</span>
                          <Badge variant="outline">Weeks 1-2</Badge>
                        </div>
                        <span className="text-sm text-muted-foreground">5 features</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                          <span className="font-medium">Phase 2: Developer Experience</span>
                          <Badge variant="outline">Weeks 3-4</Badge>
                        </div>
                        <span className="text-sm text-muted-foreground">8 features</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                          <span className="font-medium">Phase 3: Professional Tools</span>
                          <Badge variant="outline">Weeks 5-8</Badge>
                        </div>
                        <span className="text-sm text-muted-foreground">12 features</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                          <span className="font-medium">Phase 4: Advanced Features</span>
                          <Badge variant="outline">Weeks 9-12</Badge>
                        </div>
                        <span className="text-sm text-muted-foreground">15 features</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Alert>
                  <Lightbulb className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Next Priority:</strong> Focus on completing real-time syntax highlighting and drag & drop file upload. 
                    These features will significantly improve the core IDE experience.
                  </AlertDescription>
                </Alert>
              </TabsContent>

              <TabsContent value="features" className="space-y-4 m-0">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="flex items-center gap-2">
                    <Search className="h-4 w-4" />
                    <Input
                      placeholder="Search features..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-64"
                    />
                  </div>
                  
                  <select
                    value={priorityFilter}
                    onChange={(e) => setPriorityFilter(e.target.value)}
                    className="px-3 py-2 border rounded-md bg-background"
                  >
                    <option value="all">All Priorities</option>
                    <option value="high">High Priority</option>
                    <option value="medium">Medium Priority</option>
                    <option value="low">Low Priority</option>
                  </select>
                  
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-3 py-2 border rounded-md bg-background"
                  >
                    <option value="all">All Status</option>
                    <option value="completed">Completed</option>
                    <option value="in-progress">In Progress</option>
                    <option value="planned">Planned</option>
                    <option value="blocked">Blocked</option>
                  </select>
                  
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="px-3 py-2 border rounded-md bg-background"
                  >
                    <option value="priority">Sort by Priority</option>
                    <option value="progress">Sort by Progress</option>
                    <option value="dueDate">Sort by Due Date</option>
                    <option value="name">Sort by Name</option>
                  </select>
                  
                  <Button variant="outline" size="sm" onClick={() => setSearchTerm('')}>
                    <RefreshCw className="h-4 w-4 mr-1" />
                    Reset
                  </Button>
                </div>

                <div className="space-y-3">
                  {filteredFeatures.map((feature) => (
                    <Card key={feature.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              {getPriorityIcon(feature.priority)}
                              <h3 className="font-medium">{feature.name}</h3>
                              <Badge variant={
                                feature.priority === 'high' ? 'destructive' :
                                feature.priority === 'medium' ? 'default' : 'secondary'
                              }>
                                {feature.priority}
                              </Badge>
                              {getStatusIcon(feature.status)}
                              <Badge variant="outline">{feature.status}</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">
                              {feature.description}
                            </p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              {feature.assignee && <span>Assigned: {feature.assignee}</span>}
                              {feature.dueDate && <span>Due: {feature.dueDate}</span>}
                              <span>{feature.estimatedHours}h estimated</span>
                            </div>
                            <div className="flex flex-wrap gap-1 mt-2">
                              {feature.tags.map(tag => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="ml-4 text-right">
                            <div className="text-sm font-medium mb-1">{feature.progress}%</div>
                            <Progress value={feature.progress} className="w-24" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="categories" className="space-y-4 m-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {categoriesWithFeatures.map((category) => (
                    <Card key={category.id}>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-base">
                          <div className={`p-2 ${category.color} text-white rounded-lg`}>
                            {category.icon}
                          </div>
                          {category.name}
                        </CardTitle>
                        <CardDescription>
                          {category.features.length} features • {category.completion}% complete
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Progress value={category.completion} className="mb-4" />
                        <div className="space-y-2">
                          {category.features.slice(0, 3).map((feature) => (
                            <div key={feature.id} className="flex items-center justify-between text-sm">
                              <span className="truncate">{feature.name}</span>
                              <div className="flex items-center gap-1">
                                {getStatusIcon(feature.status)}
                                <span>{feature.progress}%</span>
                              </div>
                            </div>
                          ))}
                          {category.features.length > 3 && (
                            <div className="text-xs text-muted-foreground">
                              +{category.features.length - 3} more features
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="progress" className="space-y-4 m-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Development Progress Tracking</CardTitle>
                    <CardDescription>
                      Detailed progress analysis and metrics
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-green-600 mb-1">{statusCounts.completed}</div>
                        <div className="text-sm text-muted-foreground">Features Completed</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600 mb-1">
                          {features.reduce((sum, f) => sum + f.estimatedHours, 0)}
                        </div>
                        <div className="text-sm text-muted-foreground">Total Estimated Hours</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-purple-600 mb-1">12-18</div>
                        <div className="text-sm text-muted-foreground">Months to Complete</div>
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <h4 className="font-medium mb-3">High Priority Features Progress</h4>
                      <div className="space-y-3">
                        {features.filter(f => f.priority === 'high').map((feature) => (
                          <div key={feature.id}>
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-sm font-medium">{feature.name}</span>
                              <span className="text-sm text-muted-foreground">{feature.progress}%</span>
                            </div>
                            <Progress value={feature.progress} />
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="roadmap" className="space-y-4 m-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Development Roadmap</CardTitle>
                    <CardDescription>
                      Timeline and milestones for feature implementation
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="relative">
                        <div className="absolute left-4 top-0 bottom-0 w-px bg-border"></div>
                        
                        <div className="space-y-6">
                          <div className="flex items-start gap-4">
                            <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                              1
                            </div>
                            <div>
                              <h4 className="font-medium">Phase 1: Core Stability</h4>
                              <p className="text-sm text-muted-foreground mb-2">Weeks 1-2</p>
                              <div className="space-y-1">
                                <div className="text-sm">• Real-time Syntax Error Highlighting</div>
                                <div className="text-sm">• Drag & Drop File Upload</div>
                                <div className="text-sm">• Auto-save Functionality</div>
                                <div className="text-sm">• File Preview System</div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-start gap-4">
                            <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                              2
                            </div>
                            <div>
                              <h4 className="font-medium">Phase 2: Developer Experience</h4>
                              <p className="text-sm text-muted-foreground mb-2">Weeks 3-4</p>
                              <div className="space-y-1">
                                <div className="text-sm">• Advanced Find & Replace</div>
                                <div className="text-sm">• Code Snippets Manager</div>
                                <div className="text-sm">• Split Screen Editor</div>
                                <div className="text-sm">• Multi-cursor Editing</div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-start gap-4">
                            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                              3
                            </div>
                            <div>
                              <h4 className="font-medium">Phase 3: Professional Tools</h4>
                              <p className="text-sm text-muted-foreground mb-2">Weeks 5-8</p>
                              <div className="space-y-1">
                                <div className="text-sm">• REST API Client & Testing</div>
                                <div className="text-sm">• Database Schema Designer</div>
                                <div className="text-sm">• SSH Connection Manager</div>
                                <div className="text-sm">• Environment Variables Manager</div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-start gap-4">
                            <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                              4
                            </div>
                            <div>
                              <h4 className="font-medium">Phase 4: Advanced Features</h4>
                              <p className="text-sm text-muted-foreground mb-2">Weeks 9-12</p>
                              <div className="space-y-1">
                                <div className="text-sm">• Plugin Marketplace</div>
                                <div className="text-sm">• CI/CD Pipeline Builder</div>
                                <div className="text-sm">• Cloud Provider Integration</div>
                                <div className="text-sm">• Advanced Analytics</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
}