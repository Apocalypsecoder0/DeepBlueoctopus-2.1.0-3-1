import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Play, 
  Square, 
  RefreshCw, 
  Download, 
  Copy, 
  Settings, 
  Terminal,
  FileText,
  CheckCircle,
  AlertCircle,
  Clock,
  Cpu,
  MemoryStick,
  HardDrive,
  Zap,
  Code,
  Package,
  Layers,
  Monitor
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useIDEState } from '@/hooks/use-ide-state';

interface CompilationResult {
  success: boolean;
  output: string;
  error?: string;
  executionTime?: number;
  memoryUsage?: number;
  exitCode?: number;
  language: string;
  timestamp: number;
}

interface NodeJSEnvironment {
  id: string;
  name: string;
  version: string;
  description: string;
  icon: React.ElementType;
  features: string[];
  recommended: boolean;
}

interface PackageInfo {
  name: string;
  version: string;
  description: string;
  dependencies: string[];
  devDependencies: string[];
  scripts: Record<string, string>;
}

const nodeEnvironments: NodeJSEnvironment[] = [
  {
    id: 'node',
    name: 'Node.js',
    version: '20.x',
    description: 'Standard Node.js runtime for JavaScript execution',
    icon: Layers,
    features: ['ES2023 Support', 'NPM Package Manager', 'Standard Library', 'Performance Optimized'],
    recommended: true
  },
  {
    id: 'bun',
    name: 'Bun',
    version: '1.x',
    description: 'Fast JavaScript runtime and bundler',
    icon: Zap,
    features: ['Ultra Fast', 'Built-in Bundler', 'TypeScript Support', 'Web APIs'],
    recommended: false
  },
  {
    id: 'deno',
    name: 'Deno',
    version: '1.x',
    description: 'Secure JavaScript and TypeScript runtime',
    icon: Code,
    features: ['TypeScript Native', 'Secure by Default', 'Web Standard APIs', 'No NPM'],
    recommended: false
  }
];

const nodeTemplates = [
  {
    id: 'hello-world',
    name: 'Hello World',
    description: 'Basic Node.js application',
    code: `console.log('Hello, World!');
console.log('Node.js version:', process.version);
console.log('Platform:', process.platform);`
  },
  {
    id: 'express-server',
    name: 'Express Server',
    description: 'Simple HTTP server with Express.js',
    code: `const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => {
  res.json({ message: 'Hello from Express!' });
});

app.listen(port, () => {
  console.log(\`Server running at http://localhost:\${port}\`);
});`
  },
  {
    id: 'file-operations',
    name: 'File Operations',
    description: 'File system operations example',
    code: `const fs = require('fs');
const path = require('path');

// Create a sample file
const content = 'Hello from Node.js file operations!';
fs.writeFileSync('sample.txt', content);

// Read the file
const readContent = fs.readFileSync('sample.txt', 'utf8');
console.log('File content:', readContent);

// Get file stats
const stats = fs.statSync('sample.txt');
console.log('File size:', stats.size, 'bytes');

// Clean up
fs.unlinkSync('sample.txt');
console.log('File operations completed successfully!');`
  },
  {
    id: 'async-example',
    name: 'Async/Await',
    description: 'Asynchronous programming example',
    code: `async function fetchData() {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve('Data fetched successfully!');
    }, 1000);
  });
}

async function processData() {
  try {
    console.log('Starting data fetch...');
    const result = await fetchData();
    console.log('Result:', result);
    
    // Process multiple async operations
    const promises = [
      fetchData(),
      fetchData(),
      fetchData()
    ];
    
    const results = await Promise.all(promises);
    console.log('All results:', results);
  } catch (error) {
    console.error('Error:', error);
  }
}

processData();`
  },
  {
    id: 'package-json',
    name: 'Package.json Info',
    description: 'Display package.json information',
    code: `// Simulated package.json content
const packageInfo = {
  name: 'nodejs-app',
  version: '1.0.0',
  description: 'A Node.js application',
  main: 'index.js',
  scripts: {
    start: 'node index.js',
    test: 'npm test'
  },
  dependencies: {
    express: '^4.18.0',
    lodash: '^4.17.21'
  },
  devDependencies: {
    nodemon: '^2.0.20'
  }
};

console.log('Package Information:');
console.log('Name:', packageInfo.name);
console.log('Version:', packageInfo.version);
console.log('Description:', packageInfo.description);
console.log('Dependencies:', Object.keys(packageInfo.dependencies));
console.log('Dev Dependencies:', Object.keys(packageInfo.devDependencies));`
  }
];

export default function NodeJSCompiler() {
  const [activeTab, setActiveTab] = useState('compiler');
  const [selectedEnvironment, setSelectedEnvironment] = useState('node');
  const [code, setCode] = useState(nodeTemplates[0].code);
  const [input, setInput] = useState('');
  const [results, setResults] = useState<CompilationResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [executionProgress, setExecutionProgress] = useState(0);
  const [selectedTemplate, setSelectedTemplate] = useState(nodeTemplates[0].id);
  const [compilerSettings, setCompilerSettings] = useState({
    showDebugInfo: true,
    enableProfiling: false,
    timeout: 30000,
    memoryLimit: 256
  });

  const { toast } = useToast();
  const { selectedFile } = useIDEState();

  // Load code from selected file if it's a JavaScript/TypeScript file
  useEffect(() => {
    if (selectedFile && (selectedFile.language === 'javascript' || selectedFile.language === 'typescript')) {
      setCode(selectedFile.content || '');
    }
  }, [selectedFile]);

  const executeCode = useMutation({
    mutationFn: async ({ code, environment, input }: { code: string; environment: string; input?: string }) => {
      const response = await apiRequest('POST', '/api/nodejs/execute', { 
        code, 
        environment, 
        input,
        settings: compilerSettings
      });
      return response.json();
    },
    onMutate: () => {
      setIsRunning(true);
      setExecutionProgress(0);
      
      // Simulate progress updates
      const interval = setInterval(() => {
        setExecutionProgress(prev => {
          const newProgress = prev + 10;
          if (newProgress >= 90) {
            clearInterval(interval);
            return 90;
          }
          return newProgress;
        });
      }, 200);
    },
    onSuccess: (data) => {
      setExecutionProgress(100);
      const result: CompilationResult = {
        success: data.success !== false,
        output: data.output || '',
        error: data.error,
        executionTime: data.executionTime || Date.now(),
        memoryUsage: data.memoryUsage,
        exitCode: data.exitCode,
        language: data.language || selectedEnvironment,
        timestamp: Date.now()
      };
      
      setResults(prev => [result, ...prev.slice(0, 9)]);
      
      toast({
        title: result.success ? 'Execution Successful' : 'Execution Failed',
        description: result.success ? 'Node.js code executed successfully' : 'Check the output for error details',
        variant: result.success ? 'default' : 'destructive',
      });
    },
    onError: (error) => {
      const result: CompilationResult = {
        success: false,
        output: '',
        error: error.message,
        language: selectedEnvironment,
        timestamp: Date.now()
      };
      
      setResults(prev => [result, ...prev.slice(0, 9)]);
      
      toast({
        title: 'Execution Error',
        description: 'Failed to execute Node.js code',
        variant: 'destructive',
      });
    },
    onSettled: () => {
      setIsRunning(false);
      setExecutionProgress(0);
    }
  });

  const compileCode = useMutation({
    mutationFn: async ({ code, language }: { code: string; language: string }) => {
      const response = await apiRequest('POST', '/api/compile', {
        command: language === 'typescript' ? 'npx' : 'node',
        args: language === 'typescript' ? ['tsc', '--noEmit', '${file}'] : ['--check', '${file}'],
        code,
        fileName: language === 'typescript' ? 'temp.ts' : 'temp.js'
      });
      return response.json();
    },
    onSuccess: (data) => {
      const result: CompilationResult = {
        success: data.success,
        output: data.output || 'Compilation successful',
        error: data.error,
        language: selectedEnvironment,
        timestamp: Date.now()
      };
      
      setResults(prev => [result, ...prev.slice(0, 9)]);
      
      toast({
        title: data.success ? 'Compilation Successful' : 'Compilation Failed',
        description: data.success ? 'Code compiled without errors' : 'Check the output for error details',
        variant: data.success ? 'default' : 'destructive',
      });
    }
  });

  const handleRun = () => {
    if (!code.trim()) {
      toast({
        title: 'No Code',
        description: 'Please enter some code to execute',
        variant: 'destructive',
      });
      return;
    }

    executeCode.mutate({ code, environment: selectedEnvironment, input });
  };

  const handleCompile = () => {
    if (!code.trim()) {
      toast({
        title: 'No Code',
        description: 'Please enter some code to compile',
        variant: 'destructive',
      });
      return;
    }

    const language = code.includes('import') || code.includes('export') ? 'typescript' : 'javascript';
    compileCode.mutate({ code, language });
  };

  const handleTemplateChange = (templateId: string) => {
    const template = nodeTemplates.find(t => t.id === templateId);
    if (template) {
      setSelectedTemplate(templateId);
      setCode(template.code);
      toast({
        title: 'Template Loaded',
        description: `${template.name} template loaded successfully`,
      });
    }
  };

  const handleCopyOutput = (output: string) => {
    navigator.clipboard.writeText(output);
    toast({
      title: 'Copied',
      description: 'Output copied to clipboard',
    });
  };

  const handleDownloadOutput = (result: CompilationResult) => {
    const content = `Node.js Execution Result
Environment: ${result.language}
Timestamp: ${new Date(result.timestamp).toISOString()}
Success: ${result.success}
${result.executionTime ? `Execution Time: ${result.executionTime}ms` : ''}
${result.memoryUsage ? `Memory Usage: ${result.memoryUsage}MB` : ''}
${result.exitCode !== undefined ? `Exit Code: ${result.exitCode}` : ''}

Output:
${result.output}

${result.error ? `Error:
${result.error}` : ''}`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nodejs-result-${result.timestamp}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-full bg-[var(--ide-surface)]">
      <div className="flex items-center justify-between p-4 border-b border-[var(--ide-border)]">
        <div className="flex items-center gap-2">
          <Layers className="h-5 w-5 text-[var(--ide-accent)]" />
          <h2 className="text-lg font-semibold text-[var(--ide-text)]">Node.js Compiler</h2>
          <Badge variant="outline" className="text-xs">
            Professional
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedEnvironment} onValueChange={setSelectedEnvironment}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Select Environment" />
            </SelectTrigger>
            <SelectContent>
              {nodeEnvironments.map((env) => (
                <SelectItem key={env.id} value={env.id}>
                  <div className="flex items-center gap-2">
                    <env.icon className="h-4 w-4" />
                    {env.name} {env.version}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="compiler">Compiler</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="compiler" className="flex-1 flex flex-col p-4 space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 flex-1">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Code className="h-4 w-4" />
                    Code Editor
                  </CardTitle>
                  <CardDescription>
                    Write your Node.js code here
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Textarea
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="Enter your Node.js code here..."
                    className="min-h-[300px] font-mono text-sm"
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Terminal className="h-4 w-4" />
                    Input (Optional)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Enter input for your program..."
                    className="min-h-[100px] font-mono text-sm"
                  />
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Monitor className="h-4 w-4" />
                    Environment Info
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {(() => {
                    const env = nodeEnvironments.find(e => e.id === selectedEnvironment);
                    return env ? (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <env.icon className="h-5 w-5 text-[var(--ide-accent)]" />
                          <div>
                            <h3 className="font-semibold">{env.name} {env.version}</h3>
                            <p className="text-sm text-muted-foreground">{env.description}</p>
                          </div>
                          {env.recommended && (
                            <Badge variant="secondary">Recommended</Badge>
                          )}
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          {env.features.map((feature, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    ) : null;
                  })()}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Execution Controls</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex gap-2">
                    <Button
                      onClick={handleRun}
                      disabled={isRunning}
                      className="flex-1"
                    >
                      {isRunning ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Running...
                        </>
                      ) : (
                        <>
                          <Play className="h-4 w-4 mr-2" />
                          Run Code
                        </>
                      )}
                    </Button>
                    <Button
                      onClick={handleCompile}
                      variant="outline"
                      disabled={isRunning}
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Compile
                    </Button>
                  </div>
                  
                  {isRunning && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        Executing...
                      </div>
                      <Progress value={executionProgress} className="h-2" />
                    </div>
                  )}
                </CardContent>
              </Card>

              {results.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      Latest Result
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Badge variant={results[0].success ? "default" : "destructive"}>
                          {results[0].success ? 'Success' : 'Error'}
                        </Badge>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleCopyOutput(results[0].output)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDownloadOutput(results[0])}
                          >
                            <Download className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      <ScrollArea className="h-32 w-full border rounded p-2">
                        <pre className="text-xs font-mono whitespace-pre-wrap">
                          {results[0].output || results[0].error || 'No output'}
                        </pre>
                      </ScrollArea>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="templates" className="flex-1 p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {nodeTemplates.map((template) => (
              <Card key={template.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-sm">{template.name}</CardTitle>
                  <CardDescription className="text-xs">
                    {template.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <ScrollArea className="h-24 w-full border rounded p-2">
                      <pre className="text-xs font-mono whitespace-pre-wrap">
                        {template.code.slice(0, 200)}...
                      </pre>
                    </ScrollArea>
                    <Button
                      size="sm"
                      variant={selectedTemplate === template.id ? "default" : "outline"}
                      onClick={() => handleTemplateChange(template.id)}
                      className="w-full"
                    >
                      {selectedTemplate === template.id ? 'Selected' : 'Use Template'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="results" className="flex-1 p-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Execution History</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setResults([])}
                disabled={results.length === 0}
              >
                Clear History
              </Button>
            </div>
            
            {results.length === 0 ? (
              <Card>
                <CardContent className="flex items-center justify-center py-8">
                  <div className="text-center space-y-2">
                    <FileText className="h-8 w-8 text-muted-foreground mx-auto" />
                    <p className="text-muted-foreground">No execution results yet</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {results.map((result, index) => (
                  <Card key={index}>
                    <CardContent className="pt-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge variant={result.success ? "default" : "destructive"}>
                              {result.success ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <AlertCircle className="h-3 w-3 mr-1" />
                              )}
                              {result.success ? 'Success' : 'Error'}
                            </Badge>
                            <span className="text-sm text-muted-foreground">
                              {new Date(result.timestamp).toLocaleString()}
                            </span>
                            <Badge variant="outline" className="text-xs">
                              {result.language}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            {result.executionTime && (
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Clock className="h-3 w-3" />
                                {result.executionTime}ms
                              </div>
                            )}
                            {result.memoryUsage && (
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <MemoryStick className="h-3 w-3" />
                                {result.memoryUsage}MB
                              </div>
                            )}
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleCopyOutput(result.output)}
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDownloadOutput(result)}
                            >
                              <Download className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        
                        <ScrollArea className="h-32 w-full border rounded p-2">
                          <pre className="text-xs font-mono whitespace-pre-wrap">
                            {result.output || result.error || 'No output'}
                          </pre>
                        </ScrollArea>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="settings" className="flex-1 p-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Compiler Settings
              </CardTitle>
              <CardDescription>
                Configure Node.js compilation and execution settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h4 className="font-semibold">Execution Settings</h4>
                  <div className="space-y-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={compilerSettings.showDebugInfo}
                        onChange={(e) => setCompilerSettings(prev => ({
                          ...prev,
                          showDebugInfo: e.target.checked
                        }))}
                      />
                      <span className="text-sm">Show debug information</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={compilerSettings.enableProfiling}
                        onChange={(e) => setCompilerSettings(prev => ({
                          ...prev,
                          enableProfiling: e.target.checked
                        }))}
                      />
                      <span className="text-sm">Enable performance profiling</span>
                    </label>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-semibold">Resource Limits</h4>
                  <div className="space-y-2">
                    <div>
                      <label className="text-sm font-medium">Execution Timeout (ms)</label>
                      <input
                        type="number"
                        value={compilerSettings.timeout}
                        onChange={(e) => setCompilerSettings(prev => ({
                          ...prev,
                          timeout: parseInt(e.target.value) || 30000
                        }))}
                        className="w-full mt-1 px-2 py-1 border rounded"
                        min="1000"
                        max="60000"
                        step="1000"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Memory Limit (MB)</label>
                      <input
                        type="number"
                        value={compilerSettings.memoryLimit}
                        onChange={(e) => setCompilerSettings(prev => ({
                          ...prev,
                          memoryLimit: parseInt(e.target.value) || 256
                        }))}
                        className="w-full mt-1 px-2 py-1 border rounded"
                        min="64"
                        max="1024"
                        step="64"
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-3">
                <h4 className="font-semibold">Environment Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center gap-2 p-3 border rounded">
                    <Cpu className="h-4 w-4 text-blue-500" />
                    <div>
                      <p className="text-sm font-medium">CPU Usage</p>
                      <p className="text-xs text-muted-foreground">Monitoring active</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-3 border rounded">
                    <MemoryStick className="h-4 w-4 text-green-500" />
                    <div>
                      <p className="text-sm font-medium">Memory Usage</p>
                      <p className="text-xs text-muted-foreground">Limit: {compilerSettings.memoryLimit}MB</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-3 border rounded">
                    <HardDrive className="h-4 w-4 text-purple-500" />
                    <div>
                      <p className="text-sm font-medium">Storage</p>
                      <p className="text-xs text-muted-foreground">Temporary files</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}