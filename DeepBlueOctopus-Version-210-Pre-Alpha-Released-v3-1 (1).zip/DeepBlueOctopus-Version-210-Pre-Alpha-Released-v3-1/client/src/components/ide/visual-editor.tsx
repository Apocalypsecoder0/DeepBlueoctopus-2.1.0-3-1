import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Square,
  Circle,
  Triangle,
  Type,
  Image,
  MousePointer,
  Move,
  RotateCw,
  Palette,
  Download,
  Upload,
  Save,
  Undo,
  Redo,
  Copy,
  Trash2,
  Grid,
  ZoomIn,
  ZoomOut,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Layers,
  Eye,
  EyeOff,
  Lock,
  Unlock
} from 'lucide-react';

interface VisualElement {
  id: string;
  type: 'rectangle' | 'circle' | 'triangle' | 'text' | 'image';
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  color: string;
  backgroundColor: string;
  borderColor: string;
  borderWidth: number;
  opacity: number;
  text?: string;
  fontSize?: number;
  fontFamily?: string;
  imageUrl?: string;
  visible: boolean;
  locked: boolean;
  zIndex: number;
}

interface VisualEditorProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export function VisualEditor({ isOpen = true, onClose }: VisualEditorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [elements, setElements] = useState<VisualElement[]>([]);
  const [selectedElement, setSelectedElement] = useState<VisualElement | null>(null);
  const [currentTool, setCurrentTool] = useState<string>('select');
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 600 });
  const [zoom, setZoom] = useState(100);
  const [showGrid, setShowGrid] = useState(true);
  const [history, setHistory] = useState<VisualElement[][]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  const colors = [
    '#000000', '#FFFFFF', '#FF0000', '#00FF00', '#0000FF',
    '#FFFF00', '#FF00FF', '#00FFFF', '#FFA500', '#800080',
    '#008000', '#FFC0CB', '#A52A2A', '#808080', '#87CEEB'
  ];

  const fonts = [
    'Arial', 'Helvetica', 'Times New Roman', 'Courier New',
    'Verdana', 'Georgia', 'Comic Sans MS', 'Impact'
  ];

  // Canvas drawing function
  const drawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw grid
    if (showGrid) {
      ctx.strokeStyle = '#E5E5E5';
      ctx.lineWidth = 1;
      const gridSize = 20;

      for (let x = 0; x <= canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }

      for (let y = 0; y <= canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }
    }

    // Sort elements by z-index
    const sortedElements = [...elements].sort((a, b) => a.zIndex - b.zIndex);

    // Draw elements
    sortedElements.forEach(element => {
      if (!element.visible) return;

      ctx.save();
      ctx.globalAlpha = element.opacity;
      ctx.translate(element.x + element.width / 2, element.y + element.height / 2);
      ctx.rotate((element.rotation * Math.PI) / 180);
      ctx.translate(-element.width / 2, -element.height / 2);

      // Set styles
      ctx.fillStyle = element.backgroundColor;
      ctx.strokeStyle = element.borderColor;
      ctx.lineWidth = element.borderWidth;

      switch (element.type) {
        case 'rectangle':
          ctx.fillRect(0, 0, element.width, element.height);
          if (element.borderWidth > 0) {
            ctx.strokeRect(0, 0, element.width, element.height);
          }
          break;

        case 'circle':
          const radius = Math.min(element.width, element.height) / 2;
          ctx.beginPath();
          ctx.arc(element.width / 2, element.height / 2, radius, 0, 2 * Math.PI);
          ctx.fill();
          if (element.borderWidth > 0) {
            ctx.stroke();
          }
          break;

        case 'triangle':
          ctx.beginPath();
          ctx.moveTo(element.width / 2, 0);
          ctx.lineTo(element.width, element.height);
          ctx.lineTo(0, element.height);
          ctx.closePath();
          ctx.fill();
          if (element.borderWidth > 0) {
            ctx.stroke();
          }
          break;

        case 'text':
          ctx.fillStyle = element.color;
          ctx.font = `${element.fontSize}px ${element.fontFamily}`;
          ctx.textAlign = 'left';
          ctx.textBaseline = 'top';
          ctx.fillText(element.text || 'Text', 0, 0);
          break;

        case 'image':
          // For now, draw a placeholder rectangle
          ctx.fillStyle = '#CCCCCC';
          ctx.fillRect(0, 0, element.width, element.height);
          ctx.fillStyle = '#666666';
          ctx.font = '16px Arial';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('Image', element.width / 2, element.height / 2);
          break;
      }

      ctx.restore();

      // Draw selection outline
      if (selectedElement && selectedElement.id === element.id) {
        ctx.strokeStyle = '#007ACC';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        ctx.strokeRect(element.x - 2, element.y - 2, element.width + 4, element.height + 4);
        ctx.setLineDash([]);
      }
    });
  }, [elements, selectedElement, showGrid]);

  // Canvas click handler
  const handleCanvasClick = (e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (currentTool === 'select') {
      // Find clicked element (reverse order to select top element)
      const clickedElement = [...elements]
        .sort((a, b) => b.zIndex - a.zIndex)
        .find(element => 
          element.visible &&
          x >= element.x && 
          x <= element.x + element.width &&
          y >= element.y && 
          y <= element.y + element.height
        );

      setSelectedElement(clickedElement || null);
    } else {
      // Create new element
      createNewElement(x, y);
    }
  };

  // Create new element
  const createNewElement = (x: number, y: number) => {
    const newElement: VisualElement = {
      id: `element_${Date.now()}`,
      type: currentTool as any,
      x: x - 50,
      y: y - 50,
      width: 100,
      height: 100,
      rotation: 0,
      color: '#000000',
      backgroundColor: '#3B82F6',
      borderColor: '#1E40AF',
      borderWidth: 2,
      opacity: 1,
      visible: true,
      locked: false,
      zIndex: elements.length,
      ...(currentTool === 'text' && {
        text: 'New Text',
        fontSize: 16,
        fontFamily: 'Arial',
        color: '#000000',
        backgroundColor: 'transparent'
      })
    };

    const newElements = [...elements, newElement];
    setElements(newElements);
    setSelectedElement(newElement);
    saveToHistory(newElements);
    setCurrentTool('select');
  };

  // Save to history
  const saveToHistory = (newElements: VisualElement[]) => {
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push([...newElements]);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  };

  // Undo/Redo
  const undo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setElements([...history[historyIndex - 1]]);
      setSelectedElement(null);
    }
  };

  const redo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setElements([...history[historyIndex + 1]]);
      setSelectedElement(null);
    }
  };

  // Update selected element
  const updateSelectedElement = (updates: Partial<VisualElement>) => {
    if (!selectedElement) return;

    const newElements = elements.map(el =>
      el.id === selectedElement.id ? { ...el, ...updates } : el
    );

    setElements(newElements);
    setSelectedElement({ ...selectedElement, ...updates });
    saveToHistory(newElements);
  };

  // Delete selected element
  const deleteSelectedElement = () => {
    if (!selectedElement) return;

    const newElements = elements.filter(el => el.id !== selectedElement.id);
    setElements(newElements);
    setSelectedElement(null);
    saveToHistory(newElements);
  };

  // Clone selected element
  const cloneSelectedElement = () => {
    if (!selectedElement) return;

    const clonedElement: VisualElement = {
      ...selectedElement,
      id: `element_${Date.now()}`,
      x: selectedElement.x + 20,
      y: selectedElement.y + 20,
      zIndex: elements.length
    };

    const newElements = [...elements, clonedElement];
    setElements(newElements);
    setSelectedElement(clonedElement);
    saveToHistory(newElements);
  };

  // Export canvas as image
  const exportAsImage = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = 'visual-design.png';
    link.href = canvas.toDataURL();
    link.click();
  };

  // Clear canvas
  const clearCanvas = () => {
    setElements([]);
    setSelectedElement(null);
    saveToHistory([]);
  };

  useEffect(() => {
    drawCanvas();
  }, [drawCanvas]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas) {
      canvas.width = canvasSize.width;
      canvas.height = canvasSize.height;
    }
  }, [canvasSize]);

  // Initialize with empty history
  useEffect(() => {
    if (history.length === 0) {
      setHistory([[]]);
      setHistoryIndex(0);
    }
  }, []);

  const renderToolbar = () => (
    <div className="flex items-center gap-2 p-2 bg-slate-100 border-b">
      <div className="flex items-center gap-1">
        <Button
          variant={currentTool === 'select' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setCurrentTool('select')}
        >
          <MousePointer className="w-4 h-4" />
        </Button>
        <Button
          variant={currentTool === 'rectangle' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setCurrentTool('rectangle')}
        >
          <Square className="w-4 h-4" />
        </Button>
        <Button
          variant={currentTool === 'circle' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setCurrentTool('circle')}
        >
          <Circle className="w-4 h-4" />
        </Button>
        <Button
          variant={currentTool === 'triangle' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setCurrentTool('triangle')}
        >
          <Triangle className="w-4 h-4" />
        </Button>
        <Button
          variant={currentTool === 'text' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setCurrentTool('text')}
        >
          <Type className="w-4 h-4" />
        </Button>
        <Button
          variant={currentTool === 'image' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setCurrentTool('image')}
        >
          <Image className="w-4 h-4" />
        </Button>
      </div>

      <Separator orientation="vertical" className="h-6" />

      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={undo}
          disabled={historyIndex <= 0}
        >
          <Undo className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={redo}
          disabled={historyIndex >= history.length - 1}
        >
          <Redo className="w-4 h-4" />
        </Button>
      </div>

      <Separator orientation="vertical" className="h-6" />

      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={cloneSelectedElement}
          disabled={!selectedElement}
        >
          <Copy className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={deleteSelectedElement}
          disabled={!selectedElement}
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>

      <Separator orientation="vertical" className="h-6" />

      <div className="flex items-center gap-1">
        <Button
          variant={showGrid ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setShowGrid(!showGrid)}
        >
          <Grid className="w-4 h-4" />
        </Button>
        <Button variant="ghost" size="sm" onClick={() => setZoom(Math.max(25, zoom - 25))}>
          <ZoomOut className="w-4 h-4" />
        </Button>
        <span className="text-sm">{zoom}%</span>
        <Button variant="ghost" size="sm" onClick={() => setZoom(Math.min(200, zoom + 25))}>
          <ZoomIn className="w-4 h-4" />
        </Button>
      </div>

      <Separator orientation="vertical" className="h-6" />

      <div className="flex items-center gap-1">
        <Button variant="ghost" size="sm" onClick={exportAsImage}>
          <Download className="w-4 h-4" />
        </Button>
        <Button variant="ghost" size="sm" onClick={clearCanvas}>
          Clear
        </Button>
      </div>
    </div>
  );

  const renderProperties = () => (
    <Card className="w-80">
      <CardHeader>
        <CardTitle>Properties</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {selectedElement ? (
          <Tabs defaultValue="appearance">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="appearance">Style</TabsTrigger>
              <TabsTrigger value="transform">Transform</TabsTrigger>
              <TabsTrigger value="text">Text</TabsTrigger>
            </TabsList>

            <TabsContent value="appearance" className="space-y-4">
              <div>
                <Label>Background Color</Label>
                <div className="flex gap-2 mt-1">
                  {colors.map(color => (
                    <button
                      key={color}
                      className={`w-6 h-6 rounded border-2 ${
                        selectedElement.backgroundColor === color ? 'border-blue-500' : 'border-gray-300'
                      }`}
                      style={{ backgroundColor: color }}
                      onClick={() => updateSelectedElement({ backgroundColor: color })}
                    />
                  ))}
                </div>
              </div>

              <div>
                <Label>Border Color</Label>
                <div className="flex gap-2 mt-1">
                  {colors.map(color => (
                    <button
                      key={color}
                      className={`w-6 h-6 rounded border-2 ${
                        selectedElement.borderColor === color ? 'border-blue-500' : 'border-gray-300'
                      }`}
                      style={{ backgroundColor: color }}
                      onClick={() => updateSelectedElement({ borderColor: color })}
                    />
                  ))}
                </div>
              </div>

              <div>
                <Label>Border Width</Label>
                <Slider
                  value={[selectedElement.borderWidth]}
                  onValueChange={([value]) => updateSelectedElement({ borderWidth: value })}
                  max={10}
                  step={1}
                  className="mt-2"
                />
                <span className="text-sm text-gray-500">{selectedElement.borderWidth}px</span>
              </div>

              <div>
                <Label>Opacity</Label>
                <Slider
                  value={[selectedElement.opacity * 100]}
                  onValueChange={([value]) => updateSelectedElement({ opacity: value / 100 })}
                  max={100}
                  step={1}
                  className="mt-2"
                />
                <span className="text-sm text-gray-500">{Math.round(selectedElement.opacity * 100)}%</span>
              </div>
            </TabsContent>

            <TabsContent value="transform" className="space-y-4">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label>X Position</Label>
                  <Input
                    type="number"
                    value={selectedElement.x}
                    onChange={(e) => updateSelectedElement({ x: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <Label>Y Position</Label>
                  <Input
                    type="number"
                    value={selectedElement.y}
                    onChange={(e) => updateSelectedElement({ y: parseInt(e.target.value) || 0 })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label>Width</Label>
                  <Input
                    type="number"
                    value={selectedElement.width}
                    onChange={(e) => updateSelectedElement({ width: parseInt(e.target.value) || 1 })}
                  />
                </div>
                <div>
                  <Label>Height</Label>
                  <Input
                    type="number"
                    value={selectedElement.height}
                    onChange={(e) => updateSelectedElement({ height: parseInt(e.target.value) || 1 })}
                  />
                </div>
              </div>

              <div>
                <Label>Rotation</Label>
                <Slider
                  value={[selectedElement.rotation]}
                  onValueChange={([value]) => updateSelectedElement({ rotation: value })}
                  min={-180}
                  max={180}
                  step={1}
                  className="mt-2"
                />
                <span className="text-sm text-gray-500">{selectedElement.rotation}°</span>
              </div>
            </TabsContent>

            <TabsContent value="text" className="space-y-4">
              {selectedElement.type === 'text' && (
                <>
                  <div>
                    <Label>Text</Label>
                    <Input
                      value={selectedElement.text || ''}
                      onChange={(e) => updateSelectedElement({ text: e.target.value })}
                      placeholder="Enter text..."
                    />
                  </div>

                  <div>
                    <Label>Font Size</Label>
                    <Slider
                      value={[selectedElement.fontSize || 16]}
                      onValueChange={([value]) => updateSelectedElement({ fontSize: value })}
                      min={8}
                      max={72}
                      step={1}
                      className="mt-2"
                    />
                    <span className="text-sm text-gray-500">{selectedElement.fontSize || 16}px</span>
                  </div>

                  <div>
                    <Label>Font Family</Label>
                    <Select
                      value={selectedElement.fontFamily || 'Arial'}
                      onValueChange={(value) => updateSelectedElement({ fontFamily: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {fonts.map(font => (
                          <SelectItem key={font} value={font}>{font}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Text Color</Label>
                    <div className="flex gap-2 mt-1">
                      {colors.map(color => (
                        <button
                          key={color}
                          className={`w-6 h-6 rounded border-2 ${
                            selectedElement.color === color ? 'border-blue-500' : 'border-gray-300'
                          }`}
                          style={{ backgroundColor: color }}
                          onClick={() => updateSelectedElement({ color: color })}
                        />
                      ))}
                    </div>
                  </div>
                </>
              )}
            </TabsContent>
          </Tabs>
        ) : (
          <div className="text-center text-gray-500 py-8">
            Select an element to view properties
          </div>
        )}
      </CardContent>
    </Card>
  );

  const renderLayers = () => (
    <Card className="w-80">
      <CardHeader>
        <CardTitle>Layers</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-60">
          <div className="space-y-1">
            {[...elements]
              .sort((a, b) => b.zIndex - a.zIndex)
              .map((element, index) => (
                <div
                  key={element.id}
                  className={`flex items-center gap-2 p-2 rounded cursor-pointer ${
                    selectedElement?.id === element.id ? 'bg-blue-100' : 'hover:bg-gray-100'
                  }`}
                  onClick={() => setSelectedElement(element)}
                >
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      updateSelectedElement({ visible: !element.visible });
                    }}
                  >
                    {element.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      updateSelectedElement({ locked: !element.locked });
                    }}
                  >
                    {element.locked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                  </Button>
                  <span className="flex-1 text-sm">
                    {element.type} {element.id.split('_')[1]}
                  </span>
                  <Badge variant="outline" className="text-xs">
                    {element.zIndex}
                  </Badge>
                </div>
              ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-white z-50 flex flex-col">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-xl font-semibold">Visual Editor</h2>
        <Button variant="ghost" size="sm" onClick={onClose}>
          ×
        </Button>
      </div>

      {renderToolbar()}

      <div className="flex-1 flex">
        <div className="flex-1 overflow-auto p-4 bg-gray-50">
          <div className="flex justify-center">
            <div className="bg-white shadow-lg" style={{ transform: `scale(${zoom / 100})` }}>
              <canvas
                ref={canvasRef}
                width={canvasSize.width}
                height={canvasSize.height}
                className="border cursor-crosshair"
                onClick={handleCanvasClick}
                style={{ maxWidth: '100%', maxHeight: '100%' }}
              />
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-4 p-4 bg-gray-50 border-l">
          {renderProperties()}
          {renderLayers()}
        </div>
      </div>

      <div className="flex items-center justify-between p-4 border-t bg-gray-50">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Label>Canvas Size:</Label>
            <Input
              type="number"
              value={canvasSize.width}
              onChange={(e) => setCanvasSize(prev => ({ ...prev, width: parseInt(e.target.value) || 800 }))}
              className="w-20"
            />
            <span>×</span>
            <Input
              type="number"
              value={canvasSize.height}
              onChange={(e) => setCanvasSize(prev => ({ ...prev, height: parseInt(e.target.value) || 600 }))}
              className="w-20"
            />
          </div>
          <Badge variant="outline">
            {elements.length} element{elements.length !== 1 ? 's' : ''}
          </Badge>
        </div>
        <div className="text-sm text-gray-500">
          {currentTool === 'select' ? 'Click to select elements' : `Click to add ${currentTool}`}
        </div>
      </div>
    </div>
  );
}