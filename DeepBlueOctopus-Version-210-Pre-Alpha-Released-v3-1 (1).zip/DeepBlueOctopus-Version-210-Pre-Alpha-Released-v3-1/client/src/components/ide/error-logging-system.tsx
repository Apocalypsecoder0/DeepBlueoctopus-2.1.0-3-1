import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, Bug, Info, XCircle, Download, Search, Filter, Clock, FileText, Send } from "lucide-react";

interface ErrorLoggingSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface LogEntry {
  id: string;
  timestamp: string;
  level: 'error' | 'warning' | 'info' | 'debug';
  category: string;
  message: string;
  stack?: string;
  userAgent?: string;
  url?: string;
  userId?: string;
  sessionId: string;
  resolved: boolean;
}

interface CrashReport {
  id: string;
  timestamp: string;
  type: 'javascript' | 'memory' | 'network' | 'render';
  severity: 'critical' | 'high' | 'medium' | 'low';
  message: string;
  stack: string;
  browser: string;
  os: string;
  version: string;
  userActions: string[];
  reproduced: boolean;
  status: 'new' | 'investigating' | 'fixed' | 'ignored';
}

export default function ErrorLoggingSystem({ isOpen, onClose }: ErrorLoggingSystemProps) {
  const [activeTab, setActiveTab] = useState<'logs' | 'crashes' | 'analytics'>('logs');
  const [filterLevel, setFilterLevel] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const sampleLogs: LogEntry[] = [
    {
      id: '1',
      timestamp: '2025-01-01T10:30:00Z',
      level: 'error',
      category: 'Game Engine',
      message: 'Failed to initialize WebGL context',
      stack: 'Error: WebGL not supported\n    at GameEngine.init (game-engine.ts:45)\n    at main (app.ts:12)',
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      url: '/ide/game-engine',
      userId: 'user_123',
      sessionId: 'session_456',
      resolved: false
    },
    {
      id: '2',
      timestamp: '2025-01-01T10:25:00Z',
      level: 'warning',
      category: 'Terminal',
      message: 'Compilation took longer than expected (5.2s)',
      userAgent: 'Mozilla/5.0 (macOS; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
      url: '/ide/terminal',
      userId: 'user_456',
      sessionId: 'session_789',
      resolved: true
    },
    {
      id: '3',
      timestamp: '2025-01-01T10:20:00Z',
      level: 'info',
      category: 'File System',
      message: 'Large file uploaded successfully (125MB)',
      userAgent: 'Mozilla/5.0 (Linux; Ubuntu 20.04) Chrome/98.0.4758.102',
      url: '/ide/files',
      userId: 'user_789',
      sessionId: 'session_012',
      resolved: true
    },
    {
      id: '4',
      timestamp: '2025-01-01T10:15:00Z',
      level: 'error',
      category: 'AI Assistant',
      message: 'API rate limit exceeded',
      stack: 'RateLimitError: Too many requests\n    at AIService.query (ai-service.ts:67)',
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Edge/98.0.1108.62',
      url: '/ide/ai-assistant',
      userId: 'user_012',
      sessionId: 'session_345',
      resolved: false
    }
  ];

  const crashReports: CrashReport[] = [
    {
      id: '1',
      timestamp: '2025-01-01T10:35:00Z',
      type: 'javascript',
      severity: 'critical',
      message: 'Uncaught TypeError: Cannot read property \'addEventListener\' of null',
      stack: 'TypeError: Cannot read property \'addEventListener\' of null\n    at MonacoEditor.init (editor.ts:123)\n    at IDE.setupEditor (ide.ts:45)',
      browser: 'Chrome 98.0.4758.102',
      os: 'Windows 11',
      version: '1.5.2',
      userActions: [
        'Opened IDE',
        'Created new file',
        'Attempted to open Monaco Editor',
        'Crash occurred'
      ],
      reproduced: true,
      status: 'investigating'
    },
    {
      id: '2',
      timestamp: '2025-01-01T09:45:00Z',
      type: 'memory',
      severity: 'high',
      message: 'Memory usage exceeded 1GB limit',
      stack: 'MemoryError: Heap allocation failed\n    at GameEngine.loadAssets (game-engine.ts:234)',
      browser: 'Firefox 96.0',
      os: 'macOS 12.1',
      version: '1.5.2',
      userActions: [
        'Opened Game Engine',
        'Loaded multiple large textures',
        'Started game preview',
        'Memory crash occurred'
      ],
      reproduced: false,
      status: 'new'
    }
  ];

  const filteredLogs = sampleLogs.filter(log => {
    const matchesLevel = filterLevel === 'all' || log.level === filterLevel;
    const matchesCategory = filterCategory === 'all' || log.category === filterCategory;
    const matchesSearch = searchQuery === '' || 
      log.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.category.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesLevel && matchesCategory && matchesSearch;
  });

  const getLevelIcon = (level: string) => {
    const icons = {
      error: <XCircle className="w-4 h-4 text-red-500" />,
      warning: <AlertTriangle className="w-4 h-4 text-yellow-500" />,
      info: <Info className="w-4 h-4 text-blue-500" />,
      debug: <Bug className="w-4 h-4 text-gray-500" />
    };
    return icons[level as keyof typeof icons];
  };

  const getLevelBadge = (level: string) => {
    const badges = {
      error: <Badge className="bg-red-500">Error</Badge>,
      warning: <Badge className="bg-yellow-500">Warning</Badge>,
      info: <Badge className="bg-blue-500">Info</Badge>,
      debug: <Badge className="bg-gray-500">Debug</Badge>
    };
    return badges[level as keyof typeof badges];
  };

  const getSeverityBadge = (severity: string) => {
    const badges = {
      critical: <Badge className="bg-red-600">Critical</Badge>,
      high: <Badge className="bg-orange-500">High</Badge>,
      medium: <Badge className="bg-yellow-500">Medium</Badge>,
      low: <Badge className="bg-green-500">Low</Badge>
    };
    return badges[severity as keyof typeof badges];
  };

  const getStatusBadge = (status: string) => {
    const badges = {
      new: <Badge className="bg-blue-500">New</Badge>,
      investigating: <Badge className="bg-yellow-500">Investigating</Badge>,
      fixed: <Badge className="bg-green-500">Fixed</Badge>,
      ignored: <Badge className="bg-gray-500">Ignored</Badge>
    };
    return badges[status as keyof typeof badges];
  };

  const exportLogs = () => {
    const dataStr = JSON.stringify(filteredLogs, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `deepblue-logs-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const sendCrashReport = (crashId: string) => {
    const crash = crashReports.find(c => c.id === crashId);
    if (crash) {
      console.log('Sending crash report to stephend8846@gmail.com:', crash);
      alert('Crash report sent to development team');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[85vh] bg-[var(--ide-bg)] border-[var(--ide-border)]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[var(--ide-text)]">
            <Bug className="w-5 h-5" />
            Error Logging & Crash Reporting System
          </DialogTitle>
          <DialogDescription className="text-[var(--ide-text-secondary)]">
            Monitor system errors, warnings, and crash reports • Reports sent to stephend8846@gmail.com
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)} className="h-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="logs" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Error Logs
            </TabsTrigger>
            <TabsTrigger value="crashes" className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Crash Reports
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <Info className="w-4 h-4" />
              Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="logs" className="h-full space-y-4">
            {/* Filters */}
            <div className="flex items-center gap-4 p-4 bg-[var(--ide-panel)] rounded-lg">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-[var(--ide-text-secondary)]" />
                <Input
                  placeholder="Search logs..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64"
                />
              </div>
              
              <Select value={filterLevel} onValueChange={setFilterLevel}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                  <SelectItem value="debug">Debug</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Game Engine">Game Engine</SelectItem>
                  <SelectItem value="Terminal">Terminal</SelectItem>
                  <SelectItem value="File System">File System</SelectItem>
                  <SelectItem value="AI Assistant">AI Assistant</SelectItem>
                </SelectContent>
              </Select>

              <Button
                onClick={exportLogs}
                variant="outline"
                size="sm"
                className="ml-auto"
              >
                <Download className="w-4 h-4 mr-2" />
                Export Logs
              </Button>
            </div>

            {/* Logs List */}
            <ScrollArea className="h-[500px]">
              <div className="space-y-3">
                {filteredLogs.map((log) => (
                  <Card key={log.id} className="border-[var(--ide-border)]">
                    <CardContent className="pt-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3 flex-1">
                          {getLevelIcon(log.level)}
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              {getLevelBadge(log.level)}
                              <span className="text-sm font-medium text-[var(--ide-text)]">
                                {log.category}
                              </span>
                              <span className="text-xs text-[var(--ide-text-secondary)]">
                                {new Date(log.timestamp).toLocaleString()}
                              </span>
                              {log.resolved && (
                                <Badge className="bg-green-500 text-xs">Resolved</Badge>
                              )}
                            </div>
                            <p className="text-[var(--ide-text)] mb-2">{log.message}</p>
                            {log.stack && (
                              <div className="bg-[var(--ide-bg)] border border-[var(--ide-border)] rounded p-2 text-xs font-mono text-[var(--ide-text-secondary)]">
                                <pre className="whitespace-pre-wrap">{log.stack}</pre>
                              </div>
                            )}
                            <div className="flex gap-4 text-xs text-[var(--ide-text-secondary)] mt-2">
                              {log.url && <span>URL: {log.url}</span>}
                              {log.userId && <span>User: {log.userId}</span>}
                              <span>Session: {log.sessionId}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="crashes" className="h-full space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-[var(--ide-text)]">Crash Reports</h3>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="text-[var(--ide-text)]"
                >
                  <Filter className="w-4 h-4 mr-2" />
                  Filter
                </Button>
              </div>
            </div>

            <ScrollArea className="h-[500px]">
              <div className="space-y-4">
                {crashReports.map((crash) => (
                  <Card key={crash.id} className="border-[var(--ide-border)]">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <CardTitle className="text-[var(--ide-text)]">{crash.message}</CardTitle>
                          {getSeverityBadge(crash.severity)}
                          {getStatusBadge(crash.status)}
                        </div>
                        <Button
                          onClick={() => sendCrashReport(crash.id)}
                          size="sm"
                          className="bg-[var(--bioluminescent)] hover:bg-[var(--sea-foam)]"
                        >
                          <Send className="w-4 h-4 mr-2" />
                          Send Report
                        </Button>
                      </div>
                      <div className="flex gap-4 text-sm text-[var(--ide-text-secondary)]">
                        <span>{crash.type} crash</span>
                        <span>{crash.browser}</span>
                        <span>{crash.os}</span>
                        <span>v{crash.version}</span>
                        <span>{new Date(crash.timestamp).toLocaleString()}</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <h4 className="font-medium text-[var(--ide-text)] mb-2">Stack Trace:</h4>
                          <div className="bg-[var(--ide-bg)] border border-[var(--ide-border)] rounded p-3 text-xs font-mono">
                            <pre className="text-[var(--ide-text-secondary)] whitespace-pre-wrap">
                              {crash.stack}
                            </pre>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium text-[var(--ide-text)] mb-2">User Actions:</h4>
                          <ul className="space-y-1 text-sm text-[var(--ide-text-secondary)]">
                            {crash.userActions.map((action, index) => (
                              <li key={index} className="flex items-center gap-2">
                                <span className="w-4 h-4 rounded-full bg-[var(--ide-border)] flex items-center justify-center text-xs">
                                  {index + 1}
                                </span>
                                {action}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="flex items-center gap-4 text-sm">
                          <div className="flex items-center gap-2">
                            <span className="text-[var(--ide-text-secondary)]">Reproduced:</span>
                            <Badge className={crash.reproduced ? "bg-green-500" : "bg-red-500"}>
                              {crash.reproduced ? "Yes" : "No"}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="analytics" className="h-full space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <Card className="border-[var(--ide-border)]">
                <CardHeader>
                  <CardTitle className="text-[var(--ide-text)] flex items-center gap-2">
                    <XCircle className="w-5 h-5 text-red-500" />
                    Errors (24h)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-500">127</div>
                  <p className="text-sm text-[var(--ide-text-secondary)]">+23% from yesterday</p>
                </CardContent>
              </Card>

              <Card className="border-[var(--ide-border)]">
                <CardHeader>
                  <CardTitle className="text-[var(--ide-text)] flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-yellow-500" />
                    Warnings (24h)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-yellow-500">342</div>
                  <p className="text-sm text-[var(--ide-text-secondary)]">-12% from yesterday</p>
                </CardContent>
              </Card>

              <Card className="border-[var(--ide-border)]">
                <CardHeader>
                  <CardTitle className="text-[var(--ide-text)] flex items-center gap-2">
                    <Bug className="w-5 h-5 text-purple-500" />
                    Crashes (24h)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-500">8</div>
                  <p className="text-sm text-[var(--ide-text-secondary)]">-67% from yesterday</p>
                </CardContent>
              </Card>
            </div>

            <Card className="border-[var(--ide-border)]">
              <CardHeader>
                <CardTitle className="text-[var(--ide-text)]">Top Error Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { category: 'Game Engine', count: 45, percentage: 35 },
                    { category: 'Terminal', count: 32, percentage: 25 },
                    { category: 'AI Assistant', count: 28, percentage: 22 },
                    { category: 'File System', count: 22, percentage: 18 }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <div className="w-24 text-sm text-[var(--ide-text)]">{item.category}</div>
                      <div className="flex-1 bg-[var(--ide-border)] rounded-full h-2">
                        <div 
                          className="bg-[var(--bioluminescent)] h-2 rounded-full"
                          style={{ width: `${item.percentage}%` }}
                        />
                      </div>
                      <div className="w-12 text-sm text-[var(--ide-text-secondary)]">{item.count}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}