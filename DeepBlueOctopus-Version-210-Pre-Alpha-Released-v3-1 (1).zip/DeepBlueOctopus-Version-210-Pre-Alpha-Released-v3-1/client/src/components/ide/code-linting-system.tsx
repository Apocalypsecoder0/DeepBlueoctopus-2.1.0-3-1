import React, { useState, useCallback, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  AlertTriangle, CheckCircle, Info, X, Settings,
  Play, Pause, RefreshCw, Download, Upload, Filter
} from "lucide-react";

interface CodeLintingSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface LintRule {
  id: string;
  name: string;
  description: string;
  category: 'error' | 'warning' | 'info' | 'style';
  language: string;
  enabled: boolean;
  severity: 'error' | 'warning' | 'info';
  autoFix: boolean;
}

interface LintIssue {
  id: string;
  ruleId: string;
  ruleName: string;
  message: string;
  severity: 'error' | 'warning' | 'info';
  line: number;
  column: number;
  endLine?: number;
  endColumn?: number;
  file: string;
  fixable: boolean;
  suggestion?: string;
}

interface LintResult {
  fileId: number;
  fileName: string;
  language: string;
  issues: LintIssue[];
  totalErrors: number;
  totalWarnings: number;
  totalInfos: number;
  lintedAt: Date;
  executionTime: number;
}

interface LintConfiguration {
  id: string;
  name: string;
  language: string;
  rules: LintRule[];
  extends?: string[];
  env?: Record<string, boolean>;
  globals?: Record<string, boolean>;
  settings?: Record<string, any>;
}

export default function CodeLintingSystem({ isOpen, onClose }: CodeLintingSystemProps) {
  const [lintConfigurations, setLintConfigurations] = useState<LintConfiguration[]>([
    {
      id: '1',
      name: 'JavaScript Standard',
      language: 'javascript',
      rules: [
        {
          id: 'no-unused-vars',
          name: 'No Unused Variables',
          description: 'Disallow unused variables',
          category: 'error',
          language: 'javascript',
          enabled: true,
          severity: 'error',
          autoFix: false
        },
        {
          id: 'no-console',
          name: 'No Console Statements',
          description: 'Disallow use of console',
          category: 'warning',
          language: 'javascript',
          enabled: false,
          severity: 'warning',
          autoFix: false
        },
        {
          id: 'semi',
          name: 'Require Semicolons',
          description: 'Require semicolons',
          category: 'style',
          language: 'javascript',
          enabled: true,
          severity: 'error',
          autoFix: true
        },
        {
          id: 'quotes',
          name: 'Quote Style',
          description: 'Enforce consistent quote style',
          category: 'style',
          language: 'javascript',
          enabled: true,
          severity: 'warning',
          autoFix: true
        },
        {
          id: 'indent',
          name: 'Indentation',
          description: 'Enforce consistent indentation',
          category: 'style',
          language: 'javascript',
          enabled: true,
          severity: 'warning',
          autoFix: true
        }
      ],
      extends: ['eslint:recommended'],
      env: { browser: true, node: true, es6: true },
      globals: {},
      settings: {}
    },
    {
      id: '2',
      name: 'TypeScript Strict',
      language: 'typescript',
      rules: [
        {
          id: 'no-any',
          name: 'No Any Type',
          description: 'Disallow usage of the any type',
          category: 'error',
          language: 'typescript',
          enabled: true,
          severity: 'error',
          autoFix: false
        },
        {
          id: 'explicit-function-return-type',
          name: 'Explicit Return Types',
          description: 'Require explicit return types on functions',
          category: 'warning',
          language: 'typescript',
          enabled: true,
          severity: 'warning',
          autoFix: false
        },
        {
          id: 'no-unused-vars',
          name: 'No Unused Variables',
          description: 'Disallow unused variables',
          category: 'error',
          language: 'typescript',
          enabled: true,
          severity: 'error',
          autoFix: false
        }
      ],
      extends: ['@typescript-eslint/recommended'],
      env: { browser: true, node: true, es6: true },
      globals: {},
      settings: {}
    },
    {
      id: '3',
      name: 'Python PEP8',
      language: 'python',
      rules: [
        {
          id: 'line-too-long',
          name: 'Line Too Long',
          description: 'Line longer than 79 characters',
          category: 'warning',
          language: 'python',
          enabled: true,
          severity: 'warning',
          autoFix: false
        },
        {
          id: 'unused-import',
          name: 'Unused Import',
          description: 'Imported module is unused',
          category: 'warning',
          language: 'python',
          enabled: true,
          severity: 'warning',
          autoFix: true
        },
        {
          id: 'indentation',
          name: 'Indentation Error',
          description: 'Incorrect indentation',
          category: 'error',
          language: 'python',
          enabled: true,
          severity: 'error',
          autoFix: true
        }
      ],
      extends: ['pep8'],
      env: {},
      globals: {},
      settings: {}
    }
  ]);

  const [selectedConfig, setSelectedConfig] = useState<LintConfiguration>(lintConfigurations[0]);
  const [lintResults, setLintResults] = useState<LintResult[]>([]);
  const [isLinting, setIsLinting] = useState(false);
  const [autoLintEnabled, setAutoLintEnabled] = useState(true);
  const [filterSeverity, setFilterSeverity] = useState<'all' | 'error' | 'warning' | 'info'>('all');
  const [selectedIssue, setSelectedIssue] = useState<LintIssue | null>(null);

  const { files, activeTab, updateFileContent } = useIDEState();
  const { toast } = useToast();

  const performLinting = useCallback(async (fileId: number, content: string, language: string): Promise<LintResult> => {
    const startTime = Date.now();
    
    // Simulate linting process
    await new Promise(resolve => setTimeout(resolve, 500));

    const config = lintConfigurations.find(c => c.language === language) || selectedConfig;
    const file = files.find(f => f.id === fileId);
    
    if (!file) {
      throw new Error('File not found');
    }

    const issues: LintIssue[] = [];
    const lines = content.split('\n');

    // JavaScript/TypeScript linting simulation
    if (language === 'javascript' || language === 'typescript') {
      // Check for unused variables (simple regex)
      if (config.rules.find(r => r.id === 'no-unused-vars' && r.enabled)) {
        const unusedVarMatches = content.match(/(?:var|let|const)\s+(\w+)\s*=/g);
        if (unusedVarMatches) {
          unusedVarMatches.forEach((match, index) => {
            const varName = match.match(/(\w+)\s*=/)?.[1];
            if (varName && !content.includes(varName + '.') && !content.includes(varName + '(')) {
              issues.push({
                id: `unused-var-${index}`,
                ruleId: 'no-unused-vars',
                ruleName: 'No Unused Variables',
                message: `'${varName}' is assigned a value but never used`,
                severity: 'error',
                line: index + 1,
                column: 1,
                file: file.name,
                fixable: false
              });
            }
          });
        }
      }

      // Check for console statements
      if (config.rules.find(r => r.id === 'no-console' && r.enabled)) {
        lines.forEach((line, index) => {
          if (line.includes('console.')) {
            issues.push({
              id: `console-${index}`,
              ruleId: 'no-console',
              ruleName: 'No Console Statements',
              message: 'Unexpected console statement',
              severity: 'warning',
              line: index + 1,
              column: line.indexOf('console.') + 1,
              file: file.name,
              fixable: true,
              suggestion: 'Remove console statement'
            });
          }
        });
      }

      // Check for semicolons
      if (config.rules.find(r => r.id === 'semi' && r.enabled)) {
        lines.forEach((line, index) => {
          const trimmed = line.trim();
          if (trimmed && !trimmed.startsWith('//') && !trimmed.startsWith('/*') && 
              !trimmed.endsWith(';') && !trimmed.endsWith('{') && !trimmed.endsWith('}') &&
              !trimmed.startsWith('if') && !trimmed.startsWith('for') && !trimmed.startsWith('while')) {
            issues.push({
              id: `semi-${index}`,
              ruleId: 'semi',
              ruleName: 'Require Semicolons',
              message: 'Missing semicolon',
              severity: 'error',
              line: index + 1,
              column: line.length,
              file: file.name,
              fixable: true,
              suggestion: 'Add semicolon at end of statement'
            });
          }
        });
      }
    }

    // Python linting simulation
    if (language === 'python') {
      // Check line length
      if (config.rules.find(r => r.id === 'line-too-long' && r.enabled)) {
        lines.forEach((line, index) => {
          if (line.length > 79) {
            issues.push({
              id: `line-length-${index}`,
              ruleId: 'line-too-long',
              ruleName: 'Line Too Long',
              message: `Line too long (${line.length}/79)`,
              severity: 'warning',
              line: index + 1,
              column: 80,
              file: file.name,
              fixable: false
            });
          }
        });
      }

      // Check for unused imports
      if (config.rules.find(r => r.id === 'unused-import' && r.enabled)) {
        lines.forEach((line, index) => {
          const importMatch = line.match(/^import\s+(\w+)/);
          if (importMatch) {
            const importName = importMatch[1];
            if (!content.includes(importName + '.') && !content.includes(importName + '(')) {
              issues.push({
                id: `unused-import-${index}`,
                ruleId: 'unused-import',
                ruleName: 'Unused Import',
                message: `'${importName}' imported but unused`,
                severity: 'warning',
                line: index + 1,
                column: 1,
                file: file.name,
                fixable: true,
                suggestion: 'Remove unused import'
              });
            }
          }
        });
      }
    }

    const executionTime = Date.now() - startTime;
    const totalErrors = issues.filter(i => i.severity === 'error').length;
    const totalWarnings = issues.filter(i => i.severity === 'warning').length;
    const totalInfos = issues.filter(i => i.severity === 'info').length;

    return {
      fileId,
      fileName: file.name,
      language,
      issues,
      totalErrors,
      totalWarnings,
      totalInfos,
      lintedAt: new Date(),
      executionTime
    };
  }, [files, lintConfigurations, selectedConfig]);

  const handleLintCurrentFile = useCallback(async () => {
    if (!activeTab) {
      toast({
        title: "No file selected",
        description: "Please select a file to lint",
        variant: "destructive",
      });
      return;
    }

    const file = files.find(f => f.id === activeTab.id);
    if (!file || !file.content) {
      toast({
        title: "No content to lint",
        description: "The selected file is empty or invalid",
        variant: "destructive",
      });
      return;
    }

    setIsLinting(true);

    try {
      const result = await performLinting(file.id, file.content, file.language || 'text');
      setLintResults(prev => [result, ...prev.filter(r => r.fileId !== file.id)]);
      
      toast({
        title: "Linting completed",
        description: `Found ${result.totalErrors + result.totalWarnings} issues`,
      });
    } catch (error) {
      toast({
        title: "Linting failed",
        description: "An error occurred during linting",
        variant: "destructive",
      });
    } finally {
      setIsLinting(false);
    }
  }, [activeTab, files, performLinting, toast]);

  const handleLintAllFiles = useCallback(async () => {
    const codeFiles = files.filter(f => !f.isDirectory && f.content && f.language !== 'text');
    
    if (!codeFiles.length) {
      toast({
        title: "No files to lint",
        description: "Please add code files to lint",
        variant: "destructive",
      });
      return;
    }

    setIsLinting(true);
    const results: LintResult[] = [];

    try {
      for (const file of codeFiles) {
        const result = await performLinting(file.id, file.content!, file.language || 'text');
        results.push(result);
      }

      setLintResults(results);
      const totalIssues = results.reduce((sum, r) => sum + r.totalErrors + r.totalWarnings, 0);
      
      toast({
        title: "Batch linting completed",
        description: `Linted ${results.length} files, found ${totalIssues} issues`,
      });
    } catch (error) {
      toast({
        title: "Batch linting failed",
        description: "Some files could not be linted",
        variant: "destructive",
      });
    } finally {
      setIsLinting(false);
    }
  }, [files, performLinting, toast]);

  const handleAutoFix = useCallback(async (issue: LintIssue) => {
    const file = files.find(f => f.name === issue.file);
    if (!file || !file.content) return;

    let fixedContent = file.content;
    const lines = fixedContent.split('\n');

    // Apply automatic fixes based on rule
    switch (issue.ruleId) {
      case 'semi':
        if (lines[issue.line - 1]) {
          lines[issue.line - 1] = lines[issue.line - 1] + ';';
          fixedContent = lines.join('\n');
        }
        break;

      case 'no-console':
        if (lines[issue.line - 1]) {
          lines[issue.line - 1] = lines[issue.line - 1].replace(/console\.[^;]+;?/, '');
          fixedContent = lines.join('\n');
        }
        break;

      case 'unused-import':
        if (lines[issue.line - 1]) {
          lines[issue.line - 1] = '';
          fixedContent = lines.join('\n');
        }
        break;
    }

    updateFileContent(file.id, fixedContent);
    
    // Re-lint the file
    const result = await performLinting(file.id, fixedContent, file.language || 'text');
    setLintResults(prev => [result, ...prev.filter(r => r.fileId !== file.id)]);

    toast({
      title: "Issue fixed",
      description: `Applied fix for ${issue.ruleName}`,
    });
  }, [files, updateFileContent, performLinting, toast]);

  const toggleRule = useCallback((ruleId: string, enabled: boolean) => {
    setSelectedConfig(prev => ({
      ...prev,
      rules: prev.rules.map(rule => 
        rule.id === ruleId ? { ...rule, enabled } : rule
      )
    }));
  }, []);

  const updateRuleSeverity = useCallback((ruleId: string, severity: 'error' | 'warning' | 'info') => {
    setSelectedConfig(prev => ({
      ...prev,
      rules: prev.rules.map(rule => 
        rule.id === ruleId ? { ...rule, severity } : rule
      )
    }));
  }, []);

  const exportConfiguration = useCallback(() => {
    const configData = {
      configuration: selectedConfig,
      exportedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(configData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedConfig.name.toLowerCase().replace(/\s+/g, '-')}-lint-config.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Configuration exported",
      description: "Lint configuration has been downloaded",
    });
  }, [selectedConfig, toast]);

  // Auto-lint effect
  useEffect(() => {
    if (autoLintEnabled && activeTab) {
      const file = files.find(f => f.id === activeTab.id);
      if (file && file.content && file.language !== 'text') {
        const debounceTimer = setTimeout(() => {
          performLinting(file.id, file.content!, file.language || 'text')
            .then(result => {
              setLintResults(prev => [result, ...prev.filter(r => r.fileId !== file.id)]);
            })
            .catch(() => {});
        }, 1000);

        return () => clearTimeout(debounceTimer);
      }
    }
  }, [activeTab, files, autoLintEnabled, performLinting]);

  const filteredIssues = lintResults
    .flatMap(result => result.issues)
    .filter(issue => filterSeverity === 'all' || issue.severity === filterSeverity);

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Code Linting System
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex gap-6">
          {/* Configuration Panel */}
          <div className="w-80 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Lint Configuration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Language Config</label>
                    <Select 
                      value={selectedConfig.id} 
                      onValueChange={(value) => {
                        const config = lintConfigurations.find(c => c.id === value);
                        if (config) setSelectedConfig(config);
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {lintConfigurations.map((config) => (
                          <SelectItem key={config.id} value={config.id}>
                            {config.name} ({config.language})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm">Auto-lint</span>
                    <Switch 
                      checked={autoLintEnabled}
                      onCheckedChange={setAutoLintEnabled}
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      onClick={handleLintCurrentFile}
                      disabled={isLinting}
                      className="flex-1"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      {isLinting ? 'Linting...' : 'Lint Current'}
                    </Button>
                  </div>

                  <Button 
                    onClick={handleLintAllFiles}
                    disabled={isLinting}
                    variant="outline"
                    className="w-full"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Lint All Files
                  </Button>

                  <Button 
                    onClick={exportConfiguration}
                    variant="outline"
                    className="w-full"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export Config
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Summary Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-red-500">Errors</span>
                    <Badge variant="destructive">
                      {lintResults.reduce((sum, r) => sum + r.totalErrors, 0)}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-yellow-500">Warnings</span>
                    <Badge variant="secondary">
                      {lintResults.reduce((sum, r) => sum + r.totalWarnings, 0)}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-blue-500">Info</span>
                    <Badge variant="outline">
                      {lintResults.reduce((sum, r) => sum + r.totalInfos, 0)}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <Tabs defaultValue="issues">
              <TabsList>
                <TabsTrigger value="issues">Issues</TabsTrigger>
                <TabsTrigger value="rules">Rules</TabsTrigger>
                <TabsTrigger value="results">Results</TabsTrigger>
              </TabsList>

              <TabsContent value="issues" className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4" />
                    <Select value={filterSeverity} onValueChange={(value: any) => setFilterSeverity(value)}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All</SelectItem>
                        <SelectItem value="error">Errors</SelectItem>
                        <SelectItem value="warning">Warnings</SelectItem>
                        <SelectItem value="info">Info</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <span className="text-sm text-gray-500">
                    {filteredIssues.length} issues
                  </span>
                </div>

                <ScrollArea className="h-[600px]">
                  <div className="space-y-2">
                    {filteredIssues.map((issue) => (
                      <Card 
                        key={issue.id} 
                        className={`cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 ${
                          selectedIssue?.id === issue.id ? 'ring-2 ring-blue-500' : ''
                        }`}
                        onClick={() => setSelectedIssue(issue)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                {issue.severity === 'error' && (
                                  <X className="w-4 h-4 text-red-500" />
                                )}
                                {issue.severity === 'warning' && (
                                  <AlertTriangle className="w-4 h-4 text-yellow-500" />
                                )}
                                {issue.severity === 'info' && (
                                  <Info className="w-4 h-4 text-blue-500" />
                                )}
                                <span className="font-medium text-sm">{issue.ruleName}</span>
                                <Badge variant="outline" className="text-xs">
                                  {issue.file}:{issue.line}:{issue.column}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-600 dark:text-gray-300">
                                {issue.message}
                              </p>
                              {issue.suggestion && (
                                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                                  💡 {issue.suggestion}
                                </p>
                              )}
                            </div>
                            {issue.fixable && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleAutoFix(issue);
                                }}
                              >
                                Fix
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="rules" className="space-y-4">
                <ScrollArea className="h-[600px]">
                  <div className="space-y-4">
                    {selectedConfig.rules.map((rule) => (
                      <Card key={rule.id}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Switch
                                checked={rule.enabled}
                                onCheckedChange={(checked) => toggleRule(rule.id, checked)}
                              />
                              <span className="font-medium">{rule.name}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Select
                                value={rule.severity}
                                onValueChange={(value: any) => updateRuleSeverity(rule.id, value)}
                              >
                                <SelectTrigger className="w-24">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="error">Error</SelectItem>
                                  <SelectItem value="warning">Warning</SelectItem>
                                  <SelectItem value="info">Info</SelectItem>
                                </SelectContent>
                              </Select>
                              {rule.autoFix && (
                                <Badge variant="secondary" className="text-xs">
                                  Auto-fix
                                </Badge>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-300">
                            {rule.description}
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="results" className="space-y-4">
                <ScrollArea className="h-[600px]">
                  <div className="space-y-4">
                    {lintResults.map((result) => (
                      <Card key={`${result.fileId}-${result.lintedAt.getTime()}`}>
                        <CardHeader>
                          <CardTitle className="flex items-center justify-between">
                            <span>{result.fileName}</span>
                            <Badge variant="outline">
                              {result.language}
                            </Badge>
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex items-center justify-between mb-4">
                            <div className="flex gap-4">
                              <div className="flex items-center gap-1">
                                <X className="w-4 h-4 text-red-500" />
                                <span className="text-sm">{result.totalErrors}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <AlertTriangle className="w-4 h-4 text-yellow-500" />
                                <span className="text-sm">{result.totalWarnings}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Info className="w-4 h-4 text-blue-500" />
                                <span className="text-sm">{result.totalInfos}</span>
                              </div>
                            </div>
                            <span className="text-xs text-gray-500">
                              {result.executionTime}ms
                            </span>
                          </div>
                          
                          <div className="space-y-2">
                            {result.issues.slice(0, 3).map((issue) => (
                              <div key={issue.id} className="text-sm p-2 bg-gray-50 dark:bg-gray-800 rounded">
                                <span className="font-medium">{issue.ruleName}</span> - {issue.message}
                              </div>
                            ))}
                            {result.issues.length > 3 && (
                              <div className="text-xs text-gray-500">
                                +{result.issues.length - 3} more issues
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}