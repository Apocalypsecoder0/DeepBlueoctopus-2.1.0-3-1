import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { 
  Rocket, 
  Play, 
  Square, 
  RefreshCw, 
  Settings,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Clock,
  Globe,
  Server,
  Cloud,
  Package,
  GitBranch,
  Upload,
  Download,
  ExternalLink,
  Eye,
  Trash2,
  Plus,
  Copy,
  Edit,
  Monitor,
  Zap,
  Shield
} from "lucide-react";

interface DeployManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Deployment {
  id: string;
  name: string;
  status: 'deploying' | 'success' | 'failed' | 'cancelled';
  environment: 'production' | 'staging' | 'development';
  platform: 'vercel' | 'netlify' | 'aws' | 'heroku' | 'docker' | 'kubernetes';
  url?: string;
  branch: string;
  commit: string;
  createdAt: string;
  deployedAt?: string;
  duration?: number;
  buildLogs: string[];
  buildSize?: string;
  performance?: {
    loadTime: number;
    lighthouse: number;
  };
}

interface DeploymentTarget {
  id: string;
  name: string;
  platform: string;
  environment: string;
  auto: boolean;
  branch: string;
  buildCommand: string;
  outputDir: string;
  envVars: Record<string, string>;
}

export default function DeployManager({ isOpen, onClose }: DeployManagerProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('deployments');
  const [deployments, setDeployments] = useState<Deployment[]>([]);
  const [targets, setTargets] = useState<DeploymentTarget[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedDeployment, setSelectedDeployment] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadDeployments();
      loadTargets();
    }
  }, [isOpen]);

  const loadDeployments = async () => {
    try {
      const response = await fetch('/api/deployments');
      const data = await response.json();
      setDeployments(data);
    } catch (error) {
      console.error('Failed to load deployments:', error);
      // Load sample deployments
      setDeployments([
        {
          id: 'deploy-1',
          name: 'Production Deploy',
          status: 'success',
          environment: 'production',
          platform: 'vercel',
          url: 'https://deepblue-ide.vercel.app',
          branch: 'main',
          commit: 'a1b2c3d',
          createdAt: '2025-01-01T14:30:00Z',
          deployedAt: '2025-01-01T14:33:45Z',
          duration: 225,
          buildLogs: [
            'Building application...',
            'Installing dependencies...',
            'Running build scripts...',
            'Optimizing bundle...',
            'Deploy successful!'
          ],
          buildSize: '2.4 MB',
          performance: {
            loadTime: 1.2,
            lighthouse: 95
          }
        },
        {
          id: 'deploy-2',
          name: 'Staging Deploy',
          status: 'deploying',
          environment: 'staging',
          platform: 'netlify',
          branch: 'develop',
          commit: 'e4f5g6h',
          createdAt: '2025-01-01T15:15:00Z',
          buildLogs: [
            'Starting build process...',
            'Fetching dependencies...',
            'Compiling TypeScript...',
            'Building React components...'
          ]
        },
        {
          id: 'deploy-3',
          name: 'Feature Branch',
          status: 'failed',
          environment: 'development',
          platform: 'heroku',
          branch: 'feature/new-ui',
          commit: 'i7j8k9l',
          createdAt: '2025-01-01T13:45:00Z',
          duration: 180,
          buildLogs: [
            'Starting build...',
            'Installing packages...',
            'Error: Module not found',
            'Build failed with exit code 1'
          ]
        }
      ]);
    }
  };

  const loadTargets = async () => {
    try {
      const response = await fetch('/api/deployment-targets');
      const data = await response.json();
      setTargets(data);
    } catch (error) {
      console.error('Failed to load targets:', error);
      // Load sample targets
      setTargets([
        {
          id: 'target-1',
          name: 'Production',
          platform: 'vercel',
          environment: 'production',
          auto: true,
          branch: 'main',
          buildCommand: 'npm run build',
          outputDir: 'dist',
          envVars: {
            'NODE_ENV': 'production',
            'API_URL': 'https://api.example.com'
          }
        },
        {
          id: 'target-2',
          name: 'Staging',
          platform: 'netlify',
          environment: 'staging',
          auto: true,
          branch: 'develop',
          buildCommand: 'npm run build:staging',
          outputDir: 'build',
          envVars: {
            'NODE_ENV': 'staging',
            'API_URL': 'https://staging-api.example.com'
          }
        }
      ]);
    }
  };

  const deployToTarget = async (targetId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/deployments/deploy/${targetId}`, {
        method: 'POST'
      });

      if (response.ok) {
        const result = await response.json();
        await loadDeployments();
        
        toast({
          title: "Deployment Started",
          description: `Deployment to ${targetId} has been initiated.`,
        });
      }
    } catch (error) {
      toast({
        title: "Deployment Failed",
        description: "Failed to start deployment.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const cancelDeployment = async (deploymentId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/deployments/${deploymentId}/cancel`, {
        method: 'POST'
      });

      if (response.ok) {
        await loadDeployments();
        toast({
          title: "Deployment Cancelled",
          description: "Deployment has been cancelled.",
        });
      }
    } catch (error) {
      toast({
        title: "Cancel Failed",
        description: "Failed to cancel deployment.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const retryDeployment = async (deploymentId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/deployments/${deploymentId}/retry`, {
        method: 'POST'
      });

      if (response.ok) {
        await loadDeployments();
        toast({
          title: "Deployment Retried",
          description: "Deployment has been restarted.",
        });
      }
    } catch (error) {
      toast({
        title: "Retry Failed",
        description: "Failed to retry deployment.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: Deployment['status']) => {
    switch (status) {
      case 'success': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'failed': return <XCircle className="w-4 h-4 text-red-400" />;
      case 'deploying': return <Clock className="w-4 h-4 text-yellow-400 animate-pulse" />;
      case 'cancelled': return <XCircle className="w-4 h-4 text-gray-400" />;
      default: return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'vercel': return <Zap className="w-4 h-4 text-black bg-white rounded" />;
      case 'netlify': return <Globe className="w-4 h-4 text-teal-400" />;
      case 'aws': return <Cloud className="w-4 h-4 text-orange-400" />;
      case 'heroku': return <Server className="w-4 h-4 text-purple-400" />;
      case 'docker': return <Package className="w-4 h-4 text-blue-400" />;
      case 'kubernetes': return <Server className="w-4 h-4 text-blue-600" />;
      default: return <Server className="w-4 h-4 text-gray-400" />;
    }
  };

  const getEnvironmentColor = (environment: string) => {
    switch (environment) {
      case 'production': return 'bg-red-600';
      case 'staging': return 'bg-yellow-600';
      case 'development': return 'bg-blue-600';
      default: return 'bg-gray-600';
    }
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[95vh] bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <Rocket className="w-5 h-5" />
            Deploy Manager
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800">
            <TabsTrigger value="deployments">Deployments</TabsTrigger>
            <TabsTrigger value="targets">Targets</TabsTrigger>
            <TabsTrigger value="logs">Build Logs</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="deployments" className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Recent Deployments</h3>
              <div className="flex gap-2">
                <Button
                  onClick={loadDeployments}
                  variant="outline"
                  size="sm"
                  disabled={loading}
                >
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                </Button>
                <Button
                  onClick={() => deployToTarget('target-1')}
                  className="bg-blue-600 hover:bg-blue-700"
                  disabled={loading}
                >
                  <Rocket className="w-4 h-4 mr-2" />
                  Deploy Now
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              {deployments.map((deployment) => (
                <Card key={deployment.id} className="bg-slate-800 border-slate-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {getStatusIcon(deployment.status)}
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-white">{deployment.name}</span>
                            <Badge className={getEnvironmentColor(deployment.environment)}>
                              {deployment.environment}
                            </Badge>
                            <div className="flex items-center gap-1">
                              {getPlatformIcon(deployment.platform)}
                              <span className="text-sm text-slate-400">{deployment.platform}</span>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-4 text-sm text-slate-400">
                            <div className="flex items-center gap-1">
                              <GitBranch className="w-3 h-3" />
                              {deployment.branch}
                            </div>
                            <span>{deployment.commit}</span>
                            <span>{new Date(deployment.createdAt).toLocaleString()}</span>
                            {deployment.duration && (
                              <span>{formatDuration(deployment.duration)}</span>
                            )}
                            {deployment.buildSize && (
                              <span>{deployment.buildSize}</span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {deployment.url && (
                          <Button
                            onClick={() => window.open(deployment.url, '_blank')}
                            variant="outline"
                            size="sm"
                          >
                            <ExternalLink className="w-3 h-3" />
                          </Button>
                        )}
                        
                        {deployment.status === 'deploying' && (
                          <Button
                            onClick={() => cancelDeployment(deployment.id)}
                            variant="outline"
                            size="sm"
                            disabled={loading}
                          >
                            <Square className="w-3 h-3" />
                          </Button>
                        )}
                        
                        {deployment.status === 'failed' && (
                          <Button
                            onClick={() => retryDeployment(deployment.id)}
                            size="sm"
                            className="bg-orange-600 hover:bg-orange-700"
                            disabled={loading}
                          >
                            <RefreshCw className="w-3 h-3 mr-1" />
                            Retry
                          </Button>
                        )}
                        
                        <Button
                          onClick={() => setSelectedDeployment(deployment.id)}
                          variant="outline"
                          size="sm"
                        >
                          <Eye className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>

                    {deployment.status === 'deploying' && (
                      <div className="mt-3">
                        <Progress value={65} className="h-2" />
                        <p className="text-sm text-slate-400 mt-1">Building application...</p>
                      </div>
                    )}

                    {deployment.performance && (
                      <div className="mt-3 grid grid-cols-2 gap-4 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-400">Load Time:</span>
                          <span className="text-green-400">{deployment.performance.loadTime}s</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Lighthouse:</span>
                          <span className="text-green-400">{deployment.performance.lighthouse}/100</span>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="targets" className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Deployment Targets</h3>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Target
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {targets.map((target) => (
                <Card key={target.id} className="bg-slate-800 border-slate-700">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white flex items-center gap-2">
                        {getPlatformIcon(target.platform)}
                        {target.name}
                      </CardTitle>
                      <Badge className={getEnvironmentColor(target.environment)}>
                        {target.environment}
                      </Badge>
                    </div>
                    <CardDescription>
                      {target.platform} • Branch: {target.branch}
                    </CardDescription>
                  </CardHeader>

                  <CardContent className="space-y-3">
                    <div className="text-sm space-y-2">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Build Command:</span>
                        <span className="text-white font-mono text-xs">{target.buildCommand}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Output Dir:</span>
                        <span className="text-white font-mono text-xs">{target.outputDir}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Auto Deploy:</span>
                        <Badge className={target.auto ? 'bg-green-600' : 'bg-gray-600'}>
                          {target.auto ? 'Enabled' : 'Disabled'}
                        </Badge>
                      </div>
                    </div>

                    <div>
                      <Label className="text-slate-400 text-xs">Environment Variables:</Label>
                      <div className="mt-1 space-y-1">
                        {Object.entries(target.envVars).slice(0, 2).map(([key, value]) => (
                          <div key={key} className="flex justify-between text-xs">
                            <span className="text-slate-500">{key}:</span>
                            <span className="text-slate-300 truncate ml-2">{value}</span>
                          </div>
                        ))}
                        {Object.keys(target.envVars).length > 2 && (
                          <p className="text-xs text-slate-500">
                            +{Object.keys(target.envVars).length - 2} more...
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <Button
                        onClick={() => deployToTarget(target.id)}
                        size="sm"
                        className="bg-blue-600 hover:bg-blue-700"
                        disabled={loading}
                      >
                        <Rocket className="w-3 h-3 mr-1" />
                        Deploy
                      </Button>
                      <Button variant="outline" size="sm">
                        <Edit className="w-3 h-3" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="logs" className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Build Logs</h3>
              <div className="flex gap-2">
                <select
                  value={selectedDeployment || ''}
                  onChange={(e) => setSelectedDeployment(e.target.value)}
                  className="bg-slate-800 border-slate-600 text-white rounded px-3 py-2"
                >
                  <option value="">Select deployment</option>
                  {deployments.map((dep) => (
                    <option key={dep.id} value={dep.id}>
                      {dep.name} - {dep.status}
                    </option>
                  ))}
                </select>
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <Card className="bg-slate-800 border-slate-700 h-96">
              <CardContent className="p-0">
                <ScrollArea className="h-full">
                  <div className="p-4 font-mono text-sm">
                    {selectedDeployment ? (
                      deployments.find(d => d.id === selectedDeployment)?.buildLogs.map((log, index) => (
                        <div key={index} className="mb-1">
                          <span className="text-slate-500">[{new Date().toLocaleTimeString()}]</span>
                          <span className="text-white ml-2">{log}</span>
                        </div>
                      ))
                    ) : (
                      <div className="text-slate-400 text-center py-8">
                        Select a deployment to view build logs
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="flex-1">
            <div className="space-y-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">General Settings</CardTitle>
                  <CardDescription>
                    Configure deployment behavior and notifications
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white">Auto-deploy on push</Label>
                      <p className="text-sm text-slate-400">Automatically deploy when code is pushed to main branch</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white">Build notifications</Label>
                      <p className="text-sm text-slate-400">Receive notifications about deployment status</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white">Performance monitoring</Label>
                      <p className="text-sm text-slate-400">Monitor deployment performance and Lighthouse scores</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Build Settings</CardTitle>
                  <CardDescription>
                    Default build configuration for new targets
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-white mb-2 block">Default build command</Label>
                    <Input
                      defaultValue="npm run build"
                      className="bg-slate-700 border-slate-600 text-white font-mono"
                    />
                  </div>
                  
                  <div>
                    <Label className="text-white mb-2 block">Default output directory</Label>
                    <Input
                      defaultValue="dist"
                      className="bg-slate-700 border-slate-600 text-white font-mono"
                    />
                  </div>
                  
                  <div>
                    <Label className="text-white mb-2 block">Node.js version</Label>
                    <select className="w-full bg-slate-700 border-slate-600 text-white rounded px-3 py-2">
                      <option value="18">Node.js 18</option>
                      <option value="20">Node.js 20</option>
                      <option value="21">Node.js 21</option>
                    </select>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}