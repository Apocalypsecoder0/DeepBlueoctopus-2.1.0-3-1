import React, { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Edit3, Undo, Redo, Copy, Scissors, Clipboard, Search, Replace,
  MousePointer2, Type, RotateCcw,
  AlignLeft, AlignCenter, AlignRight, AlignJustify,
  Bold, Italic, Underline, Strikethrough, Subscript,
  Superscript, Highlighter, Paintbrush, Eraser,
  Indent, Outdent, ListOrdered, List, Quote,
  Link, Image, Table, Code, FileText, Settings,
  Zap, Wand2, Target, CheckSquare, X
} from "lucide-react";

interface AdvancedEditSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface EditAction {
  id: string;
  type: 'insert' | 'delete' | 'replace' | 'format' | 'move';
  content: string;
  position: { start: number; end: number };
  timestamp: Date;
  description: string;
}

interface EditSelection {
  start: number;
  end: number;
  text: string;
  line: number;
  column: number;
}

interface EditCommand {
  id: string;
  name: string;
  description: string;
  shortcut: string;
  category: 'basic' | 'formatting' | 'advanced' | 'navigation';
  action: () => void;
}

interface FindReplaceState {
  findText: string;
  replaceText: string;
  matchCase: boolean;
  wholeWord: boolean;
  useRegex: boolean;
  searchResults: number[];
  currentIndex: number;
  totalMatches: number;
}

export default function AdvancedEditSystem({ isOpen, onClose }: AdvancedEditSystemProps) {
  const [activeTab, setActiveTab] = useState("editor");
  const [currentText, setCurrentText] = useState(`// DeepBlue IDE Advanced Edit System Demo
function calculateFibonacci(n) {
    if (n <= 1) return n;
    return calculateFibonacci(n - 1) + calculateFibonacci(n - 2);
}

const numbers = [1, 2, 3, 4, 5];
const doubled = numbers.map(x => x * 2);

// TODO: Optimize this algorithm
console.log("Fibonacci of 10:", calculateFibonacci(10));
console.log("Doubled numbers:", doubled);

/* Multi-line comment
   demonstrating various
   editing capabilities */

class Calculator {
    constructor() {
        this.history = [];
    }
    
    add(a, b) {
        const result = a + b;
        this.history.push(\`\${a} + \${b} = \${result}\`);
        return result;
    }
}

const calc = new Calculator();
console.log(calc.add(5, 3));`);

  const [selection, setSelection] = useState<EditSelection>({
    start: 0,
    end: 0,
    text: '',
    line: 1,
    column: 1
  });

  const [editHistory, setEditHistory] = useState<EditAction[]>([
    {
      id: '1',
      type: 'insert',
      content: '// Added comment',
      position: { start: 0, end: 16 },
      timestamp: new Date(Date.now() - 300000),
      description: 'Added initial comment'
    },
    {
      id: '2',
      type: 'format',
      content: 'calculateFibonacci',
      position: { start: 45, end: 62 },
      timestamp: new Date(Date.now() - 240000),
      description: 'Applied camelCase formatting'
    },
    {
      id: '3',
      type: 'replace',
      content: 'x => x * 2',
      position: { start: 210, end: 220 },
      timestamp: new Date(Date.now() - 180000),
      description: 'Converted to arrow function'
    }
  ]);

  const [findReplace, setFindReplace] = useState<FindReplaceState>({
    findText: '',
    replaceText: '',
    matchCase: false,
    wholeWord: false,
    useRegex: false,
    searchResults: [],
    currentIndex: 0,
    totalMatches: 0
  });

  const [multiCursors, setMultiCursors] = useState<number[]>([]);
  const [isMultiCursorMode, setIsMultiCursorMode] = useState(false);

  const textAreaRef = useRef<HTMLTextAreaElement>(null);

  const editCommands: EditCommand[] = [
    {
      id: 'undo',
      name: 'Undo',
      description: 'Undo last action',
      shortcut: 'Ctrl+Z',
      category: 'basic',
      action: () => performUndo()
    },
    {
      id: 'redo',
      name: 'Redo',
      description: 'Redo last undone action',
      shortcut: 'Ctrl+Y',
      category: 'basic',
      action: () => performRedo()
    },
    {
      id: 'copy',
      name: 'Copy',
      description: 'Copy selected text',
      shortcut: 'Ctrl+C',
      category: 'basic',
      action: () => copyToClipboard()
    },
    {
      id: 'cut',
      name: 'Cut',
      description: 'Cut selected text',
      shortcut: 'Ctrl+X',
      category: 'basic',
      action: () => cutToClipboard()
    },
    {
      id: 'paste',
      name: 'Paste',
      description: 'Paste from clipboard',
      shortcut: 'Ctrl+V',
      category: 'basic',
      action: () => pasteFromClipboard()
    },
    {
      id: 'selectAll',
      name: 'Select All',
      description: 'Select all text',
      shortcut: 'Ctrl+A',
      category: 'basic',
      action: () => selectAllText()
    },
    {
      id: 'duplicateLine',
      name: 'Duplicate Line',
      description: 'Duplicate current line',
      shortcut: 'Ctrl+D',
      category: 'advanced',
      action: () => duplicateCurrentLine()
    },
    {
      id: 'deleteLine',
      name: 'Delete Line',
      description: 'Delete current line',
      shortcut: 'Ctrl+Shift+K',
      category: 'advanced',
      action: () => deleteCurrentLine()
    },
    {
      id: 'moveLineUp',
      name: 'Move Line Up',
      description: 'Move line up',
      shortcut: 'Alt+Up',
      category: 'advanced',
      action: () => moveLineUp()
    },
    {
      id: 'moveLineDown',
      name: 'Move Line Down',
      description: 'Move line down',
      shortcut: 'Alt+Down',
      category: 'advanced',
      action: () => moveLineDown()
    },
    {
      id: 'toggleComment',
      name: 'Toggle Comment',
      description: 'Toggle line comment',
      shortcut: 'Ctrl+/',
      category: 'advanced',
      action: () => toggleLineComment()
    },
    {
      id: 'formatDocument',
      name: 'Format Document',
      description: 'Format entire document',
      shortcut: 'Shift+Alt+F',
      category: 'formatting',
      action: () => formatDocument()
    }
  ];

  const performUndo = () => {
    if (editHistory.length > 0) {
      console.log('Performing undo operation');
      // Implementation would restore previous state
    }
  };

  const performRedo = () => {
    console.log('Performing redo operation');
    // Implementation would restore next state
  };

  const copyToClipboard = async () => {
    if (selection.text) {
      try {
        await navigator.clipboard.writeText(selection.text);
        console.log('Text copied to clipboard');
      } catch (err) {
        console.error('Failed to copy text:', err);
      }
    }
  };

  const cutToClipboard = async () => {
    if (selection.text) {
      try {
        await navigator.clipboard.writeText(selection.text);
        deleteSelection();
        console.log('Text cut to clipboard');
      } catch (err) {
        console.error('Failed to cut text:', err);
      }
    }
  };

  const pasteFromClipboard = async () => {
    try {
      const clipboardText = await navigator.clipboard.readText();
      insertTextAtCursor(clipboardText);
      console.log('Text pasted from clipboard');
    } catch (err) {
      console.error('Failed to paste text:', err);
    }
  };

  const selectAllText = () => {
    const textarea = textAreaRef.current;
    if (textarea) {
      textarea.select();
      setSelection({
        start: 0,
        end: currentText.length,
        text: currentText,
        line: 1,
        column: 1
      });
    }
  };

  const duplicateCurrentLine = () => {
    const textarea = textAreaRef.current;
    if (!textarea) return;

    const lines = currentText.split('\n');
    const cursorPosition = textarea.selectionStart;
    const lineNumber = currentText.substring(0, cursorPosition).split('\n').length - 1;
    const currentLine = lines[lineNumber];
    
    lines.splice(lineNumber + 1, 0, currentLine);
    const newText = lines.join('\n');
    setCurrentText(newText);
    
    addToHistory('insert', currentLine, { start: cursorPosition, end: cursorPosition }, 'Duplicated line');
  };

  const deleteCurrentLine = () => {
    const textarea = textAreaRef.current;
    if (!textarea) return;

    const lines = currentText.split('\n');
    const cursorPosition = textarea.selectionStart;
    const lineNumber = currentText.substring(0, cursorPosition).split('\n').length - 1;
    const deletedLine = lines[lineNumber];
    
    lines.splice(lineNumber, 1);
    const newText = lines.join('\n');
    setCurrentText(newText);
    
    addToHistory('delete', deletedLine, { start: cursorPosition, end: cursorPosition }, 'Deleted line');
  };

  const moveLineUp = () => {
    const textarea = textAreaRef.current;
    if (!textarea) return;

    const lines = currentText.split('\n');
    const cursorPosition = textarea.selectionStart;
    const lineNumber = currentText.substring(0, cursorPosition).split('\n').length - 1;
    
    if (lineNumber > 0) {
      const currentLine = lines[lineNumber];
      const previousLine = lines[lineNumber - 1];
      
      lines[lineNumber - 1] = currentLine;
      lines[lineNumber] = previousLine;
      
      const newText = lines.join('\n');
      setCurrentText(newText);
      
      addToHistory('move', currentLine, { start: cursorPosition, end: cursorPosition }, 'Moved line up');
    }
  };

  const moveLineDown = () => {
    const textarea = textAreaRef.current;
    if (!textarea) return;

    const lines = currentText.split('\n');
    const cursorPosition = textarea.selectionStart;
    const lineNumber = currentText.substring(0, cursorPosition).split('\n').length - 1;
    
    if (lineNumber < lines.length - 1) {
      const currentLine = lines[lineNumber];
      const nextLine = lines[lineNumber + 1];
      
      lines[lineNumber] = nextLine;
      lines[lineNumber + 1] = currentLine;
      
      const newText = lines.join('\n');
      setCurrentText(newText);
      
      addToHistory('move', currentLine, { start: cursorPosition, end: cursorPosition }, 'Moved line down');
    }
  };

  const toggleLineComment = () => {
    const textarea = textAreaRef.current;
    if (!textarea) return;

    const lines = currentText.split('\n');
    const cursorPosition = textarea.selectionStart;
    const lineNumber = currentText.substring(0, cursorPosition).split('\n').length - 1;
    const currentLine = lines[lineNumber];
    
    if (currentLine.trim().startsWith('//')) {
      lines[lineNumber] = currentLine.replace('//', '').trim();
    } else {
      lines[lineNumber] = `// ${currentLine}`;
    }
    
    const newText = lines.join('\n');
    setCurrentText(newText);
    
    addToHistory('format', lines[lineNumber], { start: cursorPosition, end: cursorPosition }, 'Toggled comment');
  };

  const formatDocument = () => {
    // Simple formatting: fix indentation
    const lines = currentText.split('\n');
    let indentLevel = 0;
    const formatted = lines.map(line => {
      const trimmed = line.trim();
      if (trimmed.includes('}')) indentLevel = Math.max(0, indentLevel - 1);
      const formattedLine = '    '.repeat(indentLevel) + trimmed;
      if (trimmed.includes('{')) indentLevel++;
      return formattedLine;
    });
    
    const newText = formatted.join('\n');
    setCurrentText(newText);
    
    addToHistory('format', 'entire document', { start: 0, end: newText.length }, 'Formatted document');
  };

  const deleteSelection = () => {
    const textarea = textAreaRef.current;
    if (!textarea || !selection.text) return;

    const newText = currentText.substring(0, selection.start) + currentText.substring(selection.end);
    setCurrentText(newText);
    
    addToHistory('delete', selection.text, selection, 'Deleted selection');
    
    setSelection({ start: 0, end: 0, text: '', line: 1, column: 1 });
  };

  const insertTextAtCursor = (text: string) => {
    const textarea = textAreaRef.current;
    if (!textarea) return;

    const cursorPosition = textarea.selectionStart;
    const newText = currentText.substring(0, cursorPosition) + text + currentText.substring(cursorPosition);
    setCurrentText(newText);
    
    addToHistory('insert', text, { start: cursorPosition, end: cursorPosition + text.length }, 'Inserted text');
  };

  const addToHistory = (type: EditAction['type'], content: string, position: { start: number; end: number }, description: string) => {
    const newAction: EditAction = {
      id: `action_${Date.now()}`,
      type,
      content,
      position,
      timestamp: new Date(),
      description
    };
    
    setEditHistory(prev => [newAction, ...prev.slice(0, 49)]); // Keep last 50 actions
  };

  const performFind = () => {
    if (!findReplace.findText) return;

    const text = findReplace.matchCase ? currentText : currentText.toLowerCase();
    const searchTerm = findReplace.matchCase ? findReplace.findText : findReplace.findText.toLowerCase();
    
    const results: number[] = [];
    let index = text.indexOf(searchTerm);
    
    while (index !== -1) {
      results.push(index);
      index = text.indexOf(searchTerm, index + 1);
    }
    
    setFindReplace(prev => ({
      ...prev,
      searchResults: results,
      totalMatches: results.length,
      currentIndex: results.length > 0 ? 0 : -1
    }));
  };

  const performReplace = () => {
    if (!findReplace.findText || findReplace.searchResults.length === 0) return;

    let newText = currentText;
    let offset = 0;
    
    findReplace.searchResults.forEach(position => {
      const adjustedPosition = position + offset;
      const before = newText.substring(0, adjustedPosition);
      const after = newText.substring(adjustedPosition + findReplace.findText.length);
      
      newText = before + findReplace.replaceText + after;
      offset += findReplace.replaceText.length - findReplace.findText.length;
    });
    
    setCurrentText(newText);
    addToHistory('replace', `${findReplace.findText} → ${findReplace.replaceText}`, 
      { start: 0, end: newText.length }, `Replaced ${findReplace.totalMatches} occurrences`);
    
    // Clear search results
    setFindReplace(prev => ({
      ...prev,
      searchResults: [],
      totalMatches: 0,
      currentIndex: -1
    }));
  };

  const addMultiCursor = (position: number) => {
    if (!multiCursors.includes(position)) {
      setMultiCursors(prev => [...prev, position].sort((a, b) => a - b));
    }
  };

  const clearMultiCursors = () => {
    setMultiCursors([]);
    setIsMultiCursorMode(false);
  };

  const handleTextSelection = () => {
    const textarea = textAreaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = currentText.substring(start, end);
    
    // Calculate line and column
    const textBeforeCursor = currentText.substring(0, start);
    const lines = textBeforeCursor.split('\n');
    const line = lines.length;
    const column = lines[lines.length - 1].length + 1;
    
    setSelection({
      start,
      end,
      text: selectedText,
      line,
      column
    });
  };

  const executeCommand = (commandId: string) => {
    const command = editCommands.find(cmd => cmd.id === commandId);
    if (command) {
      command.action();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Edit3 className="h-5 w-5 text-blue-500" />
            Advanced Edit System
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-5 flex-shrink-0 mb-4">
            <TabsTrigger value="editor">Editor</TabsTrigger>
            <TabsTrigger value="commands">Commands</TabsTrigger>
            <TabsTrigger value="find">Find/Replace</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="advanced">Advanced</TabsTrigger>
          </TabsList>

          <TabsContent value="editor" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 h-full">
              <div className="lg:col-span-3 flex flex-col">
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center gap-1">
                    <Button size="sm" variant="outline" onClick={() => executeCommand('undo')}>
                      <Undo className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => executeCommand('redo')}>
                      <Redo className="h-4 w-4" />
                    </Button>
                  </div>

                  <Separator orientation="vertical" className="h-6" />

                  <div className="flex items-center gap-1">
                    <Button size="sm" variant="outline" onClick={() => executeCommand('copy')}>
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => executeCommand('cut')}>
                      <Scissors className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => executeCommand('paste')}>
                      <Clipboard className="h-4 w-4" />
                    </Button>
                  </div>

                  <Separator orientation="vertical" className="h-6" />

                  <div className="flex items-center gap-1">
                    <Button 
                      size="sm" 
                      variant={isMultiCursorMode ? "default" : "outline"}
                      onClick={() => setIsMultiCursorMode(!isMultiCursorMode)}
                    >
                      <MousePointer2 className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={clearMultiCursors}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>

                  <Separator orientation="vertical" className="h-6" />

                  <Button size="sm" variant="outline" onClick={() => executeCommand('formatDocument')}>
                    <Wand2 className="h-4 w-4 mr-2" />
                    Format
                  </Button>
                </div>

                <Textarea
                  ref={textAreaRef}
                  value={currentText}
                  onChange={(e) => setCurrentText(e.target.value)}
                  onSelect={handleTextSelection}
                  className="flex-1 font-mono text-sm resize-none"
                  placeholder="Start editing your code..."
                  style={{ 
                    minHeight: '400px',
                    lineHeight: '1.6'
                  }}
                />

                <div className="flex items-center justify-between mt-2 text-sm text-muted-foreground">
                  <div className="flex items-center gap-4">
                    <span>Line {selection.line}, Column {selection.column}</span>
                    {selection.text && <span>Selected: {selection.text.length} chars</span>}
                    {isMultiCursorMode && <span>Multi-cursor: {multiCursors.length} cursors</span>}
                  </div>
                  <div className="flex items-center gap-2">
                    <span>{currentText.length} characters</span>
                    <span>{currentText.split('\n').length} lines</span>
                  </div>
                </div>
              </div>

              <Card className="lg:col-span-1">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Button size="sm" className="w-full justify-start" onClick={() => executeCommand('duplicateLine')}>
                      <Copy className="h-4 w-4 mr-2" />
                      Duplicate Line
                    </Button>
                    <Button size="sm" variant="outline" className="w-full justify-start" onClick={() => executeCommand('deleteLine')}>
                      <X className="h-4 w-4 mr-2" />
                      Delete Line
                    </Button>
                    <Button size="sm" variant="outline" className="w-full justify-start" onClick={() => executeCommand('moveLineUp')}>
                      ↑ Move Line Up
                    </Button>
                    <Button size="sm" variant="outline" className="w-full justify-start" onClick={() => executeCommand('moveLineDown')}>
                      ↓ Move Line Down
                    </Button>
                    <Button size="sm" variant="outline" className="w-full justify-start" onClick={() => executeCommand('toggleComment')}>
                      <Code className="h-4 w-4 mr-2" />
                      Toggle Comment
                    </Button>
                    <Button size="sm" variant="outline" className="w-full justify-start" onClick={() => executeCommand('selectAll')}>
                      <Target className="h-4 w-4 mr-2" />
                      Select All
                    </Button>
                  </div>

                  <Separator className="my-4" />

                  <div className="space-y-3">
                    <div>
                      <Label className="text-xs text-muted-foreground">Current Selection</Label>
                      <div className="mt-1 p-2 bg-muted rounded text-xs">
                        {selection.text || 'No selection'}
                      </div>
                    </div>

                    {multiCursors.length > 0 && (
                      <div>
                        <Label className="text-xs text-muted-foreground">Multi-Cursors</Label>
                        <div className="mt-1 text-xs">
                          {multiCursors.length} cursor{multiCursors.length !== 1 ? 's' : ''} active
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="commands" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Available Commands</CardTitle>
                  <CardDescription>All editing commands with keyboard shortcuts</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-1">
                      {editCommands.map((command) => (
                        <div 
                          key={command.id}
                          className="flex items-center justify-between p-3 border rounded hover:bg-accent/50 cursor-pointer"
                          onClick={() => executeCommand(command.id)}
                        >
                          <div>
                            <div className="font-medium">{command.name}</div>
                            <div className="text-sm text-muted-foreground">{command.description}</div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs">
                              {command.category}
                            </Badge>
                            <Badge variant="secondary" className="text-xs font-mono">
                              {command.shortcut}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Command Palette</CardTitle>
                  <CardDescription>Search and execute commands</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Input placeholder="Search commands..." />
                    
                    <div className="space-y-2">
                      <Label className="text-sm">Recent Commands</Label>
                      <div className="space-y-1">
                        <div className="p-2 border rounded text-sm hover:bg-accent/50 cursor-pointer">
                          Format Document
                        </div>
                        <div className="p-2 border rounded text-sm hover:bg-accent/50 cursor-pointer">
                          Toggle Comment
                        </div>
                        <div className="p-2 border rounded text-sm hover:bg-accent/50 cursor-pointer">
                          Duplicate Line
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-sm">Command Categories</Label>
                      <div className="grid grid-cols-2 gap-2">
                        <Button size="sm" variant="outline" className="justify-start">
                          <Edit3 className="h-4 w-4 mr-2" />
                          Basic
                        </Button>
                        <Button size="sm" variant="outline" className="justify-start">
                          <Type className="h-4 w-4 mr-2" />
                          Formatting
                        </Button>
                        <Button size="sm" variant="outline" className="justify-start">
                          <Zap className="h-4 w-4 mr-2" />
                          Advanced
                        </Button>
                        <Button size="sm" variant="outline" className="justify-start">
                          <Target className="h-4 w-4 mr-2" />
                          Navigation
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="find" className="flex-1 overflow-hidden">
            <Card className="h-full flex flex-col">
              <CardHeader>
                <CardTitle className="text-base">Find & Replace</CardTitle>
                <CardDescription>Search and replace text with advanced options</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 overflow-hidden">
                <div className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div>
                      <Label>Find</Label>
                      <div className="flex gap-2 mt-1">
                        <Input 
                          value={findReplace.findText}
                          onChange={(e) => setFindReplace(prev => ({ ...prev, findText: e.target.value }))}
                          placeholder="Search text..."
                        />
                        <Button size="sm" onClick={performFind}>
                          <Search className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div>
                      <Label>Replace</Label>
                      <div className="flex gap-2 mt-1">
                        <Input 
                          value={findReplace.replaceText}
                          onChange={(e) => setFindReplace(prev => ({ ...prev, replaceText: e.target.value }))}
                          placeholder="Replace with..."
                        />
                        <Button size="sm" onClick={performReplace}>
                          <Replace className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="flex items-center space-x-2">
                      <Switch 
                        checked={findReplace.matchCase}
                        onCheckedChange={(checked) => setFindReplace(prev => ({ ...prev, matchCase: checked }))}
                      />
                      <Label>Match case</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch 
                        checked={findReplace.wholeWord}
                        onCheckedChange={(checked) => setFindReplace(prev => ({ ...prev, wholeWord: checked }))}
                      />
                      <Label>Whole word</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch 
                        checked={findReplace.useRegex}
                        onCheckedChange={(checked) => setFindReplace(prev => ({ ...prev, useRegex: checked }))}
                      />
                      <Label>Regular expression</Label>
                    </div>
                  </div>

                  {findReplace.totalMatches > 0 && (
                    <div className="flex items-center gap-4">
                      <Badge variant="secondary">
                        {findReplace.totalMatches} match{findReplace.totalMatches !== 1 ? 'es' : ''} found
                      </Badge>
                      {findReplace.currentIndex >= 0 && (
                        <Badge variant="outline">
                          {findReplace.currentIndex + 1} of {findReplace.totalMatches}
                        </Badge>
                      )}
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label className="text-sm">Quick Replace Patterns</Label>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
                      <Button size="sm" variant="outline" className="justify-start text-left">
                        <span className="font-mono text-xs">var → let/const</span>
                      </Button>
                      <Button size="sm" variant="outline" className="justify-start text-left">
                        <span className="font-mono text-xs">function() → () =&gt;</span>
                      </Button>
                      <Button size="sm" variant="outline" className="justify-start text-left">
                        <span className="font-mono text-xs">TODO → FIXME</span>
                      </Button>
                      <Button size="sm" variant="outline" className="justify-start text-left">
                        <span className="font-mono text-xs">console.log → debug</span>
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="flex-1 overflow-hidden">
            <Card className="h-full flex flex-col">
              <CardHeader>
                <CardTitle className="text-base">Edit History</CardTitle>
                <CardDescription>Track all editing actions</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 overflow-hidden">
                <ScrollArea className="h-full">
                  <div className="space-y-2">
                    {editHistory.map((action) => (
                      <div key={action.id} className="p-3 border rounded">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant={
                              action.type === 'insert' ? 'default' :
                              action.type === 'delete' ? 'destructive' :
                              action.type === 'replace' ? 'secondary' :
                              action.type === 'format' ? 'outline' : 'default'
                            }>
                              {action.type}
                            </Badge>
                            <span className="font-medium">{action.description}</span>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            {action.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                        
                        <div className="text-sm text-muted-foreground">
                          Position: {action.position.start}-{action.position.end}
                        </div>
                        
                        {action.content && (
                          <div className="mt-2 p-2 bg-muted rounded text-xs font-mono">
                            {action.content.substring(0, 100)}
                            {action.content.length > 100 && '...'}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="advanced" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Multi-Cursor Editing</CardTitle>
                  <CardDescription>Advanced cursor and selection management</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>Multi-cursor mode</Label>
                      <Switch 
                        checked={isMultiCursorMode}
                        onCheckedChange={setIsMultiCursorMode}
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Active cursors</span>
                        <Badge variant="outline">{multiCursors.length}</Badge>
                      </div>
                      
                      <div className="space-y-1">
                        <Button size="sm" variant="outline" className="w-full">
                          Add cursor at current position
                        </Button>
                        <Button size="sm" variant="outline" className="w-full">
                          Add cursor at each line end
                        </Button>
                        <Button size="sm" variant="outline" className="w-full">
                          Add cursor at matching words
                        </Button>
                        <Button size="sm" variant="destructive" className="w-full" onClick={clearMultiCursors}>
                          Clear all cursors
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Advanced Settings</CardTitle>
                  <CardDescription>Configure editing behavior</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label>Auto-format on save</Label>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Auto-indent new lines</Label>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Show invisibles</Label>
                        <Switch />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Wrap long lines</Label>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Smart selection</Label>
                        <Switch defaultChecked />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Tab behavior</Label>
                      <Select defaultValue="spaces">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="spaces">Insert spaces</SelectItem>
                          <SelectItem value="tabs">Insert tabs</SelectItem>
                          <SelectItem value="auto">Auto-detect</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Line ending style</Label>
                      <Select defaultValue="lf">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="lf">LF (Unix)</SelectItem>
                          <SelectItem value="crlf">CRLF (Windows)</SelectItem>
                          <SelectItem value="cr">CR (Classic Mac)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}