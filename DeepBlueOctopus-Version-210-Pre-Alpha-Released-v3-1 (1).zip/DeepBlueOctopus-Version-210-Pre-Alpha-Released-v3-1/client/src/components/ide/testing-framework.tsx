import React, { useState, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Play, Pause, Square, RotateCcw, CheckCircle2, XCircle, 
  Clock, Zap, Target, Bug, TestTube, FileText, 
  Settings, Filter, Search, Download, Upload,
  BarChart3, TrendingUp, AlertTriangle, Info,
  ChevronRight, ChevronDown, Eye, EyeOff
} from "lucide-react";

interface TestingFrameworkProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TestCase {
  id: string;
  name: string;
  description: string;
  file: string;
  suite: string;
  status: 'pending' | 'running' | 'passed' | 'failed' | 'skipped';
  duration: number;
  error?: string;
  assertions: number;
  passedAssertions: number;
  coverage: number;
  lastRun: Date;
}

interface TestSuite {
  id: string;
  name: string;
  description: string;
  framework: string;
  testCount: number;
  passedTests: number;
  failedTests: number;
  coverage: number;
  duration: number;
  isExpanded: boolean;
  tests: TestCase[];
}

interface TestRun {
  id: string;
  timestamp: Date;
  duration: number;
  totalTests: number;
  passedTests: number;
  failedTests: number;
  skippedTests: number;
  coverage: number;
  status: 'running' | 'completed' | 'failed';
}

interface CoverageData {
  file: string;
  lines: number;
  coveredLines: number;
  functions: number;
  coveredFunctions: number;
  branches: number;
  coveredBranches: number;
  percentage: number;
}

export default function TestingFramework({ isOpen, onClose }: TestingFrameworkProps) {
  const [activeTab, setActiveTab] = useState("test-runner");
  const [selectedFramework, setSelectedFramework] = useState("jest");
  const [isRunning, setIsRunning] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [showCoverage, setShowCoverage] = useState(true);
  const [autoRun, setAutoRun] = useState(false);

  const [testSuites, setTestSuites] = useState<TestSuite[]>([
    {
      id: "unit-tests",
      name: "Unit Tests",
      description: "Component and utility function tests",
      framework: "Jest",
      testCount: 12,
      passedTests: 10,
      failedTests: 1,
      coverage: 85.4,
      duration: 2.3,
      isExpanded: true,
      tests: [
        {
          id: "test-1",
          name: "Component rendering",
          description: "Test if components render correctly",
          file: "components/Button.test.tsx",
          suite: "unit-tests",
          status: "passed",
          duration: 0.15,
          assertions: 3,
          passedAssertions: 3,
          coverage: 92,
          lastRun: new Date()
        },
        {
          id: "test-2",
          name: "Utility functions",
          description: "Test utility function behavior",
          file: "utils/helpers.test.ts",
          suite: "unit-tests",
          status: "failed",
          duration: 0.08,
          error: "Expected 'hello world' but received 'hello'",
          assertions: 2,
          passedAssertions: 1,
          coverage: 78,
          lastRun: new Date()
        },
        {
          id: "test-3",
          name: "API service",
          description: "Test API service methods",
          file: "services/api.test.ts",
          suite: "unit-tests",
          status: "passed",
          duration: 0.23,
          assertions: 5,
          passedAssertions: 5,
          coverage: 88,
          lastRun: new Date()
        }
      ]
    },
    {
      id: "integration-tests",
      name: "Integration Tests",
      description: "Component integration and workflow tests",
      framework: "Cypress",
      testCount: 8,
      passedTests: 7,
      failedTests: 0,
      coverage: 76.2,
      duration: 12.8,
      isExpanded: false,
      tests: [
        {
          id: "test-4",
          name: "User authentication flow",
          description: "Test complete auth workflow",
          file: "e2e/auth.cy.ts",
          suite: "integration-tests",
          status: "passed",
          duration: 3.2,
          assertions: 8,
          passedAssertions: 8,
          coverage: 82,
          lastRun: new Date()
        },
        {
          id: "test-5",
          name: "File operations",
          description: "Test file create/edit/delete",
          file: "e2e/files.cy.ts",
          suite: "integration-tests",
          status: "passed",
          duration: 2.1,
          assertions: 12,
          passedAssertions: 12,
          coverage: 75,
          lastRun: new Date()
        }
      ]
    },
    {
      id: "performance-tests",
      name: "Performance Tests",
      description: "Load and performance benchmarks",
      framework: "Artillery",
      testCount: 5,
      passedTests: 4,
      failedTests: 1,
      coverage: 45.8,
      duration: 45.2,
      isExpanded: false,
      tests: [
        {
          id: "test-6",
          name: "API load test",
          description: "Test API under load",
          file: "performance/api-load.yml",
          suite: "performance-tests",
          status: "skipped",
          duration: 0,
          assertions: 0,
          passedAssertions: 0,
          coverage: 0,
          lastRun: new Date()
        }
      ]
    }
  ]);

  const [testRuns, setTestRuns] = useState<TestRun[]>([
    {
      id: "run-1",
      timestamp: new Date(),
      duration: 15.6,
      totalTests: 25,
      passedTests: 21,
      failedTests: 2,
      skippedTests: 2,
      coverage: 78.5,
      status: "completed"
    },
    {
      id: "run-2",
      timestamp: new Date(Date.now() - 3600000),
      duration: 14.2,
      totalTests: 25,
      passedTests: 23,
      failedTests: 1,
      skippedTests: 1,
      coverage: 81.2,
      status: "completed"
    }
  ]);

  const [coverageData, setCoverageData] = useState<CoverageData[]>([
    {
      file: "src/components/Button.tsx",
      lines: 45,
      coveredLines: 42,
      functions: 6,
      coveredFunctions: 6,
      branches: 8,
      coveredBranches: 7,
      percentage: 93.3
    },
    {
      file: "src/utils/helpers.ts",
      lines: 120,
      coveredLines: 89,
      functions: 12,
      coveredFunctions: 10,
      branches: 24,
      coveredBranches: 18,
      percentage: 74.2
    },
    {
      file: "src/services/api.ts",
      lines: 85,
      coveredLines: 76,
      functions: 8,
      coveredFunctions: 8,
      branches: 16,
      coveredBranches: 14,
      percentage: 89.4
    }
  ]);

  const frameworks = ["Jest", "Vitest", "Cypress", "Playwright", "Mocha", "Jasmine"];

  const runAllTests = async () => {
    setIsRunning(true);
    
    // Simulate test execution
    for (let i = 0; i < testSuites.length; i++) {
      const suite = testSuites[i];
      for (let j = 0; j < suite.tests.length; j++) {
        const test = suite.tests[j];
        
        // Update test status to running
        setTestSuites(prev => prev.map(s => 
          s.id === suite.id 
            ? {
                ...s,
                tests: s.tests.map(t => 
                  t.id === test.id ? { ...t, status: 'running' as const } : t
                )
              }
            : s
        ));
        
        // Simulate test execution time
        await new Promise(resolve => setTimeout(resolve, Math.random() * 1000 + 500));
        
        // Random test result
        const passed = Math.random() > 0.2;
        setTestSuites(prev => prev.map(s => 
          s.id === suite.id 
            ? {
                ...s,
                tests: s.tests.map(t => 
                  t.id === test.id 
                    ? { 
                        ...t, 
                        status: passed ? 'passed' as const : 'failed' as const,
                        lastRun: new Date()
                      } 
                    : t
                )
              }
            : s
        ));
      }
    }
    
    setIsRunning(false);
  };

  const runSingleTest = async (testId: string) => {
    setTestSuites(prev => prev.map(suite => ({
      ...suite,
      tests: suite.tests.map(test => 
        test.id === testId ? { ...test, status: 'running' as const } : test
      )
    })));
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const passed = Math.random() > 0.3;
    setTestSuites(prev => prev.map(suite => ({
      ...suite,
      tests: suite.tests.map(test => 
        test.id === testId 
          ? { 
              ...test, 
              status: passed ? 'passed' as const : 'failed' as const,
              lastRun: new Date()
            } 
          : test
      )
    })));
  };

  const toggleSuiteExpansion = (suiteId: string) => {
    setTestSuites(prev => prev.map(suite => 
      suite.id === suiteId ? { ...suite, isExpanded: !suite.isExpanded } : suite
    ));
  };

  const getStatusIcon = (status: TestCase['status']) => {
    switch (status) {
      case 'passed':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'running':
        return <Clock className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'skipped':
        return <Eye className="h-4 w-4 text-yellow-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: TestCase['status']) => {
    switch (status) {
      case 'passed': return 'bg-green-500';
      case 'failed': return 'bg-red-500';
      case 'running': return 'bg-blue-500';
      case 'skipped': return 'bg-yellow-500';
      default: return 'bg-gray-400';
    }
  };

  const filteredSuites = testSuites.filter(suite => {
    const matchesSearch = suite.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         suite.tests.some(test => test.name.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (filterStatus === 'all') return matchesSearch;
    
    const hasStatus = suite.tests.some(test => test.status === filterStatus);
    return matchesSearch && hasStatus;
  });

  const totalTests = testSuites.reduce((sum, suite) => sum + suite.testCount, 0);
  const totalPassed = testSuites.reduce((sum, suite) => sum + suite.passedTests, 0);
  const totalFailed = testSuites.reduce((sum, suite) => sum + suite.failedTests, 0);
  const overallCoverage = testSuites.reduce((sum, suite) => sum + (suite.coverage * suite.testCount), 0) / totalTests;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <TestTube className="h-5 w-5 text-blue-500" />
            Testing Framework
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-4 flex-shrink-0">
            <TabsTrigger value="test-runner" className="flex items-center gap-2">
              <Play className="h-4 w-4" />
              Test Runner
            </TabsTrigger>
            <TabsTrigger value="coverage" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Coverage
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Reports
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="test-runner" className="flex-1 overflow-hidden flex flex-col">
            <div className="flex items-center gap-4 mb-4 flex-shrink-0">
              <div className="flex items-center gap-2">
                <Button 
                  onClick={runAllTests} 
                  disabled={isRunning}
                  className="flex items-center gap-2"
                >
                  {isRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  {isRunning ? 'Running...' : 'Run All Tests'}
                </Button>
                <Button variant="outline" size="sm">
                  <Square className="h-4 w-4 mr-2" />
                  Stop
                </Button>
                <Button variant="outline" size="sm">
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Rerun Failed
                </Button>
              </div>
              
              <Separator orientation="vertical" className="h-6" />
              
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search tests..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 w-64"
                  />
                </div>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="passed">Passed</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                    <SelectItem value="running">Running</SelectItem>
                    <SelectItem value="skipped">Skipped</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center gap-2 ml-auto">
                <Label className="text-sm">Auto-run</Label>
                <Switch checked={autoRun} onCheckedChange={setAutoRun} />
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4 mb-4 flex-shrink-0">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Total Tests</p>
                      <p className="text-2xl font-bold">{totalTests}</p>
                    </div>
                    <TestTube className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-600">Passed</p>
                      <p className="text-2xl font-bold text-green-600">{totalPassed}</p>
                    </div>
                    <CheckCircle2 className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-red-600">Failed</p>
                      <p className="text-2xl font-bold text-red-600">{totalFailed}</p>
                    </div>
                    <XCircle className="h-8 w-8 text-red-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Coverage</p>
                      <p className="text-2xl font-bold">{overallCoverage.toFixed(1)}%</p>
                    </div>
                    <Target className="h-8 w-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <ScrollArea className="flex-1">
              <div className="space-y-4 pr-4">
                {filteredSuites.map((suite) => (
                  <Card key={suite.id}>
                    <CardHeader 
                      className="cursor-pointer pb-3"
                      onClick={() => toggleSuiteExpansion(suite.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {suite.isExpanded ? 
                            <ChevronDown className="h-4 w-4" /> : 
                            <ChevronRight className="h-4 w-4" />
                          }
                          <CardTitle className="text-lg">{suite.name}</CardTitle>
                          <Badge variant="secondary">{suite.framework}</Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm">
                          <span className="flex items-center gap-1">
                            <CheckCircle2 className="h-4 w-4 text-green-500" />
                            {suite.passedTests}
                          </span>
                          <span className="flex items-center gap-1">
                            <XCircle className="h-4 w-4 text-red-500" />
                            {suite.failedTests}
                          </span>
                          <span>{suite.coverage.toFixed(1)}%</span>
                          <span>{suite.duration}s</span>
                        </div>
                      </div>
                      <CardDescription>{suite.description}</CardDescription>
                    </CardHeader>
                    
                    {suite.isExpanded && (
                      <CardContent className="pt-0">
                        <div className="space-y-3">
                          {suite.tests.map((test) => (
                            <div 
                              key={test.id} 
                              className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                            >
                              <div className="flex items-center gap-3 flex-1">
                                {getStatusIcon(test.status)}
                                <div className="flex-1">
                                  <div className="flex items-center gap-2">
                                    <p className="font-medium">{test.name}</p>
                                    <Badge variant="outline" className="text-xs">{test.file}</Badge>
                                  </div>
                                  <p className="text-sm text-muted-foreground">{test.description}</p>
                                  {test.error && (
                                    <p className="text-sm text-red-600 mt-1">{test.error}</p>
                                  )}
                                </div>
                              </div>
                              
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <span>{test.assertions > 0 && `${test.passedAssertions}/${test.assertions}`}</span>
                                <span>{test.duration > 0 && `${test.duration}s`}</span>
                                <span>{test.coverage > 0 && `${test.coverage}%`}</span>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => runSingleTest(test.id)}
                                  disabled={test.status === 'running'}
                                >
                                  <Play className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    )}
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="coverage" className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Code Coverage Report</h3>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
                <Button variant="outline" size="sm">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Trends
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-600">78.5%</p>
                    <p className="text-sm text-muted-foreground">Overall Coverage</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">85.2%</p>
                    <p className="text-sm text-muted-foreground">Line Coverage</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-purple-600">72.8%</p>
                    <p className="text-sm text-muted-foreground">Branch Coverage</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-orange-600">91.4%</p>
                    <p className="text-sm text-muted-foreground">Function Coverage</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <ScrollArea className="flex-1">
              <div className="space-y-3 pr-4">
                {coverageData.map((file, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium">{file.file}</h4>
                        <Badge 
                          variant={file.percentage >= 80 ? "default" : file.percentage >= 60 ? "secondary" : "destructive"}
                        >
                          {file.percentage.toFixed(1)}%
                        </Badge>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Lines</span>
                          <span>{file.coveredLines}/{file.lines}</span>
                        </div>
                        <Progress value={file.percentage} className="h-2" />
                        
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div className="flex justify-between">
                            <span>Functions:</span>
                            <span>{file.coveredFunctions}/{file.functions}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Branches:</span>
                            <span>{file.coveredBranches}/{file.branches}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="reports" className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Test Reports</h3>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export Report
              </Button>
            </div>

            <ScrollArea className="flex-1">
              <div className="space-y-4 pr-4">
                {testRuns.map((run) => (
                  <Card key={run.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">
                          Test Run - {run.timestamp.toLocaleString()}
                        </CardTitle>
                        <Badge variant={run.status === 'completed' ? 'default' : 'secondary'}>
                          {run.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Duration</p>
                          <p className="font-medium">{run.duration}s</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Total Tests</p>
                          <p className="font-medium">{run.totalTests}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Passed</p>
                          <p className="font-medium text-green-600">{run.passedTests}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Failed</p>
                          <p className="font-medium text-red-600">{run.failedTests}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Coverage</p>
                          <p className="font-medium">{run.coverage.toFixed(1)}%</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="settings" className="flex-1 overflow-hidden">
            <ScrollArea className="flex-1">
              <div className="space-y-6 pr-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Test Framework Configuration</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Default Framework</Label>
                      <Select value={selectedFramework} onValueChange={setSelectedFramework}>
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {frameworks.map(framework => (
                            <SelectItem key={framework} value={framework.toLowerCase()}>
                              {framework}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Show Coverage</Label>
                        <p className="text-sm text-muted-foreground">Display coverage information in test results</p>
                      </div>
                      <Switch checked={showCoverage} onCheckedChange={setShowCoverage} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Auto-run on File Change</Label>
                        <p className="text-sm text-muted-foreground">Automatically run tests when files change</p>
                      </div>
                      <Switch checked={autoRun} onCheckedChange={setAutoRun} />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Coverage Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Coverage Threshold (%)</Label>
                      <Input type="number" defaultValue="80" className="mt-1" />
                    </div>
                    
                    <div>
                      <Label>Excluded Patterns</Label>
                      <Textarea 
                        placeholder="node_modules/&#10;*.test.ts&#10;*.spec.ts"
                        className="mt-1"
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Test Discovery</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Test Pattern</Label>
                      <Input defaultValue="**/*.{test,spec}.{js,ts,jsx,tsx}" className="mt-1" />
                    </div>
                    
                    <div>
                      <Label>Test Directory</Label>
                      <Input defaultValue="./tests" className="mt-1" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}