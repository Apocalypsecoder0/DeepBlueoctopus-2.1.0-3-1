import React, { useState, useEffect, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  Lightbulb, Code, Zap, Target, Brain, 
  Star, TrendingUp, Clock, CheckCircle,
  AlertCircle, Search, Filter, Settings,
  BookOpen, Sparkles, ArrowRight, Copy,
  ThumbsUp, ThumbsDown, RefreshCw, Play
} from "lucide-react";

interface SmartCodeSuggestionsProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CodeSuggestion {
  id: string;
  title: string;
  description: string;
  code: string;
  language: string;
  category: 'function' | 'pattern' | 'optimization' | 'security' | 'library' | 'template';
  confidence: number;
  relevanceScore: number;
  tags: string[];
  usageCount: number;
  lastUsed?: Date;
  source: 'ai' | 'pattern' | 'community' | 'documentation';
  context: {
    fileName?: string;
    lineNumber?: number;
    surroundingCode?: string;
    variables?: string[];
    imports?: string[];
  };
}

interface ContextAnalysis {
  language: string;
  fileName: string;
  currentFunction?: string;
  variables: string[];
  imports: string[];
  patterns: string[];
  complexity: 'low' | 'medium' | 'high';
  suggestions: number;
}

interface UserPreferences {
  enableAutoSuggestions: boolean;
  suggestionFrequency: 'low' | 'medium' | 'high';
  preferredCategories: string[];
  excludePatterns: string[];
  minConfidence: number;
  showInlinePreview: boolean;
  autoApplySuggestions: boolean;
}

export default function SmartCodeSuggestions({ isOpen, onClose }: SmartCodeSuggestionsProps) {
  const [suggestions, setSuggestions] = useState<CodeSuggestion[]>([]);
  const [filteredSuggestions, setFilteredSuggestions] = useState<CodeSuggestion[]>([]);
  const [contextAnalysis, setContextAnalysis] = useState<ContextAnalysis>({
    language: 'typescript',
    fileName: 'example.ts',
    variables: ['user', 'data', 'result'],
    imports: ['React', 'useState', 'useEffect'],
    patterns: ['hooks', 'components', 'async'],
    complexity: 'medium',
    suggestions: 12
  });

  const [preferences, setPreferences] = useState<UserPreferences>({
    enableAutoSuggestions: true,
    suggestionFrequency: 'medium',
    preferredCategories: ['function', 'pattern', 'optimization'],
    excludePatterns: [],
    minConfidence: 0.7,
    showInlinePreview: true,
    autoApplySuggestions: false
  });

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("relevance");
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const { toast } = useToast();

  // Sample suggestions data
  const sampleSuggestions: CodeSuggestion[] = [
    {
      id: '1',
      title: 'Error Boundary Component',
      description: 'Add error boundary to catch and handle React component errors gracefully',
      code: `class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('Error caught by boundary:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return <h1>Something went wrong.</h1>;
    }
    return this.props.children;
  }
}`,
      language: 'typescript',
      category: 'pattern',
      confidence: 0.92,
      relevanceScore: 0.88,
      tags: ['react', 'error-handling', 'components'],
      usageCount: 156,
      lastUsed: new Date('2024-01-15'),
      source: 'pattern',
      context: {
        fileName: 'App.tsx',
        lineNumber: 25,
        variables: ['React', 'Component'],
        imports: ['React']
      }
    },
    {
      id: '2',
      title: 'Custom Hook for API Calls',
      description: 'Reusable hook for handling API requests with loading and error states',
      code: `const useAPI = (url: string) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error('Failed to fetch');
      const result = await response.json();
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [url]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
};`,
      language: 'typescript',
      category: 'function',
      confidence: 0.95,
      relevanceScore: 0.91,
      tags: ['react', 'hooks', 'api', 'typescript'],
      usageCount: 89,
      source: 'ai',
      context: {
        fileName: 'hooks.ts',
        variables: ['useState', 'useEffect', 'useCallback'],
        imports: ['React', 'useState', 'useEffect', 'useCallback']
      }
    },
    {
      id: '3',
      title: 'Memoized Component Optimization',
      description: 'Optimize component re-renders using React.memo and useMemo',
      code: `const OptimizedComponent = React.memo(({ data, onAction }) => {
  const expensiveValue = useMemo(() => {
    return data.reduce((acc, item) => acc + item.value, 0);
  }, [data]);

  const memoizedCallback = useCallback((id: string) => {
    onAction(id);
  }, [onAction]);

  return (
    <div>
      <p>Total: {expensiveValue}</p>
      {data.map(item => (
        <Item 
          key={item.id} 
          item={item} 
          onClick={memoizedCallback}
        />
      ))}
    </div>
  );
});`,
      language: 'typescript',
      category: 'optimization',
      confidence: 0.87,
      relevanceScore: 0.84,
      tags: ['react', 'performance', 'memo', 'optimization'],
      usageCount: 67,
      source: 'pattern',
      context: {
        fileName: 'components.tsx',
        variables: ['React', 'useMemo', 'useCallback'],
        imports: ['React', 'useMemo', 'useCallback']
      }
    },
    {
      id: '4',
      title: 'Input Validation Schema',
      description: 'Comprehensive input validation using Zod schema',
      code: `import { z } from 'zod';

const userSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email format'),
  age: z.number().min(18, 'Must be at least 18 years old'),
  password: z.string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)/, 'Password must contain uppercase, lowercase, and number')
});

type User = z.infer<typeof userSchema>;

const validateUser = (data: unknown): User => {
  return userSchema.parse(data);
};`,
      language: 'typescript',
      category: 'security',
      confidence: 0.94,
      relevanceScore: 0.89,
      tags: ['validation', 'zod', 'security', 'typescript'],
      usageCount: 134,
      source: 'community',
      context: {
        fileName: 'validation.ts',
        variables: ['z', 'zod'],
        imports: ['zod']
      }
    },
    {
      id: '5',
      title: 'Debounced Search Hook',
      description: 'Optimize search performance with debounced input handling',
      code: `const useDebounce = (value: string, delay: number) => {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
};

// Usage example
const SearchComponent = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  useEffect(() => {
    if (debouncedSearchTerm) {
      // Perform search
      performSearch(debouncedSearchTerm);
    }
  }, [debouncedSearchTerm]);

  return (
    <input
      value={searchTerm}
      onChange={(e) => setSearchTerm(e.target.value)}
      placeholder="Search..."
    />
  );
};`,
      language: 'typescript',
      category: 'function',
      confidence: 0.91,
      relevanceScore: 0.86,
      tags: ['react', 'hooks', 'performance', 'debounce'],
      usageCount: 78,
      source: 'pattern',
      context: {
        fileName: 'search.tsx',
        variables: ['useState', 'useEffect'],
        imports: ['React', 'useState', 'useEffect']
      }
    },
    {
      id: '6',
      title: 'Theme Context Provider',
      description: 'Global theme management with context and local storage persistence',
      code: `interface ThemeContextType {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('theme');
    return (saved as 'light' | 'dark') || 'light';
  });

  const toggleTheme = useCallback(() => {
    setTheme(prev => {
      const newTheme = prev === 'light' ? 'dark' : 'light';
      localStorage.setItem('theme', newTheme);
      document.documentElement.setAttribute('data-theme', newTheme);
      return newTheme;
    });
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
};`,
      language: 'typescript',
      category: 'template',
      confidence: 0.93,
      relevanceScore: 0.87,
      tags: ['react', 'context', 'theme', 'localStorage'],
      usageCount: 92,
      source: 'documentation',
      context: {
        fileName: 'theme-context.tsx',
        variables: ['createContext', 'useContext', 'useState', 'useCallback'],
        imports: ['React', 'createContext', 'useContext', 'useState', 'useCallback']
      }
    }
  ];

  useEffect(() => {
    try {
      setSuggestions(sampleSuggestions);
      setFilteredSuggestions(sampleSuggestions);
    } catch (error) {
      console.error('Error setting initial suggestions:', error);
    }
  }, []);

  useEffect(() => {
    try {
      filterSuggestions();
    } catch (error) {
      console.error('Error filtering suggestions:', error);
    }
  }, [searchTerm, selectedCategory, sortBy, suggestions]);

  const filterSuggestions = () => {
    let filtered = [...suggestions];

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(suggestion =>
        suggestion.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        suggestion.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        suggestion.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(suggestion => suggestion.category === selectedCategory);
    }

    // Filter by confidence
    filtered = filtered.filter(suggestion => suggestion.confidence >= preferences.minConfidence);

    // Sort suggestions
    switch (sortBy) {
      case 'relevance':
        filtered.sort((a, b) => b.relevanceScore - a.relevanceScore);
        break;
      case 'confidence':
        filtered.sort((a, b) => b.confidence - a.confidence);
        break;
      case 'usage':
        filtered.sort((a, b) => b.usageCount - a.usageCount);
        break;
      case 'recent':
        filtered.sort((a, b) => {
          const dateA = a.lastUsed ? new Date(a.lastUsed).getTime() : 0;
          const dateB = b.lastUsed ? new Date(b.lastUsed).getTime() : 0;
          return dateB - dateA;
        });
        break;
    }

    setFilteredSuggestions(filtered);
  };

  const analyzeCurrentContext = async () => {
    try {
      setIsAnalyzing(true);
      
      // Simulate context analysis
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setContextAnalysis(prev => ({
        ...prev,
        suggestions: Math.floor(Math.random() * 20) + 5,
        complexity: ['low', 'medium', 'high'][Math.floor(Math.random() * 3)] as any
      }));
      
      setIsAnalyzing(false);
      
      toast({
        title: "Context Analysis Complete",
        description: `Found ${contextAnalysis.suggestions} relevant suggestions for your current code context`,
      });
    } catch (error) {
      console.error('Error analyzing code context:', error);
      setIsAnalyzing(false);
      toast({
        title: "Analysis Failed",
        description: "Unable to analyze code context. Please try again.",
        variant: "destructive",
      });
    }
  };

  const applySuggestion = async (suggestion: CodeSuggestion) => {
    try {
      // Copy to clipboard
      await navigator.clipboard.writeText(suggestion.code);
      
      // Update usage count
      setSuggestions(prev => 
        prev.map(s => 
          s.id === suggestion.id 
            ? { ...s, usageCount: s.usageCount + 1, lastUsed: new Date() }
            : s
        )
      );

      toast({
        title: "Code Copied",
        description: `"${suggestion.title}" has been copied to your clipboard`,
      });
    } catch (error) {
      console.error('Error copying to clipboard:', error);
      toast({
        title: "Copy Failed",
        description: "Unable to copy code to clipboard. Please try again.",
        variant: "destructive",
      });
    }
  };

  const rateSuggestion = (suggestionId: string, rating: 'up' | 'down') => {
    toast({
      title: "Feedback Recorded",
      description: `Thank you for rating this suggestion`,
    });
  };

  const updatePreference = <K extends keyof UserPreferences>(
    key: K,
    value: UserPreferences[K]
  ) => {
    setPreferences(prev => ({ ...prev, [key]: value }));
  };

  const getCategoryIcon = (category: CodeSuggestion['category']) => {
    switch (category) {
      case 'function': return <Code className="h-3 w-3" />;
      case 'pattern': return <Target className="h-3 w-3" />;
      case 'optimization': return <Zap className="h-3 w-3" />;
      case 'security': return <AlertCircle className="h-3 w-3" />;
      case 'library': return <BookOpen className="h-3 w-3" />;
      case 'template': return <Sparkles className="h-3 w-3" />;
    }
  };

  const getSourceBadgeColor = (source: CodeSuggestion['source']) => {
    switch (source) {
      case 'ai': return 'bg-purple-500';
      case 'pattern': return 'bg-blue-500';
      case 'community': return 'bg-green-500';
      case 'documentation': return 'bg-orange-500';
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Smart Context-Aware Code Suggestions
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="suggestions" className="flex-1">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="suggestions">Smart Suggestions</TabsTrigger>
            <TabsTrigger value="context">Context Analysis</TabsTrigger>
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
            <TabsTrigger value="analytics">Usage Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="suggestions" className="space-y-4">
            {/* Search and Filter Controls */}
            <div className="flex gap-4 items-center">
              <div className="flex-1">
                <Input
                  placeholder="Search suggestions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
              </div>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="function">Functions</SelectItem>
                  <SelectItem value="pattern">Patterns</SelectItem>
                  <SelectItem value="optimization">Optimization</SelectItem>
                  <SelectItem value="security">Security</SelectItem>
                  <SelectItem value="library">Libraries</SelectItem>
                  <SelectItem value="template">Templates</SelectItem>
                </SelectContent>
              </Select>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevance">Relevance</SelectItem>
                  <SelectItem value="confidence">Confidence</SelectItem>
                  <SelectItem value="usage">Usage</SelectItem>
                  <SelectItem value="recent">Recent</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={analyzeCurrentContext} disabled={isAnalyzing}>
                {isAnalyzing ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                {isAnalyzing ? 'Analyzing...' : 'Analyze Context'}
              </Button>
            </div>

            {/* Results Summary */}
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>Showing {filteredSuggestions.length} of {suggestions.length} suggestions</span>
              <Badge variant="outline" className="flex items-center gap-1">
                <Target className="h-3 w-3" />
                {contextAnalysis.language}
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1">
                <TrendingUp className="h-3 w-3" />
                {contextAnalysis.complexity} complexity
              </Badge>
            </div>

            {/* Suggestions List */}
            <ScrollArea className="h-96">
              <div className="space-y-4">
                {filteredSuggestions.map((suggestion) => (
                  <Card key={suggestion.id} className="p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          {getCategoryIcon(suggestion.category)}
                          <h3 className="font-medium">{suggestion.title}</h3>
                          <Badge 
                            variant="secondary" 
                            className={`text-white ${getSourceBadgeColor(suggestion.source)}`}
                          >
                            {suggestion.source}
                          </Badge>
                          <Badge variant="outline">
                            {Math.round(suggestion.confidence * 100)}% confidence
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">
                          {suggestion.description}
                        </p>
                        <div className="flex gap-2 mb-3">
                          {suggestion.tags.map((tag) => (
                            <Badge key={tag} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => applySuggestion(suggestion)}
                        >
                          <Copy className="h-3 w-3 mr-1" />
                          Apply
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => rateSuggestion(suggestion.id, 'up')}
                        >
                          <ThumbsUp className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => rateSuggestion(suggestion.id, 'down')}
                        >
                          <ThumbsDown className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>

                    {/* Code Preview */}
                    <div className="bg-muted rounded p-3 font-mono text-sm overflow-x-auto">
                      <pre className="whitespace-pre-wrap">{suggestion.code}</pre>
                    </div>

                    {/* Usage Stats */}
                    <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Star className="h-3 w-3" />
                        {suggestion.relevanceScore.toFixed(2)} relevance
                      </span>
                      <span className="flex items-center gap-1">
                        <TrendingUp className="h-3 w-3" />
                        Used {suggestion.usageCount} times
                      </span>
                      {suggestion.lastUsed && (
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          Last used {new Date(suggestion.lastUsed).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="context" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-4 w-4" />
                  Current Context Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-500">{contextAnalysis.language}</div>
                    <div className="text-sm text-muted-foreground">Language</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-500">{contextAnalysis.suggestions}</div>
                    <div className="text-sm text-muted-foreground">Suggestions</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-500">{contextAnalysis.variables.length}</div>
                    <div className="text-sm text-muted-foreground">Variables</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-500">{contextAnalysis.complexity}</div>
                    <div className="text-sm text-muted-foreground">Complexity</div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-sm font-medium">Variables in Scope</Label>
                    <div className="mt-2 space-y-1">
                      {contextAnalysis.variables.map((variable) => (
                        <Badge key={variable} variant="outline" className="mr-1">
                          {variable}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">Imported Modules</Label>
                    <div className="mt-2 space-y-1">
                      {contextAnalysis.imports.map((imp) => (
                        <Badge key={imp} variant="outline" className="mr-1">
                          {imp}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium">Detected Patterns</Label>
                    <div className="mt-2 space-y-1">
                      {contextAnalysis.patterns.map((pattern) => (
                        <Badge key={pattern} variant="outline" className="mr-1">
                          {pattern}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                <Button onClick={analyzeCurrentContext} className="w-full" disabled={isAnalyzing}>
                  {isAnalyzing ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : <Brain className="h-4 w-4 mr-2" />}
                  {isAnalyzing ? 'Analyzing Context...' : 'Re-analyze Current Context'}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="preferences" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  Suggestion Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Auto Suggestions</Label>
                      <p className="text-xs text-muted-foreground">Show suggestions automatically while typing</p>
                    </div>
                    <Switch
                      checked={preferences.enableAutoSuggestions}
                      onCheckedChange={(value) => updatePreference('enableAutoSuggestions', value)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Inline Preview</Label>
                      <p className="text-xs text-muted-foreground">Show code preview inline in editor</p>
                    </div>
                    <Switch
                      checked={preferences.showInlinePreview}
                      onCheckedChange={(value) => updatePreference('showInlinePreview', value)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Auto Apply</Label>
                      <p className="text-xs text-muted-foreground">Automatically apply high-confidence suggestions</p>
                    </div>
                    <Switch
                      checked={preferences.autoApplySuggestions}
                      onCheckedChange={(value) => updatePreference('autoApplySuggestions', value)}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label>Suggestion Frequency</Label>
                    <Select 
                      value={preferences.suggestionFrequency} 
                      onValueChange={(value: any) => updatePreference('suggestionFrequency', value)}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low - Minimal interruptions</SelectItem>
                        <SelectItem value="medium">Medium - Balanced suggestions</SelectItem>
                        <SelectItem value="high">High - Maximum assistance</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Minimum Confidence: {Math.round(preferences.minConfidence * 100)}%</Label>
                    <div className="mt-2">
                      <input
                        type="range"
                        min="0.5"
                        max="1"
                        step="0.05"
                        value={preferences.minConfidence}
                        onChange={(e) => updatePreference('minConfidence', parseFloat(e.target.value))}
                        className="w-full"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Most Used Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Functions</span>
                      <span>45%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Patterns</span>
                      <span>28%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Optimization</span>
                      <span>18%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Security</span>
                      <span>9%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Weekly Usage</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-500">127</div>
                    <div className="text-sm text-muted-foreground">Suggestions Applied</div>
                    <div className="text-xs text-green-500 mt-1">↑ 23% from last week</div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Accuracy Score</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-500">89%</div>
                    <div className="text-sm text-muted-foreground">Helpful Suggestions</div>
                    <div className="text-xs text-blue-500 mt-1">Based on your feedback</div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { action: 'Applied Error Boundary pattern', time: '2 minutes ago', type: 'success' },
                    { action: 'Rated Custom Hook suggestion', time: '5 minutes ago', type: 'feedback' },
                    { action: 'Copied optimization code', time: '12 minutes ago', type: 'copy' },
                    { action: 'Analyzed React component context', time: '1 hour ago', type: 'analysis' }
                  ].map((activity, index) => (
                    <div key={index} className="flex items-center gap-3 text-sm">
                      <div className={`w-2 h-2 rounded-full ${
                        activity.type === 'success' ? 'bg-green-500' :
                        activity.type === 'feedback' ? 'bg-blue-500' :
                        activity.type === 'copy' ? 'bg-orange-500' : 'bg-purple-500'
                      }`} />
                      <span className="flex-1">{activity.action}</span>
                      <span className="text-muted-foreground">{activity.time}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}