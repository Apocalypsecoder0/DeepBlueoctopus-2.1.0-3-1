import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { 
  Container,
  Play,
  Square,
  RefreshCw,
  Download,
  Upload,
  Monitor,
  Terminal,
  Settings,
  Trash2,
  Plus,
  FileText,
  Activity,
  Cpu,
  HardDrive,
  Network
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface DockerContainer {
  id: string;
  name: string;
  image: string;
  status: 'running' | 'stopped' | 'building' | 'error';
  ports: string[];
  created: string;
  cpuUsage: number;
  memoryUsage: number;
  networkIO: string;
}

interface DockerImage {
  id: string;
  repository: string;
  tag: string;
  size: string;
  created: string;
}

const mockContainers: DockerContainer[] = [
  {
    id: 'cont_1',
    name: 'deepblue-dev',
    image: 'node:18-alpine',
    status: 'running',
    ports: ['3000:3000', '5000:5000'],
    created: '2025-07-07T10:00:00Z',
    cpuUsage: 15.2,
    memoryUsage: 45.8,
    networkIO: '12.3 MB / 8.7 MB'
  },
  {
    id: 'cont_2',
    name: 'postgres-db',
    image: 'postgres:14',
    status: 'running',
    ports: ['5432:5432'],
    created: '2025-07-07T09:30:00Z',
    cpuUsage: 8.1,
    memoryUsage: 128.5,
    networkIO: '5.2 MB / 15.8 MB'
  },
  {
    id: 'cont_3',
    name: 'redis-cache',
    image: 'redis:7-alpine',
    status: 'stopped',
    ports: ['6379:6379'],
    created: '2025-07-07T08:15:00Z',
    cpuUsage: 0,
    memoryUsage: 0,
    networkIO: '0 MB / 0 MB'
  }
];

const mockImages: DockerImage[] = [
  {
    id: 'img_1',
    repository: 'node',
    tag: '18-alpine',
    size: '174 MB',
    created: '2025-07-01T00:00:00Z'
  },
  {
    id: 'img_2',
    repository: 'postgres',
    tag: '14',
    size: '374 MB',
    created: '2025-06-28T00:00:00Z'
  },
  {
    id: 'img_3',
    repository: 'redis',
    tag: '7-alpine',
    size: '28 MB',
    created: '2025-06-25T00:00:00Z'
  }
];

export default function DockerIntegration() {
  const [activeTab, setActiveTab] = useState('containers');
  const [containers, setContainers] = useState<DockerContainer[]>(mockContainers);
  const [images, setImages] = useState<DockerImage[]>(mockImages);
  const [selectedContainer, setSelectedContainer] = useState<string | null>(null);
  const [newImageName, setNewImageName] = useState('');
  const [newContainerName, setNewContainerName] = useState('');
  const [dockerStats, setDockerStats] = useState({
    totalContainers: 3,
    runningContainers: 2,
    totalImages: 3,
    diskUsage: '576 MB'
  });

  const { toast } = useToast();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'bg-green-500';
      case 'stopped': return 'bg-gray-500';
      case 'building': return 'bg-blue-500';
      case 'error': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const handleContainerAction = async (containerId: string, action: 'start' | 'stop' | 'restart' | 'remove') => {
    try {
      const container = containers.find(c => c.id === containerId);
      if (!container) return;

      if (action === 'start') {
        setContainers(prev => prev.map(c => 
          c.id === containerId ? { ...c, status: 'running' as const } : c
        ));
        toast({
          title: "Container Started",
          description: `Container ${container.name} is now running`
        });
      } else if (action === 'stop') {
        setContainers(prev => prev.map(c => 
          c.id === containerId ? { ...c, status: 'stopped' as const, cpuUsage: 0, memoryUsage: 0 } : c
        ));
        toast({
          title: "Container Stopped",
          description: `Container ${container.name} has been stopped`
        });
      } else if (action === 'restart') {
        setContainers(prev => prev.map(c => 
          c.id === containerId ? { ...c, status: 'building' as const } : c
        ));
        setTimeout(() => {
          setContainers(prev => prev.map(c => 
            c.id === containerId ? { ...c, status: 'running' as const } : c
          ));
        }, 2000);
        toast({
          title: "Container Restarting",
          description: `Container ${container.name} is being restarted`
        });
      } else if (action === 'remove') {
        setContainers(prev => prev.filter(c => c.id !== containerId));
        toast({
          title: "Container Removed",
          description: `Container ${container.name} has been removed`
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${action} container`,
        variant: "destructive"
      });
    }
  };

  const handleCreateContainer = async () => {
    if (!newContainerName.trim()) {
      toast({
        title: "Error",
        description: "Container name is required",
        variant: "destructive"
      });
      return;
    }

    const newContainer: DockerContainer = {
      id: `cont_${Date.now()}`,
      name: newContainerName,
      image: 'node:18-alpine',
      status: 'building',
      ports: ['3001:3000'],
      created: new Date().toISOString(),
      cpuUsage: 0,
      memoryUsage: 0,
      networkIO: '0 MB / 0 MB'
    };

    setContainers(prev => [...prev, newContainer]);
    setNewContainerName('');

    setTimeout(() => {
      setContainers(prev => prev.map(c => 
        c.id === newContainer.id ? { ...c, status: 'running' as const } : c
      ));
    }, 3000);

    toast({
      title: "Container Created",
      description: `Container ${newContainer.name} is being built`
    });
  };

  const handlePullImage = async () => {
    if (!newImageName.trim()) {
      toast({
        title: "Error",
        description: "Image name is required",
        variant: "destructive"
      });
      return;
    }

    const [repository, tag] = newImageName.split(':');
    const newImage: DockerImage = {
      id: `img_${Date.now()}`,
      repository: repository,
      tag: tag || 'latest',
      size: '128 MB',
      created: new Date().toISOString()
    };

    setImages(prev => [...prev, newImage]);
    setNewImageName('');

    toast({
      title: "Image Pulled",
      description: `Image ${newImage.repository}:${newImage.tag} has been pulled`
    });
  };

  return (
    <div className="w-full h-full bg-background overflow-hidden">
      <div className="border-b p-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-500/10 rounded-lg">
            <Container className="h-6 w-6 text-blue-500" />
          </div>
          <div>
            <h1 className="text-xl font-bold">Docker Integration</h1>
            <p className="text-sm text-muted-foreground">
              Container management and orchestration
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Badge variant="outline">
              {dockerStats.runningContainers}/{dockerStats.totalContainers} Running
            </Badge>
            <Badge variant="outline">
              {dockerStats.totalImages} Images
            </Badge>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
          <div className="border-b px-4">
            <TabsList className="grid grid-cols-4 w-[400px]">
              <TabsTrigger value="containers" className="flex items-center gap-2">
                <Container className="h-4 w-4" />
                Containers
              </TabsTrigger>
              <TabsTrigger value="images" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Images
              </TabsTrigger>
              <TabsTrigger value="stats" className="flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Stats
              </TabsTrigger>
              <TabsTrigger value="settings" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Settings
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="flex-1 overflow-hidden">
            <TabsContent value="containers" className="h-full p-4 m-0">
              <div className="space-y-4 h-full">
                <div className="flex items-center gap-4">
                  <Input
                    placeholder="Container name"
                    value={newContainerName}
                    onChange={(e) => setNewContainerName(e.target.value)}
                    className="max-w-xs"
                  />
                  <Button onClick={handleCreateContainer} className="flex items-center gap-2">
                    <Plus className="h-4 w-4" />
                    Create Container
                  </Button>
                  <Button variant="outline" className="flex items-center gap-2">
                    <RefreshCw className="h-4 w-4" />
                    Refresh
                  </Button>
                </div>

                <ScrollArea className="h-[calc(100%-5rem)]">
                  <div className="space-y-3">
                    {containers.map((container) => (
                      <Card key={container.id} className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`w-3 h-3 rounded-full ${getStatusColor(container.status)}`} />
                            <div>
                              <h3 className="font-semibold">{container.name}</h3>
                              <p className="text-sm text-muted-foreground">
                                {container.image} • {container.ports.join(', ')}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{container.status}</Badge>
                            <div className="flex gap-1">
                              {container.status === 'stopped' ? (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleContainerAction(container.id, 'start')}
                                >
                                  <Play className="h-4 w-4" />
                                </Button>
                              ) : (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleContainerAction(container.id, 'stop')}
                                >
                                  <Square className="h-4 w-4" />
                                </Button>
                              )}
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleContainerAction(container.id, 'restart')}
                              >
                                <RefreshCw className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleContainerAction(container.id, 'remove')}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                        {container.status === 'running' && (
                          <div className="mt-3 grid grid-cols-3 gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <Cpu className="h-4 w-4" />
                              CPU: {container.cpuUsage}%
                            </div>
                            <div className="flex items-center gap-2">
                              <HardDrive className="h-4 w-4" />
                              RAM: {container.memoryUsage} MB
                            </div>
                            <div className="flex items-center gap-2">
                              <Network className="h-4 w-4" />
                              I/O: {container.networkIO}
                            </div>
                          </div>
                        )}
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>

            <TabsContent value="images" className="h-full p-4 m-0">
              <div className="space-y-4 h-full">
                <div className="flex items-center gap-4">
                  <Input
                    placeholder="Image name (e.g., nginx:latest)"
                    value={newImageName}
                    onChange={(e) => setNewImageName(e.target.value)}
                    className="max-w-xs"
                  />
                  <Button onClick={handlePullImage} className="flex items-center gap-2">
                    <Download className="h-4 w-4" />
                    Pull Image
                  </Button>
                </div>

                <ScrollArea className="h-[calc(100%-5rem)]">
                  <div className="space-y-3">
                    {images.map((image) => (
                      <Card key={image.id} className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-semibold">{image.repository}:{image.tag}</h3>
                            <p className="text-sm text-muted-foreground">
                              Size: {image.size} • Created: {new Date(image.created).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">
                              <Terminal className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>

            <TabsContent value="stats" className="h-full p-4 m-0">
              <ScrollArea className="h-full">
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="p-4">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base">System Overview</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex justify-between">
                          <span>Total Containers:</span>
                          <span className="font-semibold">{dockerStats.totalContainers}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Running:</span>
                          <span className="font-semibold text-green-600">{dockerStats.runningContainers}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Total Images:</span>
                          <span className="font-semibold">{dockerStats.totalImages}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Disk Usage:</span>
                          <span className="font-semibold">{dockerStats.diskUsage}</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="p-4">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base">Resource Usage</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm">CPU Usage</span>
                            <span className="text-sm">23.3%</span>
                          </div>
                          <Progress value={23.3} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm">Memory Usage</span>
                            <span className="text-sm">174.3 MB</span>
                          </div>
                          <Progress value={35} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm">Network I/O</span>
                            <span className="text-sm">17.5 MB</span>
                          </div>
                          <Progress value={15} className="h-2" />
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <Alert>
                    <Monitor className="h-4 w-4" />
                    <AlertDescription>
                      Docker integration provides container orchestration, image management, and real-time monitoring.
                      Create development environments, manage dependencies, and deploy applications seamlessly.
                    </AlertDescription>
                  </Alert>
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="settings" className="h-full p-4 m-0">
              <ScrollArea className="h-full">
                <div className="space-y-6">
                  <Card className="p-4">
                    <CardHeader>
                      <CardTitle>Docker Configuration</CardTitle>
                      <CardDescription>Configure Docker daemon and registry settings</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Docker Host</label>
                        <Input placeholder="unix:///var/run/docker.sock" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Registry URL</label>
                        <Input placeholder="https://registry.docker.io" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Default Memory Limit</label>
                        <Input placeholder="512m" />
                      </div>
                      <Button className="w-full">Save Configuration</Button>
                    </CardContent>
                  </Card>
                </div>
              </ScrollArea>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}