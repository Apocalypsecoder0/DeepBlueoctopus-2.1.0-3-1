import { useState } from "react";
import { Play, Pause, Square, RotateCcw, ArrowRight, ArrowDown, ArrowUp, Circle, Bug, Settings, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Breakpoint {
  id: string;
  file: string;
  line: number;
  condition?: string;
  enabled: boolean;
}

interface Variable {
  name: string;
  value: string;
  type: string;
  scope: "local" | "global" | "closure";
}

interface CallStackFrame {
  id: string;
  name: string;
  file: string;
  line: number;
  column: number;
}

export default function DebugPanel() {
  const [isDebugging, setIsDebugging] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [breakpoints, setBreakpoints] = useState<Breakpoint[]>([
    { id: "1", file: "main.js", line: 10, enabled: true },
    { id: "2", file: "main.js", line: 25, condition: "x > 10", enabled: true },
    { id: "3", file: "utils.js", line: 5, enabled: false },
  ]);

  const [variables, setVariables] = useState<Variable[]>([
    { name: "x", value: "42", type: "number", scope: "local" },
    { name: "message", value: '"Hello World"', type: "string", scope: "local" },
    { name: "isActive", value: "true", type: "boolean", scope: "local" },
    { name: "config", value: "{theme: 'dark', ...}", type: "object", scope: "global" },
  ]);

  const [callStack, setCallStack] = useState<CallStackFrame[]>([
    { id: "1", name: "main", file: "main.js", line: 10, column: 5 },
    { id: "2", name: "initialize", file: "main.js", line: 25, column: 12 },
    { id: "3", name: "setupEditor", file: "editor.js", line: 8, column: 3 },
  ]);

  const [watchExpressions, setWatchExpressions] = useState<string[]>([
    "x + y",
    "config.theme",
    "users.length"
  ]);

  const [newWatch, setNewWatch] = useState("");

  const handleStartDebugging = () => {
    setIsDebugging(true);
    setIsPaused(false);
  };

  const handleStopDebugging = () => {
    setIsDebugging(false);
    setIsPaused(false);
  };

  const handlePauseResume = () => {
    setIsPaused(!isPaused);
  };

  const toggleBreakpoint = (id: string) => {
    setBreakpoints(prev => prev.map(bp => 
      bp.id === id ? { ...bp, enabled: !bp.enabled } : bp
    ));
  };

  const removeBreakpoint = (id: string) => {
    setBreakpoints(prev => prev.filter(bp => bp.id !== id));
  };

  const addWatchExpression = () => {
    if (newWatch.trim()) {
      setWatchExpressions(prev => [...prev, newWatch.trim()]);
      setNewWatch("");
    }
  };

  const removeWatchExpression = (index: number) => {
    setWatchExpressions(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="ide-sidebar w-80 border-r ide-border flex flex-col h-full">
      {/* Debug Controls */}
      <div className="p-3 border-b ide-border">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-medium text-sm">DEBUG CONSOLE</h3>
          <Button
            variant="ghost"
            size="sm"
            className="text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)] p-1"
          >
            <Settings className="h-3 w-3" />
          </Button>
        </div>

        {/* Debug Action Buttons */}
        <div className="flex items-center space-x-1">
          {!isDebugging ? (
            <Button
              onClick={handleStartDebugging}
              size="sm"
              className="bg-[var(--ide-success)] text-[var(--ide-bg)] hover:bg-green-400 px-3"
            >
              <Play className="h-3 w-3 mr-1" />
              Start
            </Button>
          ) : (
            <>
              <Button
                onClick={handlePauseResume}
                variant="ghost"
                size="sm"
                className="text-[var(--ide-text)] hover:bg-[var(--ide-panel)] p-2"
                title={isPaused ? "Continue" : "Pause"}
              >
                {isPaused ? <Play className="h-3 w-3" /> : <Pause className="h-3 w-3" />}
              </Button>
              
              <Button
                onClick={handleStopDebugging}
                variant="ghost"
                size="sm"
                className="text-[var(--ide-text)] hover:bg-[var(--ide-panel)] p-2"
                title="Stop"
              >
                <Square className="h-3 w-3" />
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                className="text-[var(--ide-text)] hover:bg-[var(--ide-panel)] p-2"
                title="Restart"
              >
                <RotateCcw className="h-3 w-3" />
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                className="text-[var(--ide-text)] hover:bg-[var(--ide-panel)] p-2"
                title="Step Over"
                disabled={!isPaused}
              >
                <ArrowRight className="h-3 w-3" />
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                className="text-[var(--ide-text)] hover:bg-[var(--ide-panel)] p-2"
                title="Step Into"
                disabled={!isPaused}
              >
                <ArrowDown className="h-3 w-3" />
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                className="text-[var(--ide-text)] hover:bg-[var(--ide-panel)] p-2"
                title="Step Out"
                disabled={!isPaused}
              >
                <ArrowUp className="h-3 w-3" />
              </Button>
            </>
          )}
        </div>

        {isDebugging && (
          <div className="mt-2 flex items-center space-x-2">
            <Badge variant={isPaused ? "destructive" : "default"} className="text-xs">
              {isPaused ? "Paused" : "Running"}
            </Badge>
            {isPaused && (
              <span className="text-xs text-[var(--ide-text-secondary)]">
                at main.js:10
              </span>
            )}
          </div>
        )}
      </div>

      {/* Debug Information Tabs */}
      <div className="flex-1 overflow-hidden">
        <Tabs defaultValue="variables" className="h-full flex flex-col">
          <TabsList className="border-b ide-border w-full justify-start rounded-none bg-transparent p-0 h-auto">
            <TabsTrigger 
              value="variables" 
              className="data-[state=active]:bg-[var(--ide-panel)] text-xs px-3 py-2"
            >
              Variables
            </TabsTrigger>
            <TabsTrigger 
              value="watch" 
              className="data-[state=active]:bg-[var(--ide-panel)] text-xs px-3 py-2"
            >
              Watch
            </TabsTrigger>
            <TabsTrigger 
              value="callstack" 
              className="data-[state=active]:bg-[var(--ide-panel)] text-xs px-3 py-2"
            >
              Call Stack
            </TabsTrigger>
            <TabsTrigger 
              value="breakpoints" 
              className="data-[state=active]:bg-[var(--ide-panel)] text-xs px-3 py-2"
            >
              Breakpoints
            </TabsTrigger>
          </TabsList>

          <TabsContent value="variables" className="flex-1 p-3 m-0 overflow-hidden">
            <ScrollArea className="h-full">
              <div className="space-y-2">
                {variables.map((variable, index) => (
                  <div key={index} className="p-2 rounded hover:bg-[var(--ide-panel)] transition-colors">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-sm text-[var(--ide-text)]">{variable.name}</span>
                      <Badge variant="outline" className="text-xs">
                        {variable.scope}
                      </Badge>
                    </div>
                    <div className="text-xs text-[var(--ide-text-secondary)] font-mono mt-1">
                      {variable.value} <span className="text-[var(--ide-accent)]">({variable.type})</span>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="watch" className="flex-1 p-3 m-0 overflow-hidden">
            <div className="space-y-3">
              <div className="flex space-x-2">
                <Input
                  placeholder="Add expression to watch"
                  value={newWatch}
                  onChange={(e) => setNewWatch(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addWatchExpression()}
                  className="text-xs bg-[var(--ide-panel)] border-[var(--ide-border)]"
                />
                <Button
                  onClick={addWatchExpression}
                  size="sm"
                  variant="ghost"
                  className="px-2"
                >
                  <Plus className="h-3 w-3" />
                </Button>
              </div>
              
              <ScrollArea className="h-[200px]">
                <div className="space-y-2">
                  {watchExpressions.map((expr, index) => (
                    <div key={index} className="flex items-center justify-between p-2 rounded hover:bg-[var(--ide-panel)]">
                      <span className="font-mono text-sm">{expr}</span>
                      <Button
                        onClick={() => removeWatchExpression(index)}
                        variant="ghost"
                        size="sm"
                        className="p-1 h-auto"
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="callstack" className="flex-1 p-3 m-0 overflow-hidden">
            <ScrollArea className="h-full">
              <div className="space-y-2">
                {callStack.map((frame, index) => (
                  <div 
                    key={frame.id} 
                    className="p-2 rounded cursor-pointer hover:bg-[var(--ide-panel)] transition-colors"
                  >
                    <div className="font-mono text-sm text-[var(--ide-text)]">{frame.name}</div>
                    <div className="text-xs text-[var(--ide-text-secondary)]">
                      {frame.file}:{frame.line}:{frame.column}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="breakpoints" className="flex-1 p-3 m-0 overflow-hidden">
            <ScrollArea className="h-full">
              <div className="space-y-2">
                {breakpoints.map((breakpoint) => (
                  <div 
                    key={breakpoint.id}
                    className="flex items-center justify-between p-2 rounded hover:bg-[var(--ide-panel)] transition-colors"
                  >
                    <div className="flex items-center space-x-2">
                      <Button
                        onClick={() => toggleBreakpoint(breakpoint.id)}
                        variant="ghost"
                        size="sm"
                        className="p-1"
                      >
                        <Circle 
                          className={`h-3 w-3 ${
                            breakpoint.enabled ? 'fill-red-500 text-red-500' : 'text-[var(--ide-text-secondary)]'
                          }`} 
                        />
                      </Button>
                      <div>
                        <div className="text-sm font-mono">{breakpoint.file}:{breakpoint.line}</div>
                        {breakpoint.condition && (
                          <div className="text-xs text-[var(--ide-text-secondary)]">
                            Condition: {breakpoint.condition}
                          </div>
                        )}
                      </div>
                    </div>
                    <Button
                      onClick={() => removeBreakpoint(breakpoint.id)}
                      variant="ghost"
                      size="sm"
                      className="p-1"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}