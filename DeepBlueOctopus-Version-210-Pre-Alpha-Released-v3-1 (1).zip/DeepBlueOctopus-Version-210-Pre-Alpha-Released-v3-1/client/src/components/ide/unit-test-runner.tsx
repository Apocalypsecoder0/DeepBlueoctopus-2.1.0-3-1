import React, { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  TestTube, Play, Square, RotateCcw, CheckCircle, 
  XCircle, AlertTriangle, Clock, FileText, Settings,
  BarChart3, Download, Upload, Filter, Search
} from "lucide-react";

interface UnitTestRunnerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TestCase {
  id: string;
  name: string;
  description: string;
  status: 'pending' | 'running' | 'passed' | 'failed' | 'skipped';
  duration: number;
  error?: string;
  file: string;
  line: number;
  framework: 'jest' | 'vitest' | 'mocha' | 'jasmine' | 'cypress' | 'playwright';
  tags: string[];
}

interface TestSuite {
  id: string;
  name: string;
  file: string;
  tests: TestCase[];
  status: 'pending' | 'running' | 'completed';
  totalTests: number;
  passedTests: number;
  failedTests: number;
  skippedTests: number;
  duration: number;
  coverage?: {
    lines: number;
    functions: number;
    branches: number;
    statements: number;
  };
}

interface TestRun {
  id: string;
  startTime: Date;
  endTime?: Date;
  status: 'running' | 'completed' | 'failed';
  totalSuites: number;
  totalTests: number;
  passedTests: number;
  failedTests: number;
  skippedTests: number;
  duration: number;
  coverage: {
    lines: number;
    functions: number;
    branches: number;
    statements: number;
  };
}

export default function UnitTestRunner({ isOpen, onClose }: UnitTestRunnerProps) {
  const [testSuites, setTestSuites] = useState<TestSuite[]>([
    {
      id: 'suite-1',
      name: 'User Service Tests',
      file: '/src/services/user.service.test.ts',
      tests: [
        {
          id: 'test-1',
          name: 'should create user successfully',
          description: 'Tests user creation with valid data',
          status: 'passed',
          duration: 45,
          file: '/src/services/user.service.test.ts',
          line: 12,
          framework: 'jest',
          tags: ['unit', 'service']
        },
        {
          id: 'test-2',
          name: 'should validate email format',
          description: 'Tests email validation logic',
          status: 'failed',
          duration: 23,
          error: 'AssertionError: Expected valid email but got invalid format',
          file: '/src/services/user.service.test.ts',
          line: 28,
          framework: 'jest',
          tags: ['unit', 'validation']
        },
        {
          id: 'test-3',
          name: 'should handle duplicate users',
          description: 'Tests duplicate user handling',
          status: 'passed',
          duration: 67,
          file: '/src/services/user.service.test.ts',
          line: 45,
          framework: 'jest',
          tags: ['unit', 'error-handling']
        }
      ],
      status: 'completed',
      totalTests: 3,
      passedTests: 2,
      failedTests: 1,
      skippedTests: 0,
      duration: 135,
      coverage: {
        lines: 87.5,
        functions: 92.3,
        branches: 78.9,
        statements: 89.1
      }
    },
    {
      id: 'suite-2',
      name: 'API Integration Tests',
      file: '/src/api/integration.test.ts',
      tests: [
        {
          id: 'test-4',
          name: 'should authenticate user',
          description: 'Tests API authentication endpoint',
          status: 'passed',
          duration: 234,
          file: '/src/api/integration.test.ts',
          line: 15,
          framework: 'jest',
          tags: ['integration', 'auth']
        },
        {
          id: 'test-5',
          name: 'should return user profile',
          description: 'Tests profile retrieval API',
          status: 'passed',
          duration: 156,
          file: '/src/api/integration.test.ts',
          line: 32,
          framework: 'jest',
          tags: ['integration', 'profile']
        },
        {
          id: 'test-6',
          name: 'should handle rate limiting',
          description: 'Tests API rate limiting behavior',
          status: 'skipped',
          duration: 0,
          file: '/src/api/integration.test.ts',
          line: 48,
          framework: 'jest',
          tags: ['integration', 'rate-limit']
        }
      ],
      status: 'completed',
      totalTests: 3,
      passedTests: 2,
      failedTests: 0,
      skippedTests: 1,
      duration: 390,
      coverage: {
        lines: 95.2,
        functions: 88.7,
        branches: 82.4,
        statements: 93.6
      }
    }
  ]);

  const [currentRun, setCurrentRun] = useState<TestRun | null>(null);
  const [selectedSuite, setSelectedSuite] = useState<TestSuite | null>(null);
  const [filterFramework, setFilterFramework] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isRunning, setIsRunning] = useState(false);

  const { files } = useIDEState();
  const { toast } = useToast();

  const runAllTests = useCallback(async () => {
    setIsRunning(true);
    
    const testRun: TestRun = {
      id: `run-${Date.now()}`,
      startTime: new Date(),
      status: 'running',
      totalSuites: testSuites.length,
      totalTests: testSuites.reduce((sum, suite) => sum + suite.totalTests, 0),
      passedTests: 0,
      failedTests: 0,
      skippedTests: 0,
      duration: 0,
      coverage: {
        lines: 0,
        functions: 0,
        branches: 0,
        statements: 0
      }
    };

    setCurrentRun(testRun);

    // Simulate running tests
    for (const suite of testSuites) {
      setTestSuites(prev => prev.map(s => 
        s.id === suite.id ? { ...s, status: 'running' as const } : s
      ));

      for (const test of suite.tests) {
        // Simulate test execution
        await new Promise(resolve => setTimeout(resolve, 100));
        
        setTestSuites(prev => prev.map(s => 
          s.id === suite.id ? {
            ...s,
            tests: s.tests.map(t => 
              t.id === test.id ? { ...t, status: 'running' as const } : t
            )
          } : s
        ));

        // Simulate test completion
        await new Promise(resolve => setTimeout(resolve, Math.random() * 500 + 200));
        
        const finalStatus = Math.random() > 0.8 ? 'failed' : 'passed';
        
        setTestSuites(prev => prev.map(s => 
          s.id === suite.id ? {
            ...s,
            tests: s.tests.map(t => 
              t.id === test.id ? { 
                ...t, 
                status: finalStatus as any,
                duration: Math.floor(Math.random() * 200 + 50)
              } : t
            )
          } : s
        ));
      }

      setTestSuites(prev => prev.map(s => 
        s.id === suite.id ? { ...s, status: 'completed' as const } : s
      ));
    }

    // Calculate final results
    const totalTests = testSuites.reduce((sum, suite) => sum + suite.totalTests, 0);
    const passedTests = testSuites.reduce((sum, suite) => sum + suite.passedTests, 0);
    const failedTests = testSuites.reduce((sum, suite) => sum + suite.failedTests, 0);
    const skippedTests = testSuites.reduce((sum, suite) => sum + suite.skippedTests, 0);

    const finalRun: TestRun = {
      ...testRun,
      endTime: new Date(),
      status: 'completed',
      passedTests,
      failedTests,
      skippedTests,
      duration: Date.now() - testRun.startTime.getTime(),
      coverage: {
        lines: 91.2,
        functions: 88.5,
        branches: 79.3,
        statements: 89.8
      }
    };

    setCurrentRun(finalRun);
    setIsRunning(false);

    toast({
      title: "Test run completed",
      description: `${passedTests}/${totalTests} tests passed`,
      variant: failedTests > 0 ? "destructive" : "default",
    });
  }, [testSuites, toast]);

  const runSingleSuite = useCallback(async (suiteId: string) => {
    const suite = testSuites.find(s => s.id === suiteId);
    if (!suite) return;

    setIsRunning(true);
    
    setTestSuites(prev => prev.map(s => 
      s.id === suiteId ? { ...s, status: 'running' as const } : s
    ));

    for (const test of suite.tests) {
      await new Promise(resolve => setTimeout(resolve, Math.random() * 300 + 100));
      
      const finalStatus = Math.random() > 0.7 ? 'failed' : 'passed';
      
      setTestSuites(prev => prev.map(s => 
        s.id === suiteId ? {
          ...s,
          tests: s.tests.map(t => 
            t.id === test.id ? { 
              ...t, 
              status: finalStatus as any,
              duration: Math.floor(Math.random() * 200 + 50)
            } : t
          )
        } : s
      ));
    }

    setTestSuites(prev => prev.map(s => 
      s.id === suiteId ? { ...s, status: 'completed' as const } : s
    ));

    setIsRunning(false);

    toast({
      title: "Suite completed",
      description: `${suite.name} tests finished`,
    });
  }, [testSuites, toast]);

  const runSingleTest = useCallback(async (testId: string) => {
    setTestSuites(prev => prev.map(suite => ({
      ...suite,
      tests: suite.tests.map(test => 
        test.id === testId ? { ...test, status: 'running' as const } : test
      )
    })));

    await new Promise(resolve => setTimeout(resolve, Math.random() * 500 + 200));
    
    const finalStatus = Math.random() > 0.8 ? 'failed' : 'passed';
    
    setTestSuites(prev => prev.map(suite => ({
      ...suite,
      tests: suite.tests.map(test => 
        test.id === testId ? { 
          ...test, 
          status: finalStatus as any,
          duration: Math.floor(Math.random() * 200 + 50)
        } : test
      )
    })));

    toast({
      title: "Test completed",
      description: `Test ${finalStatus}`,
      variant: finalStatus === 'failed' ? "destructive" : "default",
    });
  }, [toast]);

  const generateTestReport = useCallback(() => {
    const reportData = {
      timestamp: new Date().toISOString(),
      testRun: currentRun,
      suites: testSuites,
      summary: {
        totalSuites: testSuites.length,
        totalTests: testSuites.reduce((sum, s) => sum + s.totalTests, 0),
        passedTests: testSuites.reduce((sum, s) => sum + s.passedTests, 0),
        failedTests: testSuites.reduce((sum, s) => sum + s.failedTests, 0),
        skippedTests: testSuites.reduce((sum, s) => sum + s.skippedTests, 0),
        totalDuration: testSuites.reduce((sum, s) => sum + s.duration, 0),
        avgCoverage: {
          lines: testSuites.reduce((sum, s) => sum + (s.coverage?.lines || 0), 0) / testSuites.length,
          functions: testSuites.reduce((sum, s) => sum + (s.coverage?.functions || 0), 0) / testSuites.length,
          branches: testSuites.reduce((sum, s) => sum + (s.coverage?.branches || 0), 0) / testSuites.length,
          statements: testSuites.reduce((sum, s) => sum + (s.coverage?.statements || 0), 0) / testSuites.length
        }
      }
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `test-report-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Report exported",
      description: "Test report has been downloaded",
    });
  }, [currentRun, testSuites, toast]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'running':
        return <Clock className="w-4 h-4 text-yellow-500 animate-spin" />;
      case 'skipped':
        return <AlertTriangle className="w-4 h-4 text-gray-500" />;
      default:
        return <TestTube className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed':
        return 'text-green-600 bg-green-50 border-green-200';
      case 'failed':
        return 'text-red-600 bg-red-50 border-red-200';
      case 'running':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'skipped':
        return 'text-gray-600 bg-gray-50 border-gray-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const filteredSuites = testSuites.filter(suite => {
    const matchesSearch = suite.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         suite.file.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFramework = filterFramework === 'all' || 
                           suite.tests.some(test => test.framework === filterFramework);
    const matchesStatus = filterStatus === 'all' || suite.status === filterStatus;
    
    return matchesSearch && matchesFramework && matchesStatus;
  });

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <TestTube className="w-5 h-5" />
            Unit Test Runner
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex gap-6">
          {/* Test Control Panel */}
          <div className="w-80 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Test Control</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button 
                    onClick={runAllTests}
                    disabled={isRunning}
                    className="w-full"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    {isRunning ? 'Running Tests...' : 'Run All Tests'}
                  </Button>
                  
                  <div className="flex gap-2">
                    <Button variant="outline" className="flex-1" disabled={isRunning}>
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Reset
                    </Button>
                    <Button variant="outline" onClick={generateTestReport}>
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Test Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Total Suites</span>
                    <span>{testSuites.length}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Total Tests</span>
                    <span>{testSuites.reduce((sum, s) => sum + s.totalTests, 0)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-green-600">Passed</span>
                    <span>{testSuites.reduce((sum, s) => sum + s.passedTests, 0)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-red-600">Failed</span>
                    <span>{testSuites.reduce((sum, s) => sum + s.failedTests, 0)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Skipped</span>
                    <span>{testSuites.reduce((sum, s) => sum + s.skippedTests, 0)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Coverage Report */}
            <Card>
              <CardHeader>
                <CardTitle>Coverage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { label: 'Lines', value: 91.2 },
                    { label: 'Functions', value: 88.5 },
                    { label: 'Branches', value: 79.3 },
                    { label: 'Statements', value: 89.8 }
                  ].map((item) => (
                    <div key={item.label} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>{item.label}</span>
                        <span>{item.value}%</span>
                      </div>
                      <Progress value={item.value} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <Tabs defaultValue="suites">
              <TabsList>
                <TabsTrigger value="suites">Test Suites</TabsTrigger>
                <TabsTrigger value="results">Results</TabsTrigger>
                <TabsTrigger value="coverage">Coverage</TabsTrigger>
              </TabsList>

              <TabsContent value="suites" className="space-y-4">
                {/* Filters */}
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Search className="w-4 h-4" />
                    <Input
                      placeholder="Search tests..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-64"
                    />
                  </div>
                  <select
                    value={filterFramework}
                    onChange={(e) => setFilterFramework(e.target.value)}
                    className="px-3 py-2 border rounded"
                  >
                    <option value="all">All Frameworks</option>
                    <option value="jest">Jest</option>
                    <option value="vitest">Vitest</option>
                    <option value="mocha">Mocha</option>
                    <option value="cypress">Cypress</option>
                  </select>
                  <select
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value)}
                    className="px-3 py-2 border rounded"
                  >
                    <option value="all">All Status</option>
                    <option value="completed">Completed</option>
                    <option value="running">Running</option>
                    <option value="pending">Pending</option>
                  </select>
                </div>

                <ScrollArea className="h-[500px]">
                  <div className="space-y-4">
                    {filteredSuites.map((suite) => (
                      <Card key={suite.id}>
                        <CardHeader>
                          <div className="flex items-center justify-between">
                            <div>
                              <CardTitle className="flex items-center gap-2">
                                {getStatusIcon(suite.status)}
                                {suite.name}
                              </CardTitle>
                              <p className="text-sm text-gray-500">{suite.file}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">
                                {suite.passedTests}/{suite.totalTests} passed
                              </Badge>
                              <Button
                                size="sm"
                                onClick={() => runSingleSuite(suite.id)}
                                disabled={isRunning}
                              >
                                <Play className="w-3 h-3 mr-1" />
                                Run
                              </Button>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {suite.tests.map((test) => (
                              <div
                                key={test.id}
                                className={`p-3 border rounded ${getStatusColor(test.status)}`}
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    {getStatusIcon(test.status)}
                                    <span className="font-medium">{test.name}</span>
                                    <Badge variant="outline" className="text-xs">
                                      {test.framework}
                                    </Badge>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs text-gray-500">
                                      {test.duration}ms
                                    </span>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => runSingleTest(test.id)}
                                      disabled={isRunning}
                                    >
                                      <Play className="w-3 h-3" />
                                    </Button>
                                  </div>
                                </div>
                                <p className="text-sm text-gray-600 mt-1">
                                  {test.description}
                                </p>
                                {test.error && (
                                  <div className="mt-2 p-2 bg-red-100 border border-red-200 rounded text-xs">
                                    <pre className="whitespace-pre-wrap">{test.error}</pre>
                                  </div>
                                )}
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {test.tags.map((tag) => (
                                    <Badge key={tag} variant="secondary" className="text-xs">
                                      {tag}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="results" className="space-y-4">
                {currentRun ? (
                  <Card>
                    <CardHeader>
                      <CardTitle>Test Run Results</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-600">
                            {currentRun.passedTests}
                          </div>
                          <div className="text-sm text-gray-500">Passed</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-red-600">
                            {currentRun.failedTests}
                          </div>
                          <div className="text-sm text-gray-500">Failed</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-gray-600">
                            {currentRun.skippedTests}
                          </div>
                          <div className="text-sm text-gray-500">Skipped</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold">
                            {Math.round(currentRun.duration / 1000)}s
                          </div>
                          <div className="text-sm text-gray-500">Duration</div>
                        </div>
                      </div>
                      
                      <div className="text-sm text-gray-500">
                        <div>Started: {currentRun.startTime.toLocaleString()}</div>
                        {currentRun.endTime && (
                          <div>Completed: {currentRun.endTime.toLocaleString()}</div>
                        )}
                        <div>Status: {currentRun.status}</div>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    No test run data available. Run tests to see results.
                  </div>
                )}
              </TabsContent>

              <TabsContent value="coverage" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Code Coverage Report</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h4 className="font-medium">Overall Coverage</h4>
                        {[
                          { label: 'Lines', value: 91.2, color: 'bg-green-500' },
                          { label: 'Functions', value: 88.5, color: 'bg-blue-500' },
                          { label: 'Branches', value: 79.3, color: 'bg-yellow-500' },
                          { label: 'Statements', value: 89.8, color: 'bg-purple-500' }
                        ].map((item) => (
                          <div key={item.label} className="space-y-2">
                            <div className="flex justify-between">
                              <span>{item.label}</span>
                              <span className="font-mono">{item.value}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div
                                className={`${item.color} h-2 rounded-full transition-all`}
                                style={{ width: `${item.value}%` }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                      
                      <div className="space-y-4">
                        <h4 className="font-medium">File Coverage</h4>
                        <div className="text-sm space-y-2">
                          {testSuites.map((suite) => (
                            <div key={suite.id} className="flex justify-between">
                              <span className="truncate">{suite.file}</span>
                              <span className="font-mono">
                                {suite.coverage?.lines.toFixed(1)}%
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}