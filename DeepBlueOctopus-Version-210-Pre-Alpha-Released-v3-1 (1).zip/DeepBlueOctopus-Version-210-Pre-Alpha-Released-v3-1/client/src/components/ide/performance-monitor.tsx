import React, { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { 
  Activity, Cpu, HardDrive, Wifi, Clock, 
  TrendingUp, TrendingDown, AlertCircle, 
  CheckCircle, Zap, Monitor, Download,
  RefreshCw, Settings, BarChart3, LineChart
} from "lucide-react";

interface PerformanceMonitorProps {
  isOpen: boolean;
  onClose: () => void;
}

interface PerformanceMetric {
  timestamp: number;
  cpu: number;
  memory: number;
  network: number;
  fps: number;
  loadTime: number;
  bundleSize: number;
}

interface ComponentMetric {
  name: string;
  renderTime: number;
  memoryUsage: number;
  rerenderCount: number;
  lastUpdate: Date;
}

interface NetworkRequest {
  id: string;
  url: string;
  method: string;
  status: number;
  duration: number;
  size: number;
  timestamp: Date;
  type: 'api' | 'asset' | 'chunk';
}

export default function PerformanceMonitor({ isOpen, onClose }: PerformanceMonitorProps) {
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [refreshInterval, setRefreshInterval] = useState([1000]);
  const [metrics, setMetrics] = useState<PerformanceMetric[]>([]);
  const [componentMetrics, setComponentMetrics] = useState<ComponentMetric[]>([]);
  const [networkRequests, setNetworkRequests] = useState<NetworkRequest[]>([]);
  const [currentMetrics, setCurrentMetrics] = useState<PerformanceMetric>({
    timestamp: Date.now(),
    cpu: 0,
    memory: 0,
    network: 0,
    fps: 60,
    loadTime: 0,
    bundleSize: 0
  });

  const intervalRef = useRef<NodeJS.Timeout>();
  const frameRef = useRef<number>();
  const lastFrameTime = useRef<number>(performance.now());
  const frameCount = useRef<number>(0);

  useEffect(() => {
    if (isMonitoring) {
      startMonitoring();
    } else {
      stopMonitoring();
    }

    return () => stopMonitoring();
  }, [isMonitoring, refreshInterval]);

  useEffect(() => {
    // Initialize with some sample data
    initializeSampleData();
    
    // Monitor navigation timing
    if (performance.timing) {
      const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
      setCurrentMetrics(prev => ({ ...prev, loadTime }));
    }

    // Monitor bundle size (approximate)
    estimateBundleSize();

    // Start FPS monitoring
    startFPSMonitoring();

    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
    };
  }, []);

  const initializeSampleData = () => {
    const sampleComponents: ComponentMetric[] = [
      {
        name: 'CodeEditor',
        renderTime: 15.2,
        memoryUsage: 2.4,
        rerenderCount: 12,
        lastUpdate: new Date(Date.now() - 30000)
      },
      {
        name: 'FileExplorer',
        renderTime: 8.7,
        memoryUsage: 1.1,
        rerenderCount: 5,
        lastUpdate: new Date(Date.now() - 60000)
      },
      {
        name: 'Terminal',
        renderTime: 12.1,
        memoryUsage: 1.8,
        rerenderCount: 8,
        lastUpdate: new Date(Date.now() - 45000)
      },
      {
        name: 'TopMenuBar',
        renderTime: 3.4,
        memoryUsage: 0.5,
        rerenderCount: 3,
        lastUpdate: new Date(Date.now() - 120000)
      }
    ];

    const sampleRequests: NetworkRequest[] = [
      {
        id: '1',
        url: '/api/files',
        method: 'GET',
        status: 200,
        duration: 145,
        size: 2048,
        timestamp: new Date(Date.now() - 10000),
        type: 'api'
      },
      {
        id: '2',
        url: '/api/projects',
        method: 'GET',
        status: 200,
        duration: 89,
        size: 1024,
        timestamp: new Date(Date.now() - 15000),
        type: 'api'
      },
      {
        id: '3',
        url: '/assets/monaco-editor.js',
        method: 'GET',
        status: 200,
        duration: 234,
        size: 102400,
        timestamp: new Date(Date.now() - 30000),
        type: 'chunk'
      }
    ];

    setComponentMetrics(sampleComponents);
    setNetworkRequests(sampleRequests);
  };

  const estimateBundleSize = async () => {
    try {
      // Rough estimation based on loaded scripts
      const scripts = Array.from(document.querySelectorAll('script[src]'));
      let totalSize = 0;
      
      for (const script of scripts) {
        try {
          const response = await fetch(script.src, { method: 'HEAD' });
          const size = parseInt(response.headers.get('content-length') || '0');
          totalSize += size;
        } catch (e) {
          // Fallback estimation
          totalSize += 50000; // 50KB average
        }
      }
      
      setCurrentMetrics(prev => ({ ...prev, bundleSize: totalSize }));
    } catch (error) {
      console.error('Error estimating bundle size:', error);
    }
  };

  const startFPSMonitoring = () => {
    const measureFPS = (currentTime: number) => {
      frameCount.current++;
      
      if (currentTime - lastFrameTime.current >= 1000) {
        const fps = Math.round((frameCount.current * 1000) / (currentTime - lastFrameTime.current));
        setCurrentMetrics(prev => ({ ...prev, fps }));
        
        frameCount.current = 0;
        lastFrameTime.current = currentTime;
      }
      
      frameRef.current = requestAnimationFrame(measureFPS);
    };
    
    frameRef.current = requestAnimationFrame(measureFPS);
  };

  const startMonitoring = () => {
    intervalRef.current = setInterval(() => {
      collectMetrics();
    }, refreshInterval[0]);
  };

  const stopMonitoring = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
  };

  const collectMetrics = () => {
    const timestamp = Date.now();
    
    // Simulate performance metrics (in a real app, these would come from actual measurements)
    const newMetric: PerformanceMetric = {
      timestamp,
      cpu: Math.random() * 100,
      memory: getCurrentMemoryUsage(),
      network: Math.random() * 100,
      fps: currentMetrics.fps,
      loadTime: currentMetrics.loadTime,
      bundleSize: currentMetrics.bundleSize
    };

    setMetrics(prev => {
      const updated = [...prev, newMetric].slice(-50); // Keep last 50 measurements
      return updated;
    });

    setCurrentMetrics(newMetric);
  };

  const getCurrentMemoryUsage = (): number => {
    if ('memory' in performance) {
      const memory = (performance as any).memory;
      return Math.round((memory.usedJSHeapSize / memory.totalJSHeapSize) * 100);
    }
    return Math.random() * 50; // Fallback simulation
  };

  const getPerformanceScore = (): number => {
    const { cpu, memory, fps } = currentMetrics;
    const cpuScore = Math.max(0, 100 - cpu);
    const memoryScore = Math.max(0, 100 - memory);
    const fpsScore = Math.min(100, (fps / 60) * 100);
    
    return Math.round((cpuScore + memoryScore + fpsScore) / 3);
  };

  const getPerformanceLevel = (score: number): { level: string; color: string; icon: React.ReactNode } => {
    if (score >= 80) return { level: 'Excellent', color: 'text-green-500', icon: <CheckCircle className="h-4 w-4" /> };
    if (score >= 60) return { level: 'Good', color: 'text-blue-500', icon: <Activity className="h-4 w-4" /> };
    if (score >= 40) return { level: 'Fair', color: 'text-yellow-500', icon: <AlertCircle className="h-4 w-4" /> };
    return { level: 'Poor', color: 'text-red-500', icon: <TrendingDown className="h-4 w-4" /> };
  };

  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDuration = (ms: number): string => {
    if (ms < 1000) return `${ms}ms`;
    return `${(ms / 1000).toFixed(1)}s`;
  };

  const exportMetrics = () => {
    const exportData = {
      metrics,
      componentMetrics,
      networkRequests,
      timestamp: new Date().toISOString(),
      performance: {
        score: getPerformanceScore(),
        ...currentMetrics
      }
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `performance-report-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const score = getPerformanceScore();
  const performanceLevel = getPerformanceLevel(score);

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Real-time Performance Monitoring
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="overview" className="flex-1">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="realtime">Real-time</TabsTrigger>
            <TabsTrigger value="components">Components</TabsTrigger>
            <TabsTrigger value="network">Network</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Performance Score</CardTitle>
                  {performanceLevel.icon}
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{score}</div>
                  <p className={`text-xs ${performanceLevel.color}`}>
                    {performanceLevel.level}
                  </p>
                  <Progress value={score} className="mt-2" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">FPS</CardTitle>
                  <Monitor className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{currentMetrics.fps}</div>
                  <p className="text-xs text-muted-foreground">
                    {currentMetrics.fps >= 50 ? 'Smooth' : currentMetrics.fps >= 30 ? 'Acceptable' : 'Choppy'}
                  </p>
                  <Progress value={(currentMetrics.fps / 60) * 100} className="mt-2" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Memory Usage</CardTitle>
                  <HardDrive className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{currentMetrics.memory}%</div>
                  <p className="text-xs text-muted-foreground">
                    {currentMetrics.memory < 70 ? 'Good' : currentMetrics.memory < 90 ? 'High' : 'Critical'}
                  </p>
                  <Progress value={currentMetrics.memory} className="mt-2" />
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Load Performance</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Page Load Time</span>
                    <span className="text-sm font-mono">{formatDuration(currentMetrics.loadTime)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Bundle Size</span>
                    <span className="text-sm font-mono">{formatBytes(currentMetrics.bundleSize)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">First Contentful Paint</span>
                    <span className="text-sm font-mono">1.2s</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Time to Interactive</span>
                    <span className="text-sm font-mono">2.1s</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">System Resources</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">CPU Usage</span>
                      <span className="text-sm">{Math.round(currentMetrics.cpu)}%</span>
                    </div>
                    <Progress value={currentMetrics.cpu} />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Network Activity</span>
                      <span className="text-sm">{Math.round(currentMetrics.network)}%</span>
                    </div>
                    <Progress value={currentMetrics.network} />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="realtime" className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Switch checked={isMonitoring} onCheckedChange={setIsMonitoring} />
                  <Label>Real-time Monitoring</Label>
                </div>
                {isMonitoring && (
                  <Badge variant="default" className="bg-green-500">
                    <Activity className="h-3 w-3 mr-1" />
                    Live
                  </Badge>
                )}
              </div>
              <Button onClick={exportMetrics} variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export Data
              </Button>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Performance Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-end space-x-1">
                  {metrics.slice(-20).map((metric, index) => (
                    <div key={index} className="flex-1 flex flex-col space-y-1">
                      <div 
                        className="bg-blue-500 rounded-t"
                        style={{ height: `${(metric.cpu / 100) * 60}px` }}
                        title={`CPU: ${metric.cpu.toFixed(1)}%`}
                      />
                      <div 
                        className="bg-green-500"
                        style={{ height: `${(metric.memory / 100) * 60}px` }}
                        title={`Memory: ${metric.memory.toFixed(1)}%`}
                      />
                      <div 
                        className="bg-purple-500 rounded-b"
                        style={{ height: `${(metric.network / 100) * 60}px` }}
                        title={`Network: ${metric.network.toFixed(1)}%`}
                      />
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-4 mt-4 text-xs">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-blue-500 rounded" />
                    <span>CPU</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-green-500 rounded" />
                    <span>Memory</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-purple-500 rounded" />
                    <span>Network</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="components" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Component Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="space-y-2">
                    {componentMetrics.map((component, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <div className="font-medium text-sm">{component.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {component.rerenderCount} renders • Last: {component.lastUpdate.toLocaleTimeString()}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-sm">
                          <div className="text-center">
                            <div className="font-mono">{component.renderTime}ms</div>
                            <div className="text-xs text-muted-foreground">Render</div>
                          </div>
                          <div className="text-center">
                            <div className="font-mono">{component.memoryUsage}MB</div>
                            <div className="text-xs text-muted-foreground">Memory</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="network" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Network Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="space-y-2">
                    {networkRequests.map((request) => (
                      <div key={request.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <div className="font-mono text-sm">{request.method} {request.url}</div>
                          <div className="text-xs text-muted-foreground">
                            {request.timestamp.toLocaleTimeString()}
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <Badge variant={request.status === 200 ? 'default' : 'destructive'}>
                            {request.status}
                          </Badge>
                          <div className="text-sm font-mono">{request.duration}ms</div>
                          <div className="text-sm">{formatBytes(request.size)}</div>
                          <Badge variant="outline">{request.type}</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Monitoring Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label className="text-base mb-2 block">
                      Refresh Interval: {refreshInterval[0]}ms
                    </Label>
                    <Slider
                      value={refreshInterval}
                      onValueChange={setRefreshInterval}
                      max={5000}
                      min={100}
                      step={100}
                      className="w-full"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-base">Real-time Monitoring</Label>
                      <p className="text-sm text-muted-foreground">
                        Continuously collect performance metrics
                      </p>
                    </div>
                    <Switch checked={isMonitoring} onCheckedChange={setIsMonitoring} />
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Monitoring Features</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">FPS Monitoring</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Memory Tracking</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Network Monitoring</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Component Profiling</span>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}