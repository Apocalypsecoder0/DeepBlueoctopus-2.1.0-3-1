import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { 
  Brackets, 
  Eye, 
  Settings, 
  Zap, 
  Target, 
  CheckCircle,
  AlertTriangle,
  BarChart3,
  Palette,
  MousePointer
} from "lucide-react";

interface BracketMatchingProps {
  isOpen: boolean;
  onClose: () => void;
}

interface BracketPair {
  opening: string;
  closing: string;
  color: string;
  enabled: boolean;
}

interface MatchingStats {
  totalPairs: number;
  matchedPairs: number;
  unmatchedPairs: number;
  nestedLevels: number;
}

export default function BracketMatching({ isOpen, onClose }: BracketMatchingProps) {
  const [bracketPairs, setBracketPairs] = useState<BracketPair[]>([
    { opening: '(', closing: ')', color: '#FF6B6B', enabled: true },
    { opening: '[', closing: ']', color: '#4ECDC4', enabled: true },
    { opening: '{', closing: '}', color: '#45B7D1', enabled: true },
    { opening: '<', closing: '>', color: '#96CEB4', enabled: true },
    { opening: '"', closing: '"', color: '#FFEAA7', enabled: true },
    { opening: "'", closing: "'", color: '#DDA0DD', enabled: true },
    { opening: '`', closing: '`', color: '#98D8C8', enabled: true },
  ]);

  const [settings, setSettings] = useState({
    highlightOnHover: true,
    highlightOnClick: true,
    showMatchingLines: true,
    autoComplete: true,
    nestingIndicator: true,
    bracketGuides: true,
    highlightSpeed: [300],
    fadeTimeout: [2000],
    maxNestingLevel: [10],
  });

  const [matchingStats, setMatchingStats] = useState<MatchingStats>({
    totalPairs: 24,
    matchedPairs: 22,
    unmatchedPairs: 2,
    nestedLevels: 4,
  });

  const [sampleCode, setSampleCode] = useState(`function fibonacci(n) {
    if (n <= 1) {
        return n;
    }
    
    const cache = {};
    
    for (let i = 2; i <= n; i++) {
        cache[i] = cache[i-1] + cache[i-2];
    }
    
    return cache[n];
}

const numbers = [1, 2, 3, 4, 5];
const doubled = numbers.map((num) => {
    return num * 2;
});

console.log("Fibonacci of 10:", fibonacci(10));
console.log("Doubled numbers:", doubled);`);

  const [activeFeatures, setActiveFeatures] = useState({
    visualHighlighting: true,
    smartMatching: true,
    contextualHelp: true,
    performanceMode: false,
  });

  useEffect(() => {
    // Simulate real-time bracket analysis
    const interval = setInterval(() => {
      setMatchingStats(prev => ({
        ...prev,
        totalPairs: Math.floor(Math.random() * 30) + 20,
        matchedPairs: Math.floor(Math.random() * 25) + 18,
        unmatchedPairs: Math.floor(Math.random() * 5),
        nestedLevels: Math.floor(Math.random() * 6) + 2,
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const toggleBracketPair = (index: number) => {
    setBracketPairs(prev => prev.map((pair, i) => 
      i === index ? { ...pair, enabled: !pair.enabled } : pair
    ));
  };

  const updateBracketColor = (index: number, color: string) => {
    setBracketPairs(prev => prev.map((pair, i) => 
      i === index ? { ...pair, color } : pair
    ));
  };

  const runBracketAnalysis = () => {
    // Simulate bracket analysis
    const lines = sampleCode.split('\n');
    let analysis = {
      total: 0,
      matched: 0,
      unmatched: 0,
      maxNesting: 0,
    };

    lines.forEach(line => {
      const brackets = line.match(/[\(\)\[\]\{\}<>"'`]/g) || [];
      analysis.total += brackets.length;
    });

    analysis.matched = Math.floor(analysis.total * 0.9);
    analysis.unmatched = analysis.total - analysis.matched;
    analysis.maxNesting = Math.floor(Math.random() * 8) + 2;

    setMatchingStats({
      totalPairs: Math.floor(analysis.total / 2),
      matchedPairs: Math.floor(analysis.matched / 2),
      unmatchedPairs: Math.floor(analysis.unmatched / 2),
      nestedLevels: analysis.maxNesting,
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="w-[95vw] h-[95vh] bg-background rounded-lg border shadow-lg relative">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-2">
            <Brackets className="h-6 w-6 text-blue-500" />
            <div>
              <h2 className="text-xl font-bold">Bracket Matching System</h2>
              <p className="text-sm text-muted-foreground">Visual bracket pair highlighting and smart matching</p>
            </div>
          </div>
          <Button onClick={onClose} variant="outline" size="sm">
            Close
          </Button>
        </div>

        <div className="flex h-[calc(100%-80px)]">
          {/* Main Content */}
          <div className="flex-1 p-4 overflow-auto">
            <Tabs defaultValue="highlighting" className="h-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="highlighting">Visual Highlighting</TabsTrigger>
                <TabsTrigger value="settings">Configuration</TabsTrigger>
                <TabsTrigger value="analysis">Code Analysis</TabsTrigger>
                <TabsTrigger value="features">Advanced Features</TabsTrigger>
              </TabsList>

              <TabsContent value="highlighting" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {/* Bracket Pairs Configuration */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Palette className="h-4 w-4" />
                        Bracket Pairs
                      </CardTitle>
                      <CardDescription>
                        Configure bracket pairs and their highlight colors
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {bracketPairs.map((pair, index) => (
                        <div key={index} className="flex items-center justify-between p-2 border rounded">
                          <div className="flex items-center gap-2">
                            <Switch
                              checked={pair.enabled}
                              onCheckedChange={() => toggleBracketPair(index)}
                            />
                            <span className="font-mono text-sm">
                              {pair.opening} ... {pair.closing}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div 
                              className="w-6 h-6 rounded border-2 cursor-pointer"
                              style={{ backgroundColor: pair.color }}
                              onClick={() => {
                                const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];
                                const currentIndex = colors.indexOf(pair.color);
                                const nextColor = colors[(currentIndex + 1) % colors.length];
                                updateBracketColor(index, nextColor);
                              }}
                            />
                            <Badge variant={pair.enabled ? "default" : "secondary"}>
                              {pair.enabled ? "Active" : "Disabled"}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Live Preview */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Eye className="h-4 w-4" />
                        Live Preview
                      </CardTitle>
                      <CardDescription>
                        See bracket highlighting in action
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-muted p-4 rounded-lg border">
                        <pre className="text-sm font-mono whitespace-pre-wrap">
                          {sampleCode.split('').map((char, index) => {
                            const bracketPair = bracketPairs.find(pair => 
                              (char === pair.opening || char === pair.closing) && pair.enabled
                            );
                            if (bracketPair) {
                              return (
                                <span 
                                  key={index}
                                  className="px-1 rounded font-bold"
                                  style={{ 
                                    backgroundColor: bracketPair.color + '20',
                                    color: bracketPair.color,
                                    border: `1px solid ${bracketPair.color}40`
                                  }}
                                >
                                  {char}
                                </span>
                              );
                            }
                            return <span key={index}>{char}</span>;
                          })}
                        </pre>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Statistics */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-4 w-4" />
                      Matching Statistics
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">{matchingStats.totalPairs}</div>
                        <div className="text-sm text-muted-foreground">Total Pairs</div>
                      </div>
                      <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">{matchingStats.matchedPairs}</div>
                        <div className="text-sm text-muted-foreground">Matched</div>
                      </div>
                      <div className="text-center p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                        <div className="text-2xl font-bold text-red-600">{matchingStats.unmatchedPairs}</div>
                        <div className="text-sm text-muted-foreground">Unmatched</div>
                      </div>
                      <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">{matchingStats.nestedLevels}</div>
                        <div className="text-sm text-muted-foreground">Max Nesting</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="settings" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Settings className="h-4 w-4" />
                        Highlighting Settings
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Highlight on Hover</label>
                        <Switch
                          checked={settings.highlightOnHover}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, highlightOnHover: checked }))
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Highlight on Click</label>
                        <Switch
                          checked={settings.highlightOnClick}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, highlightOnClick: checked }))
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Show Matching Lines</label>
                        <Switch
                          checked={settings.showMatchingLines}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, showMatchingLines: checked }))
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Auto Complete Brackets</label>
                        <Switch
                          checked={settings.autoComplete}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, autoComplete: checked }))
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Nesting Indicator</label>
                        <Switch
                          checked={settings.nestingIndicator}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, nestingIndicator: checked }))
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Bracket Guides</label>
                        <Switch
                          checked={settings.bracketGuides}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, bracketGuides: checked }))
                          }
                        />
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Zap className="h-4 w-4" />
                        Performance Settings
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          Highlight Speed: {settings.highlightSpeed[0]}ms
                        </label>
                        <Slider
                          value={settings.highlightSpeed}
                          onValueChange={(value) => 
                            setSettings(prev => ({ ...prev, highlightSpeed: value }))
                          }
                          max={1000}
                          min={100}
                          step={50}
                          className="w-full"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          Fade Timeout: {settings.fadeTimeout[0]}ms
                        </label>
                        <Slider
                          value={settings.fadeTimeout}
                          onValueChange={(value) => 
                            setSettings(prev => ({ ...prev, fadeTimeout: value }))
                          }
                          max={5000}
                          min={500}
                          step={250}
                          className="w-full"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          Max Nesting Level: {settings.maxNestingLevel[0]}
                        </label>
                        <Slider
                          value={settings.maxNestingLevel}
                          onValueChange={(value) => 
                            setSettings(prev => ({ ...prev, maxNestingLevel: value }))
                          }
                          max={20}
                          min={3}
                          step={1}
                          className="w-full"
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="analysis" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-4 w-4" />
                      Code Analysis
                    </CardTitle>
                    <CardDescription>
                      Analyze bracket matching in your code
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <Button onClick={runBracketAnalysis} className="w-full">
                        Run Bracket Analysis
                      </Button>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium mb-2 block">Matching Accuracy</label>
                          <Progress 
                            value={(matchingStats.matchedPairs / matchingStats.totalPairs) * 100} 
                            className="w-full"
                          />
                          <p className="text-xs text-muted-foreground mt-1">
                            {Math.round((matchingStats.matchedPairs / matchingStats.totalPairs) * 100)}% of brackets matched
                          </p>
                        </div>
                        <div>
                          <label className="text-sm font-medium mb-2 block">Nesting Complexity</label>
                          <Progress 
                            value={(matchingStats.nestedLevels / settings.maxNestingLevel[0]) * 100} 
                            className="w-full"
                          />
                          <p className="text-xs text-muted-foreground mt-1">
                            {matchingStats.nestedLevels}/{settings.maxNestingLevel[0]} max nesting reached
                          </p>
                        </div>
                      </div>

                      {matchingStats.unmatchedPairs > 0 && (
                        <Alert>
                          <AlertTriangle className="h-4 w-4" />
                          <AlertDescription>
                            Found {matchingStats.unmatchedPairs} unmatched brackets. Consider reviewing your code for missing closing brackets.
                          </AlertDescription>
                        </Alert>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="features" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4" />
                        Active Features
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {Object.entries(activeFeatures).map(([key, value]) => (
                        <div key={key} className="flex items-center justify-between">
                          <label className="text-sm font-medium capitalize">
                            {key.replace(/([A-Z])/g, ' $1').trim()}
                          </label>
                          <Switch
                            checked={value}
                            onCheckedChange={(checked) => 
                              setActiveFeatures(prev => ({ ...prev, [key]: checked }))
                            }
                          />
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <MousePointer className="h-4 w-4" />
                        Keyboard Shortcuts
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Toggle Bracket Matching</span>
                          <Badge variant="outline">Ctrl+B</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Jump to Matching Bracket</span>
                          <Badge variant="outline">Ctrl+Shift+\</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Select Bracket Content</span>
                          <Badge variant="outline">Ctrl+Shift+M</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Expand Bracket Selection</span>
                          <Badge variant="outline">Ctrl+Shift+Right</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Collapse Bracket Selection</span>
                          <Badge variant="outline">Ctrl+Shift+Left</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}