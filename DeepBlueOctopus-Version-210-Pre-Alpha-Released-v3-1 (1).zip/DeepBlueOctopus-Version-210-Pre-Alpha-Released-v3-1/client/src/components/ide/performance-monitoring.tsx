import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Activity,
  Cpu,
  HardDrive,
  Network,
  Zap,
  Clock,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Monitor,
  MemoryStick,
  Gauge,
  BarChart3,
  Wifi,
  Database
} from 'lucide-react';

interface PerformanceMetric {
  name: string;
  value: number;
  unit: string;
  status: 'good' | 'warning' | 'critical';
  trend: 'up' | 'down' | 'stable';
  history: number[];
}

interface SystemProcess {
  id: string;
  name: string;
  cpuUsage: number;
  memoryUsage: number;
  status: 'running' | 'sleeping' | 'stopped';
}

const mockMetrics: PerformanceMetric[] = [
  {
    name: 'CPU Usage',
    value: 23.5,
    unit: '%',
    status: 'good',
    trend: 'stable',
    history: [18, 22, 25, 23, 21, 24, 23.5]
  },
  {
    name: 'Memory Usage',
    value: 68.2,
    unit: '%',
    status: 'warning',
    trend: 'up',
    history: [45, 52, 58, 62, 65, 67, 68.2]
  },
  {
    name: 'Disk Usage',
    value: 45.8,
    unit: '%',
    status: 'good',
    trend: 'stable',
    history: [44, 45, 46, 45, 44, 46, 45.8]
  },
  {
    name: 'Network I/O',
    value: 12.3,
    unit: 'MB/s',
    status: 'good',
    trend: 'down',
    history: [18, 15, 14, 13, 12, 11, 12.3]
  },
  {
    name: 'Response Time',
    value: 124,
    unit: 'ms',
    status: 'good',
    trend: 'stable',
    history: [130, 125, 120, 122, 125, 123, 124]
  },
  {
    name: 'Database Queries',
    value: 45,
    unit: 'q/s',
    status: 'good',
    trend: 'up',
    history: [38, 40, 42, 44, 43, 44, 45]
  }
];

const mockProcesses: SystemProcess[] = [
  {
    id: 'proc_1',
    name: 'DeepBlue IDE',
    cpuUsage: 15.2,
    memoryUsage: 245.8,
    status: 'running'
  },
  {
    id: 'proc_2',
    name: 'Node.js Server',
    cpuUsage: 8.5,
    memoryUsage: 128.4,
    status: 'running'
  },
  {
    id: 'proc_3',
    name: 'PostgreSQL',
    cpuUsage: 3.2,
    memoryUsage: 89.6,
    status: 'running'
  },
  {
    id: 'proc_4',
    name: 'Monaco Editor',
    cpuUsage: 12.1,
    memoryUsage: 67.2,
    status: 'running'
  },
  {
    id: 'proc_5',
    name: 'TypeScript Compiler',
    cpuUsage: 0.8,
    memoryUsage: 32.1,
    status: 'sleeping'
  }
];

export default function PerformanceMonitoring() {
  const [metrics, setMetrics] = useState<PerformanceMetric[]>(mockMetrics);
  const [processes, setProcesses] = useState<SystemProcess[]>(mockProcesses);
  const [realTimeMode, setRealTimeMode] = useState(true);

  useEffect(() => {
    if (!realTimeMode) return;

    const interval = setInterval(() => {
      setMetrics(prevMetrics => 
        prevMetrics.map(metric => {
          const variation = (Math.random() - 0.5) * 2; // Random variation between -1 and 1
          const newValue = Math.max(0, Math.min(100, metric.value + variation));
          const newHistory = [...metric.history.slice(1), newValue];
          
          let status: 'good' | 'warning' | 'critical' = 'good';
          if (metric.name === 'CPU Usage' || metric.name === 'Memory Usage') {
            if (newValue > 80) status = 'critical';
            else if (newValue > 60) status = 'warning';
          }
          
          const trend = newValue > metric.value ? 'up' : newValue < metric.value ? 'down' : 'stable';
          
          return {
            ...metric,
            value: newValue,
            status,
            trend,
            history: newHistory
          };
        })
      );

      setProcesses(prevProcesses =>
        prevProcesses.map(proc => ({
          ...proc,
          cpuUsage: Math.max(0, proc.cpuUsage + (Math.random() - 0.5) * 2),
          memoryUsage: Math.max(0, proc.memoryUsage + (Math.random() - 0.5) * 5)
        }))
      );
    }, 2000);

    return () => clearInterval(interval);
  }, [realTimeMode]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good': return 'text-green-500';
      case 'warning': return 'text-yellow-500';
      case 'critical': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'good': return <Badge className="bg-green-500">Good</Badge>;
      case 'warning': return <Badge className="bg-yellow-500">Warning</Badge>;
      case 'critical': return <Badge className="bg-red-500">Critical</Badge>;
      default: return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-4 w-4 text-red-500" />;
      case 'down': return <TrendingDown className="h-4 w-4 text-green-500" />;
      case 'stable': return <Activity className="h-4 w-4 text-blue-500" />;
      default: return null;
    }
  };

  const getMetricIcon = (name: string) => {
    switch (name) {
      case 'CPU Usage': return <Cpu className="h-5 w-5" />;
      case 'Memory Usage': return <MemoryStick className="h-5 w-5" />;
      case 'Disk Usage': return <HardDrive className="h-5 w-5" />;
      case 'Network I/O': return <Network className="h-5 w-5" />;
      case 'Response Time': return <Clock className="h-5 w-5" />;
      case 'Database Queries': return <Database className="h-5 w-5" />;
      default: return <Monitor className="h-5 w-5" />;
    }
  };

  const criticalMetrics = metrics.filter(m => m.status === 'critical');
  const warningMetrics = metrics.filter(m => m.status === 'warning');

  return (
    <div className="w-full h-full bg-background overflow-hidden">
      <div className="border-b p-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-green-500/10 rounded-lg">
            <Activity className="h-6 w-6 text-green-500" />
          </div>
          <div>
            <h1 className="text-xl font-bold">Performance Monitoring</h1>
            <p className="text-sm text-muted-foreground">
              Real-time system performance and resource monitoring
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Badge variant={realTimeMode ? "default" : "outline"}>
              {realTimeMode ? "Live" : "Paused"}
            </Badge>
            {criticalMetrics.length > 0 && (
              <Badge className="bg-red-500">
                {criticalMetrics.length} Critical
              </Badge>
            )}
            {warningMetrics.length > 0 && (
              <Badge className="bg-yellow-500">
                {warningMetrics.length} Warning
              </Badge>
            )}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden">
        <Tabs defaultValue="overview" className="h-full flex flex-col">
          <div className="border-b px-4">
            <TabsList className="grid grid-cols-4 w-[400px]">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <Gauge className="h-4 w-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="processes" className="flex items-center gap-2">
                <Monitor className="h-4 w-4" />
                Processes
              </TabsTrigger>
              <TabsTrigger value="network" className="flex items-center gap-2">
                <Wifi className="h-4 w-4" />
                Network
              </TabsTrigger>
              <TabsTrigger value="alerts" className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                Alerts
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="flex-1 overflow-hidden">
            <TabsContent value="overview" className="h-full p-4 m-0">
              <ScrollArea className="h-full">
                <div className="space-y-6">
                  {/* Key Metrics Grid */}
                  <div className="grid grid-cols-3 gap-4">
                    {metrics.map((metric) => (
                      <Card key={metric.name} className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            {getMetricIcon(metric.name)}
                            <span className="font-medium text-sm">{metric.name}</span>
                          </div>
                          {getTrendIcon(metric.trend)}
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className={`text-2xl font-bold ${getStatusColor(metric.status)}`}>
                              {metric.value.toFixed(1)}{metric.unit}
                            </span>
                            {getStatusBadge(metric.status)}
                          </div>
                          <Progress 
                            value={metric.name.includes('Usage') ? metric.value : (metric.value / 200) * 100} 
                            className={`h-2 ${metric.status === 'critical' ? 'bg-red-100' : metric.status === 'warning' ? 'bg-yellow-100' : 'bg-green-100'}`}
                          />
                        </div>
                      </Card>
                    ))}
                  </div>

                  {/* System Overview */}
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="p-4">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base flex items-center gap-2">
                          <Monitor className="h-5 w-5" />
                          System Information
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex justify-between">
                          <span>Uptime:</span>
                          <span className="font-semibold">2d 14h 32m</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Load Average:</span>
                          <span className="font-semibold">1.23, 1.45, 1.67</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Active Processes:</span>
                          <span className="font-semibold">{processes.filter(p => p.status === 'running').length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Total Memory:</span>
                          <span className="font-semibold">16 GB</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Available Memory:</span>
                          <span className="font-semibold">5.1 GB</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="p-4">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base flex items-center gap-2">
                          <BarChart3 className="h-5 w-5" />
                          Performance Summary
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex justify-between">
                          <span>Overall Health:</span>
                          <Badge className="bg-green-500">Excellent</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Performance Score:</span>
                          <span className="font-semibold">94/100</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Critical Issues:</span>
                          <span className="font-semibold text-red-500">{criticalMetrics.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Warnings:</span>
                          <span className="font-semibold text-yellow-500">{warningMetrics.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Last Updated:</span>
                          <span className="font-semibold">Just now</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Performance Trends */}
                  <Card className="p-4">
                    <CardHeader>
                      <CardTitle>Performance Trends</CardTitle>
                      <CardDescription>Historical performance data over the last hour</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-48 flex items-end justify-between gap-2">
                        {metrics[0].history.map((value, index) => (
                          <div key={index} className="flex flex-col items-center gap-2">
                            <div 
                              className="bg-blue-500 rounded-t"
                              style={{ 
                                height: `${(value / 100) * 160}px`,
                                width: '20px'
                              }}
                            />
                            <span className="text-xs text-muted-foreground">
                              {index * 10}m
                            </span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="processes" className="h-full p-4 m-0">
              <ScrollArea className="h-full">
                <div className="space-y-4">
                  <Card className="p-4">
                    <CardHeader className="pb-4">
                      <CardTitle>Running Processes</CardTitle>
                      <CardDescription>Active processes and their resource usage</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {processes.map((process) => (
                          <div key={process.id} className="flex items-center justify-between p-3 border rounded">
                            <div className="flex items-center gap-3">
                              <div className={`w-3 h-3 rounded-full ${
                                process.status === 'running' ? 'bg-green-500' : 
                                process.status === 'sleeping' ? 'bg-yellow-500' : 'bg-gray-500'
                              }`} />
                              <div>
                                <h4 className="font-medium">{process.name}</h4>
                                <p className="text-sm text-muted-foreground">Status: {process.status}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-6 text-sm">
                              <div className="text-center">
                                <div className="font-medium">{process.cpuUsage.toFixed(1)}%</div>
                                <div className="text-muted-foreground">CPU</div>
                              </div>
                              <div className="text-center">
                                <div className="font-medium">{process.memoryUsage.toFixed(1)} MB</div>
                                <div className="text-muted-foreground">Memory</div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="network" className="h-full p-4 m-0">
              <ScrollArea className="h-full">
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="p-4">
                      <CardHeader>
                        <CardTitle className="text-base">Network Traffic</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex justify-between">
                          <span>Bytes Sent:</span>
                          <span className="font-semibold">2.34 GB</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Bytes Received:</span>
                          <span className="font-semibold">5.67 GB</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Packets Sent:</span>
                          <span className="font-semibold">1,234,567</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Packets Received:</span>
                          <span className="font-semibold">2,345,678</span>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="p-4">
                      <CardHeader>
                        <CardTitle className="text-base">Connection Status</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex justify-between">
                          <span>Active Connections:</span>
                          <span className="font-semibold">42</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Established:</span>
                          <span className="font-semibold text-green-500">38</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Listen:</span>
                          <span className="font-semibold text-blue-500">4</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Time Wait:</span>
                          <span className="font-semibold text-yellow-500">0</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="alerts" className="h-full p-4 m-0">
              <ScrollArea className="h-full">
                <div className="space-y-4">
                  {criticalMetrics.length === 0 && warningMetrics.length === 0 ? (
                    <Alert>
                      <Activity className="h-4 w-4" />
                      <AlertDescription>
                        All systems are operating normally. No alerts or warnings detected.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <div className="space-y-3">
                      {criticalMetrics.map((metric) => (
                        <Alert key={metric.name} className="border-red-200 bg-red-50">
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                          <AlertDescription>
                            <strong>Critical:</strong> {metric.name} is at {metric.value.toFixed(1)}{metric.unit}
                          </AlertDescription>
                        </Alert>
                      ))}
                      {warningMetrics.map((metric) => (
                        <Alert key={metric.name} className="border-yellow-200 bg-yellow-50">
                          <AlertTriangle className="h-4 w-4 text-yellow-500" />
                          <AlertDescription>
                            <strong>Warning:</strong> {metric.name} is at {metric.value.toFixed(1)}{metric.unit}
                          </AlertDescription>
                        </Alert>
                      ))}
                    </div>
                  )}
                </div>
              </ScrollArea>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}