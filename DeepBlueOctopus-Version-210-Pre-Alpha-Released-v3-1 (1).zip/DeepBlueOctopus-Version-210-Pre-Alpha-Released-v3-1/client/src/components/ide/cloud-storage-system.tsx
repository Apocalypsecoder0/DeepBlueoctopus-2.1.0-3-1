import React, { useState, useCallback, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  Cloud, Upload, Download, FolderOpen, File, 
  Settings, Trash2, Share2, Link, Copy,
  HardDrive, Globe, Shield, Zap, CheckCircle,
  AlertCircle, Clock, Users, Lock, Eye,
  Archive, Image, Video, FileText, Code2
} from "lucide-react";

interface CloudStorageSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CloudProvider {
  id: string;
  name: string;
  icon: React.ReactNode;
  connected: boolean;
  storage: {
    used: number;
    total: number;
  };
  features: string[];
  color: string;
}

interface CloudFile {
  id: string;
  name: string;
  type: 'file' | 'folder';
  size: number;
  modified: Date;
  provider: string;
  path: string;
  shared: boolean;
  thumbnail?: string;
  mimeType: string;
}

interface UploadProgress {
  id: string;
  name: string;
  progress: number;
  status: 'uploading' | 'complete' | 'error';
  provider: string;
}

const CLOUD_PROVIDERS: CloudProvider[] = [
  {
    id: 'google-drive',
    name: 'Google Drive',
    icon: <Globe className="w-4 h-4" />,
    connected: true,
    storage: { used: 8.5, total: 15 },
    features: ['Real-time sync', 'Version history', 'Collaboration'],
    color: 'text-blue-600'
  },
  {
    id: 'onedrive',
    name: 'OneDrive',
    icon: <Cloud className="w-4 h-4" />,
    connected: false,
    storage: { used: 2.1, total: 5 },
    features: ['Office integration', 'Backup', 'File versioning'],
    color: 'text-blue-500'
  },
  {
    id: 'dropbox',
    name: 'Dropbox',
    icon: <HardDrive className="w-4 h-4" />,
    connected: true,
    storage: { used: 4.2, total: 10 },
    features: ['Smart sync', 'Team folders', 'File recovery'],
    color: 'text-blue-400'
  },
  {
    id: 'aws-s3',
    name: 'AWS S3',
    icon: <Shield className="w-4 h-4" />,
    connected: false,
    storage: { used: 0, total: 1000 },
    features: ['Enterprise security', 'CDN integration', 'Auto scaling'],
    color: 'text-orange-600'
  }
];

const SAMPLE_FILES: CloudFile[] = [
  {
    id: '1',
    name: 'project-files',
    type: 'folder',
    size: 0,
    modified: new Date('2024-07-04'),
    provider: 'google-drive',
    path: '/DeepBlue-IDE/projects',
    shared: false,
    mimeType: 'application/vnd.google-apps.folder'
  },
  {
    id: '2',
    name: 'main.tsx',
    type: 'file',
    size: 15680,
    modified: new Date('2024-07-04T15:30:00'),
    provider: 'google-drive',
    path: '/DeepBlue-IDE/src/main.tsx',
    shared: true,
    mimeType: 'text/typescript'
  },
  {
    id: '3',
    name: 'screenshots',
    type: 'folder',
    size: 0,
    modified: new Date('2024-07-03'),
    provider: 'dropbox',
    path: '/Screenshots',
    shared: false,
    mimeType: 'application/vnd.dropbox.folder'
  },
  {
    id: '4',
    name: 'demo-video.mp4',
    type: 'file',
    size: 45678900,
    modified: new Date('2024-07-02'),
    provider: 'dropbox',
    path: '/Videos/demo-video.mp4',
    shared: true,
    mimeType: 'video/mp4'
  }
];

export default function CloudStorageSystem({ isOpen, onClose }: CloudStorageSystemProps) {
  const [activeTab, setActiveTab] = useState('browser');
  const [selectedProvider, setSelectedProvider] = useState<string>('google-drive');
  const [files, setFiles] = useState<CloudFile[]>(SAMPLE_FILES);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { toast } = useToast();
  const { addFile } = useIDEState();

  const getFileIcon = (file: CloudFile) => {
    if (file.type === 'folder') return <FolderOpen className="w-4 h-4 text-blue-500" />;
    if (file.mimeType.startsWith('image/')) return <Image className="w-4 h-4 text-green-500" />;
    if (file.mimeType.startsWith('video/')) return <Video className="w-4 h-4 text-purple-500" />;
    if (file.mimeType.includes('text/') || file.name.endsWith('.md')) return <FileText className="w-4 h-4 text-gray-500" />;
    if (file.name.match(/\.(ts|tsx|js|jsx|py|java|cpp|rs)$/)) return <Code2 className="w-4 h-4 text-blue-600" />;
    return <File className="w-4 h-4 text-gray-400" />;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files || []);
    if (selectedFiles.length === 0) return;

    setIsUploading(true);
    
    selectedFiles.forEach((file, index) => {
      const uploadId = `upload-${Date.now()}-${index}`;
      const newUpload: UploadProgress = {
        id: uploadId,
        name: file.name,
        progress: 0,
        status: 'uploading',
        provider: selectedProvider
      };
      
      setUploadProgress(prev => [...prev, newUpload]);
      
      // Simulate upload progress
      const interval = setInterval(() => {
        setUploadProgress(prev => 
          prev.map(upload => {
            if (upload.id === uploadId) {
              const newProgress = Math.min(upload.progress + Math.random() * 15, 100);
              if (newProgress >= 100) {
                clearInterval(interval);
                
                // Add to cloud files
                const newCloudFile: CloudFile = {
                  id: `file-${Date.now()}-${index}`,
                  name: file.name,
                  type: 'file',
                  size: file.size,
                  modified: new Date(),
                  provider: selectedProvider,
                  path: `/${file.name}`,
                  shared: false,
                  mimeType: file.type
                };
                
                setFiles(prev => [...prev, newCloudFile]);
                
                return { ...upload, progress: 100, status: 'complete' as const };
              }
              return { ...upload, progress: newProgress };
            }
            return upload;
          })
        );
      }, 200);
    });

    // Clear upload progress after completion
    setTimeout(() => {
      setUploadProgress([]);
      setIsUploading(false);
      toast({
        title: "Upload Complete",
        description: `${selectedFiles.length} file(s) uploaded to ${CLOUD_PROVIDERS.find(p => p.id === selectedProvider)?.name}`,
      });
    }, 3000);
  }, [selectedProvider, toast]);

  const downloadFile = async (file: CloudFile) => {
    if (file.type === 'folder') return;
    
    toast({
      title: "Download Started",
      description: `Downloading ${file.name} from cloud storage`,
    });

    // Simulate download and add to IDE
    setTimeout(() => {
      addFile({
        name: file.name,
        path: file.path,
        content: `// Downloaded from ${file.provider}\n// File: ${file.name}\n// Modified: ${file.modified.toISOString()}\n\nconsole.log('Hello from cloud storage!');`,
        language: file.name.split('.').pop() || 'text',
        isDirectory: false,
        projectId: 1
      });
      
      toast({
        title: "File Downloaded",
        description: `${file.name} added to your workspace`,
      });
    }, 1000);
  };

  const shareFile = (file: CloudFile) => {
    navigator.clipboard.writeText(`https://cloud-storage.example.com/share/${file.id}`);
    toast({
      title: "Share Link Copied",
      description: "Shareable link copied to clipboard",
    });
  };

  const connectProvider = (providerId: string) => {
    const provider = CLOUD_PROVIDERS.find(p => p.id === providerId);
    if (provider) {
      provider.connected = true;
      toast({
        title: "Provider Connected",
        description: `Successfully connected to ${provider.name}`,
      });
    }
  };

  const filteredFiles = files.filter(file => 
    file.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
    (selectedProvider === 'all' || file.provider === selectedProvider)
  );

  const connectedProviders = CLOUD_PROVIDERS.filter(p => p.connected);

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Cloud className="w-5 h-5" />
            Cloud Storage & File Upload System
            <Badge variant="outline" className="ml-2">
              {connectedProviders.length}/{CLOUD_PROVIDERS.length} Connected
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex gap-6 overflow-hidden">
          <div className="flex-1">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="browser">File Browser</TabsTrigger>
                <TabsTrigger value="upload">Upload Files</TabsTrigger>
                <TabsTrigger value="sync">Sync & Backup</TabsTrigger>
                <TabsTrigger value="providers">Providers</TabsTrigger>
              </TabsList>
              
              <TabsContent value="browser" className="flex-1 space-y-4">
                <div className="flex items-center gap-3">
                  <Input
                    placeholder="Search files..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="flex-1"
                  />
                  <select 
                    value={selectedProvider}
                    onChange={(e) => setSelectedProvider(e.target.value)}
                    className="px-3 py-2 border rounded-md bg-background"
                  >
                    <option value="all">All Providers</option>
                    {connectedProviders.map(provider => (
                      <option key={provider.id} value={provider.id}>{provider.name}</option>
                    ))}
                  </select>
                </div>

                <ScrollArea className="flex-1">
                  <div className="space-y-2">
                    {filteredFiles.map((file) => (
                      <Card key={file.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              {getFileIcon(file)}
                              <div>
                                <h4 className="font-medium">{file.name}</h4>
                                <div className="flex items-center gap-2 text-sm text-gray-600">
                                  <span>{formatFileSize(file.size)}</span>
                                  <span>•</span>
                                  <span>{file.modified.toLocaleDateString()}</span>
                                  <span>•</span>
                                  <Badge variant="outline" className="text-xs">
                                    {CLOUD_PROVIDERS.find(p => p.id === file.provider)?.name}
                                  </Badge>
                                  {file.shared && (
                                    <Badge className="text-xs bg-green-100 text-green-800">
                                      <Share2 className="w-3 h-3 mr-1" />
                                      Shared
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => downloadFile(file)}
                                disabled={file.type === 'folder'}
                              >
                                <Download className="w-4 h-4" />
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => shareFile(file)}
                              >
                                <Share2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="upload" className="flex-1 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Upload className="w-5 h-5" />
                      Upload Files
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>Select Cloud Provider</Label>
                      <select 
                        value={selectedProvider}
                        onChange={(e) => setSelectedProvider(e.target.value)}
                        className="w-full px-3 py-2 border rounded-md bg-background"
                      >
                        {connectedProviders.map(provider => (
                          <option key={provider.id} value={provider.id}>{provider.name}</option>
                        ))}
                      </select>
                    </div>

                    <div 
                      className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-blue-500 transition-colors"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                      <h3 className="text-lg font-medium mb-2">Drop files here or click to browse</h3>
                      <p className="text-gray-600">Supports all file types • Max 100MB per file</p>
                    </div>

                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </CardContent>
                </Card>

                {uploadProgress.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Upload Progress</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {uploadProgress.map((upload) => (
                        <div key={upload.id} className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span>{upload.name}</span>
                            <div className="flex items-center gap-2">
                              {upload.status === 'complete' && <CheckCircle className="w-4 h-4 text-green-500" />}
                              {upload.status === 'error' && <AlertCircle className="w-4 h-4 text-red-500" />}
                              <span>{Math.round(upload.progress)}%</span>
                            </div>
                          </div>
                          <Progress value={upload.progress} className="w-full" />
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="sync" className="flex-1 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Auto-Sync Settings</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Enable Auto-Sync</Label>
                          <p className="text-xs text-gray-600">Automatically sync project files</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Real-time Backup</Label>
                          <p className="text-xs text-gray-600">Backup on every file save</p>
                        </div>
                        <Switch />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Version History</Label>
                          <p className="text-xs text-gray-600">Keep file version history</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Backup Status</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Last Backup</span>
                        <Badge variant="outline">2 minutes ago</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Files Synced</span>
                        <Badge>247/250</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Storage Used</span>
                        <Badge variant="outline">15.2 GB / 50 GB</Badge>
                      </div>
                      <Button className="w-full mt-4">
                        <Zap className="w-4 h-4 mr-2" />
                        Force Sync Now
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="providers" className="flex-1">
                <ScrollArea className="flex-1">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {CLOUD_PROVIDERS.map((provider) => (
                      <Card key={provider.id}>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <span className={provider.color}>{provider.icon}</span>
                            {provider.name}
                            {provider.connected && (
                              <Badge className="bg-green-100 text-green-800">
                                <CheckCircle className="w-3 h-3 mr-1" />
                                Connected
                              </Badge>
                            )}
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          {provider.connected && (
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span>Storage Used</span>
                                <span>{provider.storage.used} GB / {provider.storage.total} GB</span>
                              </div>
                              <Progress 
                                value={(provider.storage.used / provider.storage.total) * 100} 
                                className="w-full" 
                              />
                            </div>
                          )}
                          
                          <div className="space-y-1">
                            <h4 className="text-sm font-medium">Features</h4>
                            {provider.features.map((feature, idx) => (
                              <div key={idx} className="flex items-center gap-2 text-xs text-gray-600">
                                <CheckCircle className="w-3 h-3 text-green-500" />
                                <span>{feature}</span>
                              </div>
                            ))}
                          </div>

                          <div className="flex gap-2">
                            {provider.connected ? (
                              <>
                                <Button size="sm" variant="outline" className="flex-1">
                                  <Settings className="w-4 h-4 mr-2" />
                                  Settings
                                </Button>
                                <Button size="sm" variant="destructive">
                                  Disconnect
                                </Button>
                              </>
                            ) : (
                              <Button 
                                size="sm" 
                                className="flex-1"
                                onClick={() => connectProvider(provider.id)}
                              >
                                <Link className="w-4 h-4 mr-2" />
                                Connect
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t">
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Cloud className="w-4 h-4" />
              <span>{connectedProviders.length} Providers Connected</span>
            </div>
            <div className="flex items-center gap-1">
              <HardDrive className="w-4 h-4" />
              <span>{files.length} Files Available</span>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            <Button onClick={() => setShowSettings(true)}>
              <Settings className="w-4 h-4 mr-2" />
              Global Settings
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}