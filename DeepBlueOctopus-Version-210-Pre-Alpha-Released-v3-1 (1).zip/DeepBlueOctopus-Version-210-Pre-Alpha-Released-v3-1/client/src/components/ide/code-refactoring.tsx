import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { 
  RefreshCw, 
  Wand2, 
  Code2, 
  ArrowRight, 
  CheckCircle, 
  AlertTriangle,
  Settings,
  Zap,
  Target,
  FileText,
  Layers,
  Sparkles
} from "lucide-react";

interface CodeRefactoringProps {
  isOpen: boolean;
  onClose: () => void;
}

interface RefactoringRule {
  id: string;
  name: string;
  description: string;
  type: 'naming' | 'structure' | 'performance' | 'readability' | 'patterns';
  enabled: boolean;
  autoApply: boolean;
  confidence: number;
}

interface RefactoringSuggestion {
  id: string;
  rule: string;
  type: 'rename' | 'extract' | 'inline' | 'move' | 'restructure';
  file: string;
  line: number;
  originalCode: string;
  suggestedCode: string;
  reason: string;
  impact: 'low' | 'medium' | 'high';
  confidence: number;
  status: 'pending' | 'applied' | 'rejected';
}

export default function CodeRefactoring({ isOpen, onClose }: CodeRefactoringProps) {
  const [refactoringRules, setRefactoringRules] = useState<RefactoringRule[]>([
    {
      id: 'camelCase',
      name: 'Enforce camelCase',
      description: 'Convert variable names to camelCase convention',
      type: 'naming',
      enabled: true,
      autoApply: false,
      confidence: 95
    },
    {
      id: 'extractFunction',
      name: 'Extract Long Functions',
      description: 'Extract complex logic into separate functions',
      type: 'structure',
      enabled: true,
      autoApply: false,
      confidence: 88
    },
    {
      id: 'removeDeadCode',
      name: 'Remove Dead Code',
      description: 'Remove unused variables and functions',
      type: 'performance',
      enabled: true,
      autoApply: true,
      confidence: 98
    },
    {
      id: 'addTypeAnnotations',
      name: 'Add Type Annotations',
      description: 'Add TypeScript type annotations where missing',
      type: 'readability',
      enabled: true,
      autoApply: false,
      confidence: 92
    },
    {
      id: 'useModernSyntax',
      name: 'Modernize Syntax',
      description: 'Convert to arrow functions and modern ES6+ syntax',
      type: 'patterns',
      enabled: true,
      autoApply: false,
      confidence: 85
    }
  ]);

  const [suggestions, setSuggestions] = useState<RefactoringSuggestion[]>([
    {
      id: '1',
      rule: 'camelCase',
      type: 'rename',
      file: 'user-service.ts',
      line: 12,
      originalCode: 'const user_name = getUserName();',
      suggestedCode: 'const userName = getUserName();',
      reason: 'Variable name should follow camelCase convention',
      impact: 'low',
      confidence: 95,
      status: 'pending'
    },
    {
      id: '2',
      rule: 'extractFunction',
      type: 'extract',
      file: 'data-processor.ts',
      line: 25,
      originalCode: `// Complex validation logic (15 lines)
if (data.length > 0 && data.every(item => item.id)) {
  // ... complex validation logic
}`,
      suggestedCode: `const isValidDataSet = (data) => {
  return data.length > 0 && data.every(item => item.id);
};

if (isValidDataSet(data)) {
  // ... processing logic
}`,
      reason: 'Extract complex validation logic for better readability',
      impact: 'medium',
      confidence: 88,
      status: 'pending'
    },
    {
      id: '3',
      rule: 'removeDeadCode',
      type: 'inline',
      file: 'utils.ts',
      line: 8,
      originalCode: 'const unusedVariable = "not used anywhere";',
      suggestedCode: '// Variable removed - not used',
      reason: 'Variable is defined but never used',
      impact: 'low',
      confidence: 98,
      status: 'pending'
    },
    {
      id: '4',
      rule: 'useModernSyntax',
      type: 'restructure',
      file: 'api-client.ts',
      line: 15,
      originalCode: 'function processResponse(response) {\n  return response.data;\n}',
      suggestedCode: 'const processResponse = (response) => response.data;',
      reason: 'Convert to arrow function for consistency',
      impact: 'low',
      confidence: 85,
      status: 'pending'
    }
  ]);

  const [settings, setSettings] = useState({
    autoRefactor: false,
    confirmBeforeApply: true,
    backupBeforeRefactor: true,
    skipLowImpact: false,
    minConfidence: 80,
    enablePreview: true,
    groupSimilarChanges: true,
  });

  const [refactorStats, setRefactorStats] = useState({
    totalSuggestions: suggestions.length,
    appliedSuggestions: 0,
    rejectedSuggestions: 0,
    pendingSuggestions: suggestions.filter(s => s.status === 'pending').length,
    linesRefactored: 0,
    filesModified: 0,
  });

  const [activeRefactoring, setActiveRefactoring] = useState<string | null>(null);

  const applySuggestion = (suggestionId: string) => {
    setActiveRefactoring(suggestionId);
    
    setTimeout(() => {
      setSuggestions(prev => prev.map(s => 
        s.id === suggestionId 
          ? { ...s, status: 'applied' as const }
          : s
      ));
      
      setRefactorStats(prev => ({
        ...prev,
        appliedSuggestions: prev.appliedSuggestions + 1,
        pendingSuggestions: prev.pendingSuggestions - 1,
        linesRefactored: prev.linesRefactored + Math.floor(Math.random() * 5) + 1,
        filesModified: prev.filesModified + 1,
      }));
      
      setActiveRefactoring(null);
    }, 1500);
  };

  const rejectSuggestion = (suggestionId: string) => {
    setSuggestions(prev => prev.map(s => 
      s.id === suggestionId 
        ? { ...s, status: 'rejected' as const }
        : s
    ));
    
    setRefactorStats(prev => ({
      ...prev,
      rejectedSuggestions: prev.rejectedSuggestions + 1,
      pendingSuggestions: prev.pendingSuggestions - 1,
    }));
  };

  const applyAllSuggestions = () => {
    const pendingSuggestions = suggestions.filter(s => s.status === 'pending');
    pendingSuggestions.forEach((suggestion, index) => {
      setTimeout(() => applySuggestion(suggestion.id), index * 500);
    });
  };

  const runRefactorAnalysis = () => {
    // Simulate analysis
    const newSuggestions: RefactoringSuggestion[] = [
      {
        id: Date.now().toString(),
        rule: 'addTypeAnnotations',
        type: 'restructure',
        file: 'components.tsx',
        line: Math.floor(Math.random() * 50) + 1,
        originalCode: 'const handleClick = (event) => {',
        suggestedCode: 'const handleClick = (event: React.MouseEvent) => {',
        reason: 'Add type annotation for better type safety',
        impact: 'medium',
        confidence: 92,
        status: 'pending'
      }
    ];

    setSuggestions(prev => [...prev, ...newSuggestions]);
    setRefactorStats(prev => ({
      ...prev,
      totalSuggestions: prev.totalSuggestions + newSuggestions.length,
      pendingSuggestions: prev.pendingSuggestions + newSuggestions.length,
    }));
  };

  const toggleRule = (ruleId: string) => {
    setRefactoringRules(prev => prev.map(rule => 
      rule.id === ruleId 
        ? { ...rule, enabled: !rule.enabled }
        : rule
    ));
  };

  const toggleAutoApply = (ruleId: string) => {
    setRefactoringRules(prev => prev.map(rule => 
      rule.id === ruleId 
        ? { ...rule, autoApply: !rule.autoApply }
        : rule
    ));
  };

  const getImpactColor = (impact: RefactoringSuggestion['impact']) => {
    switch (impact) {
      case 'low': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'high': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const getTypeIcon = (type: RefactoringSuggestion['type']) => {
    switch (type) {
      case 'rename': return <Target className="h-3 w-3" />;
      case 'extract': return <Layers className="h-3 w-3" />;
      case 'inline': return <ArrowRight className="h-3 w-3" />;
      case 'move': return <RefreshCw className="h-3 w-3" />;
      case 'restructure': return <Code2 className="h-3 w-3" />;
      default: return <Wand2 className="h-3 w-3" />;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="w-[95vw] h-[95vh] bg-background rounded-lg border shadow-lg relative">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-2">
            <Wand2 className="h-6 w-6 text-blue-500" />
            <div>
              <h2 className="text-xl font-bold">Code Refactoring</h2>
              <p className="text-sm text-muted-foreground">Automated refactoring tools and transformations</p>
            </div>
          </div>
          <Button onClick={onClose} variant="outline" size="sm">
            Close
          </Button>
        </div>

        <div className="flex h-[calc(100%-80px)]">
          <div className="flex-1 p-4 overflow-auto">
            <Tabs defaultValue="suggestions" className="h-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
                <TabsTrigger value="rules">Rules</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
              </TabsList>

              <TabsContent value="suggestions" className="space-y-4">
                {/* Action Bar */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Button onClick={runRefactorAnalysis}>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Analyze Code
                    </Button>
                    <Button 
                      onClick={applyAllSuggestions}
                      disabled={refactorStats.pendingSuggestions === 0}
                      variant="outline"
                    >
                      Apply All ({refactorStats.pendingSuggestions})
                    </Button>
                  </div>
                  <Badge variant="secondary">
                    {refactorStats.pendingSuggestions} pending
                  </Badge>
                </div>

                {/* Statistics Cards */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">{refactorStats.totalSuggestions}</div>
                        <div className="text-sm text-muted-foreground">Total Suggestions</div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">{refactorStats.appliedSuggestions}</div>
                        <div className="text-sm text-muted-foreground">Applied</div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">{refactorStats.linesRefactored}</div>
                        <div className="text-sm text-muted-foreground">Lines Refactored</div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-orange-600">{refactorStats.filesModified}</div>
                        <div className="text-sm text-muted-foreground">Files Modified</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Suggestions List */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      Refactoring Suggestions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-96">
                      <div className="space-y-4">
                        {suggestions.map((suggestion) => (
                          <div 
                            key={suggestion.id}
                            className={`p-4 border rounded-lg ${
                              suggestion.status === 'applied' ? 'bg-green-50 dark:bg-green-900/20' :
                              suggestion.status === 'rejected' ? 'bg-red-50 dark:bg-red-900/20' :
                              'bg-background'
                            }`}
                          >
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex items-center gap-2">
                                {getTypeIcon(suggestion.type)}
                                <div>
                                  <div className="font-medium text-sm">
                                    {suggestion.file}:{suggestion.line}
                                  </div>
                                  <div className="text-xs text-muted-foreground">
                                    {suggestion.reason}
                                  </div>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge className={getImpactColor(suggestion.impact)}>
                                  {suggestion.impact}
                                </Badge>
                                <Badge variant="outline">
                                  {suggestion.confidence}%
                                </Badge>
                                {suggestion.status === 'applied' && (
                                  <CheckCircle className="h-4 w-4 text-green-500" />
                                )}
                                {suggestion.status === 'rejected' && (
                                  <AlertTriangle className="h-4 w-4 text-red-500" />
                                )}
                              </div>
                            </div>

                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-3">
                              <div>
                                <div className="text-xs font-medium text-muted-foreground mb-1">
                                  Original Code:
                                </div>
                                <div className="bg-red-50 dark:bg-red-900/20 p-2 rounded border font-mono text-xs">
                                  {suggestion.originalCode}
                                </div>
                              </div>
                              <div>
                                <div className="text-xs font-medium text-muted-foreground mb-1">
                                  Suggested Code:
                                </div>
                                <div className="bg-green-50 dark:bg-green-900/20 p-2 rounded border font-mono text-xs">
                                  {suggestion.suggestedCode}
                                </div>
                              </div>
                            </div>

                            {suggestion.status === 'pending' && (
                              <div className="flex items-center gap-2">
                                <Button 
                                  size="sm" 
                                  onClick={() => applySuggestion(suggestion.id)}
                                  disabled={activeRefactoring === suggestion.id}
                                >
                                  {activeRefactoring === suggestion.id ? (
                                    <>
                                      <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
                                      Applying...
                                    </>
                                  ) : (
                                    <>
                                      <CheckCircle className="h-3 w-3 mr-1" />
                                      Apply
                                    </>
                                  )}
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => rejectSuggestion(suggestion.id)}
                                >
                                  Reject
                                </Button>
                                {settings.enablePreview && (
                                  <Button size="sm" variant="ghost">
                                    Preview
                                  </Button>
                                )}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="rules" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="h-4 w-4" />
                      Refactoring Rules
                    </CardTitle>
                    <CardDescription>
                      Configure which refactoring rules to apply
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {refactoringRules.map((rule) => (
                        <div key={rule.id} className="p-4 border rounded-lg">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <Switch
                                  checked={rule.enabled}
                                  onCheckedChange={() => toggleRule(rule.id)}
                                />
                                <div className="font-medium">{rule.name}</div>
                                <Badge variant="outline" className="text-xs">
                                  {rule.type}
                                </Badge>
                              </div>
                              <div className="text-sm text-muted-foreground mb-2">
                                {rule.description}
                              </div>
                              <div className="flex items-center gap-4">
                                <div className="flex items-center gap-2">
                                  <Switch
                                    checked={rule.autoApply}
                                    onCheckedChange={() => toggleAutoApply(rule.id)}
                                    disabled={!rule.enabled}
                                    size="sm"
                                  />
                                  <span className="text-xs text-muted-foreground">Auto-apply</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className="text-xs text-muted-foreground">Confidence:</span>
                                  <Progress value={rule.confidence} className="w-16" />
                                  <span className="text-xs">{rule.confidence}%</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="settings" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Zap className="h-4 w-4" />
                        Refactoring Settings
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Auto Refactoring</label>
                        <Switch
                          checked={settings.autoRefactor}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, autoRefactor: checked }))
                          }
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Confirm Before Apply</label>
                        <Switch
                          checked={settings.confirmBeforeApply}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, confirmBeforeApply: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Backup Before Refactor</label>
                        <Switch
                          checked={settings.backupBeforeRefactor}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, backupBeforeRefactor: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Skip Low Impact Changes</label>
                        <Switch
                          checked={settings.skipLowImpact}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, skipLowImpact: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Enable Preview</label>
                        <Switch
                          checked={settings.enablePreview}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, enablePreview: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Group Similar Changes</label>
                        <Switch
                          checked={settings.groupSimilarChanges}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({ ...prev, groupSimilarChanges: checked }))
                          }
                        />
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Performance Settings</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">
                          Minimum Confidence: {settings.minConfidence}%
                        </label>
                        <Input
                          type="number"
                          min="0"
                          max="100"
                          value={settings.minConfidence}
                          onChange={(e) => 
                            setSettings(prev => ({ 
                              ...prev, 
                              minConfidence: parseInt(e.target.value) || 0 
                            }))
                          }
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="history" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <RefreshCw className="h-4 w-4" />
                      Refactoring History
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center text-muted-foreground py-8">
                      No refactoring history available yet.
                      Start refactoring to see your changes here.
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}