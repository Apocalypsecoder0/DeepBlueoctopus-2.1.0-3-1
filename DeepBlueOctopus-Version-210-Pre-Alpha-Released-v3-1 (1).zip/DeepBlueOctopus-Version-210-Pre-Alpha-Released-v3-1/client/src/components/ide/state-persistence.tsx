import React, { useState, useEffect, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  Save, Download, Upload, RefreshCw, Trash2, 
  Database, Clock, Settings, User, Palette,
  Monitor, Code, Terminal, FileText, 
  CheckCircle, AlertCircle, HardDrive
} from "lucide-react";

interface StatePersistenceProps {
  isOpen: boolean;
  onClose: () => void;
}

interface StorageItem {
  key: string;
  value: any;
  type: 'editor' | 'ui' | 'preferences' | 'session' | 'project';
  size: number;
  lastModified: Date;
}

interface PreferenceCategory {
  id: string;
  name: string;
  icon: React.ReactNode;
  settings: PreferenceSetting[];
}

interface PreferenceSetting {
  key: string;
  name: string;
  description: string;
  type: 'boolean' | 'string' | 'number' | 'select' | 'color';
  value: any;
  options?: string[];
  min?: number;
  max?: number;
}

export default function StatePersistence({ isOpen, onClose }: StatePersistenceProps) {
  const [storageItems, setStorageItems] = useState<StorageItem[]>([]);
  const [totalStorageSize, setTotalStorageSize] = useState(0);
  const [autoSave, setAutoSave] = useState(false);
  const [saveInterval, setSaveInterval] = useState([5]);
  const [exportData, setExportData] = useState<string>('');
  const [importData, setImportData] = useState<string>('');
  
  const [preferences, setPreferences] = useState<PreferenceCategory[]>([
    {
      id: 'editor',
      name: 'Editor',
      icon: <Code className="h-4 w-4" />,
      settings: [
        {
          key: 'fontSize',
          name: 'Font Size',
          description: 'Editor font size in pixels',
          type: 'number',
          value: 14,
          min: 10,
          max: 24
        },
        {
          key: 'fontFamily',
          name: 'Font Family',
          description: 'Editor font family',
          type: 'select',
          value: 'JetBrains Mono',
          options: ['JetBrains Mono', 'Fira Code', 'Monaco', 'Consolas', 'Courier New']
        },
        {
          key: 'wordWrap',
          name: 'Word Wrap',
          description: 'Enable word wrapping in editor',
          type: 'boolean',
          value: true
        },
        {
          key: 'lineNumbers',
          name: 'Line Numbers',
          description: 'Show line numbers',
          type: 'boolean',
          value: true
        },
        {
          key: 'minimap',
          name: 'Minimap',
          description: 'Show code minimap',
          type: 'boolean',
          value: true
        }
      ]
    },
    {
      id: 'ui',
      name: 'Interface',
      icon: <Monitor className="h-4 w-4" />,
      settings: [
        {
          key: 'theme',
          name: 'Theme',
          description: 'IDE color theme',
          type: 'select',
          value: 'DeepBlue Dark',
          options: ['DeepBlue Dark', 'Light', 'High Contrast', 'Dracula', 'Solarized']
        },
        {
          key: 'sidebarWidth',
          name: 'Sidebar Width',
          description: 'Width of the file explorer sidebar',
          type: 'number',
          value: 240,
          min: 200,
          max: 400
        },
        {
          key: 'showStatusBar',
          name: 'Status Bar',
          description: 'Show bottom status bar',
          type: 'boolean',
          value: true
        },
        {
          key: 'compactMode',
          name: 'Compact Mode',
          description: 'Use compact interface layout',
          type: 'boolean',
          value: false
        }
      ]
    },
    {
      id: 'terminal',
      name: 'Terminal',
      icon: <Terminal className="h-4 w-4" />,
      settings: [
        {
          key: 'terminalFontSize',
          name: 'Terminal Font Size',
          description: 'Terminal font size',
          type: 'number',
          value: 12,
          min: 10,
          max: 18
        },
        {
          key: 'terminalTheme',
          name: 'Terminal Theme',
          description: 'Terminal color scheme',
          type: 'select',
          value: 'DeepBlue Ocean',
          options: ['DeepBlue Ocean', 'Dark', 'Light', 'Dracula', 'Solarized Dark']
        },
        {
          key: 'terminalCursor',
          name: 'Cursor Blinking',
          description: 'Enable cursor blinking',
          type: 'boolean',
          value: true
        }
      ]
    },
    {
      id: 'project',
      name: 'Project',
      icon: <FileText className="h-4 w-4" />,
      settings: [
        {
          key: 'autoSaveFiles',
          name: 'Auto Save Files',
          description: 'Automatically save files while editing',
          type: 'boolean',
          value: true
        },
        {
          key: 'recentProjectsLimit',
          name: 'Recent Projects Limit',
          description: 'Number of recent projects to remember',
          type: 'number',
          value: 10,
          min: 5,
          max: 25
        },
        {
          key: 'defaultLanguage',
          name: 'Default Language',
          description: 'Default programming language for new files',
          type: 'select',
          value: 'javascript',
          options: ['javascript', 'typescript', 'python', 'java', 'cpp', 'rust', 'go']
        }
      ]
    }
  ]);

  const { toast } = useToast();

  useEffect(() => {
    loadStorageItems();
    loadPreferences();
  }, []);

  const loadStorageItems = () => {
    const items: StorageItem[] = [];
    let totalSize = 0;

    // Load from localStorage
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        const value = localStorage.getItem(key);
        if (value) {
          const size = new Blob([value]).size;
          totalSize += size;
          
          let parsedValue;
          try {
            parsedValue = JSON.parse(value);
          } catch {
            // If not valid JSON, store as string
            parsedValue = value;
          }
          
          items.push({
            key,
            value: parsedValue,
            type: getStorageType(key),
            size,
            lastModified: new Date()
          });
        }
      }
    }

    // Load from sessionStorage
    for (let i = 0; i < sessionStorage.length; i++) {
      const key = sessionStorage.key(i);
      if (key) {
        const value = sessionStorage.getItem(key);
        if (value) {
          const size = new Blob([value]).size;
          totalSize += size;
          
          let parsedValue;
          try {
            parsedValue = JSON.parse(value);
          } catch {
            // If not valid JSON, store as string
            parsedValue = value;
          }
          
          items.push({
            key: `session:${key}`,
            value: parsedValue,
            type: 'session',
            size,
            lastModified: new Date()
          });
        }
      }
    }

    setStorageItems(items);
    setTotalStorageSize(totalSize);
  };

  const getStorageType = (key: string): StorageItem['type'] => {
    if (key.includes('editor') || key.includes('monaco')) return 'editor';
    if (key.includes('theme') || key.includes('ui')) return 'ui';
    if (key.includes('preferences') || key.includes('settings')) return 'preferences';
    if (key.includes('project') || key.includes('file')) return 'project';
    return 'session';
  };

  const loadPreferences = () => {
    const saved = localStorage.getItem('ide-preferences');
    if (saved) {
      try {
        const savedPrefs = JSON.parse(saved);
        setPreferences(prev => prev.map(category => ({
          ...category,
          settings: category.settings.map(setting => ({
            ...setting,
            value: savedPrefs[setting.key] ?? setting.value
          }))
        })));
      } catch (error) {
        console.error('Error loading preferences:', error);
      }
    }
  };

  const savePreferences = () => {
    const prefsObject: Record<string, any> = {};
    preferences.forEach(category => {
      category.settings.forEach(setting => {
        prefsObject[setting.key] = setting.value;
      });
    });
    
    localStorage.setItem('ide-preferences', JSON.stringify(prefsObject));
    localStorage.setItem('ide-preferences-timestamp', new Date().toISOString());
    
    toast({
      title: "Preferences Saved",
      description: "Your settings have been saved to local storage",
    });
  };

  const updatePreference = (categoryId: string, settingKey: string, value: any) => {
    setPreferences(prev => prev.map(category => 
      category.id === categoryId ? {
        ...category,
        settings: category.settings.map(setting => 
          setting.key === settingKey ? { ...setting, value } : setting
        )
      } : category
    ));
  };

  const exportSettings = () => {
    const exportObj = {
      preferences: preferences,
      storageItems: storageItems.filter(item => item.type !== 'session'),
      timestamp: new Date().toISOString(),
      version: '2.1.0'
    };
    
    const jsonData = JSON.stringify(exportObj, null, 2);
    setExportData(jsonData);
    
    // Create download link
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `deepblue-ide-settings-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "Settings Exported",
      description: "Settings have been exported to file",
    });
  };

  const importSettings = () => {
    try {
      const importObj = JSON.parse(importData);
      
      if (importObj.preferences) {
        setPreferences(importObj.preferences);
        savePreferences();
      }
      
      if (importObj.storageItems) {
        importObj.storageItems.forEach((item: StorageItem) => {
          if (item.type !== 'session') {
            localStorage.setItem(item.key, JSON.stringify(item.value));
          }
        });
      }
      
      loadStorageItems();
      
      toast({
        title: "Settings Imported",
        description: "Settings have been imported successfully",
      });
      
      setImportData('');
    } catch (error) {
      toast({
        title: "Import Failed",
        description: "Invalid settings file format",
        variant: "destructive",
      });
    }
  };

  const clearStorage = (type?: StorageItem['type']) => {
    if (type) {
      const keysToRemove = storageItems
        .filter(item => item.type === type)
        .map(item => item.key.replace('session:', ''));
      
      keysToRemove.forEach(key => {
        localStorage.removeItem(key);
        sessionStorage.removeItem(key);
      });
    } else {
      localStorage.clear();
      sessionStorage.clear();
    }
    
    loadStorageItems();
    
    toast({
      title: "Storage Cleared",
      description: type ? `${type} data cleared` : "All storage data cleared",
    });
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const renderSetting = (setting: PreferenceSetting, categoryId: string) => {
    switch (setting.type) {
      case 'boolean':
        return (
          <Switch
            checked={setting.value}
            onCheckedChange={(value) => updatePreference(categoryId, setting.key, value)}
          />
        );
      
      case 'number':
        return (
          <div className="w-32">
            <Input
              type="number"
              value={setting.value}
              min={setting.min}
              max={setting.max}
              onChange={(e) => updatePreference(categoryId, setting.key, parseInt(e.target.value))}
            />
          </div>
        );
      
      case 'string':
        return (
          <Input
            value={setting.value}
            onChange={(e) => updatePreference(categoryId, setting.key, e.target.value)}
            className="w-48"
          />
        );
      
      case 'select':
        return (
          <select
            value={setting.value}
            onChange={(e) => updatePreference(categoryId, setting.key, e.target.value)}
            className="w-48 px-3 py-2 border rounded-md"
          >
            {setting.options?.map(option => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        );
      
      default:
        return null;
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            State Persistence & User Preferences
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="preferences" className="flex-1">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
            <TabsTrigger value="storage">Storage</TabsTrigger>
            <TabsTrigger value="autosave">Auto-Save</TabsTrigger>
            <TabsTrigger value="import-export">Import/Export</TabsTrigger>
          </TabsList>

          <TabsContent value="preferences" className="space-y-4">
            <ScrollArea className="h-96">
              <div className="space-y-6">
                {preferences.map((category) => (
                  <Card key={category.id}>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        {category.icon}
                        {category.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {category.settings.map((setting) => (
                          <div key={setting.key} className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="flex-1">
                              <div className="font-medium">{setting.name}</div>
                              <div className="text-sm text-muted-foreground">{setting.description}</div>
                            </div>
                            <div className="flex items-center gap-2">
                              {renderSetting(setting, category.id)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="storage" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <HardDrive className="h-4 w-4" />
                    Storage Usage
                  </span>
                  <Badge variant="outline">{formatBytes(totalStorageSize)}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-5 gap-2 mb-4">
                  {['editor', 'ui', 'preferences', 'session', 'project'].map(type => (
                    <Button
                      key={type}
                      variant="outline"
                      size="sm"
                      onClick={() => clearStorage(type as StorageItem['type'])}
                    >
                      Clear {type}
                    </Button>
                  ))}
                </div>

                <ScrollArea className="h-64">
                  <div className="space-y-2">
                    {storageItems.map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-2 border rounded text-sm">
                        <div className="flex-1">
                          <div className="font-mono text-xs truncate">{item.key}</div>
                          <div className="text-muted-foreground text-xs">
                            {item.lastModified.toLocaleDateString()}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={
                            item.type === 'editor' ? 'default' :
                            item.type === 'ui' ? 'secondary' :
                            item.type === 'preferences' ? 'outline' :
                            item.type === 'session' ? 'destructive' : 'default'
                          }>
                            {item.type}
                          </Badge>
                          <span className="text-xs">{formatBytes(item.size)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="autosave" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Auto-Save Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base">Enable Auto-Save</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically save preferences to local storage
                    </p>
                  </div>
                  <Switch checked={autoSave} onCheckedChange={setAutoSave} />
                </div>

                {autoSave && (
                  <div className="space-y-4">
                    <div>
                      <Label className="text-base mb-2 block">Save Interval: {saveInterval[0]} seconds</Label>
                      <Slider
                        value={saveInterval}
                        onValueChange={setSaveInterval}
                        max={60}
                        min={1}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    <div className="p-4 bg-muted rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="font-medium">Auto-Save Active</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Your preferences are being saved every {saveInterval[0]} seconds
                      </p>
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button onClick={savePreferences}>
                    <Save className="h-4 w-4 mr-2" />
                    Save Now
                  </Button>
                  <Button variant="outline" onClick={loadPreferences}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Reload
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="import-export" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Download className="h-4 w-4" />
                    Export Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Export your current settings and preferences to a file for backup or sharing.
                  </p>
                  
                  <Button onClick={exportSettings} className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Export Settings
                  </Button>

                  {exportData && (
                    <div className="space-y-2">
                      <Label>Exported Data Preview:</Label>
                      <ScrollArea className="h-32 p-2 bg-muted rounded border">
                        <pre className="text-xs font-mono">{exportData.substring(0, 500)}...</pre>
                      </ScrollArea>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="h-4 w-4" />
                    Import Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Import settings from a previously exported file to restore your preferences.
                  </p>
                  
                  <div className="space-y-2">
                    <Label>Paste Settings JSON:</Label>
                    <textarea
                      value={importData}
                      onChange={(e) => setImportData(e.target.value)}
                      placeholder="Paste exported settings JSON here..."
                      className="w-full h-32 p-2 border rounded-md font-mono text-xs"
                    />
                  </div>

                  <Button 
                    onClick={importSettings} 
                    className="w-full"
                    disabled={!importData.trim()}
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Import Settings
                  </Button>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trash2 className="h-4 w-4" />
                  Reset Settings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Clear all stored settings and return to default preferences.
                    </p>
                  </div>
                  <Button variant="destructive" onClick={() => clearStorage()}>
                    <Trash2 className="h-4 w-4 mr-2" />
                    Reset All
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}