import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Play, 
  Folder, 
  RefreshCw, 
  Download, 
  Copy, 
  Settings, 
  Terminal,
  FileText,
  CheckCircle,
  AlertCircle,
  Clock,
  Package2,
  FolderOpen,
  Code2,
  Hammer,
  Layers,
  File,
  Archive,
  Zap
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useIDEState } from '@/hooks/use-ide-state';

interface CompilationResult {
  success: boolean;
  output: string;
  error?: string;
  compiledFiles: string[];
  outputDir: string;
  executionTime?: number;
  warnings?: string[];
  timestamp: number;
}

interface TSConfig {
  target: string;
  module: string;
  outDir: string;
  rootDir: string;
  strict: boolean;
  esModuleInterop: boolean;
  skipLibCheck: boolean;
  forceConsistentCasingInFileNames: boolean;
  declaration: boolean;
  sourceMap: boolean;
}

interface ProjectStructure {
  name: string;
  files: ProjectFile[];
  folders: string[];
}

interface ProjectFile {
  name: string;
  path: string;
  content: string;
  type: 'typescript' | 'javascript' | 'json' | 'other';
}

const defaultTSConfig: TSConfig = {
  target: 'ES2020',
  module: 'CommonJS',
  outDir: './dist',
  rootDir: './src',
  strict: true,
  esModuleInterop: true,
  skipLibCheck: true,
  forceConsistentCasingInFileNames: true,
  declaration: true,
  sourceMap: true
};

const tsTargets = [
  { value: 'ES3', label: 'ES3' },
  { value: 'ES5', label: 'ES5' },
  { value: 'ES2015', label: 'ES2015 (ES6)' },
  { value: 'ES2016', label: 'ES2016' },
  { value: 'ES2017', label: 'ES2017' },
  { value: 'ES2018', label: 'ES2018' },
  { value: 'ES2019', label: 'ES2019' },
  { value: 'ES2020', label: 'ES2020' },
  { value: 'ES2021', label: 'ES2021' },
  { value: 'ES2022', label: 'ES2022' },
  { value: 'ESNext', label: 'ESNext' }
];

const moduleFormats = [
  { value: 'CommonJS', label: 'CommonJS' },
  { value: 'AMD', label: 'AMD' },
  { value: 'UMD', label: 'UMD' },
  { value: 'System', label: 'System' },
  { value: 'ES6', label: 'ES6 Modules' },
  { value: 'ES2015', label: 'ES2015' },
  { value: 'ES2020', label: 'ES2020' },
  { value: 'ESNext', label: 'ESNext' },
  { value: 'None', label: 'None' }
];

const sampleProjects = [
  {
    name: 'Express API Server',
    files: [
      {
        name: 'app.ts',
        path: 'src/app.ts',
        content: `import express from 'express';
import cors from 'cors';
import { userRoutes } from './routes/users';
import { errorHandler } from './middleware/errorHandler';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.use('/api/users', userRoutes);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`);
});

export default app;`,
        type: 'typescript' as const
      },
      {
        name: 'users.ts',
        path: 'src/routes/users.ts',
        content: `import { Router, Request, Response } from 'express';

export const userRoutes = Router();

interface User {
  id: number;
  name: string;
  email: string;
  createdAt: Date;
}

const users: User[] = [];

userRoutes.get('/', (req: Request, res: Response) => {
  res.json({ users, total: users.length });
});

userRoutes.post('/', (req: Request, res: Response) => {
  const { name, email } = req.body;
  
  const newUser: User = {
    id: users.length + 1,
    name,
    email,
    createdAt: new Date()
  };
  
  users.push(newUser);
  res.status(201).json(newUser);
});

userRoutes.get('/:id', (req: Request, res: Response) => {
  const user = users.find(u => u.id === parseInt(req.params.id));
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  res.json(user);
});`,
        type: 'typescript' as const
      },
      {
        name: 'errorHandler.ts',
        path: 'src/middleware/errorHandler.ts',
        content: `import { Request, Response, NextFunction } from 'express';

export const errorHandler = (
  error: Error,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  console.error('Error:', error.message);
  
  res.status(500).json({
    error: 'Internal Server Error',
    message: error.message,
    timestamp: new Date().toISOString()
  });
};`,
        type: 'typescript' as const
      },
      {
        name: 'package.json',
        path: 'package.json',
        content: `{
  "name": "express-api-server",
  "version": "1.0.0",
  "description": "TypeScript Express API Server",
  "main": "dist/app.js",
  "scripts": {
    "build": "tsc",
    "start": "node dist/app.js",
    "dev": "ts-node src/app.ts"
  },
  "dependencies": {
    "express": "^4.18.0",
    "cors": "^2.8.5"
  },
  "devDependencies": {
    "@types/express": "^4.17.17",
    "@types/cors": "^2.8.13",
    "@types/node": "^18.0.0",
    "typescript": "^5.0.0",
    "ts-node": "^10.9.0"
  }
}`,
        type: 'json' as const
      }
    ],
    folders: ['src', 'src/routes', 'src/middleware', 'dist']
  },
  {
    name: 'React Component Library',
    files: [
      {
        name: 'index.ts',
        path: 'src/index.ts',
        content: `export { Button } from './components/Button';
export { Card } from './components/Card';
export { Modal } from './components/Modal';
export * from './types';`,
        type: 'typescript' as const
      },
      {
        name: 'Button.tsx',
        path: 'src/components/Button.tsx',
        content: `import React from 'react';
import { ButtonProps } from '../types';

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'medium',
  disabled = false,
  onClick,
  className = ''
}) => {
  const baseClasses = 'rounded focus:outline-none transition-colors';
  const variantClasses = {
    primary: 'bg-blue-500 text-white hover:bg-blue-600',
    secondary: 'bg-gray-300 text-gray-800 hover:bg-gray-400',
    danger: 'bg-red-500 text-white hover:bg-red-600'
  };
  const sizeClasses = {
    small: 'px-2 py-1 text-sm',
    medium: 'px-4 py-2',
    large: 'px-6 py-3 text-lg'
  };

  return (
    <button
      className={\`\${baseClasses} \${variantClasses[variant]} \${sizeClasses[size]} \${className}\`}
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  );
};`,
        type: 'typescript' as const
      },
      {
        name: 'types.ts',
        path: 'src/types.ts',
        content: `import { ReactNode } from 'react';

export interface ButtonProps {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'danger';
  size?: 'small' | 'medium' | 'large';
  disabled?: boolean;
  onClick?: () => void;
  className?: string;
}

export interface CardProps {
  title?: string;
  children: ReactNode;
  className?: string;
}

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
}`,
        type: 'typescript' as const
      }
    ],
    folders: ['src', 'src/components', 'lib', 'dist']
  },
  {
    name: 'Node.js CLI Tool',
    files: [
      {
        name: 'cli.ts',
        path: 'src/cli.ts',
        content: `#!/usr/bin/env node
import { Command } from 'commander';
import { FileProcessor } from './utils/fileProcessor';
import { Logger } from './utils/logger';

const program = new Command();
const logger = new Logger();
const processor = new FileProcessor();

program
  .name('mytool')
  .description('A powerful CLI tool built with TypeScript')
  .version('1.0.0');

program
  .command('process')
  .description('Process files in a directory')
  .argument('<directory>', 'Directory to process')
  .option('-e, --extension <ext>', 'File extension to filter', '.txt')
  .option('-o, --output <dir>', 'Output directory', './output')
  .action(async (directory: string, options) => {
    try {
      logger.info(\`Processing files in \${directory}\`);
      const results = await processor.processDirectory(directory, options);
      logger.success(\`Processed \${results.length} files\`);
    } catch (error) {
      logger.error(\`Error: \${error.message}\`);
      process.exit(1);
    }
  });

program
  .command('init')
  .description('Initialize a new project')
  .argument('<name>', 'Project name')
  .action((name: string) => {
    logger.info(\`Initializing project: \${name}\`);
    // Implementation here
    logger.success('Project initialized successfully');
  });

program.parse();`,
        type: 'typescript' as const
      },
      {
        name: 'fileProcessor.ts',
        path: 'src/utils/fileProcessor.ts',
        content: `import fs from 'fs/promises';
import path from 'path';

export interface ProcessOptions {
  extension: string;
  output: string;
}

export interface ProcessResult {
  inputFile: string;
  outputFile: string;
  size: number;
  processed: boolean;
}

export class FileProcessor {
  async processDirectory(directory: string, options: ProcessOptions): Promise<ProcessResult[]> {
    const results: ProcessResult[] = [];
    
    try {
      const files = await fs.readdir(directory);
      
      for (const file of files) {
        const filePath = path.join(directory, file);
        const stat = await fs.stat(filePath);
        
        if (stat.isFile() && file.endsWith(options.extension)) {
          const result = await this.processFile(filePath, options.output);
          results.push(result);
        }
      }
    } catch (error) {
      throw new Error(\`Failed to process directory: \${error.message}\`);
    }
    
    return results;
  }

  private async processFile(filePath: string, outputDir: string): Promise<ProcessResult> {
    const content = await fs.readFile(filePath, 'utf-8');
    const fileName = path.basename(filePath);
    const outputPath = path.join(outputDir, \`processed_\${fileName}\`);
    
    // Ensure output directory exists
    await fs.mkdir(outputDir, { recursive: true });
    
    // Process content (example: add timestamp)
    const processedContent = \`// Processed on \${new Date().toISOString()}\\n\${content}\`;
    
    await fs.writeFile(outputPath, processedContent);
    
    return {
      inputFile: filePath,
      outputFile: outputPath,
      size: content.length,
      processed: true
    };
  }
}`,
        type: 'typescript' as const
      },
      {
        name: 'logger.ts',
        path: 'src/utils/logger.ts',
        content: `export class Logger {
  info(message: string): void {
    console.log(\`ℹ️  \${message}\`);
  }

  success(message: string): void {
    console.log(\`✅ \${message}\`);
  }

  error(message: string): void {
    console.error(\`❌ \${message}\`);
  }

  warn(message: string): void {
    console.warn(\`⚠️  \${message}\`);
  }
}`,
        type: 'typescript' as const
      }
    ],
    folders: ['src', 'src/utils', 'bin', 'dist']
  }
];

export default function TypeScriptCompiler() {
  const [activeTab, setActiveTab] = useState('project');
  const [selectedProject, setSelectedProject] = useState(sampleProjects[0]);
  const [tsConfig, setTSConfig] = useState<TSConfig>(defaultTSConfig);
  const [results, setResults] = useState<CompilationResult[]>([]);
  const [isCompiling, setIsCompiling] = useState(false);
  const [compilationProgress, setCompilationProgress] = useState(0);
  const [outputStructure, setOutputStructure] = useState<string[]>([]);

  const { toast } = useToast();
  const { projects } = useIDEState();

  // Fetch project structure
  const { data: projectStructure } = useQuery({
    queryKey: ['/api/typescript/project-structure'],
    enabled: false
  });

  const compileProject = useMutation({
    mutationFn: async ({ project, config }: { project: ProjectStructure; config: TSConfig }) => {
      const response = await apiRequest('POST', '/api/typescript/compile', { 
        project,
        config,
        createFolders: true
      });
      return response.json();
    },
    onMutate: () => {
      setIsCompiling(true);
      setCompilationProgress(0);
      
      // Simulate progress updates
      const interval = setInterval(() => {
        setCompilationProgress(prev => {
          const newProgress = prev + 15;
          if (newProgress >= 90) {
            clearInterval(interval);
            return 90;
          }
          return newProgress;
        });
      }, 300);
    },
    onSuccess: (data) => {
      setCompilationProgress(100);
      
      const result: CompilationResult = {
        success: data.success !== false,
        output: data.output || '',
        error: data.error,
        compiledFiles: data.compiledFiles || [],
        outputDir: data.outputDir || tsConfig.outDir,
        executionTime: data.executionTime,
        warnings: data.warnings || [],
        timestamp: Date.now()
      };
      
      setResults(prev => [result, ...prev.slice(0, 9)]);
      setOutputStructure(data.folderStructure || []);
      
      toast({
        title: result.success ? 'Compilation Successful' : 'Compilation Failed',
        description: result.success 
          ? `Successfully compiled ${result.compiledFiles.length} files to ${result.outputDir}` 
          : 'Check the output for error details',
        variant: result.success ? 'default' : 'destructive',
      });
    },
    onError: (error) => {
      const result: CompilationResult = {
        success: false,
        output: '',
        error: error.message,
        compiledFiles: [],
        outputDir: tsConfig.outDir,
        timestamp: Date.now()
      };
      
      setResults(prev => [result, ...prev.slice(0, 9)]);
      
      toast({
        title: 'Compilation Error',
        description: 'Failed to compile TypeScript project',
        variant: 'destructive',
      });
    },
    onSettled: () => {
      setIsCompiling(false);
      setCompilationProgress(0);
    }
  });

  const handleCompile = () => {
    if (!selectedProject.files.length) {
      toast({
        title: 'No Files',
        description: 'Please select a project with TypeScript files to compile',
        variant: 'destructive',
      });
      return;
    }

    compileProject.mutate({ project: selectedProject, config: tsConfig });
  };

  const handleProjectChange = (projectId: string) => {
    const project = sampleProjects[parseInt(projectId)];
    if (project) {
      setSelectedProject(project);
      toast({
        title: 'Project Loaded',
        description: `${project.name} project loaded successfully`,
      });
    }
  };

  const handleConfigChange = (key: keyof TSConfig, value: any) => {
    setTSConfig(prev => ({ ...prev, [key]: value }));
  };

  const handleDownloadResult = (result: CompilationResult) => {
    const content = `TypeScript Compilation Result
Project: ${selectedProject.name}
Timestamp: ${new Date(result.timestamp).toISOString()}
Success: ${result.success}
Output Directory: ${result.outputDir}
Compiled Files: ${result.compiledFiles.length}
${result.executionTime ? `Compilation Time: ${result.executionTime}ms` : ''}

Files Compiled:
${result.compiledFiles.join('\n')}

Output:
${result.output}

${result.warnings?.length ? `Warnings:
${result.warnings.join('\n')}` : ''}

${result.error ? `Error:
${result.error}` : ''}`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `typescript-compilation-${result.timestamp}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const generateTSConfigFile = () => {
    const config = {
      compilerOptions: {
        target: tsConfig.target,
        module: tsConfig.module,
        outDir: tsConfig.outDir,
        rootDir: tsConfig.rootDir,
        strict: tsConfig.strict,
        esModuleInterop: tsConfig.esModuleInterop,
        skipLibCheck: tsConfig.skipLibCheck,
        forceConsistentCasingInFileNames: tsConfig.forceConsistentCasingInFileNames,
        declaration: tsConfig.declaration,
        sourceMap: tsConfig.sourceMap,
        lib: ["ES2020"],
        moduleResolution: "node",
        allowSyntheticDefaultImports: true
      },
      include: ["src/**/*"],
      exclude: ["node_modules", "dist"]
    };

    const content = JSON.stringify(config, null, 2);
    const blob = new Blob([content], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'tsconfig.json';
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: 'tsconfig.json Generated',
      description: 'TypeScript configuration file downloaded',
    });
  };

  return (
    <div className="w-full h-full bg-background overflow-hidden">
      <div className="border-b p-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-500/10 rounded-lg">
            <Code2 className="h-6 w-6 text-blue-500" />
          </div>
          <div>
            <h1 className="text-xl font-bold">TypeScript Compiler</h1>
            <p className="text-sm text-muted-foreground">
              Compile TypeScript projects and organize output folders
            </p>
          </div>
        </div>
      </div>

      <div className="flex h-full">
        {/* Main Content */}
        <div className="flex-1 overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
            <TabsList className="w-full justify-start border-b rounded-none h-12 bg-transparent">
              <TabsTrigger value="project" className="gap-2">
                <Folder className="h-4 w-4" />
                Project Setup
              </TabsTrigger>
              <TabsTrigger value="config" className="gap-2">
                <Settings className="h-4 w-4" />
                Configuration
              </TabsTrigger>
              <TabsTrigger value="compile" className="gap-2">
                <Hammer className="h-4 w-4" />
                Compilation
              </TabsTrigger>
              <TabsTrigger value="output" className="gap-2">
                <FolderOpen className="h-4 w-4" />
                Output Structure
              </TabsTrigger>
            </TabsList>

            <div className="p-4 h-full overflow-y-auto">
              <TabsContent value="project" className="space-y-4 m-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Project Selection</CardTitle>
                    <CardDescription>
                      Choose a sample project or configure your own TypeScript project
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Sample Projects</label>
                      <Select onValueChange={handleProjectChange} defaultValue="0">
                        <SelectTrigger>
                          <SelectValue placeholder="Choose a sample project" />
                        </SelectTrigger>
                        <SelectContent>
                          {sampleProjects.map((project, index) => (
                            <SelectItem key={index} value={index.toString()}>
                              {project.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium mb-3">Current Project: {selectedProject.name}</h4>
                      <div className="space-y-3">
                        <div>
                          <h5 className="text-sm font-medium text-muted-foreground mb-2">Files ({selectedProject.files.length})</h5>
                          <div className="grid grid-cols-2 gap-2">
                            {selectedProject.files.map((file, index) => (
                              <div key={index} className="flex items-center gap-2 p-2 bg-muted rounded text-sm">
                                <File className="h-4 w-4" />
                                <span className="truncate">{file.name}</span>
                                <Badge variant="outline" className="ml-auto text-xs">
                                  {file.type}
                                </Badge>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div>
                          <h5 className="text-sm font-medium text-muted-foreground mb-2">Folders ({selectedProject.folders.length})</h5>
                          <div className="grid grid-cols-3 gap-2">
                            {selectedProject.folders.map((folder, index) => (
                              <div key={index} className="flex items-center gap-2 p-2 bg-muted rounded text-sm">
                                <Folder className="h-4 w-4" />
                                <span className="truncate">{folder}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="config" className="space-y-4 m-0">
                <Card>
                  <CardHeader>
                    <CardTitle>TypeScript Configuration</CardTitle>
                    <CardDescription>
                      Configure compilation settings and output options
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Target</label>
                        <Select value={tsConfig.target} onValueChange={(value) => handleConfigChange('target', value)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {tsTargets.map((target) => (
                              <SelectItem key={target.value} value={target.value}>
                                {target.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">Module Format</label>
                        <Select value={tsConfig.module} onValueChange={(value) => handleConfigChange('module', value)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {moduleFormats.map((format) => (
                              <SelectItem key={format.value} value={format.value}>
                                {format.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">Output Directory</label>
                        <Input 
                          value={tsConfig.outDir} 
                          onChange={(e) => handleConfigChange('outDir', e.target.value)}
                          placeholder="./dist"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">Root Directory</label>
                        <Input 
                          value={tsConfig.rootDir} 
                          onChange={(e) => handleConfigChange('rootDir', e.target.value)}
                          placeholder="./src"
                        />
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-3">
                      <h4 className="text-sm font-medium">Compiler Options</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id="strict" 
                            checked={tsConfig.strict}
                            onCheckedChange={(checked) => handleConfigChange('strict', checked)}
                          />
                          <label htmlFor="strict" className="text-sm">Strict Type Checking</label>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id="esModuleInterop" 
                            checked={tsConfig.esModuleInterop}
                            onCheckedChange={(checked) => handleConfigChange('esModuleInterop', checked)}
                          />
                          <label htmlFor="esModuleInterop" className="text-sm">ES Module Interop</label>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id="skipLibCheck" 
                            checked={tsConfig.skipLibCheck}
                            onCheckedChange={(checked) => handleConfigChange('skipLibCheck', checked)}
                          />
                          <label htmlFor="skipLibCheck" className="text-sm">Skip Lib Check</label>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id="declaration" 
                            checked={tsConfig.declaration}
                            onCheckedChange={(checked) => handleConfigChange('declaration', checked)}
                          />
                          <label htmlFor="declaration" className="text-sm">Generate Declarations</label>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id="sourceMap" 
                            checked={tsConfig.sourceMap}
                            onCheckedChange={(checked) => handleConfigChange('sourceMap', checked)}
                          />
                          <label htmlFor="sourceMap" className="text-sm">Generate Source Maps</label>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id="forceConsistentCasingInFileNames" 
                            checked={tsConfig.forceConsistentCasingInFileNames}
                            onCheckedChange={(checked) => handleConfigChange('forceConsistentCasingInFileNames', checked)}
                          />
                          <label htmlFor="forceConsistentCasingInFileNames" className="text-sm">Force Consistent Casing</label>
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <Button onClick={generateTSConfigFile} variant="outline" className="w-full">
                      <Download className="h-4 w-4 mr-2" />
                      Generate tsconfig.json
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="compile" className="space-y-4 m-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Compilation Controls</CardTitle>
                    <CardDescription>
                      Compile your TypeScript project and view results
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex gap-3">
                      <Button
                        onClick={handleCompile}
                        disabled={isCompiling}
                        className="flex-1"
                      >
                        {isCompiling ? (
                          <>
                            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                            Compiling...
                          </>
                        ) : (
                          <>
                            <Play className="h-4 w-4 mr-2" />
                            Compile Project
                          </>
                        )}
                      </Button>
                    </div>

                    {isCompiling && (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          Compiling TypeScript files...
                        </div>
                        <Progress value={compilationProgress} className="w-full" />
                      </div>
                    )}

                    <div className="bg-muted rounded-lg p-3">
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Target:</span>
                          <div className="font-mono">{tsConfig.target}</div>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Module:</span>
                          <div className="font-mono">{tsConfig.module}</div>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Output:</span>
                          <div className="font-mono">{tsConfig.outDir}</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Compilation Results */}
                {results.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Compilation Results</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-[400px] w-full">
                        <div className="space-y-3">
                          {results.map((result, index) => (
                            <div key={index} className="border rounded-lg p-4">
                              <div className="flex items-start justify-between mb-3">
                                <div className="flex items-center gap-2">
                                  {result.success ? (
                                    <CheckCircle className="h-5 w-5 text-green-500" />
                                  ) : (
                                    <AlertCircle className="h-5 w-5 text-red-500" />
                                  )}
                                  <div>
                                    <div className="font-medium">
                                      {result.success ? 'Compilation Successful' : 'Compilation Failed'}
                                    </div>
                                    <div className="text-sm text-muted-foreground">
                                      {new Date(result.timestamp).toLocaleString()}
                                      {result.executionTime && ` • ${result.executionTime}ms`}
                                    </div>
                                  </div>
                                </div>
                                <div className="flex gap-2">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => navigator.clipboard.writeText(result.output)}
                                  >
                                    <Copy className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleDownloadResult(result)}
                                  >
                                    <Download className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>

                              {result.success && result.compiledFiles.length > 0 && (
                                <div className="mb-3">
                                  <h5 className="text-sm font-medium mb-2">Compiled Files ({result.compiledFiles.length})</h5>
                                  <div className="grid grid-cols-2 gap-1">
                                    {result.compiledFiles.map((file, fileIndex) => (
                                      <div key={fileIndex} className="text-xs font-mono bg-muted p-2 rounded">
                                        {file}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {result.warnings && result.warnings.length > 0 && (
                                <Alert className="mb-3">
                                  <AlertCircle className="h-4 w-4" />
                                  <AlertDescription>
                                    {result.warnings.length} warning(s) found
                                  </AlertDescription>
                                </Alert>
                              )}

                              <div className="bg-muted rounded p-3">
                                <ScrollArea className="h-32">
                                  <pre className="text-sm whitespace-pre-wrap">
                                    {result.output}
                                    {result.error && (
                                      <div className="text-red-500 mt-2">
                                        Error: {result.error}
                                      </div>
                                    )}
                                  </pre>
                                </ScrollArea>
                              </div>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="output" className="space-y-4 m-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Output Folder Structure</CardTitle>
                    <CardDescription>
                      View the compiled project structure and files
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {outputStructure.length > 0 ? (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 mb-4">
                          <FolderOpen className="h-5 w-5 text-blue-500" />
                          <span className="font-medium">{tsConfig.outDir}</span>
                          <Badge>{outputStructure.length} items</Badge>
                        </div>
                        <ScrollArea className="h-[300px] w-full">
                          <div className="space-y-1">
                            {outputStructure.map((item, index) => (
                              <div key={index} className="flex items-center gap-2 p-2 hover:bg-muted rounded">
                                {item.endsWith('/') ? (
                                  <Folder className="h-4 w-4 text-blue-500" />
                                ) : (
                                  <File className="h-4 w-4 text-gray-500" />
                                )}
                                <span className="font-mono text-sm">{item}</span>
                              </div>
                            ))}
                          </div>
                        </ScrollArea>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <Archive className="h-12 w-12 mx-auto mb-3 opacity-50" />
                        <p>No compiled output yet</p>
                        <p className="text-sm">Compile a project to see the folder structure</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
}