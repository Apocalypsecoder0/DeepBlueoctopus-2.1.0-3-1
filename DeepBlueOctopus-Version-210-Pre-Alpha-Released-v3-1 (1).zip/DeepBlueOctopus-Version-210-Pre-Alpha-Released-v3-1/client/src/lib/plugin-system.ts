/**
 * Comprehensive Plugin System for DeepBlue IDE
 * Supports dynamic loading, dependency management, and plugin lifecycle
 */

export interface PluginManifest {
  id: string;
  name: string;
  version: string;
  description: string;
  author: string;
  homepage?: string;
  repository?: string;
  license: string;
  keywords: string[];
  category: 'editor' | 'theme' | 'language' | 'tool' | 'debugger' | 'integration' | 'ui' | 'productivity';
  
  // Plugin metadata
  main: string; // Entry point file
  icon?: string;
  displayName: string;
  
  // Dependencies
  dependencies?: Record<string, string>;
  peerDependencies?: Record<string, string>;
  ideVersion: string; // Compatible IDE version
  
  // Capabilities
  contributes: {
    commands?: PluginCommand[];
    themes?: PluginTheme[];
    languages?: PluginLanguage[];
    snippets?: PluginSnippet[];
    menus?: PluginMenu[];
    keybindings?: PluginKeybinding[];
    views?: PluginView[];
    debuggers?: PluginDebugger[];
    tasks?: PluginTask[];
  };
  
  // Activation events
  activationEvents: string[];
  
  // Runtime configuration
  extensionKind?: 'ui' | 'workspace';
  enableProposedApi?: boolean;
  
  // Security and permissions
  permissions?: string[];
  trustedWorkspace?: boolean;
  
  // Publishing info
  publisher: string;
  publishedDate?: string;
  lastUpdated?: string;
  downloads?: number;
  rating?: number;
  
  // Premium features
  isPremium?: boolean;
  pricing?: {
    type: 'free' | 'paid' | 'freemium';
    price?: number;
    currency?: string;
    trialDays?: number;
  };
}

export interface PluginCommand {
  command: string;
  title: string;
  category?: string;
  icon?: string;
  when?: string; // Conditional execution
}

export interface PluginTheme {
  id: string;
  label: string;
  path: string;
  uiTheme: 'vs' | 'vs-dark' | 'hc-black';
}

export interface PluginLanguage {
  id: string;
  aliases: string[];
  extensions: string[];
  configuration?: string;
  grammar?: string;
}

export interface PluginSnippet {
  language: string;
  path: string;
}

export interface PluginMenu {
  commandPalette?: PluginMenuItem[];
  editor?: PluginMenuItem[];
  explorer?: PluginMenuItem[];
  view?: PluginMenuItem[];
}

export interface PluginMenuItem {
  command: string;
  when?: string;
  group?: string;
}

export interface PluginKeybinding {
  command: string;
  key: string;
  mac?: string;
  linux?: string;
  when?: string;
}

export interface PluginView {
  id: string;
  name: string;
  when?: string;
  icon?: string;
  contextualTitle?: string;
}

export interface PluginDebugger {
  type: string;
  label: string;
  languages?: string[];
  configurationAttributes?: Record<string, any>;
}

export interface PluginTask {
  type: string;
  required: string[];
  properties: Record<string, any>;
}

export interface Plugin {
  manifest: PluginManifest;
  isActive: boolean;
  isInstalled: boolean;
  isEnabled: boolean;
  installPath: string;
  activationTime?: number;
  context?: PluginContext;
  exports?: any;
}

export interface PluginContext {
  subscriptions: { dispose(): void }[];
  workspaceState: PluginStateManager;
  globalState: PluginStateManager;
  extensionPath: string;
  extensionUri: string;
  storagePath: string;
  logPath: string;
  globalStoragePath: string;
}

export interface PluginStateManager {
  get<T>(key: string): T | undefined;
  update(key: string, value: any): Promise<void>;
  keys(): readonly string[];
}

export interface PluginAPI {
  // Core IDE API
  window: {
    showInformationMessage(message: string): Promise<string | undefined>;
    showWarningMessage(message: string): Promise<string | undefined>;
    showErrorMessage(message: string): Promise<string | undefined>;
    showInputBox(options?: any): Promise<string | undefined>;
    showQuickPick(items: any[], options?: any): Promise<any>;
  };
  
  // Workspace API
  workspace: {
    openTextDocument(uri: string): Promise<any>;
    saveTextDocument(document: any): Promise<boolean>;
    findFiles(pattern: string): Promise<string[]>;
    createFileSystemWatcher(pattern: string): any;
  };
  
  // Editor API
  editor: {
    getActiveEditor(): any;
    openEditor(uri: string): Promise<any>;
    closeEditor(editor: any): Promise<void>;
    insertText(text: string, position?: any): Promise<void>;
    replaceText(range: any, text: string): Promise<void>;
  };
  
  // Commands API
  commands: {
    registerCommand(command: string, callback: (...args: any[]) => any): void;
    executeCommand(command: string, ...args: any[]): Promise<any>;
    getCommands(): Promise<string[]>;
  };
  
  // Languages API
  languages: {
    registerHoverProvider(language: string, provider: any): void;
    registerCompletionItemProvider(language: string, provider: any): void;
    registerDefinitionProvider(language: string, provider: any): void;
    registerCodeActionProvider(language: string, provider: any): void;
  };
  
  // Debug API
  debug: {
    startDebugging(folder: any, config: any): Promise<boolean>;
    stopDebugging(session?: any): Promise<void>;
    addBreakpoints(breakpoints: any[]): void;
    removeBreakpoints(breakpoints: any[]): void;
  };
  
  // Tasks API
  tasks: {
    registerTaskProvider(type: string, provider: any): void;
    executeTask(task: any): Promise<any>;
    fetchTasks(filter?: any): Promise<any[]>;
  };
  
  // Terminal API
  terminal: {
    createTerminal(options?: any): any;
    getActiveTerminal(): any | undefined;
    sendText(text: string, addNewLine?: boolean): void;
  };
  
  // File System API
  fs: {
    readFile(uri: string): Promise<Uint8Array>;
    writeFile(uri: string, content: Uint8Array): Promise<void>;
    delete(uri: string): Promise<void>;
    rename(oldUri: string, newUri: string): Promise<void>;
    copy(source: string, destination: string): Promise<void>;
    createDirectory(uri: string): Promise<void>;
    stat(uri: string): Promise<any>;
    readDirectory(uri: string): Promise<[string, number][]>;
  };
  
  // UI API
  ui: {
    createStatusBarItem(alignment?: any, priority?: number): any;
    createOutputChannel(name: string): any;
    createWebviewPanel(viewType: string, title: string, options: any): any;
    registerTreeDataProvider(viewId: string, provider: any): void;
  };
  
  // Configuration API
  configuration: {
    get<T>(section: string, defaultValue?: T): T;
    update(section: string, value: any, target?: any): Promise<void>;
    inspect(section: string): any;
  };
  
  // Events API
  events: {
    onDidChangeActiveTextEditor: any;
    onDidChangeTextDocument: any;
    onDidSaveTextDocument: any;
    onDidOpenTextDocument: any;
    onDidCloseTextDocument: any;
    onDidChangeWorkspaceFolders: any;
    onDidChangeConfiguration: any;
  };
}

class PluginSystemManager {
  private static instance: PluginSystemManager;
  private plugins: Map<string, Plugin> = new Map();
  private pluginAPI: PluginAPI;
  private eventEmitter = new EventTarget();

  public static getInstance(): PluginSystemManager {
    if (!PluginSystemManager.instance) {
      PluginSystemManager.instance = new PluginSystemManager();
    }
    return PluginSystemManager.instance;
  }

  constructor() {
    this.pluginAPI = this.createPluginAPI();
    this.initializeBuiltInPlugins();
  }

  private createPluginAPI(): PluginAPI {
    return {
      window: {
        showInformationMessage: async (message: string) => {
          console.log(`[Plugin Info] ${message}`);
          return message;
        },
        showWarningMessage: async (message: string) => {
          console.warn(`[Plugin Warning] ${message}`);
          return message;
        },
        showErrorMessage: async (message: string) => {
          console.error(`[Plugin Error] ${message}`);
          return message;
        },
        showInputBox: async (options?: any) => {
          return prompt(options?.prompt || 'Enter value:') || undefined;
        },
        showQuickPick: async (items: any[], options?: any) => {
          // Mock implementation - in real IDE, this would show a quick pick UI
          return items[0];
        }
      },
      workspace: {
        openTextDocument: async (uri: string) => ({ uri, content: '' }),
        saveTextDocument: async (document: any) => true,
        findFiles: async (pattern: string) => [],
        createFileSystemWatcher: (pattern: string) => ({ dispose: () => {} })
      },
      editor: {
        getActiveEditor: () => null,
        openEditor: async (uri: string) => ({ uri }),
        closeEditor: async (editor: any) => {},
        insertText: async (text: string, position?: any) => {},
        replaceText: async (range: any, text: string) => {}
      },
      commands: {
        registerCommand: (command: string, callback: (...args: any[]) => any) => {
          console.log(`[Plugin] Registered command: ${command}`);
        },
        executeCommand: async (command: string, ...args: any[]) => {
          console.log(`[Plugin] Executing command: ${command}`, args);
        },
        getCommands: async () => []
      },
      languages: {
        registerHoverProvider: (language: string, provider: any) => {
          console.log(`[Plugin] Registered hover provider for ${language}`);
        },
        registerCompletionItemProvider: (language: string, provider: any) => {
          console.log(`[Plugin] Registered completion provider for ${language}`);
        },
        registerDefinitionProvider: (language: string, provider: any) => {
          console.log(`[Plugin] Registered definition provider for ${language}`);
        },
        registerCodeActionProvider: (language: string, provider: any) => {
          console.log(`[Plugin] Registered code action provider for ${language}`);
        }
      },
      debug: {
        startDebugging: async (folder: any, config: any) => {
          console.log(`[Plugin] Starting debug session`, config);
          return true;
        },
        stopDebugging: async (session?: any) => {
          console.log(`[Plugin] Stopping debug session`);
        },
        addBreakpoints: (breakpoints: any[]) => {
          console.log(`[Plugin] Adding breakpoints`, breakpoints);
        },
        removeBreakpoints: (breakpoints: any[]) => {
          console.log(`[Plugin] Removing breakpoints`, breakpoints);
        }
      },
      tasks: {
        registerTaskProvider: (type: string, provider: any) => {
          console.log(`[Plugin] Registered task provider: ${type}`);
        },
        executeTask: async (task: any) => {
          console.log(`[Plugin] Executing task`, task);
        },
        fetchTasks: async (filter?: any) => []
      },
      terminal: {
        createTerminal: (options?: any) => ({
          sendText: (text: string) => console.log(`[Terminal] ${text}`)
        }),
        getActiveTerminal: () => null,
        sendText: (text: string, addNewLine?: boolean) => {
          console.log(`[Terminal] ${text}`);
        }
      },
      fs: {
        readFile: async (uri: string) => new Uint8Array(),
        writeFile: async (uri: string, content: Uint8Array) => {},
        delete: async (uri: string) => {},
        rename: async (oldUri: string, newUri: string) => {},
        copy: async (source: string, destination: string) => {},
        createDirectory: async (uri: string) => {},
        stat: async (uri: string) => ({ type: 1, size: 0, mtime: Date.now() }),
        readDirectory: async (uri: string) => []
      },
      ui: {
        createStatusBarItem: (alignment?: any, priority?: number) => ({
          text: '',
          show: () => {},
          hide: () => {},
          dispose: () => {}
        }),
        createOutputChannel: (name: string) => ({
          append: (text: string) => console.log(`[${name}] ${text}`),
          appendLine: (text: string) => console.log(`[${name}] ${text}`),
          show: () => {},
          hide: () => {},
          dispose: () => {}
        }),
        createWebviewPanel: (viewType: string, title: string, options: any) => ({
          webview: { html: '', postMessage: () => {} },
          dispose: () => {}
        }),
        registerTreeDataProvider: (viewId: string, provider: any) => {
          console.log(`[Plugin] Registered tree data provider: ${viewId}`);
        }
      },
      configuration: {
        get: <T>(section: string, defaultValue?: T) => defaultValue,
        update: async (section: string, value: any, target?: any) => {},
        inspect: (section: string) => ({ key: section, defaultValue: null })
      },
      events: {
        onDidChangeActiveTextEditor: { dispose: () => {} },
        onDidChangeTextDocument: { dispose: () => {} },
        onDidSaveTextDocument: { dispose: () => {} },
        onDidOpenTextDocument: { dispose: () => {} },
        onDidCloseTextDocument: { dispose: () => {} },
        onDidChangeWorkspaceFolders: { dispose: () => {} },
        onDidChangeConfiguration: { dispose: () => {} }
      }
    };
  }

  private initializeBuiltInPlugins() {
    // Initialize built-in plugins
    const builtInPlugins: PluginManifest[] = [
      {
        id: 'builtin.typescript',
        name: 'TypeScript Language Support',
        version: '1.0.0',
        description: 'TypeScript language support with IntelliSense',
        author: 'DeepBlue IDE Team',
        license: 'MIT',
        keywords: ['typescript', 'javascript', 'language'],
        category: 'language',
        main: 'typescript-plugin.js',
        displayName: 'TypeScript',
        ideVersion: '^2.1.0',
        contributes: {
          languages: [{
            id: 'typescript',
            aliases: ['TypeScript', 'ts'],
            extensions: ['.ts', '.tsx'],
            configuration: 'typescript-configuration.json'
          }],
          commands: [{
            command: 'typescript.restart',
            title: 'Restart TypeScript Server',
            category: 'TypeScript'
          }]
        },
        activationEvents: ['onLanguage:typescript'],
        publisher: 'deepblue-ide',
        isPremium: false
      },
      {
        id: 'builtin.git',
        name: 'Git Integration',
        version: '1.0.0',
        description: 'Git version control integration',
        author: 'DeepBlue IDE Team',
        license: 'MIT',
        keywords: ['git', 'version-control', 'scm'],
        category: 'integration',
        main: 'git-plugin.js',
        displayName: 'Git',
        ideVersion: '^2.1.0',
        contributes: {
          commands: [{
            command: 'git.commit',
            title: 'Commit',
            category: 'Git'
          }, {
            command: 'git.push',
            title: 'Push',
            category: 'Git'
          }],
          views: [{
            id: 'git',
            name: 'Git',
            icon: 'git-branch'
          }]
        },
        activationEvents: ['*'],
        publisher: 'deepblue-ide',
        isPremium: false
      },
      {
        id: 'builtin.dark-theme',
        name: 'DeepBlue Dark Theme',
        version: '1.0.0',
        description: 'Official dark theme for DeepBlue IDE',
        author: 'DeepBlue IDE Team',
        license: 'MIT',
        keywords: ['theme', 'dark', 'ui'],
        category: 'theme',
        main: 'dark-theme.js',
        displayName: 'DeepBlue Dark',
        ideVersion: '^2.1.0',
        contributes: {
          themes: [{
            id: 'deepblue-dark',
            label: 'DeepBlue Dark',
            path: './themes/dark.json',
            uiTheme: 'vs-dark'
          }]
        },
        activationEvents: ['*'],
        publisher: 'deepblue-ide',
        isPremium: false
      }
    ];

    builtInPlugins.forEach(manifest => {
      this.installPlugin(manifest, true);
    });
  }

  async installPlugin(manifest: PluginManifest, isBuiltIn = false): Promise<boolean> {
    try {
      // Validate manifest
      if (!this.validateManifest(manifest)) {
        throw new Error('Invalid plugin manifest');
      }

      // Check dependencies
      if (!await this.checkDependencies(manifest)) {
        throw new Error('Plugin dependencies not satisfied');
      }

      // Create plugin instance
      const plugin: Plugin = {
        manifest,
        isActive: false,
        isInstalled: true,
        isEnabled: true,
        installPath: isBuiltIn ? 'builtin' : `/plugins/${manifest.id}`,
        context: this.createPluginContext(manifest)
      };

      // Register plugin
      this.plugins.set(manifest.id, plugin);

      // Emit installation event
      this.eventEmitter.dispatchEvent(new CustomEvent('plugin:installed', { 
        detail: { pluginId: manifest.id } 
      }));

      console.log(`[Plugin System] Installed plugin: ${manifest.name} (${manifest.id})`);
      return true;

    } catch (error) {
      console.error(`[Plugin System] Failed to install plugin ${manifest.id}:`, error);
      return false;
    }
  }

  async activatePlugin(pluginId: string): Promise<boolean> {
    const plugin = this.plugins.get(pluginId);
    if (!plugin || plugin.isActive) {
      return false;
    }

    try {
      const startTime = performance.now();

      // Load plugin module
      if (!plugin.manifest.main.startsWith('builtin')) {
        // In a real implementation, this would dynamically import the plugin module
        plugin.exports = await this.loadPluginModule(plugin);
      }

      // Call activation function
      if (plugin.exports?.activate) {
        await plugin.exports.activate(plugin.context);
      }

      plugin.isActive = true;
      plugin.activationTime = performance.now() - startTime;

      // Emit activation event
      this.eventEmitter.dispatchEvent(new CustomEvent('plugin:activated', { 
        detail: { pluginId, activationTime: plugin.activationTime } 
      }));

      console.log(`[Plugin System] Activated plugin: ${plugin.manifest.name} (${plugin.activationTime.toFixed(2)}ms)`);
      return true;

    } catch (error) {
      console.error(`[Plugin System] Failed to activate plugin ${pluginId}:`, error);
      return false;
    }
  }

  async deactivatePlugin(pluginId: string): Promise<boolean> {
    const plugin = this.plugins.get(pluginId);
    if (!plugin || !plugin.isActive) {
      return false;
    }

    try {
      // Call deactivation function
      if (plugin.exports?.deactivate) {
        await plugin.exports.deactivate();
      }

      // Dispose subscriptions
      if (plugin.context) {
        plugin.context.subscriptions.forEach(subscription => {
          subscription.dispose();
        });
        plugin.context.subscriptions.length = 0;
      }

      plugin.isActive = false;

      // Emit deactivation event
      this.eventEmitter.dispatchEvent(new CustomEvent('plugin:deactivated', { 
        detail: { pluginId } 
      }));

      console.log(`[Plugin System] Deactivated plugin: ${plugin.manifest.name}`);
      return true;

    } catch (error) {
      console.error(`[Plugin System] Failed to deactivate plugin ${pluginId}:`, error);
      return false;
    }
  }

  async uninstallPlugin(pluginId: string): Promise<boolean> {
    const plugin = this.plugins.get(pluginId);
    if (!plugin) {
      return false;
    }

    try {
      // Deactivate if active
      if (plugin.isActive) {
        await this.deactivatePlugin(pluginId);
      }

      // Remove plugin files (in real implementation)
      // await this.removePluginFiles(plugin.installPath);

      // Remove from registry
      this.plugins.delete(pluginId);

      // Emit uninstall event
      this.eventEmitter.dispatchEvent(new CustomEvent('plugin:uninstalled', { 
        detail: { pluginId } 
      }));

      console.log(`[Plugin System] Uninstalled plugin: ${plugin.manifest.name}`);
      return true;

    } catch (error) {
      console.error(`[Plugin System] Failed to uninstall plugin ${pluginId}:`, error);
      return false;
    }
  }

  getInstalledPlugins(): Plugin[] {
    return Array.from(this.plugins.values());
  }

  getActivePlugins(): Plugin[] {
    return Array.from(this.plugins.values()).filter(plugin => plugin.isActive);
  }

  getPlugin(pluginId: string): Plugin | undefined {
    return this.plugins.get(pluginId);
  }

  async searchPlugins(query: string, category?: string): Promise<PluginManifest[]> {
    // Mock plugin marketplace search
    const mockPlugins: PluginManifest[] = [
      {
        id: 'prettier-plugin',
        name: 'Prettier Code Formatter',
        version: '2.8.0',
        description: 'Code formatter using Prettier',
        author: 'Prettier Community',
        license: 'MIT',
        keywords: ['formatter', 'prettier', 'code-style'],
        category: 'editor',
        main: 'prettier-plugin.js',
        displayName: 'Prettier',
        ideVersion: '^2.0.0',
        contributes: {
          commands: [{
            command: 'prettier.format',
            title: 'Format Document',
            category: 'Prettier'
          }]
        },
        activationEvents: ['onLanguage:javascript', 'onLanguage:typescript'],
        publisher: 'prettier',
        downloads: 50000,
        rating: 4.8,
        isPremium: false
      },
      {
        id: 'ai-copilot',
        name: 'AI Code Copilot',
        version: '1.5.0',
        description: 'AI-powered code completion and suggestions',
        author: 'AI Solutions Inc.',
        license: 'Commercial',
        keywords: ['ai', 'completion', 'copilot'],
        category: 'productivity',
        main: 'ai-copilot.js',
        displayName: 'AI Copilot',
        ideVersion: '^2.1.0',
        contributes: {
          commands: [{
            command: 'ai.suggest',
            title: 'Get AI Suggestion',
            category: 'AI'
          }]
        },
        activationEvents: ['*'],
        publisher: 'ai-solutions',
        downloads: 25000,
        rating: 4.9,
        isPremium: true,
        pricing: {
          type: 'paid',
          price: 9.99,
          currency: 'USD',
          trialDays: 7
        }
      }
    ];

    // Filter by query and category
    return mockPlugins.filter(plugin => {
      const matchesQuery = !query || 
        plugin.name.toLowerCase().includes(query.toLowerCase()) ||
        plugin.description.toLowerCase().includes(query.toLowerCase()) ||
        plugin.keywords.some(keyword => keyword.toLowerCase().includes(query.toLowerCase()));
      
      const matchesCategory = !category || plugin.category === category;
      
      return matchesQuery && matchesCategory;
    });
  }

  private validateManifest(manifest: PluginManifest): boolean {
    // Basic validation
    return !!(
      manifest.id &&
      manifest.name &&
      manifest.version &&
      manifest.main &&
      manifest.publisher &&
      manifest.activationEvents &&
      manifest.ideVersion
    );
  }

  private async checkDependencies(manifest: PluginManifest): Promise<boolean> {
    // Check IDE version compatibility
    const ideVersion = '2.1.0';
    if (!this.isVersionCompatible(ideVersion, manifest.ideVersion)) {
      return false;
    }

    // Check plugin dependencies
    if (manifest.dependencies) {
      for (const [depId, depVersion] of Object.entries(manifest.dependencies)) {
        const depPlugin = this.plugins.get(depId);
        if (!depPlugin || !this.isVersionCompatible(depPlugin.manifest.version, depVersion)) {
          return false;
        }
      }
    }

    return true;
  }

  private isVersionCompatible(current: string, required: string): boolean {
    // Simplified version check (in real implementation, use semver)
    const currentParts = current.split('.').map(Number);
    const requiredParts = required.replace('^', '').split('.').map(Number);
    
    return currentParts[0] >= requiredParts[0] &&
           (currentParts[0] > requiredParts[0] || currentParts[1] >= requiredParts[1]);
  }

  private createPluginContext(manifest: PluginManifest): PluginContext {
    return {
      subscriptions: [],
      workspaceState: this.createStateManager(`workspace.${manifest.id}`),
      globalState: this.createStateManager(`global.${manifest.id}`),
      extensionPath: `/plugins/${manifest.id}`,
      extensionUri: `plugin://${manifest.id}`,
      storagePath: `/storage/plugins/${manifest.id}`,
      logPath: `/logs/plugins/${manifest.id}`,
      globalStoragePath: `/storage/global/plugins/${manifest.id}`
    };
  }

  private createStateManager(namespace: string): PluginStateManager {
    const storage = new Map<string, any>();
    
    return {
      get: <T>(key: string): T | undefined => {
        return storage.get(`${namespace}.${key}`);
      },
      update: async (key: string, value: any): Promise<void> => {
        storage.set(`${namespace}.${key}`, value);
      },
      keys: (): readonly string[] => {
        return Array.from(storage.keys())
          .filter(k => k.startsWith(`${namespace}.`))
          .map(k => k.substring(namespace.length + 1));
      }
    };
  }

  private async loadPluginModule(plugin: Plugin): Promise<any> {
    // In a real implementation, this would dynamically import the plugin module
    // For now, return a mock module
    return {
      activate: async (context: PluginContext) => {
        console.log(`[Plugin] Activating ${plugin.manifest.name}`);
      },
      deactivate: async () => {
        console.log(`[Plugin] Deactivating ${plugin.manifest.name}`);
      }
    };
  }

  // Event system
  onPluginInstalled(callback: (pluginId: string) => void) {
    this.eventEmitter.addEventListener('plugin:installed', (event: any) => {
      callback(event.detail.pluginId);
    });
  }

  onPluginActivated(callback: (pluginId: string, activationTime: number) => void) {
    this.eventEmitter.addEventListener('plugin:activated', (event: any) => {
      callback(event.detail.pluginId, event.detail.activationTime);
    });
  }

  onPluginDeactivated(callback: (pluginId: string) => void) {
    this.eventEmitter.addEventListener('plugin:deactivated', (event: any) => {
      callback(event.detail.pluginId);
    });
  }

  onPluginUninstalled(callback: (pluginId: string) => void) {
    this.eventEmitter.addEventListener('plugin:uninstalled', (event: any) => {
      callback(event.detail.pluginId);
    });
  }
}

export const pluginSystem = PluginSystemManager.getInstance();
export default pluginSystem;