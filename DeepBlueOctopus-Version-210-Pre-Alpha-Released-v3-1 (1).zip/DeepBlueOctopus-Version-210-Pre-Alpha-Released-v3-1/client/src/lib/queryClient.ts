import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  try {
    if (!res.ok) {
      const text = (await res.text()) || res.statusText;
      throw new Error(`${res.status}: ${text}`);
    }
  } catch (error) {
    // Ensure error has meaningful content
    if (error && typeof error === 'object' && Object.keys(error).length === 0) {
      console.error('Empty error object detected, converting to meaningful error');
      throw new Error(`HTTP ${res.status}: ${res.statusText || 'Request failed'}`);
    }
    throw error;
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  try {
    const res = await fetch(url, {
      method,
      headers: data ? { "Content-Type": "application/json" } : {},
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
    });

    await throwIfResNotOk(res);
    return res;
  } catch (error) {
    // Enhance error logging for debugging
    console.error(`API request failed: ${method} ${url}`, error);
    
    // Convert empty objects to meaningful errors
    if (error && typeof error === 'object' && Object.keys(error).length === 0) {
      throw new Error(`API request failed: ${method} ${url} - Unknown error`);
    }
    throw error;
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    try {
      console.log(`Query function starting for ${queryKey[0]}`);
      const res = await fetch(queryKey[0] as string, {
        credentials: "include",
      });

      if (unauthorizedBehavior === "returnNull" && res.status === 401) {
        console.log(`Query function returning null for 401: ${queryKey[0]}`);
        return null;
      }

      await throwIfResNotOk(res);
      const result = await res.json();
      console.log(`Query function successful for ${queryKey[0]}, result:`, result);
      return result;
    } catch (error) {
      console.error(`Query function failed for ${queryKey[0]}:`, error);
      
      // Handle empty object errors silently
      if (error && typeof error === 'object' && Object.keys(error).length === 0) {
        // Return a meaningful error instead of throwing empty object
        throw new Error(`Query failed for ${queryKey[0]} - Network or parsing error`);
      }
      throw error;
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
      onError: (error: unknown) => {
        // Only log meaningful errors
        if (error && typeof error === 'object' && Object.keys(error).length > 0) {
          console.error('React Query error:', error);
        }
      }
    },
    mutations: {
      retry: false,
      onError: (error: unknown) => {
        // Only log meaningful errors
        if (error && typeof error === 'object' && Object.keys(error).length > 0) {
          console.error('React Query mutation error:', error);
        }
      }
    },
  },
});
