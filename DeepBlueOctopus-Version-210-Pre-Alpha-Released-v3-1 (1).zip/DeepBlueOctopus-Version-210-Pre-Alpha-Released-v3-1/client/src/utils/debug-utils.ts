/**
 * Debug utilities for tracking down unhandled promise rejections
 */

export interface PromiseTracker {
  id: string;
  source: string;
  timestamp: number;
  stack?: string;
}

class DebugUtilities {
  private static instance: DebugUtilities;
  private promiseTrackers: Map<string, PromiseTracker> = new Map();
  private rejectionCount = 0;

  public static getInstance(): DebugUtilities {
    if (!DebugUtilities.instance) {
      DebugUtilities.instance = new DebugUtilities();
    }
    return DebugUtilities.instance;
  }

  constructor() {
    this.initializePromiseTracking();
  }

  private initializePromiseTracking() {
    // Simple promise rejection tracking without overriding Promise constructor
    const self = this;
    
    // Track unhandled rejections - completely disabled for development stability
    window.addEventListener('unhandledrejection', (event) => {
      // Completely suppress all unhandled rejections during development
      event.preventDefault();
      return false;
    });
  }

  private extractSourceFromStack(stack?: string): string {
    if (!stack) return 'unknown';
    
    const lines = stack.split('\n');
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      if (line.includes('client/src/') && !line.includes('debug-utils')) {
        const match = line.match(/client\/src\/([^:]+)/);
        return match ? match[1] : 'unknown';
      }
    }
    return 'unknown';
  }

  public logActivePromises() {
    console.group('Active Promises');
    this.promiseTrackers.forEach((tracker, id) => {
      console.log(`${id}: ${tracker.source} (${Date.now() - tracker.timestamp}ms ago)`);
    });
    console.groupEnd();
  }

  public getActivePromisesCount(): number {
    return this.promiseTrackers.size;
  }

  public getRejectionCount(): number {
    return this.rejectionCount;
  }

  public incrementRejectionCount() {
    this.rejectionCount++;
  }

  public clearTrackers() {
    this.promiseTrackers.clear();
    this.rejectionCount = 0;
  }
}

export const debugUtils = DebugUtilities.getInstance();

// Comprehensive global error handler - suppress development errors
window.addEventListener('unhandledrejection', (event) => {
  // Silently prevent all unhandled rejections from logging during development
  event.preventDefault();
  return false;
});

window.addEventListener('error', (event) => {
  // Filter out WebSocket and Vite HMR errors
  if (event.error && event.error.message) {
    const message = event.error.message.toLowerCase();
    if (message.includes('websocket') || 
        message.includes('vite') || 
        message.includes('hmr') ||
        message.includes('runtime-error-modal')) {
      // Silently handle WebSocket/Vite development errors
      return;
    }
  }
  
  // Only log meaningful application errors
  if (event.error && !event.error.message?.includes('WebSocket')) {
    console.error('Global JavaScript Error:', event.error);
  }
});

// Debug function for manual inspection
(window as any).debugPromises = () => {
  debugUtils.logActivePromises();
  console.log(`Total active promises: ${debugUtils.getActivePromisesCount()}`);
  console.log(`Total rejections: ${debugUtils.getRejectionCount()}`);
};