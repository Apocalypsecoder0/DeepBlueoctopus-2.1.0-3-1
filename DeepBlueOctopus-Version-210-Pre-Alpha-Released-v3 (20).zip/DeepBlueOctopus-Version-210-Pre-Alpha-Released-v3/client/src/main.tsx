import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import "./utils/vite-plugin-suppressor"; // Import Vite plugin suppressor - MUST BE FIRST
import "./utils/debug-utils"; // Import debug utilities
import "./utils/websocket-error-handler"; // Import WebSocket error handler
import "./utils/runtime-error-suppressor"; // Import runtime error suppressor

createRoot(document.getElementById("root")!).render(<App />);
