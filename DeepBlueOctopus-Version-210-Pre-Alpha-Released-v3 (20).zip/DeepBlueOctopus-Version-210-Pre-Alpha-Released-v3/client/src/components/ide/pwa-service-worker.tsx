import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { 
  Wifi, WifiOff, Download, RefreshCw, Globe, 
  HardDrive, Smartphone, Monitor, Settings,
  CheckCircle, AlertCircle, Clock, Zap
} from "lucide-react";

interface PWAServiceWorkerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ServiceWorkerStatus {
  registered: boolean;
  active: boolean;
  waiting: boolean;
  state: 'installing' | 'installed' | 'activating' | 'activated' | 'redundant' | null;
}

interface CacheItem {
  url: string;
  size: number;
  lastModified: Date;
  type: 'static' | 'dynamic' | 'api';
}

interface OfflineCapability {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  cacheSize: number;
  lastSync: Date | null;
}

export default function PWAServiceWorker({ isOpen, onClose }: PWAServiceWorkerProps) {
  const [serviceWorkerStatus, setServiceWorkerStatus] = useState<ServiceWorkerStatus>({
    registered: false,
    active: false,
    waiting: false,
    state: null
  });
  
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [cacheItems, setCacheItems] = useState<CacheItem[]>([]);
  const [totalCacheSize, setTotalCacheSize] = useState(0);
  const [offlineCapabilities, setOfflineCapabilities] = useState<OfflineCapability[]>([
    {
      id: 'editor',
      name: 'Code Editor',
      description: 'Continue editing code while offline',
      enabled: true,
      cacheSize: 2.5,
      lastSync: new Date()
    },
    {
      id: 'files',
      name: 'File Management',
      description: 'Access and modify project files offline',
      enabled: true,
      cacheSize: 1.8,
      lastSync: new Date()
    },
    {
      id: 'terminal',
      name: 'Terminal Commands',
      description: 'Run cached terminal commands offline',
      enabled: false,
      cacheSize: 0.5,
      lastSync: null
    },
    {
      id: 'ai-assistant',
      name: 'AI Assistant',
      description: 'Limited AI assistance with cached responses',
      enabled: false,
      cacheSize: 3.2,
      lastSync: null
    }
  ]);

  const { toast } = useToast();

  useEffect(() => {
    // Check service worker support and status
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then((registration) => {
        setServiceWorkerStatus({
          registered: true,
          active: !!registration.active,
          waiting: !!registration.waiting,
          state: registration.active?.state || null
        });
      });

      // Monitor service worker updates
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        window.location.reload();
      });
    }

    // Monitor online/offline status
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Load cache information
    loadCacheInfo();

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const loadCacheInfo = async () => {
    if ('caches' in window) {
      try {
        const cacheNames = await caches.keys();
        let totalSize = 0;
        const items: CacheItem[] = [];

        for (const cacheName of cacheNames) {
          const cache = await caches.open(cacheName);
          const requests = await cache.keys();
          
          for (const request of requests) {
            const response = await cache.match(request);
            if (response) {
              const blob = await response.blob();
              const size = blob.size;
              totalSize += size;
              
              items.push({
                url: request.url,
                size,
                lastModified: new Date(response.headers.get('date') || Date.now()),
                type: request.url.includes('/api/') ? 'api' : 
                      request.url.includes('.js') || request.url.includes('.css') ? 'static' : 'dynamic'
              });
            }
          }
        }

        setCacheItems(items);
        setTotalCacheSize(totalSize);
      } catch (error) {
        console.error('Error loading cache info:', error);
      }
    }
  };

  const registerServiceWorker = async () => {
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.register('/sw.js');
        
        setServiceWorkerStatus({
          registered: true,
          active: !!registration.active,
          waiting: !!registration.waiting,
          state: registration.active?.state || 'installing'
        });

        toast({
          title: "Service Worker Registered",
          description: "PWA functionality is now available",
        });
      } catch (error) {
        toast({
          title: "Registration Failed",
          description: "Failed to register service worker",
          variant: "destructive",
        });
      }
    }
  };

  const updateServiceWorker = async () => {
    if ('serviceWorker' in navigator) {
      const registration = await navigator.serviceWorker.ready;
      registration.update();
      
      toast({
        title: "Update Initiated",
        description: "Checking for service worker updates",
      });
    }
  };

  const clearCache = async () => {
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      await Promise.all(cacheNames.map(name => caches.delete(name)));
      
      setCacheItems([]);
      setTotalCacheSize(0);
      
      toast({
        title: "Cache Cleared",
        description: "All cached data has been removed",
      });
    }
  };

  const toggleOfflineCapability = (id: string) => {
    setOfflineCapabilities(prev => prev.map(cap => 
      cap.id === id ? { ...cap, enabled: !cap.enabled } : cap
    ));
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Smartphone className="h-5 w-5" />
            Progressive Web App & Offline Functionality
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="status" className="flex-1">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="status">Service Worker</TabsTrigger>
            <TabsTrigger value="offline">Offline Features</TabsTrigger>
            <TabsTrigger value="cache">Cache Management</TabsTrigger>
            <TabsTrigger value="install">PWA Install</TabsTrigger>
          </TabsList>

          <TabsContent value="status" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  Connection Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  {isOnline ? (
                    <>
                      <Wifi className="h-5 w-5 text-green-500" />
                      <Badge variant="default" className="bg-green-500">Online</Badge>
                      <span className="text-sm text-muted-foreground">Full functionality available</span>
                    </>
                  ) : (
                    <>
                      <WifiOff className="h-5 w-5 text-red-500" />
                      <Badge variant="destructive">Offline</Badge>
                      <span className="text-sm text-muted-foreground">Limited functionality available</span>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  Service Worker Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <Label>Registered</Label>
                    {serviceWorkerStatus.registered ? (
                      <CheckCircle className="h-4 w-4 text-green-500" />
                    ) : (
                      <AlertCircle className="h-4 w-4 text-red-500" />
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Active</Label>
                    {serviceWorkerStatus.active ? (
                      <CheckCircle className="h-4 w-4 text-green-500" />
                    ) : (
                      <Clock className="h-4 w-4 text-yellow-500" />
                    )}
                  </div>
                </div>

                {serviceWorkerStatus.state && (
                  <div className="flex items-center gap-2">
                    <Label>State:</Label>
                    <Badge variant="outline">{serviceWorkerStatus.state}</Badge>
                  </div>
                )}

                <div className="flex gap-2">
                  {!serviceWorkerStatus.registered && (
                    <Button onClick={registerServiceWorker}>
                      <Download className="h-4 w-4 mr-2" />
                      Register Service Worker
                    </Button>
                  )}
                  <Button variant="outline" onClick={updateServiceWorker}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Check for Updates
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="offline" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Offline Capabilities</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="space-y-4">
                    {offlineCapabilities.map((capability) => (
                      <div key={capability.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-medium">{capability.name}</h4>
                            {capability.enabled && <Badge variant="default" className="bg-green-500">Enabled</Badge>}
                          </div>
                          <p className="text-sm text-muted-foreground">{capability.description}</p>
                          <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                            <span>Cache: {capability.cacheSize} MB</span>
                            <span>
                              Last Sync: {capability.lastSync ? capability.lastSync.toLocaleDateString() : 'Never'}
                            </span>
                          </div>
                        </div>
                        <Switch
                          checked={capability.enabled}
                          onCheckedChange={() => toggleOfflineCapability(capability.id)}
                        />
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="cache" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <HardDrive className="h-4 w-4" />
                    Cache Storage
                  </span>
                  <Badge variant="outline">{formatBytes(totalCacheSize)}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2 mb-4">
                  <Button variant="outline" onClick={loadCacheInfo}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Refresh
                  </Button>
                  <Button variant="destructive" onClick={clearCache}>
                    Clear All Cache
                  </Button>
                </div>

                <ScrollArea className="h-48">
                  <div className="space-y-2">
                    {cacheItems.map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-2 border rounded text-sm">
                        <div className="flex-1 truncate">
                          <div className="font-mono text-xs">{item.url.split('/').pop()}</div>
                          <div className="text-muted-foreground text-xs">
                            {item.lastModified.toLocaleDateString()}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={item.type === 'static' ? 'default' : item.type === 'api' ? 'secondary' : 'outline'}>
                            {item.type}
                          </Badge>
                          <span className="text-xs">{formatBytes(item.size)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="install" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Monitor className="h-4 w-4" />
                  Install as PWA
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  Install DeepBlue:Octopus IDE as a Progressive Web App to access it like a native application.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium mb-2">Desktop Installation</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• Click the install button in your browser</li>
                      <li>• Add to desktop for quick access</li>
                      <li>• Works offline when installed</li>
                      <li>• Automatic updates</li>
                    </ul>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium mb-2">Mobile Installation</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• Open in mobile browser</li>
                      <li>• Tap "Add to Home Screen"</li>
                      <li>• Full-screen app experience</li>
                      <li>• Push notifications support</li>
                    </ul>
                  </div>
                </div>

                <div className="p-4 bg-muted rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="h-4 w-4 text-blue-500" />
                    <span className="font-medium">PWA Benefits</span>
                  </div>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Faster loading times with caching</li>
                    <li>• Work offline with cached content</li>
                    <li>• Native app-like experience</li>
                    <li>• Automatic background updates</li>
                    <li>• Reduced data usage</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}