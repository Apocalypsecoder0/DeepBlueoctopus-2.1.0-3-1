import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  Folder, File, Download, Star, Zap, 
  Code, Globe, Smartphone, Database, 
  Gamepad2, Brain, ShoppingCart, Calendar,
  Users, Shield, BarChart3, Camera
} from "lucide-react";

interface AdvancedProjectTemplatesProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ProjectTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: React.ReactNode;
  tags: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  popularity: number;
  downloadCount: number;
  rating: number;
  author: string;
  version: string;
  lastUpdated: Date;
  fileStructure: TemplateFile[];
  dependencies: string[];
  scripts: Record<string, string>;
  features: string[];
  preview?: string;
  documentation?: string;
}

interface TemplateFile {
  path: string;
  content: string;
  type: 'file' | 'folder';
  language?: string;
}

const PROJECT_TEMPLATES: ProjectTemplate[] = [
  {
    id: 'react-typescript-app',
    name: 'React TypeScript App',
    description: 'Modern React application with TypeScript, Vite, and comprehensive tooling setup',
    category: 'Web Development',
    icon: <Code className="w-6 h-6 text-blue-500" />,
    tags: ['react', 'typescript', 'vite', 'eslint', 'prettier'],
    difficulty: 'intermediate',
    popularity: 98,
    downloadCount: 125000,
    rating: 4.9,
    author: 'DeepBlue Team',
    version: '2.1.0',
    lastUpdated: new Date('2024-07-04'),
    fileStructure: [
      {
        path: 'src/App.tsx',
        content: `import React from 'react';\nimport './App.css';\n\nfunction App() {\n  return (\n    <div className="App">\n      <header className="App-header">\n        <h1>Welcome to React TypeScript</h1>\n        <p>Built with DeepBlue IDE</p>\n      </header>\n    </div>\n  );\n}\n\nexport default App;`,
        type: 'file',
        language: 'typescript'
      },
      {
        path: 'src/main.tsx',
        content: `import React from 'react';\nimport ReactDOM from 'react-dom/client';\nimport App from './App';\nimport './index.css';\n\nReactDOM.createRoot(document.getElementById('root')!).render(\n  <React.StrictMode>\n    <App />\n  </React.StrictMode>\n);`,
        type: 'file',
        language: 'typescript'
      }
    ],
    dependencies: ['react', 'react-dom', '@types/react', '@types/react-dom', 'typescript', 'vite'],
    scripts: {
      'dev': 'vite',
      'build': 'tsc && vite build',
      'preview': 'vite preview'
    },
    features: ['Hot Module Replacement', 'TypeScript Support', 'ESLint Configuration', 'Prettier Setup', 'Vite Build Tool'],
    preview: 'A clean React application with TypeScript support and modern development tools.',
    documentation: 'Comprehensive React TypeScript starter with best practices and development tools.'
  },
  {
    id: 'nextjs-ecommerce',
    name: 'Next.js E-Commerce Platform',
    description: 'Full-featured e-commerce platform with Next.js, Stripe integration, and admin dashboard',
    category: 'E-Commerce',
    icon: <ShoppingCart className="w-6 h-6 text-green-500" />,
    tags: ['nextjs', 'ecommerce', 'stripe', 'tailwind', 'prisma'],
    difficulty: 'advanced',
    popularity: 92,
    downloadCount: 45000,
    rating: 4.8,
    author: 'Commerce Team',
    version: '1.5.2',
    lastUpdated: new Date('2024-07-02'),
    fileStructure: [
      {
        path: 'pages/index.tsx',
        content: `import React from 'react';\nimport { GetServerSideProps } from 'next';\nimport ProductGrid from '../components/ProductGrid';\n\ninterface HomeProps {\n  products: Product[];\n}\n\nexport default function Home({ products }: HomeProps) {\n  return (\n    <div>\n      <h1>Welcome to Our Store</h1>\n      <ProductGrid products={products} />\n    </div>\n  );\n}`,
        type: 'file',
        language: 'typescript'
      }
    ],
    dependencies: ['next', 'react', 'stripe', '@prisma/client', 'tailwindcss'],
    scripts: {
      'dev': 'next dev',
      'build': 'next build',
      'start': 'next start'
    },
    features: ['Product Catalog', 'Shopping Cart', 'Stripe Payments', 'User Authentication', 'Admin Dashboard', 'Order Management'],
    preview: 'Complete e-commerce solution with payment processing and inventory management.',
    documentation: 'Full e-commerce platform with modern React patterns and payment integration.'
  },
  {
    id: 'node-express-api',
    name: 'Node.js Express API',
    description: 'RESTful API server with Express, TypeScript, JWT authentication, and PostgreSQL',
    category: 'Backend Development',
    icon: <Database className="w-6 h-6 text-purple-500" />,
    tags: ['nodejs', 'express', 'typescript', 'jwt', 'postgresql'],
    difficulty: 'intermediate',
    popularity: 89,
    downloadCount: 78000,
    rating: 4.7,
    author: 'Backend Team',
    version: '3.2.1',
    lastUpdated: new Date('2024-07-01'),
    fileStructure: [
      {
        path: 'src/server.ts',
        content: `import express from 'express';\nimport cors from 'cors';\nimport helmet from 'helmet';\nimport { router } from './routes';\n\nconst app = express();\nconst PORT = process.env.PORT || 3000;\n\napp.use(helmet());\napp.use(cors());\napp.use(express.json());\napp.use('/api', router);\n\napp.listen(PORT, () => {\n  console.log(\`Server running on port \${PORT}\`);\n});`,
        type: 'file',
        language: 'typescript'
      }
    ],
    dependencies: ['express', 'typescript', 'jsonwebtoken', 'bcrypt', 'pg', 'cors', 'helmet'],
    scripts: {
      'dev': 'nodemon src/server.ts',
      'build': 'tsc',
      'start': 'node dist/server.js'
    },
    features: ['JWT Authentication', 'Database Integration', 'Input Validation', 'Error Handling', 'Security Middleware', 'API Documentation'],
    preview: 'Production-ready API server with authentication and database integration.',
    documentation: 'Comprehensive API server template with security best practices.'
  },
  {
    id: 'flutter-mobile-app',
    name: 'Flutter Mobile App',
    description: 'Cross-platform mobile application with Flutter, state management, and native features',
    category: 'Mobile Development',
    icon: <Smartphone className="w-6 h-6 text-cyan-500" />,
    tags: ['flutter', 'dart', 'mobile', 'bloc', 'firebase'],
    difficulty: 'advanced',
    popularity: 85,
    downloadCount: 32000,
    rating: 4.6,
    author: 'Mobile Team',
    version: '2.0.3',
    lastUpdated: new Date('2024-06-28'),
    fileStructure: [
      {
        path: 'lib/main.dart',
        content: `import 'package:flutter/material.dart';\nimport 'package:flutter_bloc/flutter_bloc.dart';\nimport 'screens/home_screen.dart';\n\nvoid main() {\n  runApp(MyApp());\n}\n\nclass MyApp extends StatelessWidget {\n  @override\n  Widget build(BuildContext context) {\n    return MaterialApp(\n      title: 'Flutter App',\n      home: HomeScreen(),\n    );\n  }\n}`,
        type: 'file',
        language: 'dart'
      }
    ],
    dependencies: ['flutter', 'flutter_bloc', 'http', 'shared_preferences', 'firebase_core'],
    scripts: {
      'run': 'flutter run',
      'build': 'flutter build apk',
      'test': 'flutter test'
    },
    features: ['State Management (BLoC)', 'Firebase Integration', 'Native Device Features', 'Responsive Design', 'Push Notifications', 'Offline Support'],
    preview: 'Professional mobile app with modern Flutter architecture and native integrations.',
    documentation: 'Complete mobile app template with best practices and platform integrations.'
  },
  {
    id: 'python-ml-project',
    name: 'Python Machine Learning Project',
    description: 'Data science project with Jupyter notebooks, scikit-learn, and comprehensive analysis tools',
    category: 'Data Science',
    icon: <Brain className="w-6 h-6 text-orange-500" />,
    tags: ['python', 'ml', 'jupyter', 'pandas', 'scikit-learn'],
    difficulty: 'advanced',
    popularity: 91,
    downloadCount: 56000,
    rating: 4.8,
    author: 'Data Science Team',
    version: '1.8.0',
    lastUpdated: new Date('2024-07-03'),
    fileStructure: [
      {
        path: 'src/main.py',
        content: `import pandas as pd\nimport numpy as np\nfrom sklearn.model_selection import train_test_split\nfrom sklearn.ensemble import RandomForestClassifier\nfrom sklearn.metrics import accuracy_score\n\n# Load and preprocess data\ndef load_data():\n    # Your data loading logic here\n    pass\n\n# Train model\ndef train_model(X, y):\n    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)\n    model = RandomForestClassifier()\n    model.fit(X_train, y_train)\n    return model, X_test, y_test\n\nif __name__ == "__main__":\n    print("Machine Learning Project Started")`,
        type: 'file',
        language: 'python'
      }
    ],
    dependencies: ['pandas', 'numpy', 'scikit-learn', 'matplotlib', 'seaborn', 'jupyter'],
    scripts: {
      'train': 'python src/main.py',
      'notebook': 'jupyter lab',
      'test': 'pytest tests/'
    },
    features: ['Data Analysis Pipeline', 'Model Training', 'Visualization Tools', 'Jupyter Integration', 'Model Evaluation', 'Feature Engineering'],
    preview: 'Complete ML workflow with data analysis, model training, and evaluation tools.',
    documentation: 'Comprehensive machine learning project template with industry best practices.'
  },
  {
    id: 'unity-game-project',
    name: 'Unity Game Project',
    description: '2D/3D game development project with Unity, C# scripting, and game mechanics',
    category: 'Game Development',
    icon: <Gamepad2 className="w-6 h-6 text-red-500" />,
    tags: ['unity', 'csharp', 'gamedev', '2d', '3d'],
    difficulty: 'advanced',
    popularity: 87,
    downloadCount: 41000,
    rating: 4.7,
    author: 'Game Dev Team',
    version: '2022.3.1',
    lastUpdated: new Date('2024-06-30'),
    fileStructure: [
      {
        path: 'Assets/Scripts/PlayerController.cs',
        content: `using UnityEngine;\n\npublic class PlayerController : MonoBehaviour\n{\n    public float speed = 5f;\n    public float jumpForce = 10f;\n    \n    private Rigidbody2D rb;\n    private bool isGrounded;\n    \n    void Start()\n    {\n        rb = GetComponent<Rigidbody2D>();\n    }\n    \n    void Update()\n    {\n        Move();\n        Jump();\n    }\n    \n    void Move()\n    {\n        float horizontal = Input.GetAxis("Horizontal");\n        transform.Translate(Vector2.right * horizontal * speed * Time.deltaTime);\n    }\n    \n    void Jump()\n    {\n        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)\n        {\n            rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);\n        }\n    }\n}`,
        type: 'file',
        language: 'csharp'
      }
    ],
    dependencies: ['unity-engine', 'unity-editor'],
    scripts: {
      'build': 'Unity -batchmode -buildTarget StandaloneWindows64',
      'test': 'Unity -runTests'
    },
    features: ['Player Controller', 'Physics System', 'Input Management', 'Scene Management', 'Audio System', 'UI Framework'],
    preview: 'Complete game development setup with player mechanics and game systems.',
    documentation: 'Professional game development template with Unity best practices.'
  }
];

export default function AdvancedProjectTemplates({ isOpen, onClose }: AdvancedProjectTemplatesProps) {
  const [selectedTemplate, setSelectedTemplate] = useState<ProjectTemplate | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [customProjectName, setCustomProjectName] = useState("");
  const [customDescription, setCustomDescription] = useState("");
  const [includeTests, setIncludeTests] = useState(true);
  const [includeDocs, setIncludeDocs] = useState(true);
  const [includeCI, setIncludeCI] = useState(false);

  const { toast } = useToast();
  const { createProject, addFile } = useIDEState();

  const categories = ["All", "Web Development", "Mobile Development", "Backend Development", "Data Science", "Game Development", "E-Commerce"];

  const filteredTemplates = PROJECT_TEMPLATES.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategory === "All" || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-100 text-green-800';
      case 'intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'advanced': return 'bg-orange-100 text-orange-800';
      case 'expert': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const createProjectFromTemplate = async (template: ProjectTemplate) => {
    const projectName = customProjectName || template.name;
    
    try {
      // Create project
      const projectId = await createProject(
        projectName,
        customDescription || template.description
      );

      // Add template files
      for (const file of template.fileStructure) {
        addFile({
          name: file.path.split('/').pop() || 'untitled',
          path: file.path,
          content: file.content,
          language: file.language || 'text',
          isDirectory: file.type === 'folder',
          projectId: projectId
        });
      }

      // Add additional files based on options
      if (includeTests) {
        addFile({
          name: 'example.test.js',
          path: '/tests/example.test.js',
          content: `// Test file for ${projectName}\ndescribe('${projectName}', () => {\n  test('should work correctly', () => {\n    expect(true).toBe(true);\n  });\n});`,
          language: 'javascript',
          isDirectory: false,
          projectId: projectId
        });
      }

      if (includeDocs) {
        addFile({
          name: 'README.md',
          path: '/README.md',
          content: `# ${projectName}\n\n${template.description}\n\n## Getting Started\n\n1. Install dependencies\n2. Run the development server\n3. Start coding!\n\n## Features\n\n${template.features.map(f => `- ${f}`).join('\n')}\n\n## Documentation\n\n${template.documentation}`,
          language: 'markdown',
          isDirectory: false,
          projectId: projectId
        });
      }

      if (includeCI) {
        addFile({
          name: 'ci.yml',
          path: '/.github/workflows/ci.yml',
          content: `name: CI\n\non: [push, pull_request]\n\njobs:\n  test:\n    runs-on: ubuntu-latest\n    steps:\n    - uses: actions/checkout@v2\n    - name: Setup Node\n      uses: actions/setup-node@v2\n      with:\n        node-version: '18'\n    - run: npm install\n    - run: npm test`,
          language: 'yaml',
          isDirectory: false,
          projectId: projectId
        });
      }

      toast({
        title: "Project Created",
        description: `${projectName} created from ${template.name} template`,
      });

      onClose();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create project from template",
      });
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Folder className="w-5 h-5" />
            Advanced Project Templates
            <Badge variant="outline" className="ml-2">
              {filteredTemplates.length} Templates
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex gap-6 overflow-hidden">
          {/* Left Panel - Template Browser */}
          <div className="flex-1 space-y-4">
            {/* Search and Filters */}
            <div className="flex gap-3">
              <Input
                placeholder="Search templates..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1"
              />
              <select 
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 py-2 border rounded-md bg-background"
              >
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>

            {/* Template Grid */}
            <ScrollArea className="flex-1">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {filteredTemplates.map((template) => (
                  <Card 
                    key={template.id}
                    className={`cursor-pointer transition-all hover:shadow-lg ${
                      selectedTemplate?.id === template.id ? 'ring-2 ring-blue-500' : ''
                    }`}
                    onClick={() => setSelectedTemplate(template)}
                  >
                    <CardHeader>
                      <CardTitle className="flex items-center gap-3">
                        {template.icon}
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span>{template.name}</span>
                            <Badge className={getDifficultyColor(template.difficulty)}>
                              {template.difficulty}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex items-center gap-1">
                              <Star className="w-3 h-3 text-yellow-500 fill-current" />
                              <span className="text-xs">{template.rating}</span>
                            </div>
                            <span className="text-xs text-gray-500">•</span>
                            <span className="text-xs text-gray-500">
                              {template.downloadCount.toLocaleString()} downloads
                            </span>
                          </div>
                        </div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600 mb-3">{template.description}</p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex gap-1">
                          {template.tags.slice(0, 3).map((tag, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {template.tags.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{template.tags.length - 3}
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            v{template.version}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            by {template.author}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* Right Panel - Template Details & Configuration */}
          {selectedTemplate && (
            <div className="w-96 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {selectedTemplate.icon}
                    {selectedTemplate.name}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600">{selectedTemplate.description}</p>
                  
                  {/* Project Configuration */}
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="projectName">Project Name</Label>
                      <Input
                        id="projectName"
                        value={customProjectName}
                        onChange={(e) => setCustomProjectName(e.target.value)}
                        placeholder={selectedTemplate.name}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="projectDescription">Description</Label>
                      <Textarea
                        id="projectDescription"
                        value={customDescription}
                        onChange={(e) => setCustomDescription(e.target.value)}
                        placeholder={selectedTemplate.description}
                        rows={3}
                      />
                    </div>
                  </div>

                  {/* Options */}
                  <div className="space-y-3">
                    <h4 className="text-sm font-medium">Additional Options</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm">Include Tests</Label>
                        <Switch
                          checked={includeTests}
                          onCheckedChange={setIncludeTests}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-sm">Include Documentation</Label>
                        <Switch
                          checked={includeDocs}
                          onCheckedChange={setIncludeDocs}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-sm">Include CI/CD</Label>
                        <Switch
                          checked={includeCI}
                          onCheckedChange={setIncludeCI}
                        />
                      </div>
                    </div>
                  </div>

                  <Button 
                    className="w-full"
                    onClick={() => createProjectFromTemplate(selectedTemplate)}
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    Create Project
                  </Button>
                </CardContent>
              </Card>

              {/* Template Details */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Template Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Tabs defaultValue="features">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="features" className="text-xs">Features</TabsTrigger>
                      <TabsTrigger value="structure" className="text-xs">Structure</TabsTrigger>
                      <TabsTrigger value="dependencies" className="text-xs">Dependencies</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="features" className="space-y-2">
                      {selectedTemplate.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm">
                          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                          <span>{feature}</span>
                        </div>
                      ))}
                    </TabsContent>
                    
                    <TabsContent value="structure" className="space-y-1">
                      {selectedTemplate.fileStructure.map((file, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-xs">
                          <File className="w-3 h-3 text-gray-500" />
                          <span className="font-mono">{file.path}</span>
                        </div>
                      ))}
                    </TabsContent>
                    
                    <TabsContent value="dependencies" className="space-y-1">
                      {selectedTemplate.dependencies.map((dep, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-xs">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                          <span className="font-mono">{dep}</span>
                        </div>
                      ))}
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 border-t">
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Folder className="w-4 h-4" />
              <span>{filteredTemplates.length} Templates Available</span>
            </div>
            <div className="flex items-center gap-1">
              <Download className="w-4 h-4" />
              <span>Ready to Create</span>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            <Button disabled={!selectedTemplate}>
              <Star className="w-4 h-4 mr-2" />
              Star Template
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}