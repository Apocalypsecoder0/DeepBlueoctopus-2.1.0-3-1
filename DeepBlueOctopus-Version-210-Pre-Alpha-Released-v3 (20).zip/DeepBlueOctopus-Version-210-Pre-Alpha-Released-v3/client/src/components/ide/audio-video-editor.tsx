import { useState, useEffect, useRef, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SoundButton } from "@/components/ui/sound-system";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import {
  Play,
  Pause,
  Square,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Music,
  Video,
  Film,
  Headphones,
  BarChart3,
  Settings,
  Download,
  Upload,
  Save,
  Copy,
  Trash2,
  Scissors,
  Plus,
  Minus,
  RefreshCw,
  ZoomIn,
  ZoomOut,
  Layers,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Maximize,
  Minimize,
  FastForward,
  Rewind,
  Repeat,
  Shuffle
} from "lucide-react";

interface AudioVideoEditorProps {
  isOpen: boolean;
  onClose: () => void;
}

interface AudioTrack {
  id: string;
  name: string;
  type: 'audio' | 'music' | 'voice' | 'sfx';
  duration: number;
  volume: number;
  muted: boolean;
  solo: boolean;
  visible: boolean;
  locked: boolean;
  waveform: number[];
  effects: AudioEffect[];
  startTime: number;
  endTime: number;
}

interface VideoTrack {
  id: string;
  name: string;
  type: 'video' | 'image' | 'text' | 'shape';
  duration: number;
  visible: boolean;
  locked: boolean;
  opacity: number;
  effects: VideoEffect[];
  startTime: number;
  endTime: number;
  properties: {
    width: number;
    height: number;
    x: number;
    y: number;
    rotation: number;
    scale: number;
  };
}

interface AudioEffect {
  id: string;
  name: string;
  type: 'reverb' | 'delay' | 'distortion' | 'equalizer' | 'compressor' | 'chorus' | 'flanger';
  enabled: boolean;
  parameters: Record<string, number>;
}

interface VideoEffect {
  id: string;
  name: string;
  type: 'blur' | 'brightness' | 'contrast' | 'saturation' | 'hue' | 'sepia' | 'grayscale' | 'invert';
  enabled: boolean;
  parameters: Record<string, number>;
}

interface TimelineMarker {
  id: string;
  time: number;
  label: string;
  color: string;
}

export default function AudioVideoEditor({ isOpen, onClose }: AudioVideoEditorProps) {
  const [activeTab, setActiveTab] = useState('timeline');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalDuration, setTotalDuration] = useState(120); // 2 minutes
  const [zoom, setZoom] = useState(1);
  const [selectedTrack, setSelectedTrack] = useState<AudioTrack | VideoTrack | null>(null);
  const [audioTracks, setAudioTracks] = useState<AudioTrack[]>([]);
  const [videoTracks, setVideoTracks] = useState<VideoTrack[]>([]);
  const [markers, setMarkers] = useState<TimelineMarker[]>([]);
  const [masterVolume, setMasterVolume] = useState(1);
  const [isRecording, setIsRecording] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [loopEnabled, setLoopEnabled] = useState(false);
  
  const timelineRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  const audioEffectPresets = [
    { name: 'Reverb Hall', type: 'reverb', parameters: { wetness: 0.3, roomSize: 0.8, decay: 0.6 } },
    { name: 'Echo Delay', type: 'delay', parameters: { time: 0.3, feedback: 0.4, wetness: 0.3 } },
    { name: 'Warm Distortion', type: 'distortion', parameters: { drive: 0.5, tone: 0.6, level: 0.8 } },
    { name: 'Voice Compressor', type: 'compressor', parameters: { threshold: -12, ratio: 4, attack: 0.01, release: 0.1 } },
    { name: 'Chorus Wide', type: 'chorus', parameters: { rate: 0.5, depth: 0.6, mix: 0.4 } }
  ];

  const videoEffectPresets = [
    { name: 'Cinematic Blur', type: 'blur', parameters: { radius: 2, quality: 0.8 } },
    { name: 'High Contrast', type: 'contrast', parameters: { amount: 1.3 } },
    { name: 'Vintage Sepia', type: 'sepia', parameters: { amount: 0.7 } },
    { name: 'Desaturated', type: 'saturation', parameters: { amount: 0.3 } },
    { name: 'Film Grain', type: 'brightness', parameters: { amount: 1.1, noise: 0.2 } }
  ];

  const soundLibrary = [
    { id: 'kick', name: 'Kick Drum', category: 'Drums', duration: 0.5, type: 'sfx' },
    { id: 'snare', name: 'Snare Hit', category: 'Drums', duration: 0.3, type: 'sfx' },
    { id: 'hihat', name: 'Hi-Hat', category: 'Drums', duration: 0.1, type: 'sfx' },
    { id: 'bass', name: 'Bass Drop', category: 'Bass', duration: 2.0, type: 'music' },
    { id: 'piano', name: 'Piano Chord', category: 'Melodic', duration: 1.5, type: 'music' },
    { id: 'voice', name: 'Voice Sample', category: 'Vocal', duration: 3.0, type: 'voice' },
    { id: 'ambient', name: 'Ambient Pad', category: 'Atmospheric', duration: 8.0, type: 'music' },
    { id: 'whoosh', name: 'Whoosh SFX', category: 'Effects', duration: 1.2, type: 'sfx' }
  ];

  const createAudioTrack = useCallback((soundId: string) => {
    const sound = soundLibrary.find(s => s.id === soundId);
    if (!sound) return;

    const newTrack: AudioTrack = {
      id: Date.now().toString(),
      name: sound.name,
      type: sound.type as AudioTrack['type'],
      duration: sound.duration,
      volume: 0.8,
      muted: false,
      solo: false,
      visible: true,
      locked: false,
      waveform: Array.from({ length: 100 }, () => Math.random() * 0.8 + 0.1),
      effects: [],
      startTime: currentTime,
      endTime: currentTime + sound.duration
    };

    setAudioTracks([...audioTracks, newTrack]);
  }, [audioTracks, currentTime, soundLibrary]);

  const createVideoTrack = useCallback((type: VideoTrack['type']) => {
    const newTrack: VideoTrack = {
      id: Date.now().toString(),
      name: `${type}_${videoTracks.length + 1}`,
      type,
      duration: 5.0,
      visible: true,
      locked: false,
      opacity: 1,
      effects: [],
      startTime: currentTime,
      endTime: currentTime + 5.0,
      properties: {
        width: 1920,
        height: 1080,
        x: 0,
        y: 0,
        rotation: 0,
        scale: 1
      }
    };

    setVideoTracks([...videoTracks, newTrack]);
  }, [videoTracks, currentTime]);

  const togglePlayback = useCallback(() => {
    if (isPlaying) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      let startTime = Date.now() - (currentTime * 1000 / playbackSpeed);
      
      const animate = () => {
        const elapsed = (Date.now() - startTime) * playbackSpeed / 1000;
        const newTime = elapsed;
        
        if (newTime >= totalDuration) {
          if (loopEnabled) {
            setCurrentTime(0);
            startTime = Date.now();
          } else {
            setIsPlaying(false);
            setCurrentTime(totalDuration);
            return;
          }
        } else {
          setCurrentTime(newTime);
        }
        
        animationRef.current = requestAnimationFrame(animate);
      };
      
      animate();
    }
  }, [isPlaying, currentTime, totalDuration, playbackSpeed, loopEnabled]);

  const drawWaveform = useCallback((canvas: HTMLCanvasElement, waveform: number[], color: string) => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.beginPath();

    const barWidth = canvas.width / waveform.length;
    
    for (let i = 0; i < waveform.length; i++) {
      const barHeight = waveform[i] * canvas.height;
      const x = i * barWidth;
      const y = (canvas.height - barHeight) / 2;
      
      ctx.moveTo(x, y);
      ctx.lineTo(x, y + barHeight);
    }
    
    ctx.stroke();
  }, []);

  const addMarker = useCallback(() => {
    const newMarker: TimelineMarker = {
      id: Date.now().toString(),
      time: currentTime,
      label: `Marker ${markers.length + 1}`,
      color: '#3b82f6'
    };
    setMarkers([...markers, newMarker]);
  }, [currentTime, markers]);

  const addAudioEffect = useCallback((trackId: string, effectType: AudioEffect['type']) => {
    const preset = audioEffectPresets.find(p => p.type === effectType);
    if (!preset) return;

    const newEffect: AudioEffect = {
      id: Date.now().toString(),
      name: preset.name,
      type: effectType,
      enabled: true,
      parameters: preset.parameters
    };

    setAudioTracks(tracks =>
      tracks.map(track =>
        track.id === trackId
          ? { ...track, effects: [...track.effects, newEffect] }
          : track
      )
    );
  }, [audioEffectPresets]);

  const addVideoEffect = useCallback((trackId: string, effectType: VideoEffect['type']) => {
    const preset = videoEffectPresets.find(p => p.type === effectType);
    if (!preset) return;

    const newEffect: VideoEffect = {
      id: Date.now().toString(),
      name: preset.name,
      type: effectType,
      enabled: true,
      parameters: preset.parameters
    };

    setVideoTracks(tracks =>
      tracks.map(track =>
        track.id === trackId
          ? { ...track, effects: [...track.effects, newEffect] }
          : track
      )
    );
  }, [videoEffectPresets]);

  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  // Initialize with sample tracks
  useEffect(() => {
    const sampleAudioTrack: AudioTrack = {
      id: 'sample-audio',
      name: 'Sample Audio',
      type: 'music',
      duration: 30,
      volume: 0.8,
      muted: false,
      solo: false,
      visible: true,
      locked: false,
      waveform: Array.from({ length: 100 }, () => Math.random() * 0.8 + 0.1),
      effects: [],
      startTime: 0,
      endTime: 30
    };

    const sampleVideoTrack: VideoTrack = {
      id: 'sample-video',
      name: 'Sample Video',
      type: 'video',
      duration: 30,
      visible: true,
      locked: false,
      opacity: 1,
      effects: [],
      startTime: 0,
      endTime: 30,
      properties: {
        width: 1920,
        height: 1080,
        x: 0,
        y: 0,
        rotation: 0,
        scale: 1
      }
    };

    setAudioTracks([sampleAudioTrack]);
    setVideoTracks([sampleVideoTrack]);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const frames = Math.floor((seconds % 1) * 30);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${frames.toString().padStart(2, '0')}`;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[98vw] h-[98vh] bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 border-indigo-700">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-indigo-100 flex items-center gap-2">
            <Music className="h-6 w-6 text-indigo-400" />
            Audio/Video/Sound Effects Editor
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col h-full gap-4">
          {/* Top Toolbar */}
          <div className="flex items-center justify-between p-3 bg-indigo-900/30 rounded-lg border border-indigo-700">
            <div className="flex items-center gap-4">
              {/* Transport Controls */}
              <div className="flex items-center gap-2">
                <TooltipWrapper title="Go to Start" type="action" content="Jump to beginning">
                  <SoundButton
                    size="sm"
                    variant="outline"
                    className="border-indigo-600 text-indigo-300"
                    onClick={() => setCurrentTime(0)}
                  >
                    <SkipBack className="h-4 w-4" />
                  </SoundButton>
                </TooltipWrapper>
                
                <TooltipWrapper title={isPlaying ? "Pause" : "Play"} type="action" content="Toggle playback">
                  <SoundButton
                    size="sm"
                    className="bg-indigo-600 hover:bg-indigo-500"
                    onClick={togglePlayback}
                  >
                    {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </SoundButton>
                </TooltipWrapper>
                
                <TooltipWrapper title="Stop" type="action" content="Stop playback">
                  <SoundButton
                    size="sm"
                    variant="outline"
                    className="border-indigo-600 text-indigo-300"
                    onClick={() => {
                      setIsPlaying(false);
                      setCurrentTime(0);
                    }}
                  >
                    <Square className="h-4 w-4" />
                  </SoundButton>
                </TooltipWrapper>
                
                <TooltipWrapper title="Record" type="action" content="Start recording">
                  <SoundButton
                    size="sm"
                    variant={isRecording ? "default" : "outline"}
                    className={isRecording ? "bg-red-600" : "border-indigo-600 text-indigo-300"}
                    onClick={() => setIsRecording(!isRecording)}
                  >
                    {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                  </SoundButton>
                </TooltipWrapper>
              </div>

              <Separator orientation="vertical" className="h-6 bg-indigo-600" />

              {/* Time Display */}
              <div className="flex items-center gap-2 text-indigo-300 text-sm font-mono">
                <span>{formatTime(currentTime)}</span>
                <span>/</span>
                <span>{formatTime(totalDuration)}</span>
              </div>

              <Separator orientation="vertical" className="h-6 bg-indigo-600" />

              {/* Speed Control */}
              <div className="flex items-center gap-2">
                <Label className="text-indigo-200 text-xs">Speed:</Label>
                <Select value={playbackSpeed.toString()} onValueChange={(value) => setPlaybackSpeed(parseFloat(value))}>
                  <SelectTrigger className="w-20 h-7 bg-indigo-800/30 border-indigo-600 text-indigo-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0.25">0.25x</SelectItem>
                    <SelectItem value="0.5">0.5x</SelectItem>
                    <SelectItem value="1">1x</SelectItem>
                    <SelectItem value="1.5">1.5x</SelectItem>
                    <SelectItem value="2">2x</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Loop */}
              <TooltipWrapper title="Loop Playback" type="action" content="Enable loop mode">
                <SoundButton
                  size="sm"
                  variant={loopEnabled ? "default" : "outline"}
                  className={loopEnabled ? "bg-indigo-600" : "border-indigo-600 text-indigo-300"}
                  onClick={() => setLoopEnabled(!loopEnabled)}
                >
                  <Repeat className="h-4 w-4" />
                </SoundButton>
              </TooltipWrapper>
            </div>

            <div className="flex items-center gap-4">
              {/* Master Volume */}
              <div className="flex items-center gap-2">
                <Volume2 className="h-4 w-4 text-indigo-300" />
                <Slider
                  value={[masterVolume]}
                  onValueChange={([value]) => setMasterVolume(value)}
                  max={1}
                  step={0.01}
                  className="w-24"
                />
                <span className="text-indigo-300 text-xs w-8 text-right">
                  {Math.round(masterVolume * 100)}%
                </span>
              </div>

              <Separator orientation="vertical" className="h-6 bg-indigo-600" />

              {/* Zoom Controls */}
              <div className="flex items-center gap-1">
                <TooltipWrapper title="Zoom Out" type="action" content="Decrease timeline zoom">
                  <SoundButton
                    size="sm"
                    variant="outline"
                    className="border-indigo-600 text-indigo-300"
                    onClick={() => setZoom(Math.max(0.1, zoom - 0.1))}
                  >
                    <ZoomOut className="h-4 w-4" />
                  </SoundButton>
                </TooltipWrapper>
                <span className="text-indigo-300 text-xs w-12 text-center">{Math.round(zoom * 100)}%</span>
                <TooltipWrapper title="Zoom In" type="action" content="Increase timeline zoom">
                  <SoundButton
                    size="sm"
                    variant="outline"
                    className="border-indigo-600 text-indigo-300"
                    onClick={() => setZoom(Math.min(5, zoom + 0.1))}
                  >
                    <ZoomIn className="h-4 w-4" />
                  </SoundButton>
                </TooltipWrapper>
              </div>

              {/* Add Marker */}
              <TooltipWrapper title="Add Marker" type="action" content="Add timeline marker">
                <SoundButton
                  size="sm"
                  className="bg-indigo-600 hover:bg-indigo-500"
                  onClick={addMarker}
                >
                  <Plus className="h-4 w-4" />
                </SoundButton>
              </TooltipWrapper>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex flex-1 gap-4">
            {/* Left Panel - Library & Tools */}
            <div className="w-80 space-y-4">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-3 bg-indigo-900/30">
                  <TabsTrigger value="library" className="text-xs">Library</TabsTrigger>
                  <TabsTrigger value="effects" className="text-xs">Effects</TabsTrigger>
                  <TabsTrigger value="mixer" className="text-xs">Mixer</TabsTrigger>
                </TabsList>

                <TabsContent value="library" className="space-y-4">
                  <Card className="bg-indigo-900/30 border-indigo-700">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-indigo-100 text-sm">Sound Library</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-64">
                        <div className="space-y-2">
                          {soundLibrary.map((sound) => (
                            <div
                              key={sound.id}
                              className="flex items-center justify-between p-2 bg-indigo-800/30 rounded cursor-pointer hover:bg-indigo-700/30"
                              onClick={() => createAudioTrack(sound.id)}
                            >
                              <div>
                                <p className="text-indigo-100 text-xs font-medium">{sound.name}</p>
                                <p className="text-indigo-400 text-xs">{sound.category} • {sound.duration}s</p>
                              </div>
                              <Badge className="text-xs bg-indigo-600/50 text-indigo-200">
                                {sound.type}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>

                  <Card className="bg-indigo-900/30 border-indigo-700">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-indigo-100 text-sm">Add Elements</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-2 gap-2">
                        <TooltipWrapper title="Add Video Track" type="action" content="Create new video track">
                          <SoundButton
                            size="sm"
                            variant="outline"
                            className="border-indigo-600 text-indigo-300 hover:bg-indigo-800/30"
                            onClick={() => createVideoTrack('video')}
                          >
                            <Video className="h-4 w-4 mr-1" />
                            Video
                          </SoundButton>
                        </TooltipWrapper>
                        <TooltipWrapper title="Add Image Track" type="action" content="Create new image track">
                          <SoundButton
                            size="sm"
                            variant="outline"
                            className="border-indigo-600 text-indigo-300 hover:bg-indigo-800/30"
                            onClick={() => createVideoTrack('image')}
                          >
                            <Film className="h-4 w-4 mr-1" />
                            Image
                          </SoundButton>
                        </TooltipWrapper>
                        <TooltipWrapper title="Add Text Track" type="action" content="Create new text track">
                          <SoundButton
                            size="sm"
                            variant="outline"
                            className="border-indigo-600 text-indigo-300 hover:bg-indigo-800/30"
                            onClick={() => createVideoTrack('text')}
                          >
                            Text
                          </SoundButton>
                        </TooltipWrapper>
                        <TooltipWrapper title="Add Shape Track" type="action" content="Create new shape track">
                          <SoundButton
                            size="sm"
                            variant="outline"
                            className="border-indigo-600 text-indigo-300 hover:bg-indigo-800/30"
                            onClick={() => createVideoTrack('shape')}
                          >
                            Shape
                          </SoundButton>
                        </TooltipWrapper>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="effects" className="space-y-4">
                  <Card className="bg-indigo-900/30 border-indigo-700">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-indigo-100 text-sm">Audio Effects</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {audioEffectPresets.map((preset, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-2 bg-indigo-800/30 rounded cursor-pointer hover:bg-indigo-700/30"
                            onClick={() => selectedTrack && 'waveform' in selectedTrack && addAudioEffect(selectedTrack.id, preset.type)}
                          >
                            <span className="text-indigo-100 text-xs">{preset.name}</span>
                            <Badge className="text-xs bg-indigo-600/50 text-indigo-200">
                              {preset.type}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-indigo-900/30 border-indigo-700">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-indigo-100 text-sm">Video Effects</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {videoEffectPresets.map((preset, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-2 bg-indigo-800/30 rounded cursor-pointer hover:bg-indigo-700/30"
                            onClick={() => selectedTrack && 'properties' in selectedTrack && addVideoEffect(selectedTrack.id, preset.type)}
                          >
                            <span className="text-indigo-100 text-xs">{preset.name}</span>
                            <Badge className="text-xs bg-indigo-600/50 text-indigo-200">
                              {preset.type}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="mixer" className="space-y-4">
                  <Card className="bg-indigo-900/30 border-indigo-700">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-indigo-100 text-sm">Audio Mixer</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {audioTracks.map((track) => (
                          <div key={track.id} className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-indigo-200 text-xs">{track.name}</span>
                              <div className="flex gap-1">
                                <SoundButton
                                  size="sm"
                                  variant={track.muted ? "default" : "ghost"}
                                  className="h-6 w-6 p-0"
                                  onClick={() => {
                                    setAudioTracks(tracks =>
                                      tracks.map(t =>
                                        t.id === track.id ? { ...t, muted: !t.muted } : t
                                      )
                                    );
                                  }}
                                >
                                  {track.muted ? <VolumeX className="h-3 w-3" /> : <Volume2 className="h-3 w-3" />}
                                </SoundButton>
                                <SoundButton
                                  size="sm"
                                  variant={track.solo ? "default" : "ghost"}
                                  className="h-6 w-6 p-0"
                                  onClick={() => {
                                    setAudioTracks(tracks =>
                                      tracks.map(t =>
                                        t.id === track.id ? { ...t, solo: !t.solo } : t
                                      )
                                    );
                                  }}
                                >
                                  <Headphones className="h-3 w-3" />
                                </SoundButton>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Slider
                                value={[track.volume]}
                                onValueChange={([value]) => {
                                  setAudioTracks(tracks =>
                                    tracks.map(t =>
                                      t.id === track.id ? { ...t, volume: value } : t
                                    )
                                  );
                                }}
                                max={1}
                                step={0.01}
                                className="flex-1"
                              />
                              <span className="text-indigo-300 text-xs w-8 text-right">
                                {Math.round(track.volume * 100)}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>

            {/* Center - Timeline */}
            <div className="flex-1 space-y-4">
              {/* Timeline Header */}
              <div className="bg-indigo-900/30 border border-indigo-700 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-indigo-100 font-medium">Timeline</h3>
                  <div className="flex gap-2">
                    <TooltipWrapper title="Fit to Window" type="action" content="Fit timeline to window">
                      <SoundButton size="sm" variant="outline" className="border-indigo-600 text-indigo-300">
                        <Maximize className="h-4 w-4" />
                      </SoundButton>
                    </TooltipWrapper>
                    <TooltipWrapper title="Export Video" type="action" content="Export timeline as video">
                      <SoundButton size="sm" className="bg-indigo-600 hover:bg-indigo-500">
                        <Download className="h-4 w-4" />
                      </SoundButton>
                    </TooltipWrapper>
                  </div>
                </div>

                {/* Time Ruler */}
                <div className="relative h-8 bg-indigo-950/50 border border-indigo-600 rounded mb-2">
                  <div
                    className="absolute top-0 w-0.5 h-full bg-yellow-400 z-10"
                    style={{ left: `${(currentTime / totalDuration) * 100}%` }}
                  />
                  {Array.from({ length: Math.ceil(totalDuration) + 1 }, (_, i) => (
                    <div
                      key={i}
                      className="absolute top-0 h-full flex items-end text-indigo-300 text-xs"
                      style={{ left: `${(i / totalDuration) * 100}%` }}
                    >
                      <div className="w-px h-2 bg-indigo-400 mb-1" />
                      <span className="ml-1">{i}s</span>
                    </div>
                  ))}
                  
                  {/* Markers */}
                  {markers.map((marker) => (
                    <div
                      key={marker.id}
                      className="absolute top-0 h-full flex items-start"
                      style={{ left: `${(marker.time / totalDuration) * 100}%` }}
                    >
                      <div className="w-px h-full bg-blue-400" />
                      <div className="text-xs text-blue-300 ml-1 bg-blue-900/80 px-1 rounded">
                        {marker.label}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Video Tracks */}
                <div className="space-y-1 mb-4">
                  <Label className="text-indigo-200 text-xs">Video Tracks</Label>
                  {videoTracks.map((track) => (
                    <div
                      key={track.id}
                      className={`flex items-center gap-2 p-2 rounded cursor-pointer ${
                        selectedTrack?.id === track.id ? 'bg-indigo-700/50' : 'bg-indigo-800/30 hover:bg-indigo-700/30'
                      }`}
                      onClick={() => setSelectedTrack(track)}
                    >
                      <div className="flex items-center gap-1 w-32">
                        <div className="flex gap-1">
                          {track.visible ? (
                            <Eye className="h-3 w-3 text-indigo-300" />
                          ) : (
                            <EyeOff className="h-3 w-3 text-indigo-500" />
                          )}
                          {track.locked && <Lock className="h-3 w-3 text-indigo-500" />}
                        </div>
                        <span className="text-indigo-100 text-xs truncate">{track.name}</span>
                      </div>
                      <div className="flex-1 relative h-8 bg-indigo-950/50 border border-indigo-600 rounded">
                        <div
                          className="absolute top-0 h-full bg-purple-600/70 border border-purple-500 rounded flex items-center justify-center"
                          style={{
                            left: `${(track.startTime / totalDuration) * 100}%`,
                            width: `${((track.endTime - track.startTime) / totalDuration) * 100}%`
                          }}
                        >
                          <span className="text-white text-xs">{track.type}</span>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <TooltipWrapper title="Copy Track" type="action" content="Duplicate track">
                          <SoundButton size="sm" variant="ghost">
                            <Copy className="h-3 w-3" />
                          </SoundButton>
                        </TooltipWrapper>
                        <TooltipWrapper title="Delete Track" type="warning" content="Remove track">
                          <SoundButton
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation();
                              setVideoTracks(tracks => tracks.filter(t => t.id !== track.id));
                              if (selectedTrack?.id === track.id) setSelectedTrack(null);
                            }}
                          >
                            <Trash2 className="h-3 w-3" />
                          </SoundButton>
                        </TooltipWrapper>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Audio Tracks */}
                <div className="space-y-1">
                  <Label className="text-indigo-200 text-xs">Audio Tracks</Label>
                  {audioTracks.map((track) => (
                    <div
                      key={track.id}
                      className={`flex items-center gap-2 p-2 rounded cursor-pointer ${
                        selectedTrack?.id === track.id ? 'bg-indigo-700/50' : 'bg-indigo-800/30 hover:bg-indigo-700/30'
                      }`}
                      onClick={() => setSelectedTrack(track)}
                    >
                      <div className="flex items-center gap-1 w-32">
                        <div className="flex gap-1">
                          {track.visible ? (
                            <Eye className="h-3 w-3 text-indigo-300" />
                          ) : (
                            <EyeOff className="h-3 w-3 text-indigo-500" />
                          )}
                          {track.locked && <Lock className="h-3 w-3 text-indigo-500" />}
                          {track.muted && <VolumeX className="h-3 w-3 text-indigo-500" />}
                          {track.solo && <Headphones className="h-3 w-3 text-green-400" />}
                        </div>
                        <span className="text-indigo-100 text-xs truncate">{track.name}</span>
                      </div>
                      <div className="flex-1 relative h-8 bg-indigo-950/50 border border-indigo-600 rounded">
                        <div
                          className="absolute top-0 h-full bg-blue-600/70 border border-blue-500 rounded"
                          style={{
                            left: `${(track.startTime / totalDuration) * 100}%`,
                            width: `${((track.endTime - track.startTime) / totalDuration) * 100}%`
                          }}
                        >
                          <canvas
                            width={200}
                            height={32}
                            className="w-full h-full"
                            ref={(canvas) => {
                              if (canvas) {
                                drawWaveform(canvas, track.waveform, '#60a5fa');
                              }
                            }}
                          />
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <TooltipWrapper title="Copy Track" type="action" content="Duplicate track">
                          <SoundButton size="sm" variant="ghost">
                            <Copy className="h-3 w-3" />
                          </SoundButton>
                        </TooltipWrapper>
                        <TooltipWrapper title="Delete Track" type="warning" content="Remove track">
                          <SoundButton
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation();
                              setAudioTracks(tracks => tracks.filter(t => t.id !== track.id));
                              if (selectedTrack?.id === track.id) setSelectedTrack(null);
                            }}
                          >
                            <Trash2 className="h-3 w-3" />
                          </SoundButton>
                        </TooltipWrapper>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Panel - Properties */}
            <div className="w-80 space-y-4">
              {selectedTrack ? (
                <>
                  <Card className="bg-indigo-900/30 border-indigo-700">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-indigo-100 text-sm flex items-center gap-2">
                        <Settings className="h-4 w-4" />
                        Track Properties
                      </CardTitle>
                      <CardDescription className="text-indigo-300 text-xs">
                        {selectedTrack.name} ({'waveform' in selectedTrack ? 'Audio' : 'Video'})
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Common Properties */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label className="text-indigo-200 text-xs">Visible</Label>
                          <Switch
                            checked={selectedTrack.visible}
                            onCheckedChange={(checked) => {
                              const updater = 'waveform' in selectedTrack ? setAudioTracks : setVideoTracks;
                              updater((tracks: any) =>
                                tracks.map((t: any) =>
                                  t.id === selectedTrack.id ? { ...t, visible: checked } : t
                                )
                              );
                              setSelectedTrack({ ...selectedTrack, visible: checked });
                            }}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <Label className="text-indigo-200 text-xs">Locked</Label>
                          <Switch
                            checked={selectedTrack.locked}
                            onCheckedChange={(checked) => {
                              const updater = 'waveform' in selectedTrack ? setAudioTracks : setVideoTracks;
                              updater((tracks: any) =>
                                tracks.map((t: any) =>
                                  t.id === selectedTrack.id ? { ...t, locked: checked } : t
                                )
                              );
                              setSelectedTrack({ ...selectedTrack, locked: checked });
                            }}
                          />
                        </div>
                      </div>

                      {/* Audio-specific Properties */}
                      {'waveform' in selectedTrack && (
                        <div className="space-y-3">
                          <Separator className="bg-indigo-700" />
                          
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <Label className="text-indigo-200 text-xs">Volume</Label>
                              <span className="text-indigo-300 text-xs">{Math.round(selectedTrack.volume * 100)}%</span>
                            </div>
                            <Slider
                              value={[selectedTrack.volume]}
                              onValueChange={([value]) => {
                                setAudioTracks(tracks =>
                                  tracks.map(t =>
                                    t.id === selectedTrack.id ? { ...t, volume: value } : t
                                  )
                                );
                                setSelectedTrack({ ...selectedTrack, volume: value });
                              }}
                              max={1}
                              step={0.01}
                              className="w-full"
                            />
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <TooltipWrapper title="Mute Track" type="action" content="Toggle mute">
                              <SoundButton
                                size="sm"
                                variant={selectedTrack.muted ? "default" : "outline"}
                                className="flex-1"
                                onClick={() => {
                                  const newMuted = !selectedTrack.muted;
                                  setAudioTracks(tracks =>
                                    tracks.map(t =>
                                      t.id === selectedTrack.id ? { ...t, muted: newMuted } : t
                                    )
                                  );
                                  setSelectedTrack({ ...selectedTrack, muted: newMuted });
                                }}
                              >
                                {selectedTrack.muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                              </SoundButton>
                            </TooltipWrapper>
                            
                            <TooltipWrapper title="Solo Track" type="action" content="Toggle solo">
                              <SoundButton
                                size="sm"
                                variant={selectedTrack.solo ? "default" : "outline"}
                                className="flex-1"
                                onClick={() => {
                                  const newSolo = !selectedTrack.solo;
                                  setAudioTracks(tracks =>
                                    tracks.map(t =>
                                      t.id === selectedTrack.id ? { ...t, solo: newSolo } : t
                                    )
                                  );
                                  setSelectedTrack({ ...selectedTrack, solo: newSolo });
                                }}
                              >
                                <Headphones className="h-4 w-4" />
                              </SoundButton>
                            </TooltipWrapper>
                          </div>
                        </div>
                      )}

                      {/* Video-specific Properties */}
                      {'properties' in selectedTrack && (
                        <div className="space-y-3">
                          <Separator className="bg-indigo-700" />
                          
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <Label className="text-indigo-200 text-xs">Opacity</Label>
                              <span className="text-indigo-300 text-xs">{Math.round(selectedTrack.opacity * 100)}%</span>
                            </div>
                            <Slider
                              value={[selectedTrack.opacity]}
                              onValueChange={([value]) => {
                                setVideoTracks(tracks =>
                                  tracks.map(t =>
                                    t.id === selectedTrack.id ? { ...t, opacity: value } : t
                                  )
                                );
                                setSelectedTrack({ ...selectedTrack, opacity: value });
                              }}
                              max={1}
                              step={0.01}
                              className="w-full"
                            />
                          </div>
                          
                          <div className="grid grid-cols-2 gap-2">
                            <div className="space-y-1">
                              <Label className="text-indigo-200 text-xs">X Position</Label>
                              <Input
                                type="number"
                                value={selectedTrack.properties.x}
                                onChange={(e) => {
                                  const newX = parseFloat(e.target.value) || 0;
                                  const newProperties = { ...selectedTrack.properties, x: newX };
                                  setVideoTracks(tracks =>
                                    tracks.map(t =>
                                      t.id === selectedTrack.id ? { ...t, properties: newProperties } : t
                                    )
                                  );
                                  setSelectedTrack({ ...selectedTrack, properties: newProperties });
                                }}
                                className="h-7 bg-indigo-800/30 border-indigo-600 text-indigo-100 text-xs"
                              />
                            </div>
                            <div className="space-y-1">
                              <Label className="text-indigo-200 text-xs">Y Position</Label>
                              <Input
                                type="number"
                                value={selectedTrack.properties.y}
                                onChange={(e) => {
                                  const newY = parseFloat(e.target.value) || 0;
                                  const newProperties = { ...selectedTrack.properties, y: newY };
                                  setVideoTracks(tracks =>
                                    tracks.map(t =>
                                      t.id === selectedTrack.id ? { ...t, properties: newProperties } : t
                                    )
                                  );
                                  setSelectedTrack({ ...selectedTrack, properties: newProperties });
                                }}
                                className="h-7 bg-indigo-800/30 border-indigo-600 text-indigo-100 text-xs"
                              />
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Effects Panel */}
                  <Card className="bg-indigo-900/30 border-indigo-700">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-indigo-100 text-sm">Effects</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {selectedTrack.effects.map((effect) => (
                          <div key={effect.id} className="flex items-center justify-between p-2 bg-indigo-800/30 rounded">
                            <div className="flex items-center gap-2">
                              <Switch
                                checked={effect.enabled}
                                onCheckedChange={(checked) => {
                                  const updater = 'waveform' in selectedTrack ? setAudioTracks : setVideoTracks;
                                  updater((tracks: any) =>
                                    tracks.map((t: any) =>
                                      t.id === selectedTrack.id
                                        ? {
                                            ...t,
                                            effects: t.effects.map((e: any) =>
                                              e.id === effect.id ? { ...e, enabled: checked } : e
                                            )
                                          }
                                        : t
                                    )
                                  );
                                }}
                              />
                              <span className="text-indigo-100 text-xs">{effect.name}</span>
                            </div>
                            <TooltipWrapper title="Remove Effect" type="warning" content="Delete effect">
                              <SoundButton
                                size="sm"
                                variant="ghost"
                                onClick={() => {
                                  const updater = 'waveform' in selectedTrack ? setAudioTracks : setVideoTracks;
                                  updater((tracks: any) =>
                                    tracks.map((t: any) =>
                                      t.id === selectedTrack.id
                                        ? { ...t, effects: t.effects.filter((e: any) => e.id !== effect.id) }
                                        : t
                                    )
                                  );
                                }}
                              >
                                <Trash2 className="h-3 w-3" />
                              </SoundButton>
                            </TooltipWrapper>
                          </div>
                        ))}
                        
                        {selectedTrack.effects.length === 0 && (
                          <p className="text-indigo-400 text-xs text-center py-4">
                            No effects applied. Add effects from the Effects panel.
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </>
              ) : (
                <Card className="bg-indigo-900/30 border-indigo-700">
                  <CardContent className="flex items-center justify-center h-64">
                    <div className="text-center text-indigo-300">
                      <Music className="h-12 w-12 mx-auto mb-3 text-indigo-500" />
                      <p className="text-sm">Select a track to edit properties</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}