import React, { useState, useRef, useEffect, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { 
  Users, Video, MessageSquare, Share2, UserPlus,
  Mic, MicOff, Camera, CameraOff, Phone, PhoneOff,
  Monitor, ScreenShare, Settings, Crown, Eye,
  Edit, Lock, Unlock, Clock, Activity, Globe
} from "lucide-react";

interface RealTimeCollaborationProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Collaborator {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: 'owner' | 'editor' | 'viewer';
  status: 'online' | 'offline' | 'away';
  cursor?: {
    line: number;
    column: number;
    file: string;
  };
  lastSeen: Date;
  permissions: {
    read: boolean;
    write: boolean;
    admin: boolean;
  };
}

interface ChatMessage {
  id: string;
  userId: string;
  content: string;
  timestamp: Date;
  type: 'text' | 'file' | 'code' | 'system';
  metadata?: any;
}

interface SessionSettings {
  allowGuests: boolean;
  requireApproval: boolean;
  maxCollaborators: number;
  sessionTimeout: number;
  recordSession: boolean;
  shareAudio: boolean;
  shareVideo: boolean;
  shareScreen: boolean;
}

export default function RealTimeCollaboration({ isOpen, onClose }: RealTimeCollaborationProps) {
  const [collaborators, setCollaborators] = useState<Collaborator[]>([
    {
      id: '1',
      name: 'Stephen Deline Jr.',
      email: 'stephend8846@gmail.com',
      role: 'owner',
      status: 'online',
      lastSeen: new Date(),
      permissions: { read: true, write: true, admin: true }
    },
    {
      id: '2',
      name: 'John Developer',
      email: 'john@example.com',
      role: 'editor',
      status: 'online',
      cursor: { line: 45, column: 12, file: 'main.js' },
      lastSeen: new Date(),
      permissions: { read: true, write: true, admin: false }
    },
    {
      id: '3',
      name: 'Sarah Viewer',
      email: 'sarah@example.com',
      role: 'viewer',
      status: 'away',
      lastSeen: new Date(Date.now() - 5 * 60 * 1000),
      permissions: { read: true, write: false, admin: false }
    }
  ]);

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      userId: '2',
      content: 'Hey everyone! I just joined the session.',
      timestamp: new Date(Date.now() - 10 * 60 * 1000),
      type: 'text'
    },
    {
      id: '2',
      userId: '1',
      content: 'Welcome! Feel free to look around and make suggestions.',
      timestamp: new Date(Date.now() - 8 * 60 * 1000),
      type: 'text'
    },
    {
      id: '3',
      userId: 'system',
      content: 'Sarah Viewer joined the session',
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      type: 'system'
    }
  ]);

  const [newMessage, setNewMessage] = useState('');
  const [isVideoCall, setIsVideoCall] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [sessionSettings, setSessionSettings] = useState<SessionSettings>({
    allowGuests: false,
    requireApproval: true,
    maxCollaborators: 10,
    sessionTimeout: 8, // hours
    recordSession: false,
    shareAudio: true,
    shareVideo: false,
    shareScreen: false
  });

  const { toast } = useToast();
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleSendMessage = useCallback(() => {
    if (newMessage.trim()) {
      const message: ChatMessage = {
        id: Date.now().toString(),
        userId: '1', // Current user
        content: newMessage,
        timestamp: new Date(),
        type: 'text'
      };
      setChatMessages(prev => [...prev, message]);
      setNewMessage('');
    }
  }, [newMessage]);

  const handleInviteCollaborator = useCallback(() => {
    if (inviteEmail) {
      toast({
        title: "Invitation sent",
        description: `Collaboration invite sent to ${inviteEmail}`,
      });
      setInviteEmail('');
    }
  }, [inviteEmail, toast]);

  const handleStartVideoCall = useCallback(() => {
    setIsVideoCall(true);
    const systemMessage: ChatMessage = {
      id: Date.now().toString(),
      userId: 'system',
      content: 'Video call started',
      timestamp: new Date(),
      type: 'system'
    };
    setChatMessages(prev => [...prev, systemMessage]);
  }, []);

  const handleEndVideoCall = useCallback(() => {
    setIsVideoCall(false);
    setIsScreenSharing(false);
    const systemMessage: ChatMessage = {
      id: Date.now().toString(),
      userId: 'system',
      content: 'Video call ended',
      timestamp: new Date(),
      type: 'system'
    };
    setChatMessages(prev => [...prev, systemMessage]);
  }, []);

  const handleScreenShare = useCallback(() => {
    setIsScreenSharing(!isScreenSharing);
    const action = isScreenSharing ? 'stopped' : 'started';
    const systemMessage: ChatMessage = {
      id: Date.now().toString(),
      userId: 'system',
      content: `Screen sharing ${action}`,
      timestamp: new Date(),
      type: 'system'
    };
    setChatMessages(prev => [...prev, systemMessage]);
  }, [isScreenSharing]);

  const handleChangeRole = useCallback((collaboratorId: string, newRole: Collaborator['role']) => {
    setCollaborators(prev => prev.map(c => 
      c.id === collaboratorId ? { ...c, role: newRole } : c
    ));
    toast({
      title: "Role updated",
      description: "Collaborator role has been changed",
    });
  }, [toast]);

  const handleRemoveCollaborator = useCallback((collaboratorId: string) => {
    setCollaborators(prev => prev.filter(c => c.id !== collaboratorId));
    toast({
      title: "Collaborator removed",
      description: "Collaborator has been removed from the session",
    });
  }, [toast]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner': return <Crown className="w-4 h-4 text-yellow-500" />;
      case 'editor': return <Edit className="w-4 h-4 text-blue-500" />;
      case 'viewer': return <Eye className="w-4 h-4 text-gray-500" />;
      default: return null;
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatLastSeen = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return date.toLocaleDateString();
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Real-Time Collaboration
            <Badge variant="outline" className="ml-2">
              {collaborators.filter(c => c.status === 'online').length} online
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex gap-4">
          {/* Left Panel - Collaborators & Settings */}
          <div className="w-80 flex flex-col space-y-4">
            {/* Active Collaborators */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Active Users ({collaborators.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-48">
                  <div className="space-y-3">
                    {collaborators.map((collaborator) => (
                      <div key={collaborator.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="relative">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={collaborator.avatar} />
                            <AvatarFallback>{collaborator.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                          </Avatar>
                          <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white ${getStatusColor(collaborator.status)}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1">
                            <p className="font-medium text-sm truncate">{collaborator.name}</p>
                            {getRoleIcon(collaborator.role)}
                          </div>
                          <p className="text-xs text-gray-500">
                            {collaborator.status === 'online' ? 'Active now' : formatLastSeen(collaborator.lastSeen)}
                          </p>
                          {collaborator.cursor && (
                            <p className="text-xs text-blue-500">
                              Editing {collaborator.cursor.file}:{collaborator.cursor.line}
                            </p>
                          )}
                        </div>
                        <div className="flex flex-col gap-1">
                          <select
                            value={collaborator.role}
                            onChange={(e) => handleChangeRole(collaborator.id, e.target.value as any)}
                            className="text-xs px-2 py-1 border rounded"
                            disabled={collaborator.role === 'owner'}
                          >
                            <option value="viewer">Viewer</option>
                            <option value="editor">Editor</option>
                            <option value="owner">Owner</option>
                          </select>
                          {collaborator.role !== 'owner' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemoveCollaborator(collaborator.id)}
                              className="h-6 px-2 text-red-500"
                            >
                              Remove
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Invite New Collaborator */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <UserPlus className="w-4 h-4" />
                  Invite Collaborator
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Input
                    placeholder="Enter email address"
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                  />
                  <Button 
                    onClick={handleInviteCollaborator}
                    className="w-full"
                    disabled={!inviteEmail}
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Send Invite
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Video Call Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Video className="w-4 h-4" />
                  Video Call
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {!isVideoCall ? (
                    <Button onClick={handleStartVideoCall} className="w-full">
                      <Video className="w-4 h-4 mr-2" />
                      Start Video Call
                    </Button>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <Button
                          variant={isMuted ? "destructive" : "outline"}
                          size="sm"
                          onClick={() => setIsMuted(!isMuted)}
                        >
                          {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                        </Button>
                        <Button
                          variant={isCameraOff ? "destructive" : "outline"}
                          size="sm"
                          onClick={() => setIsCameraOff(!isCameraOff)}
                        >
                          {isCameraOff ? <CameraOff className="w-4 h-4" /> : <Camera className="w-4 h-4" />}
                        </Button>
                        <Button
                          variant={isScreenSharing ? "secondary" : "outline"}
                          size="sm"
                          onClick={handleScreenShare}
                        >
                          <ScreenShare className="w-4 h-4" />
                        </Button>
                      </div>
                      <Button
                        variant="destructive"
                        onClick={handleEndVideoCall}
                        className="w-full"
                      >
                        <PhoneOff className="w-4 h-4 mr-2" />
                        End Call
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Chat & Session Info */}
          <div className="flex-1 flex flex-col space-y-4">
            {/* Session Stats */}
            <div className="grid grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <Users className="w-6 h-6 mx-auto mb-2 text-blue-500" />
                  <p className="text-2xl font-bold">{collaborators.length}</p>
                  <p className="text-sm text-gray-500">Total Users</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Activity className="w-6 h-6 mx-auto mb-2 text-green-500" />
                  <p className="text-2xl font-bold">{collaborators.filter(c => c.status === 'online').length}</p>
                  <p className="text-sm text-gray-500">Online</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <MessageSquare className="w-6 h-6 mx-auto mb-2 text-purple-500" />
                  <p className="text-2xl font-bold">{chatMessages.filter(m => m.type === 'text').length}</p>
                  <p className="text-sm text-gray-500">Messages</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Clock className="w-6 h-6 mx-auto mb-2 text-orange-500" />
                  <p className="text-2xl font-bold">2h 15m</p>
                  <p className="text-sm text-gray-500">Session Time</p>
                </CardContent>
              </Card>
            </div>

            {/* Chat */}
            <Card className="flex-1">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  Team Chat
                </CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col h-80">
                <ScrollArea className="flex-1 mb-4">
                  <div className="space-y-3">
                    {chatMessages.map((message) => (
                      <div key={message.id} className="flex gap-3">
                        {message.type !== 'system' && (
                          <Avatar className="w-6 h-6">
                            <AvatarFallback>
                              {collaborators.find(c => c.id === message.userId)?.name.split(' ').map(n => n[0]).join('') || 'U'}
                            </AvatarFallback>
                          </Avatar>
                        )}
                        <div className={`flex-1 ${message.type === 'system' ? 'text-center' : ''}`}>
                          {message.type !== 'system' && (
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium text-sm">
                                {collaborators.find(c => c.id === message.userId)?.name || 'Unknown User'}
                              </span>
                              <span className="text-xs text-gray-500">
                                {formatTime(message.timestamp)}
                              </span>
                            </div>
                          )}
                          <p className={`text-sm ${
                            message.type === 'system' 
                              ? 'text-gray-500 italic' 
                              : 'text-gray-900 dark:text-gray-100'
                          }`}>
                            {message.content}
                          </p>
                        </div>
                      </div>
                    ))}
                    <div ref={chatEndRef} />
                  </div>
                </ScrollArea>
                <div className="flex gap-2">
                  <Input
                    placeholder="Type your message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
                    Send
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}