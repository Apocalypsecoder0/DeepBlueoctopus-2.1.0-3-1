import React, { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings2, Plus, Edit, Trash2, Copy, Eye, EyeOff,
  Key, Shield, Globe, Server, Database, Lock,
  Download, Upload, Search, Filter, AlertTriangle
} from "lucide-react";

interface EnvVarManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface EnvironmentVariable {
  id: string;
  key: string;
  value: string;
  description: string;
  category: 'database' | 'api' | 'auth' | 'config' | 'secret' | 'custom';
  environment: 'development' | 'staging' | 'production' | 'all';
  isSecret: boolean;
  isRequired: boolean;
  defaultValue?: string;
  validation?: {
    type?: 'string' | 'number' | 'boolean' | 'url' | 'email' | 'json';
    pattern?: string;
    minLength?: number;
    maxLength?: number;
  };
  lastModified: Date;
  createdBy: string;
}

interface EnvironmentGroup {
  id: string;
  name: string;
  description: string;
  variables: EnvironmentVariable[];
  isActive: boolean;
  environment: 'development' | 'staging' | 'production';
}

export default function EnvVarManager({ isOpen, onClose }: EnvVarManagerProps) {
  const [envGroups, setEnvGroups] = useState<EnvironmentGroup[]>([
    {
      id: '1',
      name: 'Development',
      description: 'Development environment variables',
      environment: 'development',
      isActive: true,
      variables: [
        {
          id: '1',
          key: 'DATABASE_URL',
          value: 'postgresql://localhost:5432/deepblue_dev',
          description: 'Database connection string for development',
          category: 'database',
          environment: 'development',
          isSecret: true,
          isRequired: true,
          validation: { type: 'url' },
          lastModified: new Date(),
          createdBy: 'system'
        },
        {
          id: '2',
          key: 'API_KEY',
          value: 'dev_api_key_12345',
          description: 'API key for external services',
          category: 'api',
          environment: 'development',
          isSecret: true,
          isRequired: true,
          validation: { type: 'string', minLength: 10 },
          lastModified: new Date(),
          createdBy: 'developer'
        },
        {
          id: '3',
          key: 'PORT',
          value: '3000',
          description: 'Server port number',
          category: 'config',
          environment: 'development',
          isSecret: false,
          isRequired: false,
          defaultValue: '3000',
          validation: { type: 'number' },
          lastModified: new Date(),
          createdBy: 'system'
        }
      ]
    },
    {
      id: '2',
      name: 'Production',
      description: 'Production environment variables',
      environment: 'production',
      isActive: false,
      variables: [
        {
          id: '4',
          key: 'DATABASE_URL',
          value: 'postgresql://prod-server:5432/deepblue_prod',
          description: 'Production database connection',
          category: 'database',
          environment: 'production',
          isSecret: true,
          isRequired: true,
          validation: { type: 'url' },
          lastModified: new Date(),
          createdBy: 'admin'
        }
      ]
    }
  ]);

  const [selectedGroup, setSelectedGroup] = useState<EnvironmentGroup>(envGroups[0]);
  const [showSecrets, setShowSecrets] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [isEditing, setIsEditing] = useState(false);
  const [editingVar, setEditingVar] = useState<Partial<EnvironmentVariable>>({});

  const { toast } = useToast();

  const filteredVariables = selectedGroup.variables.filter(envVar => {
    const matchesSearch = envVar.key.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         envVar.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === 'all' || envVar.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const handleCreateVariable = useCallback(() => {
    setEditingVar({
      key: '',
      value: '',
      description: '',
      category: 'custom',
      environment: selectedGroup.environment,
      isSecret: false,
      isRequired: false,
      validation: { type: 'string' }
    });
    setIsEditing(true);
  }, [selectedGroup]);

  const handleEditVariable = useCallback((envVar: EnvironmentVariable) => {
    setEditingVar(envVar);
    setIsEditing(true);
  }, []);

  const handleSaveVariable = useCallback(() => {
    if (!editingVar.key || !editingVar.value) {
      toast({
        title: "Validation error",
        description: "Key and value are required",
        variant: "destructive",
      });
      return;
    }

    const variable: EnvironmentVariable = {
      id: editingVar.id || Date.now().toString(),
      key: editingVar.key!,
      value: editingVar.value!,
      description: editingVar.description || '',
      category: editingVar.category || 'custom',
      environment: editingVar.environment || selectedGroup.environment,
      isSecret: editingVar.isSecret || false,
      isRequired: editingVar.isRequired || false,
      defaultValue: editingVar.defaultValue,
      validation: editingVar.validation || { type: 'string' },
      lastModified: new Date(),
      createdBy: editingVar.createdBy || 'user'
    };

    setEnvGroups(prev => prev.map(group => 
      group.id === selectedGroup.id
        ? {
            ...group,
            variables: editingVar.id
              ? group.variables.map(v => v.id === variable.id ? variable : v)
              : [...group.variables, variable]
          }
        : group
    ));

    // Update selected group
    setSelectedGroup(prev => ({
      ...prev,
      variables: editingVar.id
        ? prev.variables.map(v => v.id === variable.id ? variable : v)
        : [...prev.variables, variable]
    }));

    toast({
      title: editingVar.id ? "Variable updated" : "Variable created",
      description: `Environment variable ${variable.key} has been saved`,
    });

    setIsEditing(false);
    setEditingVar({});
  }, [editingVar, selectedGroup, toast]);

  const handleDeleteVariable = useCallback((id: string) => {
    setEnvGroups(prev => prev.map(group => 
      group.id === selectedGroup.id
        ? { ...group, variables: group.variables.filter(v => v.id !== id) }
        : group
    ));

    setSelectedGroup(prev => ({
      ...prev,
      variables: prev.variables.filter(v => v.id !== id)
    }));

    toast({
      title: "Variable deleted",
      description: "Environment variable has been deleted",
    });
  }, [selectedGroup, toast]);

  const handleCopyValue = useCallback((value: string) => {
    navigator.clipboard.writeText(value);
    toast({
      title: "Value copied",
      description: "Environment variable value copied to clipboard",
    });
  }, [toast]);

  const handleExportEnv = useCallback(() => {
    const envContent = selectedGroup.variables
      .map(envVar => `${envVar.key}=${envVar.value}`)
      .join('\n');

    const blob = new Blob([envContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `.env.${selectedGroup.environment}`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Environment exported",
      description: `Exported ${selectedGroup.variables.length} variables`,
    });
  }, [selectedGroup, toast]);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'database': return <Database className="w-4 h-4 text-blue-500" />;
      case 'api': return <Globe className="w-4 h-4 text-green-500" />;
      case 'auth': return <Shield className="w-4 h-4 text-purple-500" />;
      case 'config': return <Settings2 className="w-4 h-4 text-orange-500" />;
      case 'secret': return <Lock className="w-4 h-4 text-red-500" />;
      default: return <Key className="w-4 h-4 text-gray-500" />;
    }
  };

  const validateVariable = (envVar: EnvironmentVariable): string | null => {
    if (!envVar.validation) return null;

    const { type, pattern, minLength, maxLength } = envVar.validation;
    const { value } = envVar;

    switch (type) {
      case 'number':
        if (isNaN(Number(value))) return 'Must be a valid number';
        break;
      case 'boolean':
        if (!['true', 'false', '1', '0'].includes(value.toLowerCase())) {
          return 'Must be a boolean value (true/false)';
        }
        break;
      case 'url':
        try {
          new URL(value);
        } catch {
          return 'Must be a valid URL';
        }
        break;
      case 'email':
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) return 'Must be a valid email address';
        break;
      case 'json':
        try {
          JSON.parse(value);
        } catch {
          return 'Must be valid JSON';
        }
        break;
    }

    if (pattern && !new RegExp(pattern).test(value)) {
      return `Must match pattern: ${pattern}`;
    }

    if (minLength && value.length < minLength) {
      return `Must be at least ${minLength} characters`;
    }

    if (maxLength && value.length > maxLength) {
      return `Must be no more than ${maxLength} characters`;
    }

    return null;
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings2 className="w-5 h-5" />
            Environment Variable Manager
            <Badge variant="outline">
              {selectedGroup.variables.length} variables
            </Badge>
          </DialogTitle>
        </DialogHeader>

        {!isEditing ? (
          <Tabs defaultValue="variables" className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="variables">Variables</TabsTrigger>
              <TabsTrigger value="validation">Validation</TabsTrigger>
              <TabsTrigger value="templates">Templates</TabsTrigger>
            </TabsList>

            <TabsContent value="variables" className="flex-1 flex flex-col space-y-4">
              {/* Environment Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Environment Selection</span>
                    <div className="flex gap-2">
                      <Button onClick={handleCreateVariable}>
                        <Plus className="w-4 h-4 mr-2" />
                        Add Variable
                      </Button>
                      <Button variant="outline" onClick={handleExportEnv}>
                        <Download className="w-4 h-4 mr-2" />
                        Export .env
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4">
                    <div className="flex gap-2">
                      {envGroups.map((group) => (
                        <Button
                          key={group.id}
                          variant={selectedGroup.id === group.id ? "default" : "outline"}
                          onClick={() => setSelectedGroup(group)}
                          className="flex items-center gap-2"
                        >
                          <Server className="w-4 h-4" />
                          {group.name}
                          <Badge variant="secondary">{group.variables.length}</Badge>
                        </Button>
                      ))}
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={showSecrets}
                          onChange={(e) => setShowSecrets(e.target.checked)}
                          className="rounded"
                        />
                        <span className="text-sm">Show secret values</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Filters */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <Input
                        placeholder="Search variables..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <select
                      value={filterCategory}
                      onChange={(e) => setFilterCategory(e.target.value)}
                      className="px-3 py-2 border rounded-md"
                    >
                      <option value="all">All Categories</option>
                      <option value="database">Database</option>
                      <option value="api">API</option>
                      <option value="auth">Authentication</option>
                      <option value="config">Configuration</option>
                      <option value="secret">Secrets</option>
                      <option value="custom">Custom</option>
                    </select>
                  </div>
                </CardContent>
              </Card>

              {/* Variables List */}
              <Card className="flex-1">
                <CardHeader>
                  <CardTitle>{selectedGroup.name} Environment Variables</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-3">
                      {filteredVariables.map((envVar) => {
                        const validationError = validateVariable(envVar);
                        return (
                          <div
                            key={envVar.id}
                            className={`p-4 border rounded-lg ${
                              validationError ? 'border-red-200 bg-red-50 dark:bg-red-950' : ''
                            }`}
                          >
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  {getCategoryIcon(envVar.category)}
                                  <span className="font-medium font-mono">{envVar.key}</span>
                                  <Badge variant="outline">{envVar.category}</Badge>
                                  {envVar.isRequired && (
                                    <Badge variant="destructive">Required</Badge>
                                  )}
                                  {envVar.isSecret && (
                                    <Badge variant="secondary">Secret</Badge>
                                  )}
                                </div>
                                <p className="text-sm text-gray-500 mb-2">
                                  {envVar.description}
                                </p>
                                <div className="flex items-center gap-2">
                                  <span className="text-sm font-mono bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                                    {envVar.isSecret && !showSecrets 
                                      ? '••••••••' 
                                      : envVar.value.length > 50 
                                        ? `${envVar.value.substring(0, 50)}...` 
                                        : envVar.value}
                                  </span>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleCopyValue(envVar.value)}
                                  >
                                    <Copy className="w-3 h-3" />
                                  </Button>
                                </div>
                                {validationError && (
                                  <div className="flex items-center gap-2 mt-2 text-red-600">
                                    <AlertTriangle className="w-4 h-4" />
                                    <span className="text-sm">{validationError}</span>
                                  </div>
                                )}
                              </div>
                              <div className="flex items-center gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleEditVariable(envVar)}
                                >
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDeleteVariable(envVar.id)}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                            <div className="text-xs text-gray-400">
                              Modified: {envVar.lastModified.toLocaleString()} by {envVar.createdBy}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="validation" className="flex-1 flex flex-col space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Validation Rules</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {selectedGroup.variables.map((envVar) => {
                      const validationError = validateVariable(envVar);
                      return (
                        <div key={envVar.id} className="flex items-center justify-between p-3 border rounded">
                          <div className="flex items-center gap-3">
                            <span className="font-mono">{envVar.key}</span>
                            <Badge variant="outline">{envVar.validation?.type || 'string'}</Badge>
                            {envVar.validation?.pattern && (
                              <Badge variant="secondary">Pattern</Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            {validationError ? (
                              <div className="flex items-center gap-2 text-red-600">
                                <AlertTriangle className="w-4 h-4" />
                                <span className="text-sm">Invalid</span>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2 text-green-600">
                                <Shield className="w-4 h-4" />
                                <span className="text-sm">Valid</span>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="templates" className="flex-1 flex flex-col space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Environment Templates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Node.js Application</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-500 mb-3">
                          Standard environment variables for a Node.js application
                        </p>
                        <Button variant="outline" className="w-full">
                          Apply Template
                        </Button>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Database Configuration</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-500 mb-3">
                          Database connection and configuration variables
                        </p>
                        <Button variant="outline" className="w-full">
                          Apply Template
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        ) : (
          <div className="flex-1 flex flex-col space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">
                {editingVar.id ? 'Edit Variable' : 'New Environment Variable'}
              </h3>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSaveVariable}>
                  Save Variable
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Variable Key *</label>
                  <Input
                    value={editingVar.key || ''}
                    onChange={(e) => setEditingVar(prev => ({ ...prev, key: e.target.value }))}
                    placeholder="DATABASE_URL"
                    className="font-mono"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">Value *</label>
                  <div className="relative">
                    <Textarea
                      value={editingVar.value || ''}
                      onChange={(e) => setEditingVar(prev => ({ ...prev, value: e.target.value }))}
                      placeholder="Enter variable value"
                      rows={3}
                      className="font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium">Description</label>
                  <Input
                    value={editingVar.description || ''}
                    onChange={(e) => setEditingVar(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe this variable"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm font-medium">Category</label>
                    <select
                      value={editingVar.category || 'custom'}
                      onChange={(e) => setEditingVar(prev => ({ ...prev, category: e.target.value as any }))}
                      className="w-full px-3 py-2 border rounded-md"
                    >
                      <option value="database">Database</option>
                      <option value="api">API</option>
                      <option value="auth">Authentication</option>
                      <option value="config">Configuration</option>
                      <option value="secret">Secret</option>
                      <option value="custom">Custom</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Environment</label>
                    <select
                      value={editingVar.environment || selectedGroup.environment}
                      onChange={(e) => setEditingVar(prev => ({ ...prev, environment: e.target.value as any }))}
                      className="w-full px-3 py-2 border rounded-md"
                    >
                      <option value="development">Development</option>
                      <option value="staging">Staging</option>
                      <option value="production">Production</option>
                      <option value="all">All Environments</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-3">
                  <h4 className="font-medium">Options</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={editingVar.isSecret || false}
                        onChange={(e) => setEditingVar(prev => ({ ...prev, isSecret: e.target.checked }))}
                        className="rounded"
                      />
                      <span className="text-sm">Secret value (hidden by default)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={editingVar.isRequired || false}
                        onChange={(e) => setEditingVar(prev => ({ ...prev, isRequired: e.target.checked }))}
                        className="rounded"
                      />
                      <span className="text-sm">Required variable</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium">Default Value</label>
                  <Input
                    value={editingVar.defaultValue || ''}
                    onChange={(e) => setEditingVar(prev => ({ ...prev, defaultValue: e.target.value }))}
                    placeholder="Optional default value"
                  />
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">Validation</h4>
                  <div>
                    <label className="text-sm font-medium">Data Type</label>
                    <select
                      value={editingVar.validation?.type || 'string'}
                      onChange={(e) => setEditingVar(prev => ({
                        ...prev,
                        validation: { ...prev.validation, type: e.target.value as any }
                      }))}
                      className="w-full px-3 py-2 border rounded-md"
                    >
                      <option value="string">String</option>
                      <option value="number">Number</option>
                      <option value="boolean">Boolean</option>
                      <option value="url">URL</option>
                      <option value="email">Email</option>
                      <option value="json">JSON</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-sm font-medium">Min Length</label>
                      <Input
                        type="number"
                        value={editingVar.validation?.minLength || ''}
                        onChange={(e) => setEditingVar(prev => ({
                          ...prev,
                          validation: { 
                            type: prev.validation?.type || 'string',
                            ...prev.validation, 
                            minLength: e.target.value ? parseInt(e.target.value) : undefined 
                          }
                        }))}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Max Length</label>
                      <Input
                        type="number"
                        value={editingVar.validation?.maxLength || ''}
                        onChange={(e) => setEditingVar(prev => ({
                          ...prev,
                          validation: { 
                            type: prev.validation?.type || 'string',
                            ...prev.validation, 
                            maxLength: e.target.value ? parseInt(e.target.value) : undefined 
                          }
                        }))}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Pattern (Regex)</label>
                    <Input
                      value={editingVar.validation?.pattern || ''}
                      onChange={(e) => setEditingVar(prev => ({
                        ...prev,
                        validation: { 
                          type: prev.validation?.type || 'string',
                          ...prev.validation, 
                          pattern: e.target.value 
                        }
                      }))}
                      placeholder="^[A-Z0-9_]+$"
                      className="font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}