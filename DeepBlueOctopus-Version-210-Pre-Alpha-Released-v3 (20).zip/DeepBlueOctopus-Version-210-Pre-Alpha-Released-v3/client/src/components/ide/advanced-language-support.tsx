import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { 
  Code, Terminal, Play, Download, Settings, 
  FileCode, Cpu, HardDrive, Clock, Check, 
  AlertCircle, Package, Zap, BookOpen,
  ChevronRight, Monitor, Database
} from "lucide-react";

interface AdvancedLanguageSupportProps {
  isOpen: boolean;
  onClose: () => void;
}

interface LanguageConfig {
  id: string;
  name: string;
  version: string;
  status: 'installed' | 'available' | 'installing' | 'error';
  category: string;
  description: string;
  features: string[];
  fileExtensions: string[];
  packageManager?: string;
  compiler?: string;
  interpreter?: string;
  debugger?: boolean;
  linting?: boolean;
  formatting?: boolean;
  intellisense?: boolean;
  frameworks?: string[];
  size: string;
  popularity: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'expert';
}

const PROGRAMMING_LANGUAGES: LanguageConfig[] = [
  {
    id: 'javascript',
    name: 'JavaScript',
    version: 'ES2024',
    status: 'installed',
    category: 'Web Development',
    description: 'Modern JavaScript with ES modules, async/await, and TypeScript integration',
    features: ['ES2024', 'Node.js', 'NPM', 'Webpack', 'Babel'],
    fileExtensions: ['.js', '.mjs', '.cjs'],
    packageManager: 'npm',
    interpreter: 'node',
    debugger: true,
    linting: true,
    formatting: true,
    intellisense: true,
    frameworks: ['React', 'Vue', 'Angular', 'Express', 'Next.js'],
    size: '45MB',
    popularity: 98,
    difficulty: 'beginner'
  },
  {
    id: 'typescript',
    name: 'TypeScript',
    version: '5.3.0',
    status: 'installed',
    category: 'Web Development',
    description: 'Strongly typed JavaScript with advanced type system and modern features',
    features: ['Type Safety', 'TSC', 'Declaration Files', 'Decorators'],
    fileExtensions: ['.ts', '.tsx', '.d.ts'],
    packageManager: 'npm',
    compiler: 'tsc',
    debugger: true,
    linting: true,
    formatting: true,
    intellisense: true,
    frameworks: ['React', 'Angular', 'NestJS', 'Express'],
    size: '52MB',
    popularity: 95,
    difficulty: 'intermediate'
  },
  {
    id: 'python',
    name: 'Python',
    version: '3.12',
    status: 'installed',
    category: 'Data Science',
    description: 'High-level programming language for AI, data science, and web development',
    features: ['CPython', 'Pip', 'Virtual Env', 'Jupyter', 'NumPy'],
    fileExtensions: ['.py', '.pyw', '.ipynb'],
    packageManager: 'pip',
    interpreter: 'python',
    debugger: true,
    linting: true,
    formatting: true,
    intellisense: true,
    frameworks: ['Django', 'Flask', 'FastAPI', 'PyTorch', 'TensorFlow'],
    size: '78MB',
    popularity: 94,
    difficulty: 'beginner'
  },
  {
    id: 'rust',
    name: 'Rust',
    version: '1.75.0',
    status: 'available',
    category: 'Systems Programming',
    description: 'Memory-safe systems programming language with zero-cost abstractions',
    features: ['Cargo', 'Memory Safety', 'Concurrency', 'Performance'],
    fileExtensions: ['.rs'],
    packageManager: 'cargo',
    compiler: 'rustc',
    debugger: true,
    linting: true,
    formatting: true,
    intellisense: true,
    frameworks: ['Tokio', 'Actix', 'Rocket', 'Yew'],
    size: '165MB',
    popularity: 87,
    difficulty: 'advanced'
  },
  {
    id: 'go',
    name: 'Go',
    version: '1.21.6',
    status: 'available',
    category: 'Backend Development',
    description: 'Fast, statically typed language designed for modern distributed systems',
    features: ['Goroutines', 'Modules', 'Cross Platform', 'Fast Compilation'],
    fileExtensions: ['.go'],
    packageManager: 'go mod',
    compiler: 'go build',
    debugger: true,
    linting: true,
    formatting: true,
    intellisense: true,
    frameworks: ['Gin', 'Echo', 'Fiber', 'Gorilla'],
    size: '125MB',
    popularity: 82,
    difficulty: 'intermediate'
  },
  {
    id: 'java',
    name: 'Java',
    version: '21 LTS',
    status: 'available',
    category: 'Enterprise Development',
    description: 'Enterprise-grade object-oriented programming language',
    features: ['JVM', 'Maven', 'Gradle', 'Spring', 'JPA'],
    fileExtensions: ['.java', '.class', '.jar'],
    packageManager: 'maven',
    compiler: 'javac',
    debugger: true,
    linting: true,
    formatting: true,
    intellisense: true,
    frameworks: ['Spring Boot', 'Hibernate', 'Apache Kafka', 'JUnit'],
    size: '195MB',
    popularity: 85,
    difficulty: 'intermediate'
  },
  {
    id: 'csharp',
    name: 'C#',
    version: '.NET 8',
    status: 'available',
    category: 'Enterprise Development',
    description: 'Modern object-oriented language for .NET ecosystem',
    features: ['.NET 8', 'NuGet', 'LINQ', 'Async/Await'],
    fileExtensions: ['.cs', '.csx'],
    packageManager: 'nuget',
    compiler: 'dotnet',
    debugger: true,
    linting: true,
    formatting: true,
    intellisense: true,
    frameworks: ['ASP.NET Core', 'Entity Framework', 'Blazor', 'MAUI'],
    size: '175MB',
    popularity: 78,
    difficulty: 'intermediate'
  },
  {
    id: 'cpp',
    name: 'C++',
    version: 'C++23',
    status: 'available',
    category: 'Systems Programming',
    description: 'High-performance systems programming language',
    features: ['STL', 'CMake', 'Conan', 'Modern C++'],
    fileExtensions: ['.cpp', '.cxx', '.cc', '.h', '.hpp'],
    packageManager: 'conan',
    compiler: 'g++',
    debugger: true,
    linting: true,
    formatting: true,
    intellisense: true,
    frameworks: ['Qt', 'Boost', 'POCO', 'OpenCV'],
    size: '145MB',
    popularity: 75,
    difficulty: 'advanced'
  },
  {
    id: 'kotlin',
    name: 'Kotlin',
    version: '1.9.22',
    status: 'available',
    category: 'Mobile Development',
    description: 'Modern JVM language for Android and multiplatform development',
    features: ['JVM', 'Android', 'Multiplatform', 'Coroutines'],
    fileExtensions: ['.kt', '.kts'],
    packageManager: 'gradle',
    compiler: 'kotlinc',
    debugger: true,
    linting: true,
    formatting: true,
    intellisense: true,
    frameworks: ['Android SDK', 'Ktor', 'Compose', 'Spring'],
    size: '155MB',
    popularity: 73,
    difficulty: 'intermediate'
  },
  {
    id: 'swift',
    name: 'Swift',
    version: '5.9',
    status: 'available',
    category: 'Mobile Development',
    description: 'Apple\'s modern language for iOS, macOS, and server development',
    features: ['iOS SDK', 'SwiftUI', 'Combine', 'SPM'],
    fileExtensions: ['.swift'],
    packageManager: 'swift package manager',
    compiler: 'swiftc',
    debugger: true,
    linting: true,
    formatting: true,
    intellisense: true,
    frameworks: ['SwiftUI', 'UIKit', 'Vapor', 'Perfect'],
    size: '185MB',
    popularity: 68,
    difficulty: 'intermediate'
  }
];

export default function AdvancedLanguageSupport({ isOpen, onClose }: AdvancedLanguageSupportProps) {
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageConfig | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [installProgress, setInstallProgress] = useState(0);
  const [isInstalling, setIsInstalling] = useState(false);
  const [languageStats, setLanguageStats] = useState({
    installed: 3,
    available: 7,
    total: 10
  });

  const { toast } = useToast();

  const categories = ["All", "Web Development", "Mobile Development", "Data Science", "Systems Programming", "Enterprise Development", "Backend Development"];

  const filteredLanguages = PROGRAMMING_LANGUAGES.filter(lang => {
    const matchesSearch = lang.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         lang.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || lang.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const installLanguage = async (language: LanguageConfig) => {
    setIsInstalling(true);
    setInstallProgress(0);
    
    // Simulate installation progress
    const interval = setInterval(() => {
      setInstallProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsInstalling(false);
          language.status = 'installed';
          toast({
            title: "Installation Complete",
            description: `${language.name} ${language.version} has been successfully installed`,
          });
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 200);
  };

  const uninstallLanguage = (language: LanguageConfig) => {
    language.status = 'available';
    toast({
      title: "Language Uninstalled",
      description: `${language.name} has been removed from your system`,
    });
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-500';
      case 'intermediate': return 'bg-yellow-500';
      case 'advanced': return 'bg-orange-500';
      case 'expert': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'installed': return <Check className="w-4 h-4 text-green-500" />;
      case 'installing': return <Download className="w-4 h-4 text-blue-500 animate-spin" />;
      case 'error': return <AlertCircle className="w-4 h-4 text-red-500" />;
      default: return <Download className="w-4 h-4 text-gray-500" />;
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Code className="w-5 h-5" />
            Advanced Language Support
            <Badge variant="outline" className="ml-2">
              {languageStats.installed}/{languageStats.total} Languages
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex gap-6 overflow-hidden">
          {/* Left Panel - Language List */}
          <div className="flex-1 space-y-4">
            {/* Search and Filters */}
            <div className="space-y-3">
              <Input
                placeholder="Search programming languages..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full"
              />
              
              <div className="flex gap-2 overflow-x-auto">
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedCategory(category)}
                    className="whitespace-nowrap"
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>

            {/* Language Grid */}
            <ScrollArea className="flex-1">
              <div className="grid grid-cols-1 gap-3">
                {filteredLanguages.map((language) => (
                  <Card 
                    key={language.id}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      selectedLanguage?.id === language.id ? 'ring-2 ring-blue-500' : ''
                    }`}
                    onClick={() => setSelectedLanguage(language)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-2">
                            {getStatusIcon(language.status)}
                            <h3 className="font-semibold">{language.name}</h3>
                            <Badge variant="outline" className="text-xs">
                              {language.version}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${getDifficultyColor(language.difficulty)}`} />
                          <span className="text-xs text-gray-600 capitalize">{language.difficulty}</span>
                        </div>
                      </div>
                      
                      <p className="text-sm text-gray-600 mb-3">{language.description}</p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex gap-1">
                          {language.features.slice(0, 3).map((feature, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                          {language.features.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{language.features.length - 3}
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-gray-500">{language.size}</span>
                          <Progress value={language.popularity} className="w-12 h-1" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* Right Panel - Language Details */}
          {selectedLanguage && (
            <div className="w-96 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getStatusIcon(selectedLanguage.status)}
                    {selectedLanguage.name}
                    <Badge>{selectedLanguage.version}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600">{selectedLanguage.description}</p>
                  
                  {/* Installation Progress */}
                  {isInstalling && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Installing...</span>
                        <span>{Math.round(installProgress)}%</span>
                      </div>
                      <Progress value={installProgress} className="w-full" />
                    </div>
                  )}
                  
                  {/* Action Button */}
                  <div className="flex gap-2">
                    {selectedLanguage.status === 'installed' ? (
                      <Button 
                        variant="destructive" 
                        size="sm"
                        onClick={() => uninstallLanguage(selectedLanguage)}
                        disabled={isInstalling}
                      >
                        Uninstall
                      </Button>
                    ) : (
                      <Button 
                        onClick={() => installLanguage(selectedLanguage)}
                        disabled={isInstalling}
                        size="sm"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Install
                      </Button>
                    )}
                    <Button variant="outline" size="sm">
                      <Settings className="w-4 h-4 mr-2" />
                      Configure
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Language Details Tabs */}
              <Card>
                <CardContent className="p-0">
                  <Tabs defaultValue="features" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="features">Features</TabsTrigger>
                      <TabsTrigger value="tools">Tools</TabsTrigger>
                      <TabsTrigger value="frameworks">Frameworks</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="features" className="p-4 space-y-3">
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">Language Features</h4>
                        <div className="space-y-1">
                          {selectedLanguage.features.map((feature, idx) => (
                            <div key={idx} className="flex items-center gap-2 text-sm">
                              <ChevronRight className="w-3 h-3" />
                              <span>{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">File Extensions</h4>
                        <div className="flex flex-wrap gap-1">
                          {selectedLanguage.fileExtensions.map((ext, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {ext}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">Capabilities</h4>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div className="flex items-center gap-1">
                            <Terminal className="w-3 h-3" />
                            <span>Debugging</span>
                            {selectedLanguage.debugger ? <Check className="w-3 h-3 text-green-500" /> : null}
                          </div>
                          <div className="flex items-center gap-1">
                            <Code className="w-3 h-3" />
                            <span>Linting</span>
                            {selectedLanguage.linting ? <Check className="w-3 h-3 text-green-500" /> : null}
                          </div>
                          <div className="flex items-center gap-1">
                            <Zap className="w-3 h-3" />
                            <span>Formatting</span>
                            {selectedLanguage.formatting ? <Check className="w-3 h-3 text-green-500" /> : null}
                          </div>
                          <div className="flex items-center gap-1">
                            <BookOpen className="w-3 h-3" />
                            <span>IntelliSense</span>
                            {selectedLanguage.intellisense ? <Check className="w-3 h-3 text-green-500" /> : null}
                          </div>
                        </div>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="tools" className="p-4 space-y-3">
                      <div className="space-y-3">
                        {selectedLanguage.packageManager && (
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Package className="w-4 h-4" />
                              <span className="text-sm">Package Manager</span>
                            </div>
                            <Badge variant="outline">{selectedLanguage.packageManager}</Badge>
                          </div>
                        )}
                        
                        {selectedLanguage.compiler && (
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Cpu className="w-4 h-4" />
                              <span className="text-sm">Compiler</span>
                            </div>
                            <Badge variant="outline">{selectedLanguage.compiler}</Badge>
                          </div>
                        )}
                        
                        {selectedLanguage.interpreter && (
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Terminal className="w-4 h-4" />
                              <span className="text-sm">Interpreter</span>
                            </div>
                            <Badge variant="outline">{selectedLanguage.interpreter}</Badge>
                          </div>
                        )}
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="frameworks" className="p-4">
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">Popular Frameworks</h4>
                        <div className="space-y-1">
                          {selectedLanguage.frameworks?.map((framework, idx) => (
                            <div key={idx} className="flex items-center gap-2 text-sm">
                              <ChevronRight className="w-3 h-3" />
                              <span>{framework}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 border-t">
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Check className="w-4 h-4 text-green-500" />
              <span>{languageStats.installed} Installed</span>
            </div>
            <div className="flex items-center gap-1">
              <Download className="w-4 h-4 text-gray-500" />
              <span>{languageStats.available} Available</span>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            <Button>
              <Settings className="w-4 h-4 mr-2" />
              Global Settings
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}