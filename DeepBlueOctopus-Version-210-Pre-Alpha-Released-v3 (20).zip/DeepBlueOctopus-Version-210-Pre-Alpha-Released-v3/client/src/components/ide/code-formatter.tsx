import React, { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  Code, Settings, Zap, Download, Upload,
  FileText, CheckCircle, AlertTriangle, RefreshCw
} from "lucide-react";

interface CodeFormatterProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FormatConfig {
  id: string;
  name: string;
  language: string;
  settings: {
    indent: {
      type: 'spaces' | 'tabs';
      size: number;
    };
    semicolons: boolean;
    quotes: 'single' | 'double' | 'auto';
    trailingCommas: 'none' | 'es5' | 'all';
    bracketSpacing: boolean;
    bracketSameLine: boolean;
    arrowParens: 'avoid' | 'always';
    printWidth: number;
    tabWidth: number;
    useTabs: boolean;
    endOfLine: 'lf' | 'crlf' | 'cr' | 'auto';
    insertFinalNewline: boolean;
    trimTrailingWhitespace: boolean;
  };
}

interface FormattingResult {
  success: boolean;
  formattedCode: string;
  errors: string[];
  warnings: string[];
  stats: {
    originalLines: number;
    formattedLines: number;
    changes: number;
  };
}

export default function CodeFormatter({ isOpen, onClose }: CodeFormatterProps) {
  const [formatConfigs, setFormatConfigs] = useState<FormatConfig[]>([
    {
      id: '1',
      name: 'JavaScript Standard',
      language: 'javascript',
      settings: {
        indent: { type: 'spaces', size: 2 },
        semicolons: true,
        quotes: 'single',
        trailingCommas: 'es5',
        bracketSpacing: true,
        bracketSameLine: false,
        arrowParens: 'avoid',
        printWidth: 80,
        tabWidth: 2,
        useTabs: false,
        endOfLine: 'lf',
        insertFinalNewline: true,
        trimTrailingWhitespace: true
      }
    },
    {
      id: '2',
      name: 'TypeScript Strict',
      language: 'typescript',
      settings: {
        indent: { type: 'spaces', size: 2 },
        semicolons: true,
        quotes: 'double',
        trailingCommas: 'all',
        bracketSpacing: true,
        bracketSameLine: false,
        arrowParens: 'always',
        printWidth: 100,
        tabWidth: 2,
        useTabs: false,
        endOfLine: 'lf',
        insertFinalNewline: true,
        trimTrailingWhitespace: true
      }
    },
    {
      id: '3',
      name: 'Python PEP8',
      language: 'python',
      settings: {
        indent: { type: 'spaces', size: 4 },
        semicolons: false,
        quotes: 'single',
        trailingCommas: 'none',
        bracketSpacing: false,
        bracketSameLine: true,
        arrowParens: 'avoid',
        printWidth: 88,
        tabWidth: 4,
        useTabs: false,
        endOfLine: 'lf',
        insertFinalNewline: true,
        trimTrailingWhitespace: true
      }
    }
  ]);

  const [selectedConfig, setSelectedConfig] = useState<FormatConfig>(formatConfigs[0]);
  const [formatResults, setFormatResults] = useState<FormattingResult[]>([]);
  const [isFormatting, setIsFormatting] = useState(false);
  const [batchMode, setBatchMode] = useState(false);

  const { files, activeTab, updateFileContent } = useIDEState();
  const { toast } = useToast();

  const formatCode = useCallback(async (code: string, language: string, config: FormatConfig): Promise<FormattingResult> => {
    // Simulate code formatting logic
    await new Promise(resolve => setTimeout(resolve, 1000));

    const lines = code.split('\n');
    let formattedCode = code;
    let changes = 0;

    // Apply basic formatting rules based on config
    const { settings } = config;
    
    // Handle indentation
    if (settings.indent.type === 'spaces') {
      formattedCode = formattedCode.replace(/\t/g, ' '.repeat(settings.indent.size));
      changes += (code.match(/\t/g) || []).length;
    } else {
      formattedCode = formattedCode.replace(/ {2,}/g, '\t');
      changes += (code.match(/ {2,}/g) || []).length;
    }

    // Handle quotes (simple replacement for demo)
    if (language === 'javascript' || language === 'typescript') {
      if (settings.quotes === 'single') {
        const doubleQuotes = formattedCode.match(/"/g);
        formattedCode = formattedCode.replace(/"/g, "'");
        changes += doubleQuotes ? doubleQuotes.length : 0;
      } else if (settings.quotes === 'double') {
        const singleQuotes = formattedCode.match(/'/g);
        formattedCode = formattedCode.replace(/'/g, '"');
        changes += singleQuotes ? singleQuotes.length : 0;
      }
    }

    // Handle semicolons
    if (language === 'javascript' || language === 'typescript') {
      if (settings.semicolons) {
        const missingSemicolons = formattedCode.match(/[^;]\n/g);
        formattedCode = formattedCode.replace(/([^;])\n/g, '$1;\n');
        changes += missingSemicolons ? missingSemicolons.length : 0;
      }
    }

    // Trim trailing whitespace
    if (settings.trimTrailingWhitespace) {
      const beforeTrim = formattedCode;
      formattedCode = formattedCode.replace(/ +$/gm, '');
      changes += beforeTrim.length - formattedCode.length;
    }

    // Insert final newline
    if (settings.insertFinalNewline && !formattedCode.endsWith('\n')) {
      formattedCode += '\n';
      changes += 1;
    }

    const formattedLines = formattedCode.split('\n');

    return {
      success: true,
      formattedCode,
      errors: [],
      warnings: [],
      stats: {
        originalLines: lines.length,
        formattedLines: formattedLines.length,
        changes
      }
    };
  }, []);

  const handleFormatCurrent = useCallback(async () => {
    if (!activeTab) {
      toast({
        title: "No file selected",
        description: "Please select a file to format",
        variant: "destructive",
      });
      return;
    }

    const file = files.find(f => f.id === activeTab.id);
    if (!file || !file.content) {
      toast({
        title: "No content to format",
        description: "The selected file is empty or invalid",
        variant: "destructive",
      });
      return;
    }

    setIsFormatting(true);

    try {
      const result = await formatCode(file.content, file.language || 'text', selectedConfig);
      
      if (result.success) {
        updateFileContent(file.id, result.formattedCode);
        setFormatResults(prev => [result, ...prev.slice(0, 9)]);
        
        toast({
          title: "File formatted successfully",
          description: `Applied ${result.stats.changes} changes`,
        });
      } else {
        toast({
          title: "Formatting failed",
          description: result.errors.join(', '),
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Formatting error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsFormatting(false);
    }
  }, [activeTab, files, selectedConfig, formatCode, updateFileContent, toast]);

  const handleBatchFormat = useCallback(async () => {
    if (!files.length) {
      toast({
        title: "No files to format",
        description: "Please add files to format",
        variant: "destructive",
      });
      return;
    }

    setIsFormatting(true);
    const results: FormattingResult[] = [];

    try {
      for (const file of files) {
        if (file.isDirectory || !file.content) continue;
        
        const config = formatConfigs.find(c => c.language === file.language) || selectedConfig;
        const result = await formatCode(file.content, file.language || 'text', config);
        
        if (result.success) {
          updateFileContent(file.id, result.formattedCode);
          results.push(result);
        }
      }

      setFormatResults(prev => [...results, ...prev.slice(0, 10 - results.length)]);
      
      toast({
        title: "Batch formatting completed",
        description: `Formatted ${results.length} files`,
      });
    } catch (error) {
      toast({
        title: "Batch formatting error",
        description: "Some files could not be formatted",
        variant: "destructive",
      });
    } finally {
      setIsFormatting(false);
    }
  }, [files, formatConfigs, selectedConfig, formatCode, updateFileContent, toast]);

  const createCustomConfig = useCallback(() => {
    const newConfig: FormatConfig = {
      id: Date.now().toString(),
      name: 'Custom Config',
      language: 'javascript',
      settings: { ...selectedConfig.settings }
    };

    setFormatConfigs(prev => [...prev, newConfig]);
    setSelectedConfig(newConfig);

    toast({
      title: "Custom config created",
      description: "You can now modify the settings",
    });
  }, [selectedConfig, toast]);

  const exportConfig = useCallback(() => {
    const configData = {
      config: selectedConfig,
      exportedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(configData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedConfig.name.toLowerCase().replace(/\s+/g, '-')}-config.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Config exported",
      description: "Configuration has been downloaded",
    });
  }, [selectedConfig, toast]);

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Code className="w-5 h-5" />
            Code Formatter
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex gap-6">
          {/* Configuration Panel */}
          <div className="w-80 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Format Configuration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Config Preset</label>
                    <Select 
                      value={selectedConfig.id} 
                      onValueChange={(value) => {
                        const config = formatConfigs.find(c => c.id === value);
                        if (config) setSelectedConfig(config);
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {formatConfigs.map((config) => (
                          <SelectItem key={config.id} value={config.id}>
                            {config.name} ({config.language})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm">Batch Mode</span>
                    <Switch 
                      checked={batchMode}
                      onCheckedChange={setBatchMode}
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      onClick={batchMode ? handleBatchFormat : handleFormatCurrent}
                      disabled={isFormatting}
                      className="flex-1"
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      {isFormatting ? 'Formatting...' : (batchMode ? 'Format All' : 'Format Current')}
                    </Button>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" onClick={createCustomConfig} className="flex-1">
                      <Settings className="w-4 h-4 mr-2" />
                      New Config
                    </Button>
                    <Button variant="outline" onClick={exportConfig}>
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Format Results */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Results</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-48">
                  <div className="space-y-2">
                    {formatResults.map((result, index) => (
                      <div key={index} className="p-2 border rounded text-xs">
                        <div className="flex items-center gap-2 mb-1">
                          {result.success ? (
                            <CheckCircle className="w-3 h-3 text-green-500" />
                          ) : (
                            <AlertTriangle className="w-3 h-3 text-red-500" />
                          )}
                          <span className="font-medium">
                            {result.stats.changes} changes
                          </span>
                        </div>
                        <div className="text-gray-500">
                          {result.stats.originalLines} → {result.stats.formattedLines} lines
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Settings Panel */}
          <div className="flex-1">
            <Card>
              <CardHeader>
                <CardTitle>Format Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="basic">
                  <TabsList>
                    <TabsTrigger value="basic">Basic</TabsTrigger>
                    <TabsTrigger value="advanced">Advanced</TabsTrigger>
                    <TabsTrigger value="rules">Rules</TabsTrigger>
                  </TabsList>

                  <TabsContent value="basic" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Indentation</label>
                        <Select 
                          value={selectedConfig.settings.indent.type}
                          onValueChange={(value: 'spaces' | 'tabs') => {
                            setSelectedConfig(prev => ({
                              ...prev,
                              settings: {
                                ...prev.settings,
                                indent: { ...prev.settings.indent, type: value }
                              }
                            }));
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="spaces">Spaces</SelectItem>
                            <SelectItem value="tabs">Tabs</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Indent Size</label>
                        <Input
                          type="number"
                          value={selectedConfig.settings.indent.size}
                          onChange={(e) => {
                            const size = parseInt(e.target.value) || 2;
                            setSelectedConfig(prev => ({
                              ...prev,
                              settings: {
                                ...prev.settings,
                                indent: { ...prev.settings.indent, size }
                              }
                            }));
                          }}
                          min="1"
                          max="8"
                        />
                      </div>

                      <div>
                        <label className="text-sm font-medium">Quotes</label>
                        <Select 
                          value={selectedConfig.settings.quotes}
                          onValueChange={(value: 'single' | 'double' | 'auto') => {
                            setSelectedConfig(prev => ({
                              ...prev,
                              settings: { ...prev.settings, quotes: value }
                            }));
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="single">Single</SelectItem>
                            <SelectItem value="double">Double</SelectItem>
                            <SelectItem value="auto">Auto</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Print Width</label>
                        <Input
                          type="number"
                          value={selectedConfig.settings.printWidth}
                          onChange={(e) => {
                            const printWidth = parseInt(e.target.value) || 80;
                            setSelectedConfig(prev => ({
                              ...prev,
                              settings: { ...prev.settings, printWidth }
                            }));
                          }}
                          min="40"
                          max="200"
                        />
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Semicolons</span>
                        <Switch 
                          checked={selectedConfig.settings.semicolons}
                          onCheckedChange={(checked) => {
                            setSelectedConfig(prev => ({
                              ...prev,
                              settings: { ...prev.settings, semicolons: checked }
                            }));
                          }}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm">Bracket Spacing</span>
                        <Switch 
                          checked={selectedConfig.settings.bracketSpacing}
                          onCheckedChange={(checked) => {
                            setSelectedConfig(prev => ({
                              ...prev,
                              settings: { ...prev.settings, bracketSpacing: checked }
                            }));
                          }}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm">Insert Final Newline</span>
                        <Switch 
                          checked={selectedConfig.settings.insertFinalNewline}
                          onCheckedChange={(checked) => {
                            setSelectedConfig(prev => ({
                              ...prev,
                              settings: { ...prev.settings, insertFinalNewline: checked }
                            }));
                          }}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm">Trim Trailing Whitespace</span>
                        <Switch 
                          checked={selectedConfig.settings.trimTrailingWhitespace}
                          onCheckedChange={(checked) => {
                            setSelectedConfig(prev => ({
                              ...prev,
                              settings: { ...prev.settings, trimTrailingWhitespace: checked }
                            }));
                          }}
                        />
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="advanced" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Trailing Commas</label>
                        <Select 
                          value={selectedConfig.settings.trailingCommas}
                          onValueChange={(value: 'none' | 'es5' | 'all') => {
                            setSelectedConfig(prev => ({
                              ...prev,
                              settings: { ...prev.settings, trailingCommas: value }
                            }));
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">None</SelectItem>
                            <SelectItem value="es5">ES5</SelectItem>
                            <SelectItem value="all">All</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Arrow Parens</label>
                        <Select 
                          value={selectedConfig.settings.arrowParens}
                          onValueChange={(value: 'avoid' | 'always') => {
                            setSelectedConfig(prev => ({
                              ...prev,
                              settings: { ...prev.settings, arrowParens: value }
                            }));
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="avoid">Avoid</SelectItem>
                            <SelectItem value="always">Always</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium">End of Line</label>
                        <Select 
                          value={selectedConfig.settings.endOfLine}
                          onValueChange={(value: 'lf' | 'crlf' | 'cr' | 'auto') => {
                            setSelectedConfig(prev => ({
                              ...prev,
                              settings: { ...prev.settings, endOfLine: value }
                            }));
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="lf">LF</SelectItem>
                            <SelectItem value="crlf">CRLF</SelectItem>
                            <SelectItem value="cr">CR</SelectItem>
                            <SelectItem value="auto">Auto</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Tab Width</label>
                        <Input
                          type="number"
                          value={selectedConfig.settings.tabWidth}
                          onChange={(e) => {
                            const tabWidth = parseInt(e.target.value) || 2;
                            setSelectedConfig(prev => ({
                              ...prev,
                              settings: { ...prev.settings, tabWidth }
                            }));
                          }}
                          min="1"
                          max="8"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm">Bracket Same Line</span>
                      <Switch 
                        checked={selectedConfig.settings.bracketSameLine}
                        onCheckedChange={(checked) => {
                          setSelectedConfig(prev => ({
                            ...prev,
                            settings: { ...prev.settings, bracketSameLine: checked }
                          }));
                        }}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="rules" className="space-y-4">
                    <div className="text-sm text-gray-500 p-4 border rounded">
                      <h4 className="font-medium mb-2">Language-Specific Rules</h4>
                      <div className="space-y-2">
                        <div><strong>JavaScript/TypeScript:</strong> ESLint, Prettier integration</div>
                        <div><strong>Python:</strong> PEP8, Black, autopep8 compatibility</div>
                        <div><strong>HTML/CSS:</strong> Beautify, stylelint support</div>
                        <div><strong>JSON:</strong> Standard JSON formatting</div>
                        <div><strong>Markdown:</strong> CommonMark specification</div>
                      </div>
                    </div>

                    <div className="text-sm">
                      <h4 className="font-medium mb-2">Current Configuration Summary</h4>
                      <div className="bg-gray-50 dark:bg-gray-900 p-3 rounded font-mono">
                        <pre>{JSON.stringify(selectedConfig.settings, null, 2)}</pre>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}