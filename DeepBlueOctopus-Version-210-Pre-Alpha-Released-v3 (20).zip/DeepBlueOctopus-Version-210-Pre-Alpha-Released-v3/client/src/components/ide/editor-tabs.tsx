import { X, Columns } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useIDEState } from "@/hooks/use-ide-state";
import { getFileIcon } from "@/lib/file-icons";

export default function EditorTabs() {
  const { openTabs, activeTabId, setActiveTab, closeTab } = useIDEState();

  return (
    <div className="ide-sidebar border-b ide-border flex">
      {openTabs.map((tab) => (
        <div
          key={tab.id}
          className={`flex items-center px-4 py-2 border-r ide-border cursor-pointer group transition-colors ${
            activeTabId === tab.id ? "tab-active" : "hover:bg-[var(--ide-panel)]"
          }`}
          onClick={() => setActiveTab(tab.id)}
        >
          {getFileIcon(tab.name, false)}
          <span className="text-sm mx-2">{tab.name}</span>
          
          {/* Modified indicator */}
          {tab.isModified && (
            <div className="w-2 h-2 rounded-full bg-[var(--ide-warning)] mr-2" />
          )}
          
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              closeTab(tab.id);
            }}
            className="ml-auto text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)] opacity-0 group-hover:opacity-100 transition-opacity p-1 h-auto"
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      ))}
      
      {/* Tab actions */}
      <div className="ml-auto flex items-center px-2">
        <Button
          variant="ghost"
          size="sm"
          className="text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)] p-2"
          title="Split Editor"
        >
          <Columns className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
