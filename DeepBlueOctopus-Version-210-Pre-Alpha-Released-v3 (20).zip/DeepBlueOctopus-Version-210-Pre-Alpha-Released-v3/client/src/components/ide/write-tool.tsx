import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import {
  PenTool,
  FileText,
  Wand2,
  Copy,
  Save,
  Download,
  Upload,
  Search,
  Replace,
  Type,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Bold,
  Italic,
  Underline,
  List,
  ListOrdered,
  Quote,
  Code,
  Link,
  Image,
  Table,
  Palette,
  Zap,
  BookOpen,
  Lightbulb,
  CheckCircle,
  AlertCircle,
  RefreshCw,
  RotateCw,
  Eye,
  Hash,
  Calendar,
  Clock,
  User,
  Tag,
  Bookmark,
  Globe
} from "lucide-react";

interface WriteToolProps {
  isOpen: boolean;
  onClose: () => void;
}

interface WritingTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  content: string;
  placeholders: string[];
}

interface TextAnalysis {
  wordCount: number;
  characterCount: number;
  paragraphCount: number;
  sentenceCount: number;
  readabilityScore: number;
  readingTime: number;
}

interface WritingTool {
  id: string;
  name: string;
  description: string;
  icon: any;
  category: string;
}

export default function WriteTool({ isOpen, onClose }: WriteToolProps) {
  const [activeTab, setActiveTab] = useState("editor");
  const [content, setContent] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [title, setTitle] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<TextAnalysis | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [replaceTerm, setReplaceTerm] = useState("");
  const [selectedTool, setSelectedTool] = useState("");

  const writingTemplates: WritingTemplate[] = [
    {
      id: "technical-doc",
      name: "Technical Documentation",
      description: "Comprehensive technical documentation template",
      category: "Documentation",
      content: `# {{TITLE}}

## Overview

{{OVERVIEW}}

## Prerequisites

- Node.js 18+
- PostgreSQL database
- Basic understanding of {{TECHNOLOGY}}

## Installation

1. Clone the repository:
   \`\`\`bash
   git clone {{REPOSITORY_URL}}
   cd {{PROJECT_NAME}}
   \`\`\`

2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

3. Configure environment:
   \`\`\`bash
   cp .env.example .env
   # Edit .env with your configuration
   \`\`\`

## Configuration

### Database Setup

{{DATABASE_SETUP}}

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| DATABASE_URL | PostgreSQL connection string | Yes |
| JWT_SECRET | Secret for JWT tokens | Yes |
| NODE_ENV | Environment mode | No |

## Usage

### Basic Usage

{{BASIC_USAGE}}

### Advanced Features

{{ADVANCED_FEATURES}}

## API Reference

### Authentication

- \`POST /api/auth/login\` - User authentication
- \`POST /api/auth/register\` - User registration
- \`DELETE /api/auth/logout\` - User logout

### {{API_SECTION}}

{{API_ENDPOINTS}}

## Examples

### Example 1: {{EXAMPLE_1_TITLE}}

\`\`\`{{LANGUAGE}}
{{EXAMPLE_1_CODE}}
\`\`\`

### Example 2: {{EXAMPLE_2_TITLE}}

\`\`\`{{LANGUAGE}}
{{EXAMPLE_2_CODE}}
\`\`\`

## Troubleshooting

### Common Issues

**Issue**: {{COMMON_ISSUE_1}}
**Solution**: {{SOLUTION_1}}

**Issue**: {{COMMON_ISSUE_2}}
**Solution**: {{SOLUTION_2}}

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

{{LICENSE}}`,
      placeholders: ["TITLE", "OVERVIEW", "TECHNOLOGY", "REPOSITORY_URL", "PROJECT_NAME", "DATABASE_SETUP", "BASIC_USAGE", "ADVANCED_FEATURES", "API_SECTION", "API_ENDPOINTS", "EXAMPLE_1_TITLE", "EXAMPLE_1_CODE", "LANGUAGE", "EXAMPLE_2_TITLE", "EXAMPLE_2_CODE", "COMMON_ISSUE_1", "SOLUTION_1", "COMMON_ISSUE_2", "SOLUTION_2", "LICENSE"]
    },
    {
      id: "blog-post",
      name: "Blog Post",
      description: "Engaging blog post with SEO optimization",
      category: "Content",
      content: `# {{TITLE}}

*Published on {{DATE}} by {{AUTHOR}}*

{{INTRODUCTION}}

## {{SECTION_1_TITLE}}

{{SECTION_1_CONTENT}}

### Key Points:

- {{KEY_POINT_1}}
- {{KEY_POINT_2}}
- {{KEY_POINT_3}}

## {{SECTION_2_TITLE}}

{{SECTION_2_CONTENT}}

> "{{QUOTE}}" - {{QUOTE_AUTHOR}}

## {{SECTION_3_TITLE}}

{{SECTION_3_CONTENT}}

### Code Example:

\`\`\`{{LANGUAGE}}
{{CODE_EXAMPLE}}
\`\`\`

## Conclusion

{{CONCLUSION}}

### Next Steps

1. {{NEXT_STEP_1}}
2. {{NEXT_STEP_2}}
3. {{NEXT_STEP_3}}

---

**Tags**: {{TAGS}}

**Related Articles**:
- [{{RELATED_1}}]({{RELATED_1_URL}})
- [{{RELATED_2}}]({{RELATED_2_URL}})`,
      placeholders: ["TITLE", "DATE", "AUTHOR", "INTRODUCTION", "SECTION_1_TITLE", "SECTION_1_CONTENT", "KEY_POINT_1", "KEY_POINT_2", "KEY_POINT_3", "SECTION_2_TITLE", "SECTION_2_CONTENT", "QUOTE", "QUOTE_AUTHOR", "SECTION_3_TITLE", "SECTION_3_CONTENT", "LANGUAGE", "CODE_EXAMPLE", "CONCLUSION", "NEXT_STEP_1", "NEXT_STEP_2", "NEXT_STEP_3", "TAGS", "RELATED_1", "RELATED_1_URL", "RELATED_2", "RELATED_2_URL"]
    },
    {
      id: "readme",
      name: "README File",
      description: "Professional README for GitHub repositories",
      category: "Documentation",
      content: `# {{PROJECT_NAME}}

{{DESCRIPTION}}

![{{PROJECT_NAME}} Demo]({{DEMO_IMAGE_URL}})

## 🚀 Features

- ✨ {{FEATURE_1}}
- 🔧 {{FEATURE_2}}
- 📱 {{FEATURE_3}}
- 🛡️ {{FEATURE_4}}
- 🎨 {{FEATURE_5}}

## 📋 Prerequisites

- {{PREREQUISITE_1}}
- {{PREREQUISITE_2}}
- {{PREREQUISITE_3}}

## ⚡ Quick Start

1. **Clone the repository**
   \`\`\`bash
   git clone {{REPOSITORY_URL}}
   cd {{PROJECT_FOLDER}}
   \`\`\`

2. **Install dependencies**
   \`\`\`bash
   {{INSTALL_COMMAND}}
   \`\`\`

3. **Configure environment**
   \`\`\`bash
   cp .env.example .env
   # Edit .env with your settings
   \`\`\`

4. **Start the application**
   \`\`\`bash
   {{START_COMMAND}}
   \`\`\`

## 🏗️ Architecture

{{PROJECT_NAME}} is built using:

- **Frontend**: {{FRONTEND_TECH}}
- **Backend**: {{BACKEND_TECH}}
- **Database**: {{DATABASE_TECH}}
- **Authentication**: {{AUTH_TECH}}
- **Deployment**: {{DEPLOYMENT_TECH}}

## 📖 Usage

### Basic Usage

\`\`\`{{LANGUAGE}}
{{BASIC_USAGE_CODE}}
\`\`\`

### Advanced Usage

\`\`\`{{LANGUAGE}}
{{ADVANCED_USAGE_CODE}}
\`\`\`

## 🛠️ Development

### Setting up the development environment

1. Fork the repository
2. Create a development branch
3. Make your changes
4. Run tests: \`{{TEST_COMMAND}}\`
5. Submit a pull request

### Available Scripts

- \`{{DEV_COMMAND}}\` - Start development server
- \`{{BUILD_COMMAND}}\` - Build for production
- \`{{TEST_COMMAND}}\` - Run tests
- \`{{LINT_COMMAND}}\` - Lint code

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| {{ENV_VAR_1}} | {{ENV_DESC_1}} | {{ENV_DEFAULT_1}} |
| {{ENV_VAR_2}} | {{ENV_DESC_2}} | {{ENV_DEFAULT_2}} |
| {{ENV_VAR_3}} | {{ENV_DESC_3}} | {{ENV_DEFAULT_3}} |

## 📚 API Documentation

For detailed API documentation, visit: {{API_DOCS_URL}}

### Example Endpoints

- \`GET {{API_ENDPOINT_1}}\` - {{API_DESC_1}}
- \`POST {{API_ENDPOINT_2}}\` - {{API_DESC_2}}
- \`PUT {{API_ENDPOINT_3}}\` - {{API_DESC_3}}

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

1. Fork the project
2. Create your feature branch (\`git checkout -b feature/AmazingFeature\`)
3. Commit your changes (\`git commit -m 'Add some AmazingFeature'\`)
4. Push to the branch (\`git push origin feature/AmazingFeature\`)
5. Open a Pull Request

## 📄 License

This project is licensed under the {{LICENSE}} License - see the [LICENSE](LICENSE) file for details.

## 👥 Authors

- **{{AUTHOR_NAME}}** - *{{AUTHOR_ROLE}}* - [{{AUTHOR_GITHUB}}]({{AUTHOR_GITHUB_URL}})

## 🙏 Acknowledgments

- {{ACKNOWLEDGMENT_1}}
- {{ACKNOWLEDGMENT_2}}
- {{ACKNOWLEDGMENT_3}}

## 📞 Support

- 📧 Email: {{SUPPORT_EMAIL}}
- 💬 Discord: {{DISCORD_URL}}
- 🐛 Issues: {{ISSUES_URL}}`,
      placeholders: ["PROJECT_NAME", "DESCRIPTION", "DEMO_IMAGE_URL", "FEATURE_1", "FEATURE_2", "FEATURE_3", "FEATURE_4", "FEATURE_5", "PREREQUISITE_1", "PREREQUISITE_2", "PREREQUISITE_3", "REPOSITORY_URL", "PROJECT_FOLDER", "INSTALL_COMMAND", "START_COMMAND", "FRONTEND_TECH", "BACKEND_TECH", "DATABASE_TECH", "AUTH_TECH", "DEPLOYMENT_TECH", "LANGUAGE", "BASIC_USAGE_CODE", "ADVANCED_USAGE_CODE", "TEST_COMMAND", "DEV_COMMAND", "BUILD_COMMAND", "LINT_COMMAND", "ENV_VAR_1", "ENV_DESC_1", "ENV_DEFAULT_1", "ENV_VAR_2", "ENV_DESC_2", "ENV_DEFAULT_2", "ENV_VAR_3", "ENV_DESC_3", "ENV_DEFAULT_3", "API_DOCS_URL", "API_ENDPOINT_1", "API_DESC_1", "API_ENDPOINT_2", "API_DESC_2", "API_ENDPOINT_3", "API_DESC_3", "LICENSE", "AUTHOR_NAME", "AUTHOR_ROLE", "AUTHOR_GITHUB", "AUTHOR_GITHUB_URL", "ACKNOWLEDGMENT_1", "ACKNOWLEDGMENT_2", "ACKNOWLEDGMENT_3", "SUPPORT_EMAIL", "DISCORD_URL", "ISSUES_URL"]
    },
    {
      id: "email-template",
      name: "Professional Email",
      description: "Professional email template for business communication",
      category: "Communication",
      content: `Subject: {{SUBJECT}}

Dear {{RECIPIENT_NAME}},

{{GREETING}}

{{OPENING_PARAGRAPH}}

## Key Points:

- **{{POINT_1_TITLE}}**: {{POINT_1_DESCRIPTION}}
- **{{POINT_2_TITLE}}**: {{POINT_2_DESCRIPTION}}
- **{{POINT_3_TITLE}}**: {{POINT_3_DESCRIPTION}}

## Next Steps:

1. {{ACTION_1}}
2. {{ACTION_2}}
3. {{ACTION_3}}

{{CLOSING_PARAGRAPH}}

Please feel free to reach out if you have any questions or need clarification on any of the points mentioned above.

Best regards,

{{SENDER_NAME}}
{{SENDER_TITLE}}
{{COMPANY_NAME}}
{{CONTACT_INFO}}`,
      placeholders: ["SUBJECT", "RECIPIENT_NAME", "GREETING", "OPENING_PARAGRAPH", "POINT_1_TITLE", "POINT_1_DESCRIPTION", "POINT_2_TITLE", "POINT_2_DESCRIPTION", "POINT_3_TITLE", "POINT_3_DESCRIPTION", "ACTION_1", "ACTION_2", "ACTION_3", "CLOSING_PARAGRAPH", "SENDER_NAME", "SENDER_TITLE", "COMPANY_NAME", "CONTACT_INFO"]
    }
  ];

  const writingTools: WritingTool[] = [
    { id: "grammar", name: "Grammar Check", description: "Check for grammar and spelling errors", icon: CheckCircle, category: "editing" },
    { id: "readability", name: "Readability Analysis", description: "Analyze text readability and complexity", icon: BookOpen, category: "analysis" },
    { id: "tone", name: "Tone Analyzer", description: "Analyze and adjust writing tone", icon: Palette, category: "analysis" },
    { id: "seo", name: "SEO Optimizer", description: "Optimize content for search engines", icon: Search, category: "optimization" },
    { id: "plagiarism", name: "Plagiarism Check", description: "Check for plagiarism and originality", icon: AlertCircle, category: "verification" },
    { id: "summarizer", name: "Text Summarizer", description: "Generate concise summaries", icon: Lightbulb, category: "generation" },
    { id: "expander", name: "Content Expander", description: "Expand and elaborate on content", icon: Zap, category: "generation" },
    { id: "translator", name: "Language Translator", description: "Translate to different languages", icon: Globe, category: "translation" },
  ];

  const analyzeText = async (text: string): Promise<TextAnalysis> => {
    setIsAnalyzing(true);
    
    try {
      // Simulate analysis
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const words = text.trim().split(/\s+/).filter(word => word.length > 0);
      const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
      const paragraphs = text.split(/\n\s*\n/).filter(p => p.trim().length > 0);
      
      // Simple readability score calculation (Flesch Reading Ease approximation)
      const avgWordsPerSentence = words.length / Math.max(sentences.length, 1);
      const avgSyllablesPerWord = words.reduce((acc, word) => {
        return acc + Math.max(1, word.replace(/[^aeiouAEIOU]/g, '').length);
      }, 0) / Math.max(words.length, 1);
      
      const readabilityScore = Math.max(0, Math.min(100, 
        206.835 - (1.015 * avgWordsPerSentence) - (84.6 * avgSyllablesPerWord)
      ));
      
      const readingTime = Math.ceil(words.length / 200); // 200 words per minute
      
      return {
        wordCount: words.length,
        characterCount: text.length,
        paragraphCount: paragraphs.length,
        sentenceCount: sentences.length,
        readabilityScore: Math.round(readabilityScore),
        readingTime
      };
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleAnalyze = async () => {
    if (content.trim()) {
      const result = await analyzeText(content);
      setAnalysis(result);
    }
  };

  const handleTemplateSelect = (templateId: string) => {
    const template = writingTemplates.find(t => t.id === templateId);
    if (template) {
      setSelectedTemplate(templateId);
      setContent(template.content);
      setTitle(template.name);
    }
  };

  const handleFindReplace = () => {
    if (searchTerm && content.includes(searchTerm)) {
      const newContent = content.replace(new RegExp(searchTerm, 'g'), replaceTerm);
      setContent(newContent);
    }
  };

  const formatText = (type: string) => {
    const selection = window.getSelection();
    if (selection && selection.toString()) {
      const selectedText = selection.toString();
      let formattedText = selectedText;
      
      switch (type) {
        case 'bold':
          formattedText = `**${selectedText}**`;
          break;
        case 'italic':
          formattedText = `*${selectedText}*`;
          break;
        case 'code':
          formattedText = `\`${selectedText}\``;
          break;
        case 'quote':
          formattedText = `> ${selectedText}`;
          break;
        case 'link':
          formattedText = `[${selectedText}](URL)`;
          break;
      }
      
      const newContent = content.replace(selectedText, formattedText);
      setContent(newContent);
    }
  };

  const handleExport = (format: string) => {
    const blob = new Blob([content], { 
      type: format === 'markdown' ? 'text/markdown' : 'text/plain' 
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title || 'document'}.${format === 'markdown' ? 'md' : 'txt'}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PenTool className="h-5 w-5" />
            Advanced Write Tool & Content Creator
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="editor">Editor</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="tools">Writing Tools</TabsTrigger>
            <TabsTrigger value="analysis">Analysis</TabsTrigger>
            <TabsTrigger value="formatting">Formatting</TabsTrigger>
            <TabsTrigger value="export">Export</TabsTrigger>
          </TabsList>

          <TabsContent value="editor" className="flex-1">
            <div className="grid grid-cols-3 gap-4 h-full">
              <div className="col-span-2 space-y-4">
                <div>
                  <Input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Document title..."
                    className="text-lg font-semibold"
                  />
                </div>
                
                <Card className="flex-1">
                  <CardContent className="p-0 h-full">
                    <Textarea
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      placeholder="Start writing your content here..."
                      className="h-full min-h-96 resize-none border-0 focus:ring-0"
                    />
                  </CardContent>
                </Card>

                <div className="flex items-center gap-2">
                  <Button onClick={handleAnalyze} disabled={!content.trim() || isAnalyzing}>
                    <BookOpen className="h-4 w-4 mr-2" />
                    {isAnalyzing ? "Analyzing..." : "Analyze Text"}
                  </Button>
                  <Button variant="outline" onClick={() => handleExport('markdown')}>
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                  <Button variant="outline" onClick={() => setContent("")}>
                    Clear
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="grid grid-cols-3 gap-1">
                      <Button size="sm" variant="outline" onClick={() => formatText('bold')}>
                        <Bold className="h-3 w-3" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => formatText('italic')}>
                        <Italic className="h-3 w-3" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => formatText('code')}>
                        <Code className="h-3 w-3" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => formatText('quote')}>
                        <Quote className="h-3 w-3" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => formatText('link')}>
                        <Link className="h-3 w-3" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <List className="h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Find & Replace</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Input
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="Find..."
                      size={10}
                    />
                    <Input
                      value={replaceTerm}
                      onChange={(e) => setReplaceTerm(e.target.value)}
                      placeholder="Replace with..."
                      size={10}
                    />
                    <Button size="sm" onClick={handleFindReplace} className="w-full">
                      <Replace className="h-3 w-3 mr-1" />
                      Replace
                    </Button>
                  </CardContent>
                </Card>

                {analysis && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Text Statistics</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span>Words:</span>
                        <span>{analysis.wordCount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Characters:</span>
                        <span>{analysis.characterCount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Paragraphs:</span>
                        <span>{analysis.paragraphCount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Sentences:</span>
                        <span>{analysis.sentenceCount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Readability:</span>
                        <span>{analysis.readabilityScore}/100</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Reading Time:</span>
                        <span>{analysis.readingTime} min</span>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="templates" className="flex-1">
            <ScrollArea className="h-full">
              <div className="grid grid-cols-2 gap-4">
                {writingTemplates.map((template) => (
                  <Card key={template.id} className="cursor-pointer hover:shadow-lg transition-all">
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <FileText className="h-6 w-6 text-blue-500" />
                        <Badge variant="secondary" className="text-xs">
                          {template.category}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <CardTitle className="text-sm mb-1">{template.name}</CardTitle>
                      <CardDescription className="text-xs mb-3">
                        {template.description}
                      </CardDescription>
                      <div className="mb-3">
                        <div className="text-xs text-muted-foreground mb-1">
                          Placeholders ({template.placeholders.length}):
                        </div>
                        <div className="flex flex-wrap gap-1 max-h-16 overflow-y-auto">
                          {template.placeholders.slice(0, 6).map(placeholder => (
                            <Badge key={placeholder} variant="outline" className="text-xs">
                              {placeholder}
                            </Badge>
                          ))}
                          {template.placeholders.length > 6 && (
                            <Badge variant="outline" className="text-xs">
                              +{template.placeholders.length - 6} more
                            </Badge>
                          )}
                        </div>
                      </div>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="w-full"
                        onClick={() => {
                          handleTemplateSelect(template.id);
                          setActiveTab("editor");
                        }}
                      >
                        Use Template
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="tools" className="flex-1">
            <div className="grid grid-cols-4 gap-4">
              {writingTools.map((tool) => (
                <Card key={tool.id} className="cursor-pointer hover:shadow-lg transition-all">
                  <CardHeader className="pb-2 text-center">
                    <tool.icon className="h-8 w-8 mx-auto text-blue-500" />
                  </CardHeader>
                  <CardContent className="text-center">
                    <CardTitle className="text-sm mb-1">{tool.name}</CardTitle>
                    <CardDescription className="text-xs mb-3">
                      {tool.description}
                    </CardDescription>
                    <Badge variant="outline" className="text-xs mb-2">
                      {tool.category}
                    </Badge>
                    <Button size="sm" variant="outline" className="w-full">
                      Use Tool
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analysis" className="flex-1">
            <div className="grid grid-cols-2 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    Content Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Button onClick={handleAnalyze} disabled={!content.trim() || isAnalyzing} className="w-full">
                      {isAnalyzing ? "Analyzing..." : "Analyze Current Content"}
                    </Button>
                    
                    {analysis && (
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="p-3 border rounded">
                            <div className="text-2xl font-bold">{analysis.wordCount}</div>
                            <div className="text-sm text-muted-foreground">Words</div>
                          </div>
                          <div className="p-3 border rounded">
                            <div className="text-2xl font-bold">{analysis.characterCount}</div>
                            <div className="text-sm text-muted-foreground">Characters</div>
                          </div>
                          <div className="p-3 border rounded">
                            <div className="text-2xl font-bold">{analysis.paragraphCount}</div>
                            <div className="text-sm text-muted-foreground">Paragraphs</div>
                          </div>
                          <div className="p-3 border rounded">
                            <div className="text-2xl font-bold">{analysis.sentenceCount}</div>
                            <div className="text-sm text-muted-foreground">Sentences</div>
                          </div>
                        </div>
                        
                        <div className="p-4 border rounded">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium">Readability Score</span>
                            <span className="text-lg font-bold">{analysis.readabilityScore}/100</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-500 h-2 rounded-full" 
                              style={{ width: `${analysis.readabilityScore}%` }}
                            ></div>
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {analysis.readabilityScore >= 80 ? "Very Easy" :
                             analysis.readabilityScore >= 60 ? "Easy" :
                             analysis.readabilityScore >= 40 ? "Moderate" :
                             analysis.readabilityScore >= 20 ? "Difficult" : "Very Difficult"}
                          </div>
                        </div>
                        
                        <div className="p-4 border rounded">
                          <div className="flex items-center gap-2 mb-2">
                            <Clock className="h-4 w-4" />
                            <span className="text-sm font-medium">Estimated Reading Time</span>
                          </div>
                          <div className="text-lg font-bold">{analysis.readingTime} minute{analysis.readingTime !== 1 ? 's' : ''}</div>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-4 w-4" />
                    Writing Suggestions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-3">
                      <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded">
                        <div className="text-sm font-medium text-blue-700 dark:text-blue-300 mb-1">
                          Structure Improvement
                        </div>
                        <div className="text-xs text-blue-600 dark:text-blue-400">
                          Consider adding more subheadings to improve content organization and readability.
                        </div>
                      </div>
                      
                      <div className="p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded">
                        <div className="text-sm font-medium text-green-700 dark:text-green-300 mb-1">
                          SEO Optimization
                        </div>
                        <div className="text-xs text-green-600 dark:text-green-400">
                          Add meta descriptions and keywords to improve search engine visibility.
                        </div>
                      </div>
                      
                      <div className="p-3 bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded">
                        <div className="text-sm font-medium text-orange-700 dark:text-orange-300 mb-1">
                          Sentence Variety
                        </div>
                        <div className="text-xs text-orange-600 dark:text-orange-400">
                          Mix short and long sentences for better flow and engagement.
                        </div>
                      </div>
                      
                      <div className="p-3 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded">
                        <div className="text-sm font-medium text-purple-700 dark:text-purple-300 mb-1">
                          Call to Action
                        </div>
                        <div className="text-xs text-purple-600 dark:text-purple-400">
                          Include clear call-to-action statements to guide readers to next steps.
                        </div>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="formatting" className="flex-1">
            <div className="grid grid-cols-3 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Text Formatting</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-2">
                    <Button size="sm" variant="outline" onClick={() => formatText('bold')}>
                      <Bold className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => formatText('italic')}>
                      <Italic className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Underline className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <AlignLeft className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <AlignCenter className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <AlignRight className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <List className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <ListOrdered className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => formatText('quote')}>
                      <Quote className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Insert Elements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2">
                    <Button size="sm" variant="outline" onClick={() => formatText('link')}>
                      <Link className="h-4 w-4 mr-1" />
                      Link
                    </Button>
                    <Button size="sm" variant="outline">
                      <Image className="h-4 w-4 mr-1" />
                      Image
                    </Button>
                    <Button size="sm" variant="outline">
                      <Table className="h-4 w-4 mr-1" />
                      Table
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => formatText('code')}>
                      <Code className="h-4 w-4 mr-1" />
                      Code
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Style Options</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs font-medium">Font Size</label>
                      <Slider defaultValue={[14]} max={24} min={10} step={1} className="mt-1" />
                    </div>
                    <div>
                      <label className="text-xs font-medium">Line Height</label>
                      <Slider defaultValue={[1.6]} max={3} min={1} step={0.1} className="mt-1" />
                    </div>
                    <div>
                      <label className="text-xs font-medium">Theme</label>
                      <Select defaultValue="default">
                        <SelectTrigger className="h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="default">Default</SelectItem>
                          <SelectItem value="minimal">Minimal</SelectItem>
                          <SelectItem value="modern">Modern</SelectItem>
                          <SelectItem value="classic">Classic</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="export" className="flex-1">
            <div className="grid grid-cols-2 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Download className="h-4 w-4" />
                    Export Options
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" onClick={() => handleExport('markdown')}>
                      <FileText className="h-4 w-4 mr-2" />
                      Markdown
                    </Button>
                    <Button variant="outline" onClick={() => handleExport('txt')}>
                      <FileText className="h-4 w-4 mr-2" />
                      Plain Text
                    </Button>
                    <Button variant="outline">
                      <FileText className="h-4 w-4 mr-2" />
                      HTML
                    </Button>
                    <Button variant="outline">
                      <FileText className="h-4 w-4 mr-2" />
                      PDF
                    </Button>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Export Settings</label>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="include-metadata" className="rounded" />
                        <label htmlFor="include-metadata" className="text-sm">Include metadata</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="include-stats" className="rounded" />
                        <label htmlFor="include-stats" className="text-sm">Include statistics</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" id="word-wrap" className="rounded" defaultChecked />
                        <label htmlFor="word-wrap" className="text-sm">Enable word wrap</label>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Save className="h-4 w-4" />
                    Save & Share
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Button className="w-full">
                      <Save className="h-4 w-4 mr-2" />
                      Save to Account
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Copy className="h-4 w-4 mr-2" />
                      Copy to Clipboard
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Upload className="h-4 w-4 mr-2" />
                      Share Link
                    </Button>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Version History</label>
                    <div className="space-y-1">
                      <div className="p-2 border rounded text-xs">
                        <div className="flex justify-between">
                          <span>Current version</span>
                          <span>{new Date().toLocaleTimeString()}</span>
                        </div>
                      </div>
                      <div className="p-2 border rounded text-xs opacity-60">
                        <div className="flex justify-between">
                          <span>Previous version</span>
                          <span>2 hours ago</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}