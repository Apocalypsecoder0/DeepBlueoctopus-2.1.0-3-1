import React, { Component, ErrorInfo, ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { 
  AlertTriangle, RefreshCw, Bug, Code, 
  Copy, Download, Send, Home, 
  ChevronDown, ChevronRight, Info
} from "lucide-react";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  errorId: string;
  showDetails: boolean;
}

interface ErrorReport {
  id: string;
  timestamp: Date;
  error: {
    name: string;
    message: string;
    stack?: string;
  };
  componentStack: string;
  userAgent: string;
  url: string;
  userId?: string;
  buildVersion: string;
}

export class ErrorBoundary extends Component<Props, State> {
  private errorReports: ErrorReport[] = [];

  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      errorId: '',
      showDetails: false
    };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return {
      hasError: true,
      error,
      errorId: `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    this.setState({
      errorInfo,
      showDetails: false
    });

    // Create error report
    const errorReport: ErrorReport = {
      id: this.state.errorId,
      timestamp: new Date(),
      error: {
        name: error.name,
        message: error.message,
        stack: error.stack
      },
      componentStack: errorInfo.componentStack,
      userAgent: navigator.userAgent,
      url: window.location.href,
      userId: localStorage.getItem('userId') || undefined,
      buildVersion: '2.1.0'
    };

    this.errorReports.push(errorReport);

    // Save to localStorage for persistence
    this.saveErrorReport(errorReport);

    // Call optional error handler
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }

    // Log to console in development
    if (process.env.NODE_ENV === 'development') {
      console.group('🐛 Error Boundary Caught Error');
      console.error('Error:', error);
      console.error('Error Info:', errorInfo);
      console.error('Component Stack:', errorInfo.componentStack);
      console.groupEnd();
    }
  }

  private saveErrorReport(report: ErrorReport) {
    try {
      const existingReports = JSON.parse(localStorage.getItem('ide-error-reports') || '[]');
      existingReports.push(report);
      
      // Keep only last 50 reports
      if (existingReports.length > 50) {
        existingReports.splice(0, existingReports.length - 50);
      }
      
      localStorage.setItem('ide-error-reports', JSON.stringify(existingReports));
    } catch (e) {
      console.error('Failed to save error report:', e);
    }
  }

  private getStoredErrorReports(): ErrorReport[] {
    try {
      return JSON.parse(localStorage.getItem('ide-error-reports') || '[]');
    } catch (e) {
      return [];
    }
  }

  private handleReload = () => {
    window.location.reload();
  };

  private handleRetry = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
      errorId: '',
      showDetails: false
    });
  };

  private handleGoHome = () => {
    window.location.href = '/';
  };

  private copyErrorToClipboard = () => {
    const { error, errorInfo, errorId } = this.state;
    const errorText = `Error ID: ${errorId}
Error: ${error?.name}: ${error?.message}
Component Stack: ${errorInfo?.componentStack}
Stack Trace: ${error?.stack}
Timestamp: ${new Date().toISOString()}
URL: ${window.location.href}
User Agent: ${navigator.userAgent}`;

    navigator.clipboard.writeText(errorText).then(() => {
      // Could show a toast here
      console.log('Error details copied to clipboard');
    });
  };

  private downloadErrorReport = () => {
    const { error, errorInfo, errorId } = this.state;
    const report: ErrorReport = {
      id: errorId,
      timestamp: new Date(),
      error: {
        name: error?.name || 'Unknown',
        message: error?.message || 'Unknown error',
        stack: error?.stack
      },
      componentStack: errorInfo?.componentStack || '',
      userAgent: navigator.userAgent,
      url: window.location.href,
      buildVersion: '2.1.0'
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `error-report-${errorId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  private sendErrorReport = async () => {
    // In a real application, this would send to an error tracking service
    console.log('Error report would be sent to error tracking service');
    
    // For demo purposes, just log it
    const { error, errorInfo, errorId } = this.state;
    console.log('Sending error report:', {
      id: errorId,
      error: error?.message,
      componentStack: errorInfo?.componentStack
    });
  };

  private formatStackTrace = (stack?: string) => {
    if (!stack) return 'No stack trace available';
    
    return stack
      .split('\n')
      .map(line => line.trim())
      .filter(line => line.length > 0)
      .slice(0, 10) // Limit to first 10 lines
      .join('\n');
  };

  render() {
    if (this.state.hasError) {
      const { error, errorInfo, errorId, showDetails } = this.state;
      
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-gray-50 dark:bg-gray-900">
          <Card className="w-full max-w-4xl">
            <CardHeader className="text-center">
              <div className="flex items-center justify-center mb-4">
                <div className="p-3 bg-red-100 dark:bg-red-900/20 rounded-full">
                  <AlertTriangle className="h-8 w-8 text-red-600 dark:text-red-400" />
                </div>
              </div>
              <CardTitle className="text-2xl">Something went wrong</CardTitle>
              <p className="text-muted-foreground mt-2">
                An unexpected error occurred in the DeepBlue:Octopus IDE. 
                We apologize for the inconvenience.
              </p>
              <div className="flex items-center justify-center gap-2 mt-4">
                <Badge variant="outline">Error ID: {errorId}</Badge>
                <Badge variant="secondary">{error?.name || 'Unknown Error'}</Badge>
              </div>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* Quick Actions */}
              <div className="flex flex-wrap gap-2 justify-center">
                <Button onClick={this.handleRetry} variant="default">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Try Again
                </Button>
                <Button onClick={this.handleReload} variant="outline">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Reload Page
                </Button>
                <Button onClick={this.handleGoHome} variant="outline">
                  <Home className="h-4 w-4 mr-2" />
                  Go Home
                </Button>
              </div>

              <Separator />

              {/* Error Details */}
              <div className="space-y-4">
                <Button
                  variant="ghost"
                  onClick={() => this.setState({ showDetails: !showDetails })}
                  className="w-full justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Bug className="h-4 w-4" />
                    Error Details
                  </span>
                  {showDetails ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                </Button>

                {showDetails && (
                  <Card className="border-red-200 dark:border-red-800">
                    <CardContent className="pt-6">
                      <Tabs defaultValue="summary" className="w-full">
                        <TabsList className="grid w-full grid-cols-3">
                          <TabsTrigger value="summary">Summary</TabsTrigger>
                          <TabsTrigger value="stack">Stack Trace</TabsTrigger>
                          <TabsTrigger value="component">Component Stack</TabsTrigger>
                        </TabsList>

                        <TabsContent value="summary" className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <h4 className="font-medium mb-2">Error Information</h4>
                              <div className="space-y-2 text-sm">
                                <div>
                                  <span className="font-medium">Type:</span> {error?.name || 'Unknown'}
                                </div>
                                <div>
                                  <span className="font-medium">Message:</span> {error?.message || 'No message'}
                                </div>
                                <div>
                                  <span className="font-medium">Time:</span> {new Date().toLocaleString()}
                                </div>
                                <div>
                                  <span className="font-medium">URL:</span> {window.location.href}
                                </div>
                              </div>
                            </div>

                            <div>
                              <h4 className="font-medium mb-2">Environment</h4>
                              <div className="space-y-2 text-sm">
                                <div>
                                  <span className="font-medium">Browser:</span> {navigator.userAgent.split(' ')[0]}
                                </div>
                                <div>
                                  <span className="font-medium">Version:</span> 2.1.0 Alpha
                                </div>
                                <div>
                                  <span className="font-medium">Platform:</span> {navigator.platform}
                                </div>
                              </div>
                            </div>
                          </div>
                        </TabsContent>

                        <TabsContent value="stack">
                          <ScrollArea className="h-64 w-full">
                            <pre className="text-xs font-mono p-4 bg-muted rounded-md overflow-x-auto">
                              {this.formatStackTrace(error?.stack)}
                            </pre>
                          </ScrollArea>
                        </TabsContent>

                        <TabsContent value="component">
                          <ScrollArea className="h-64 w-full">
                            <pre className="text-xs font-mono p-4 bg-muted rounded-md overflow-x-auto">
                              {errorInfo?.componentStack || 'No component stack available'}
                            </pre>
                          </ScrollArea>
                        </TabsContent>
                      </Tabs>
                    </CardContent>
                  </Card>
                )}
              </div>

              <Separator />

              {/* Action Buttons */}
              <div className="space-y-4">
                <h4 className="font-medium text-center">Help us improve</h4>
                <div className="flex flex-wrap gap-2 justify-center">
                  <Button onClick={this.copyErrorToClipboard} variant="outline" size="sm">
                    <Copy className="h-4 w-4 mr-2" />
                    Copy Details
                  </Button>
                  <Button onClick={this.downloadErrorReport} variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download Report
                  </Button>
                  <Button onClick={this.sendErrorReport} variant="outline" size="sm">
                    <Send className="h-4 w-4 mr-2" />
                    Send Report
                  </Button>
                </div>
                
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">
                    Error reports help us identify and fix issues. No personal data is included.
                  </p>
                </div>
              </div>

              {/* Recovery Suggestions */}
              <Card className="border-blue-200 dark:border-blue-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <Info className="h-4 w-4" />
                    Recovery Suggestions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="text-sm space-y-2 text-muted-foreground">
                    <li>• Try refreshing the page or restarting the application</li>
                    <li>• Check if you have the latest version of your browser</li>
                    <li>• Clear your browser cache and local storage</li>
                    <li>• Disable browser extensions that might interfere</li>
                    <li>• Try using the IDE in incognito/private mode</li>
                    <li>• Contact support if the issue persists</li>
                  </ul>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

// Wrapper component for easier usage
interface ErrorBoundaryWrapperProps {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
}

export function withErrorBoundary<P extends object>(
  Component: React.ComponentType<P>,
  errorBoundaryProps?: Omit<ErrorBoundaryWrapperProps, 'children'>
) {
  return function WithErrorBoundaryComponent(props: P) {
    return (
      <ErrorBoundary {...errorBoundaryProps}>
        <Component {...props} />
      </ErrorBoundary>
    );
  };
}

// Hook for error reporting
export function useErrorHandler() {
  const reportError = (error: Error, context?: string) => {
    const errorReport = {
      id: `manual_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
      error: {
        name: error.name,
        message: error.message,
        stack: error.stack
      },
      context: context || 'Manual report',
      userAgent: navigator.userAgent,
      url: window.location.href,
      buildVersion: '2.1.0'
    };

    // Save to localStorage
    try {
      const existingReports = JSON.parse(localStorage.getItem('ide-error-reports') || '[]');
      existingReports.push(errorReport);
      localStorage.setItem('ide-error-reports', JSON.stringify(existingReports));
    } catch (e) {
      console.error('Failed to save error report:', e);
    }

    // Log to console
    console.error('Manual error report:', errorReport);
  };

  return { reportError };
}

export default ErrorBoundary;