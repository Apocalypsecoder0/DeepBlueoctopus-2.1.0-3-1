import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { 
  Server, Globe, Database, Shield, Activity, Settings,
  Play, Square, RefreshCw, Monitor, Users, Lock,
  Zap, Cloud, HardDrive, Wifi, AlertTriangle,
  CheckCircle, XCircle, Clock, TrendingUp,
  BarChart3, PieChart, LineChart, Eye,
  Download, Upload, Cpu, MemoryStick, Network
} from "lucide-react";

interface AdvancedServerSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ServerInstance {
  id: string;
  name: string;
  type: 'development' | 'staging' | 'production' | 'testing';
  status: 'running' | 'stopped' | 'starting' | 'stopping' | 'error';
  url: string;
  port: number;
  uptime: number;
  cpu: number;
  memory: number;
  requests: number;
  lastRestart: Date;
  version: string;
  framework: string;
}

interface ServerMetrics {
  timestamp: Date;
  cpu: number;
  memory: number;
  requests: number;
  responseTime: number;
  errors: number;
  activeConnections: number;
}

interface DatabaseConnection {
  id: string;
  name: string;
  type: 'postgresql' | 'mysql' | 'mongodb' | 'redis' | 'sqlite';
  host: string;
  port: number;
  database: string;
  status: 'connected' | 'disconnected' | 'error';
  connections: number;
  maxConnections: number;
  queryTime: number;
}

interface SecurityConfig {
  id: string;
  name: string;
  enabled: boolean;
  type: 'firewall' | 'ssl' | 'auth' | 'cors' | 'helmet' | 'rate-limit';
  config: any;
  lastUpdated: Date;
}

export default function AdvancedServerSystem({ isOpen, onClose }: AdvancedServerSystemProps) {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedServer, setSelectedServer] = useState<string | null>(null);
  const [isMonitoring, setIsMonitoring] = useState(true);

  const [servers, setServers] = useState<ServerInstance[]>([
    {
      id: 'dev-server',
      name: 'Development Server',
      type: 'development',
      status: 'running',
      url: 'http://localhost:5000',
      port: 5000,
      uptime: 14520, // seconds
      cpu: 12.5,
      memory: 145.2,
      requests: 1847,
      lastRestart: new Date(Date.now() - 14520000),
      version: '1.0.0',
      framework: 'Express.js'
    },
    {
      id: 'staging-server',
      name: 'Staging Server',
      type: 'staging',
      status: 'running',
      url: 'https://staging.deepblue.dev',
      port: 443,
      uptime: 86400,
      cpu: 8.3,
      memory: 89.6,
      requests: 5234,
      lastRestart: new Date(Date.now() - 86400000),
      version: '1.0.0-rc.2',
      framework: 'Express.js'
    },
    {
      id: 'prod-server',
      name: 'Production Server',
      type: 'production',
      status: 'running',
      url: 'https://deepblue.dev',
      port: 443,
      uptime: 259200,
      cpu: 15.7,
      memory: 234.8,
      requests: 18472,
      lastRestart: new Date(Date.now() - 259200000),
      version: '1.0.0',
      framework: 'Express.js'
    },
    {
      id: 'test-server',
      name: 'Testing Server',
      type: 'testing',
      status: 'stopped',
      url: 'http://localhost:3001',
      port: 3001,
      uptime: 0,
      cpu: 0,
      memory: 0,
      requests: 0,
      lastRestart: new Date(Date.now() - 3600000),
      version: '1.0.0-alpha.5',
      framework: 'Express.js'
    }
  ]);

  const [databases, setDatabases] = useState<DatabaseConnection[]>([
    {
      id: 'postgres-main',
      name: 'Main PostgreSQL',
      type: 'postgresql',
      host: 'localhost',
      port: 5432,
      database: 'deepblue_dev',
      status: 'connected',
      connections: 12,
      maxConnections: 100,
      queryTime: 2.3
    },
    {
      id: 'redis-cache',
      name: 'Redis Cache',
      type: 'redis',
      host: 'localhost',
      port: 6379,
      database: '0',
      status: 'connected',
      connections: 5,
      maxConnections: 50,
      queryTime: 0.8
    },
    {
      id: 'mongodb-logs',
      name: 'MongoDB Logs',
      type: 'mongodb',
      host: 'localhost',
      port: 27017,
      database: 'logs',
      status: 'disconnected',
      connections: 0,
      maxConnections: 25,
      queryTime: 0
    }
  ]);

  const [metrics, setMetrics] = useState<ServerMetrics[]>([
    { timestamp: new Date(Date.now() - 300000), cpu: 10.2, memory: 142.1, requests: 1820, responseTime: 85, errors: 2, activeConnections: 45 },
    { timestamp: new Date(Date.now() - 240000), cpu: 11.8, memory: 143.5, requests: 1835, responseTime: 92, errors: 1, activeConnections: 48 },
    { timestamp: new Date(Date.now() - 180000), cpu: 9.5, memory: 144.2, requests: 1841, responseTime: 78, errors: 0, activeConnections: 52 },
    { timestamp: new Date(Date.now() - 120000), cpu: 13.1, memory: 144.8, requests: 1844, responseTime: 95, errors: 3, activeConnections: 49 },
    { timestamp: new Date(Date.now() - 60000), cpu: 12.7, memory: 145.0, requests: 1846, responseTime: 88, errors: 1, activeConnections: 47 },
    { timestamp: new Date(), cpu: 12.5, memory: 145.2, requests: 1847, responseTime: 82, errors: 0, activeConnections: 46 }
  ]);

  const [securityConfig, setSecurityConfig] = useState<SecurityConfig[]>([
    {
      id: 'firewall',
      name: 'Firewall Protection',
      enabled: true,
      type: 'firewall',
      config: { allowedIPs: ['127.0.0.1', '::1'], blockedIPs: [] },
      lastUpdated: new Date(Date.now() - 86400000)
    },
    {
      id: 'ssl',
      name: 'SSL/TLS Encryption',
      enabled: true,
      type: 'ssl',
      config: { protocol: 'TLS 1.3', certificate: 'Let\'s Encrypt' },
      lastUpdated: new Date(Date.now() - 172800000)
    },
    {
      id: 'cors',
      name: 'CORS Configuration',
      enabled: true,
      type: 'cors',
      config: { origin: ['https://deepblue.dev'], credentials: true },
      lastUpdated: new Date(Date.now() - 3600000)
    },
    {
      id: 'rate-limit',
      name: 'Rate Limiting',
      enabled: true,
      type: 'rate-limit',
      config: { windowMs: 900000, max: 100 },
      lastUpdated: new Date(Date.now() - 7200000)
    }
  ]);

  const [serverLogs, setServerLogs] = useState([
    { timestamp: new Date(), level: 'info', message: 'Server started successfully on port 5000', source: 'dev-server' },
    { timestamp: new Date(Date.now() - 60000), level: 'info', message: 'Database connection established', source: 'dev-server' },
    { timestamp: new Date(Date.now() - 120000), level: 'warn', message: 'High memory usage detected: 85%', source: 'prod-server' },
    { timestamp: new Date(Date.now() - 180000), level: 'error', message: 'Failed to connect to MongoDB logs database', source: 'dev-server' },
    { timestamp: new Date(Date.now() - 240000), level: 'info', message: 'Security middleware initialized', source: 'dev-server' }
  ]);

  const formatUptime = (seconds: number): string => {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (days > 0) return `${days}d ${hours}h ${minutes}m`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'text-green-500';
      case 'stopped': return 'text-red-500';
      case 'starting': return 'text-yellow-500';
      case 'stopping': return 'text-orange-500';
      case 'error': return 'text-red-600';
      default: return 'text-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'stopped': return <XCircle className="h-4 w-4 text-red-500" />;
      case 'starting': return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'stopping': return <Clock className="h-4 w-4 text-orange-500" />;
      case 'error': return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default: return <XCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const handleServerAction = (serverId: string, action: 'start' | 'stop' | 'restart') => {
    setServers(prev => prev.map(server => 
      server.id === serverId 
        ? { 
            ...server, 
            status: action === 'start' ? 'starting' : action === 'stop' ? 'stopping' : 'starting',
            lastRestart: action === 'restart' ? new Date() : server.lastRestart
          }
        : server
    ));

    // Simulate status change after delay
    setTimeout(() => {
      setServers(prev => prev.map(server => 
        server.id === serverId 
          ? { 
              ...server, 
              status: action === 'stop' ? 'stopped' : 'running',
              uptime: action === 'stop' ? 0 : server.uptime
            }
          : server
      ));
    }, 2000);
  };

  const toggleSecurity = (configId: string) => {
    setSecurityConfig(prev => prev.map(config =>
      config.id === configId 
        ? { ...config, enabled: !config.enabled, lastUpdated: new Date() }
        : config
    ));
  };

  // Simulate real-time metrics updates
  useEffect(() => {
    if (!isMonitoring) return;

    const interval = setInterval(() => {
      const newMetric: ServerMetrics = {
        timestamp: new Date(),
        cpu: Math.random() * 20 + 5,
        memory: 140 + Math.random() * 10,
        requests: metrics[metrics.length - 1]?.requests + Math.floor(Math.random() * 5) + 1 || 1847,
        responseTime: 70 + Math.random() * 30,
        errors: Math.random() < 0.1 ? 1 : 0,
        activeConnections: 40 + Math.floor(Math.random() * 20)
      };

      setMetrics(prev => [...prev.slice(-9), newMetric]);
    }, 5000);

    return () => clearInterval(interval);
  }, [isMonitoring, metrics]);

  const currentServer = selectedServer ? servers.find(s => s.id === selectedServer) : servers[0];
  const latestMetrics = metrics[metrics.length - 1];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Server className="h-5 w-5 text-blue-500" />
            Advanced Server System Manager
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-6 flex-shrink-0 mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
            <TabsTrigger value="databases">Databases</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="logs">Logs</TabsTrigger>
            <TabsTrigger value="deployment">Deploy</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-full">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">Server Instances</CardTitle>
                      <CardDescription>Manage your development and production servers</CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="outline">
                        <Server className="h-4 w-4 mr-2" />
                        Add Server
                      </Button>
                      <Switch checked={isMonitoring} onCheckedChange={setIsMonitoring} />
                      <Label className="text-sm">Auto-refresh</Label>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {servers.map((server) => (
                      <div 
                        key={server.id}
                        className={`p-4 border rounded cursor-pointer transition-colors ${
                          selectedServer === server.id ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'hover:bg-accent/50'
                        }`}
                        onClick={() => setSelectedServer(server.id)}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            {getStatusIcon(server.status)}
                            <div>
                              <div className="font-medium">{server.name}</div>
                              <div className="text-sm text-muted-foreground">{server.url}</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={server.type === 'production' ? 'default' : 'outline'}>
                              {server.type}
                            </Badge>
                            <span className={`text-sm font-medium ${getStatusColor(server.status)}`}>
                              {server.status}
                            </span>
                          </div>
                        </div>

                        <div className="grid grid-cols-4 gap-4 text-sm">
                          <div>
                            <Label className="text-xs text-muted-foreground">Uptime</Label>
                            <p>{formatUptime(server.uptime)}</p>
                          </div>
                          <div>
                            <Label className="text-xs text-muted-foreground">CPU</Label>
                            <p>{server.cpu.toFixed(1)}%</p>
                          </div>
                          <div>
                            <Label className="text-xs text-muted-foreground">Memory</Label>
                            <p>{server.memory.toFixed(1)}MB</p>
                          </div>
                          <div>
                            <Label className="text-xs text-muted-foreground">Requests</Label>
                            <p>{server.requests.toLocaleString()}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 mt-3">
                          <Button 
                            size="sm" 
                            variant={server.status === 'running' ? 'destructive' : 'default'}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleServerAction(server.id, server.status === 'running' ? 'stop' : 'start');
                            }}
                          >
                            {server.status === 'running' ? <Square className="h-3 w-3" /> : <Play className="h-3 w-3" />}
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleServerAction(server.id, 'restart');
                            }}
                          >
                            <RefreshCw className="h-3 w-3" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Settings className="h-3 w-3" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Eye className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">System Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 border rounded">
                        <div className="text-2xl font-bold text-green-500">
                          {servers.filter(s => s.status === 'running').length}
                        </div>
                        <div className="text-sm text-muted-foreground">Running</div>
                      </div>
                      <div className="text-center p-3 border rounded">
                        <div className="text-2xl font-bold text-red-500">
                          {servers.filter(s => s.status === 'stopped').length}
                        </div>
                        <div className="text-sm text-muted-foreground">Stopped</div>
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Average CPU</span>
                          <span>{(servers.reduce((acc, s) => acc + s.cpu, 0) / servers.length).toFixed(1)}%</span>
                        </div>
                        <Progress value={servers.reduce((acc, s) => acc + s.cpu, 0) / servers.length} />
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Total Memory</span>
                          <span>{servers.reduce((acc, s) => acc + s.memory, 0).toFixed(1)}MB</span>
                        </div>
                        <Progress value={Math.min(100, servers.reduce((acc, s) => acc + s.memory, 0) / 10)} />
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <Label className="text-sm">Quick Actions</Label>
                      <div className="space-y-2">
                        <Button size="sm" className="w-full justify-start">
                          <Play className="h-4 w-4 mr-2" />
                          Start All Servers
                        </Button>
                        <Button size="sm" variant="outline" className="w-full justify-start">
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Restart Production
                        </Button>
                        <Button size="sm" variant="outline" className="w-full justify-start">
                          <Monitor className="h-4 w-4 mr-2" />
                          Health Check
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="monitoring" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Real-time Metrics</CardTitle>
                  <CardDescription>Live server performance data</CardDescription>
                </CardHeader>
                <CardContent>
                  {latestMetrics && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-3 border rounded text-center">
                          <div className="flex items-center justify-center gap-2 mb-1">
                            <Cpu className="h-4 w-4 text-blue-500" />
                            <span className="text-sm font-medium">CPU Usage</span>
                          </div>
                          <div className="text-2xl font-bold">{latestMetrics.cpu.toFixed(1)}%</div>
                          <Progress value={latestMetrics.cpu} className="mt-2" />
                        </div>
                        
                        <div className="p-3 border rounded text-center">
                          <div className="flex items-center justify-center gap-2 mb-1">
                            <MemoryStick className="h-4 w-4 text-green-500" />
                            <span className="text-sm font-medium">Memory</span>
                          </div>
                          <div className="text-2xl font-bold">{latestMetrics.memory.toFixed(1)}MB</div>
                          <Progress value={(latestMetrics.memory / 512) * 100} className="mt-2" />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-3 border rounded text-center">
                          <div className="flex items-center justify-center gap-2 mb-1">
                            <TrendingUp className="h-4 w-4 text-purple-500" />
                            <span className="text-sm font-medium">Requests</span>
                          </div>
                          <div className="text-2xl font-bold">{latestMetrics.requests}</div>
                          <div className="text-sm text-muted-foreground">Total</div>
                        </div>
                        
                        <div className="p-3 border rounded text-center">
                          <div className="flex items-center justify-center gap-2 mb-1">
                            <Clock className="h-4 w-4 text-orange-500" />
                            <span className="text-sm font-medium">Response</span>
                          </div>
                          <div className="text-2xl font-bold">{latestMetrics.responseTime}ms</div>
                          <div className="text-sm text-muted-foreground">Average</div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-3 border rounded text-center">
                          <div className="flex items-center justify-center gap-2 mb-1">
                            <Users className="h-4 w-4 text-indigo-500" />
                            <span className="text-sm font-medium">Active</span>
                          </div>
                          <div className="text-2xl font-bold">{latestMetrics.activeConnections}</div>
                          <div className="text-sm text-muted-foreground">Connections</div>
                        </div>
                        
                        <div className="p-3 border rounded text-center">
                          <div className="flex items-center justify-center gap-2 mb-1">
                            <AlertTriangle className="h-4 w-4 text-red-500" />
                            <span className="text-sm font-medium">Errors</span>
                          </div>
                          <div className="text-2xl font-bold">{latestMetrics.errors}</div>
                          <div className="text-sm text-muted-foreground">Last 5min</div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Performance Charts</CardTitle>
                  <CardDescription>Historical performance trends</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm mb-2 block">CPU Usage Over Time</Label>
                      <div className="h-24 bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded border flex items-end p-2 gap-1">
                        {metrics.slice(-8).map((metric, index) => (
                          <div 
                            key={index}
                            className="bg-blue-500 rounded-sm flex-1 min-w-[8px]"
                            style={{ height: `${(metric.cpu / 20) * 100}%` }}
                          />
                        ))}
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm mb-2 block">Memory Usage Over Time</Label>
                      <div className="h-24 bg-gradient-to-r from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 rounded border flex items-end p-2 gap-1">
                        {metrics.slice(-8).map((metric, index) => (
                          <div 
                            key={index}
                            className="bg-green-500 rounded-sm flex-1 min-w-[8px]"
                            style={{ height: `${((metric.memory - 140) / 10) * 100}%` }}
                          />
                        ))}
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm mb-2 block">Response Time Trend</Label>
                      <div className="h-24 bg-gradient-to-r from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 rounded border flex items-end p-2 gap-1">
                        {metrics.slice(-8).map((metric, index) => (
                          <div 
                            key={index}
                            className="bg-purple-500 rounded-sm flex-1 min-w-[8px]"
                            style={{ height: `${(metric.responseTime / 120) * 100}%` }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="databases" className="flex-1 overflow-hidden">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">Database Connections</CardTitle>
                      <CardDescription>Monitor and manage database connections</CardDescription>
                    </div>
                    <Button size="sm">
                      <Database className="h-4 w-4 mr-2" />
                      Add Connection
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                    {databases.map((db) => (
                      <Card key={db.id}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              <Database className="h-4 w-4 text-blue-500" />
                              <span className="font-medium">{db.name}</span>
                            </div>
                            {getStatusIcon(db.status)}
                          </div>

                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Type</span>
                              <Badge variant="outline">{db.type}</Badge>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Host</span>
                              <span>{db.host}:{db.port}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Database</span>
                              <span>{db.database}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Connections</span>
                              <span>{db.connections}/{db.maxConnections}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Query Time</span>
                              <span>{db.queryTime}ms</span>
                            </div>
                          </div>

                          <div className="mt-3">
                            <Progress value={(db.connections / db.maxConnections) * 100} />
                          </div>

                          <div className="flex gap-2 mt-3">
                            <Button size="sm" variant="outline" className="flex-1">
                              Test
                            </Button>
                            <Button size="sm" variant="outline" className="flex-1">
                              Config
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="security" className="flex-1 overflow-hidden">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Security Configuration</CardTitle>
                  <CardDescription>Manage server security settings and policies</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {securityConfig.map((config) => (
                      <div key={config.id} className="flex items-center justify-between p-4 border rounded">
                        <div className="flex items-center gap-3">
                          <Shield className="h-5 w-5 text-blue-500" />
                          <div>
                            <div className="font-medium">{config.name}</div>
                            <div className="text-sm text-muted-foreground">
                              Last updated: {config.lastUpdated.toLocaleDateString()}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge variant={config.enabled ? 'default' : 'secondary'}>
                            {config.enabled ? 'Enabled' : 'Disabled'}
                          </Badge>
                          <Switch 
                            checked={config.enabled}
                            onCheckedChange={() => toggleSecurity(config.id)}
                          />
                          <Button size="sm" variant="outline">
                            <Settings className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Security Metrics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-3 border rounded">
                          <div className="text-2xl font-bold text-green-500">0</div>
                          <div className="text-sm text-muted-foreground">Blocked IPs</div>
                        </div>
                        <div className="text-center p-3 border rounded">
                          <div className="text-2xl font-bold text-blue-500">247</div>
                          <div className="text-sm text-muted-foreground">Rate Limited</div>
                        </div>
                      </div>
                      
                      <div className="text-center p-3 border rounded">
                        <div className="text-2xl font-bold text-purple-500">99.9%</div>
                        <div className="text-sm text-muted-foreground">SSL Score</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Security Actions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Button size="sm" className="w-full justify-start">
                        <Lock className="h-4 w-4 mr-2" />
                        Generate SSL Certificate
                      </Button>
                      <Button size="sm" variant="outline" className="w-full justify-start">
                        <Shield className="h-4 w-4 mr-2" />
                        Run Security Scan
                      </Button>
                      <Button size="sm" variant="outline" className="w-full justify-start">
                        <AlertTriangle className="h-4 w-4 mr-2" />
                        View Threats
                      </Button>
                      <Button size="sm" variant="outline" className="w-full justify-start">
                        <Settings className="h-4 w-4 mr-2" />
                        Security Settings
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="logs" className="flex-1 overflow-hidden">
            <Card className="h-full flex flex-col">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">Server Logs</CardTitle>
                    <CardDescription>Real-time server log monitoring</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Select defaultValue="all">
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Levels</SelectItem>
                        <SelectItem value="error">Error</SelectItem>
                        <SelectItem value="warn">Warning</SelectItem>
                        <SelectItem value="info">Info</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button size="sm" variant="outline">
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex-1 overflow-hidden">
                <ScrollArea className="h-full">
                  <div className="space-y-2 font-mono text-sm">
                    {serverLogs.map((log, index) => (
                      <div key={index} className="flex gap-4 p-2 border rounded hover:bg-accent/50">
                        <span className="text-muted-foreground whitespace-nowrap">
                          {log.timestamp.toLocaleTimeString()}
                        </span>
                        <Badge 
                          variant={
                            log.level === 'error' ? 'destructive' :
                            log.level === 'warn' ? 'secondary' : 'default'
                          }
                          className="text-xs"
                        >
                          {log.level.toUpperCase()}
                        </Badge>
                        <span className="text-blue-500">[{log.source}]</span>
                        <span className="flex-1">{log.message}</span>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="deployment" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Deployment Pipeline</CardTitle>
                  <CardDescription>Manage deployment configurations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Environment</Label>
                      <Select defaultValue="staging">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="development">Development</SelectItem>
                          <SelectItem value="staging">Staging</SelectItem>
                          <SelectItem value="production">Production</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Branch</Label>
                      <Select defaultValue="main">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="main">main</SelectItem>
                          <SelectItem value="develop">develop</SelectItem>
                          <SelectItem value="feature/new-ui">feature/new-ui</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Deployment Notes</Label>
                      <Textarea placeholder="Describe changes in this deployment..." />
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Switch defaultChecked />
                        <Label>Run tests before deployment</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch defaultChecked />
                        <Label>Create database backup</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch />
                        <Label>Zero-downtime deployment</Label>
                      </div>
                    </div>

                    <Button className="w-full">
                      <Upload className="h-4 w-4 mr-2" />
                      Deploy to Staging
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Deployment History</CardTitle>
                  <CardDescription>Recent deployments and their status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 border rounded">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">v1.0.0</span>
                        <Badge variant="default">Success</Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Deployed to production • 2 hours ago
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Branch: main • Commit: a1b2c3d
                      </div>
                    </div>

                    <div className="p-3 border rounded">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">v1.0.0-rc.2</span>
                        <Badge variant="default">Success</Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Deployed to staging • 5 hours ago
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Branch: develop • Commit: e4f5g6h
                      </div>
                    </div>

                    <div className="p-3 border rounded">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">v1.0.0-rc.1</span>
                        <Badge variant="destructive">Failed</Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Failed staging deployment • 1 day ago
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Error: Database migration failed
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}