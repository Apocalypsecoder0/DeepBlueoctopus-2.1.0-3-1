import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { 
  User, Lock, Mail, Calendar, Settings, Shield, 
  Crown, Star, Trophy, Award, BookOpen, Code,
  Palette, Volume2, Bell, Globe, Eye, EyeOff, Clock,
  CheckCircle
} from 'lucide-react';
import { SoundButton } from '@/components/ui/sound-system';
import { TooltipWrapper } from '@/components/ui/tooltip-system';

interface AccountManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface UserProfile {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  avatar: string;
  bio: string;
  location: string;
  website: string;
  githubUsername: string;
  twitterUsername: string;
  linkedinUsername: string;
  joinDate: string;
  lastLogin: string;
  accountType: 'free' | 'pro' | 'enterprise';
  subscription: UserSubscription;
  security: SecuritySettings;
  preferences: UserPreferences;
  statistics: UserStatistics;
  achievements: Achievement[];
  apiUsage: ApiUsage;
}

interface UserPreferences {
  theme: string;
  language: string;
  notifications: boolean;
  sounds: boolean;
  autoSave: boolean;
  codeStyle: string;
  fontSize: number;
  tabSize: number;
}

interface UserStatistics {
  projectsCreated: number;
  linesOfCode: number;
  timeSpent: number;
  languagesUsed: string[];
  favoriteLanguage: string;
  streak: number;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlockedAt: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

interface UserSubscription {
  plan: 'free' | 'pro' | 'enterprise';
  status: 'active' | 'expired' | 'cancelled';
  startDate: string;
  endDate: string;
  autoRenew: boolean;
  features: string[];
  usage: {
    projects: { used: number; limit: number };
    storage: { used: number; limit: number };
    aiRequests: { used: number; limit: number };
  };
}

interface SecuritySettings {
  twoFactorEnabled: boolean;
  backupCodes: string[];
  trustedDevices: TrustedDevice[];
  activeTokens: ApiToken[];
  loginHistory: LoginEvent[];
  securityAlerts: boolean;
}

interface TrustedDevice {
  id: string;
  name: string;
  type: 'desktop' | 'mobile' | 'tablet';
  os: string;
  browser: string;
  lastUsed: string;
  trusted: boolean;
}

interface ApiToken {
  id: string;
  name: string;
  permissions: string[];
  createdAt: string;
  lastUsed: string;
  expiresAt: string;
}

interface LoginEvent {
  id: string;
  timestamp: string;
  ipAddress: string;
  location: string;
  device: string;
  success: boolean;
}

interface ApiUsage {
  openaiRequests: { used: number; limit: number; resetDate: string };
  githubIntegrations: { used: number; limit: number };
  deployments: { used: number; limit: number };
  collaborators: { used: number; limit: number };
}

export default function AccountManager({ isOpen, onClose }: AccountManagerProps) {
  const [activeTab, setActiveTab] = useState('profile');
  const [isEditing, setIsEditing] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [currentUser, setCurrentUser] = useState<UserProfile>({
    id: '1',
    username: 'Admin_developer_stephen',
    email: 'deepblueoctopus@deepblueide.dev',
    firstName: 'Stephen',
    lastName: 'Developer',
    avatar: '/avatars/default.png',
    bio: 'Full-stack developer passionate about creating innovative solutions',
    location: 'Oakville, Ont, Canada',
    website: 'https://stephendeveloper.dev',
    githubUsername: 'stephen deline jr-dev-123',
    twitterUsername: 'johndev',
    linkedinUsername: 'stephen deline jr-developer',
    joinDate: '2024-01-15',
    lastLogin: '2025-01-01T10:30:00Z',
    accountType: 'pro',
    subscription: {
      plan: 'pro',
      status: 'active',
      startDate: '2024-01-15',
      endDate: '2025-01-15',
      autoRenew: true,
      features: ['Unlimited Projects', '10GB Storage', 'AI Assistant', 'Advanced Debugging', 'Team Collaboration'],
      usage: {
        projects: { used: 15, limit: -1 },
        storage: { used: 2.5, limit: 10 },
        aiRequests: { used: 850, limit: -1 }
      }
    },
    security: {
      twoFactorEnabled: true,
      backupCodes: ['ABC123', 'DEF456', 'GHI789'],
      trustedDevices: [
        {
          id: '1',
          name: 'MacBook Pro',
          type: 'desktop',
          os: 'macOS 14.0',
          browser: 'Chrome 120.0',
          lastUsed: '2025-01-01T09:00:00Z',
          trusted: true
        }
      ],
      activeTokens: [
        {
          id: '1',
          name: 'Development API Token',
          permissions: ['read:projects', 'write:files'],
          createdAt: '2024-12-01',
          lastUsed: '2025-01-01',
          expiresAt: '2025-12-01'
        }
      ],
      loginHistory: [
        {
          id: '1',
          timestamp: '2025-01-01T09:00:00Z',
          ipAddress: '192.168.1.100',
          location: 'San Francisco, CA',
          device: 'MacBook Pro',
          success: true
        }
      ],
      securityAlerts: true
    },
    preferences: {
      theme: 'deep-blue-octopus',
      language: 'en',
      notifications: true,
      sounds: true,
      autoSave: true,
      codeStyle: 'standard',
      fontSize: 14,
      tabSize: 2
    },
    statistics: {
      projectsCreated: 42,
      linesOfCode: 15847,
      timeSpent: 156,
      languagesUsed: ['TypeScript', 'Python', 'Rust', 'Go', 'C++'],
      favoriteLanguage: 'TypeScript',
      streak: 7
    },
    achievements: [
      {
        id: '1',
        name: 'First Steps',
        description: 'Created your first project',
        icon: '🚀',
        unlockedAt: '2024-01-15',
        rarity: 'common'
      },
      {
        id: '2',
        name: 'Code Warrior',
        description: 'Wrote 10,000 lines of code',
        icon: '⚔️',
        unlockedAt: '2024-06-20',
        rarity: 'rare'
      },
      {
        id: '3',
        name: 'Polyglot',
        description: 'Used 5 different programming languages',
        icon: '🌍',
        unlockedAt: '2024-09-10',
        rarity: 'epic'
      }
    ],
    apiUsage: {
      openaiRequests: { used: 850, limit: -1, resetDate: '2025-02-01' },
      githubIntegrations: { used: 5, limit: 10 },
      deployments: { used: 12, limit: 50 },
      collaborators: { used: 3, limit: 10 }
    }
  });

  const [formData, setFormData] = useState(currentUser);

  const handleSave = () => {
    setCurrentUser(formData);
    setIsEditing(false);
    // Here you would typically save to the backend
  };

  const handleCancel = () => {
    setFormData(currentUser);
    setIsEditing(false);
  };

  const getAccountTypeIcon = (type: string) => {
    switch (type) {
      case 'enterprise': return <Crown className="h-4 w-4 text-purple-400" />;
      case 'pro': return <Star className="h-4 w-4 text-blue-400" />;
      default: return <User className="h-4 w-4 text-gray-400" />;
    }
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'legendary': return 'text-yellow-400 bg-yellow-400/20';
      case 'epic': return 'text-purple-400 bg-purple-400/20';
      case 'rare': return 'text-blue-400 bg-blue-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh] bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 border-blue-500/30 overflow-hidden">
        <DialogHeader className="border-b border-blue-500/30 pb-4">
          <DialogTitle className="text-2xl font-bold text-blue-100 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-500/20">
              <User className="h-6 w-6 text-blue-400" />
            </div>
            Account Management
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-12 gap-6 h-full overflow-hidden">
          {/* Sidebar */}
          <div className="col-span-3 space-y-2">
            <Card className="bg-slate-800/50 border-blue-500/30">
              <CardContent className="p-4">
                <div className="flex flex-col items-center space-y-3">
                  <Avatar className="h-20 w-20 border-2 border-blue-400/50">
                    <AvatarImage src={currentUser.avatar} />
                    <AvatarFallback className="bg-blue-600 text-white text-xl">
                      {currentUser.firstName[0]}{currentUser.lastName[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-center space-y-1">
                    <h3 className="font-semibold text-blue-100">{currentUser.firstName} {currentUser.lastName}</h3>
                    <p className="text-sm text-blue-300">@{currentUser.username}</p>
                    <Badge className={`${currentUser.accountType === 'pro' ? 'bg-blue-600' : currentUser.accountType === 'enterprise' ? 'bg-purple-600' : 'bg-gray-600'} text-white`}>
                      <div className="flex items-center gap-1">
                        {getAccountTypeIcon(currentUser.accountType)}
                        {currentUser.accountType.toUpperCase()}
                      </div>
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <nav className="space-y-1">
              {[
                { id: 'profile', label: 'Profile', icon: User },
                { id: 'security', label: 'Security', icon: Shield },
                { id: 'subscription', label: 'Subscription', icon: Crown },
                { id: 'api-usage', label: 'API Usage', icon: Code },
                { id: 'preferences', label: 'Preferences', icon: Settings },
                { id: 'statistics', label: 'Statistics', icon: Trophy },
                { id: 'achievements', label: 'Achievements', icon: Award }
              ].map(item => (
                <Button
                  key={item.id}
                  variant={activeTab === item.id ? "default" : "ghost"}
                  className={`w-full justify-start ${activeTab === item.id ? 'bg-blue-600 text-white' : 'text-blue-200 hover:bg-blue-800/50'}`}
                  onClick={() => setActiveTab(item.id)}
                >
                  <item.icon className="h-4 w-4 mr-2" />
                  {item.label}
                </Button>
              ))}
            </nav>
          </div>

          {/* Main Content */}
          <div className="col-span-9 overflow-y-auto">
            {activeTab === 'profile' && (
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-blue-100">Profile Information</CardTitle>
                  <div className="flex gap-2">
                    {isEditing ? (
                      <>
                        <SoundButton onClick={handleCancel} className="text-blue-200 border-blue-500/50 border bg-transparent hover:bg-blue-800/50">
                          Cancel
                        </SoundButton>
                        <SoundButton onClick={handleSave} className="bg-blue-600 hover:bg-blue-700 text-white">
                          Save Changes
                        </SoundButton>
                      </>
                    ) : (
                      <SoundButton onClick={() => setIsEditing(true)} className="bg-blue-600 hover:bg-blue-700 text-white">
                        Edit Profile
                      </SoundButton>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-blue-200">First Name</Label>
                      <Input
                        value={formData.firstName}
                        onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                        disabled={!isEditing}
                        className="bg-slate-700 border-blue-500/30 text-blue-100"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-blue-200">Last Name</Label>
                      <Input
                        value={formData.lastName}
                        onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                        disabled={!isEditing}
                        className="bg-slate-700 border-blue-500/30 text-blue-100"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-blue-200">Username</Label>
                      <Input
                        value={formData.username}
                        onChange={(e) => setFormData({...formData, username: e.target.value})}
                        disabled={!isEditing}
                        className="bg-slate-700 border-blue-500/30 text-blue-100"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-blue-200">Email</Label>
                      <Input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        disabled={!isEditing}
                        className="bg-slate-700 border-blue-500/30 text-blue-100"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 pt-4 border-t border-blue-500/30">
                    <div className="space-y-2">
                      <Label className="text-blue-200 flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        Member Since
                      </Label>
                      <Input
                        value={new Date(currentUser.joinDate).toLocaleDateString()}
                        disabled
                        className="bg-slate-700/50 border-blue-500/20 text-blue-300"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-blue-200 flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        Last Login
                      </Label>
                      <Input
                        value={new Date(currentUser.lastLogin).toLocaleString()}
                        disabled
                        className="bg-slate-700/50 border-blue-500/20 text-blue-300"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'security' && (
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-100 flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Security Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-blue-200">Change Password</h3>
                    <div className="grid grid-cols-1 gap-4">
                      <div className="space-y-2">
                        <Label className="text-blue-200">Current Password</Label>
                        <div className="relative">
                          <Input
                            type={showPassword ? "text" : "password"}
                            className="bg-slate-700 border-blue-500/30 text-blue-100 pr-10"
                            placeholder="Enter current password"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="absolute right-0 top-0 h-full px-3 text-blue-300 hover:bg-transparent"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </Button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-blue-200">New Password</Label>
                        <Input
                          type="password"
                          className="bg-slate-700 border-blue-500/30 text-blue-100"
                          placeholder="Enter new password"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-blue-200">Confirm Password</Label>
                        <Input
                          type="password"
                          className="bg-slate-700 border-blue-500/30 text-blue-100"
                          placeholder="Confirm new password"
                        />
                      </div>
                    </div>
                    <SoundButton className="bg-blue-600 hover:bg-blue-700 text-white">
                      Update Password
                    </SoundButton>
                  </div>

                  <div className="space-y-4 pt-6 border-t border-blue-500/30">
                    <h3 className="text-lg font-semibold text-blue-200">Two-Factor Authentication</h3>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-blue-200">Enable 2FA for enhanced security</p>
                        <p className="text-sm text-blue-400">Requires authenticator app</p>
                      </div>
                      <Switch />
                    </div>
                  </div>

                  <div className="space-y-4 pt-6 border-t border-blue-500/30">
                    <h3 className="text-lg font-semibold text-blue-200">Active Sessions</h3>
                    <div className="space-y-3">
                      {[
                        { device: 'Current Session - Chrome', location: 'New York, US', time: 'Active now' },
                        { device: 'MacBook Pro - Safari', location: 'San Francisco, US', time: '2 hours ago' }
                      ].map((session, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                          <div>
                            <p className="text-blue-200 font-medium">{session.device}</p>
                            <p className="text-sm text-blue-400">{session.location} • {session.time}</p>
                          </div>
                          <Button variant="outline" size="sm" className="text-red-400 border-red-400/50 hover:bg-red-400/10">
                            Revoke
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'subscription' && (
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-100 flex items-center gap-2">
                    <Crown className="h-5 w-5" />
                    Subscription Management
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Current Plan */}
                  <div className="p-4 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-lg border border-blue-500/30">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-semibold text-blue-100 flex items-center gap-2">
                          <Crown className="h-5 w-5 text-blue-400" />
                          {currentUser.subscription.plan.toUpperCase()} Plan
                        </h3>
                        <p className="text-blue-300">Active until {new Date(currentUser.subscription.endDate).toLocaleDateString()}</p>
                      </div>
                      <Badge className="bg-green-600 text-white">
                        {currentUser.subscription.status.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-blue-100">{currentUser.subscription.usage.projects.used}</p>
                        <p className="text-sm text-blue-300">Projects</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-blue-100">{currentUser.subscription.usage.storage.used}GB</p>
                        <p className="text-sm text-blue-300">Storage</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-blue-100">{currentUser.subscription.usage.aiRequests.used}</p>
                        <p className="text-sm text-blue-300">AI Requests</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-blue-100">∞</p>
                        <p className="text-sm text-blue-300">Languages</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Switch checked={currentUser.subscription.autoRenew} />
                        <Label className="text-blue-200">Auto-renew subscription</Label>
                      </div>
                      <SoundButton className="bg-blue-600 hover:bg-blue-700 text-white">
                        Manage Billing
                      </SoundButton>
                    </div>
                  </div>

                  {/* Features */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-blue-200">Plan Features</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {currentUser.subscription.features.map((feature, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-400" />
                          <span className="text-blue-200">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Usage Progress */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-blue-200">Usage Overview</h3>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-blue-200">Storage</span>
                          <span className="text-blue-300">{currentUser.subscription.usage.storage.used}GB / {currentUser.subscription.usage.storage.limit}GB</span>
                        </div>
                        <Progress value={(currentUser.subscription.usage.storage.used / currentUser.subscription.usage.storage.limit) * 100} className="bg-slate-700" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'api-usage' && (
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-100 flex items-center gap-2">
                    <Code className="h-5 w-5" />
                    API Usage & Integration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* API Usage Stats */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Card className="bg-slate-700/50 border-blue-500/20">
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl font-bold text-blue-100 mb-1">{currentUser.apiUsage.openaiRequests.used}</div>
                        <div className="text-sm text-blue-300">OpenAI Requests</div>
                        <div className="text-xs text-blue-400 mt-1">Resets {currentUser.apiUsage.openaiRequests.resetDate}</div>
                      </CardContent>
                    </Card>
                    <Card className="bg-slate-700/50 border-blue-500/20">
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl font-bold text-blue-100 mb-1">{currentUser.apiUsage.githubIntegrations.used}/{currentUser.apiUsage.githubIntegrations.limit}</div>
                        <div className="text-sm text-blue-300">GitHub Repos</div>
                        <div className="text-xs text-blue-400 mt-1">Connected repositories</div>
                      </CardContent>
                    </Card>
                    <Card className="bg-slate-700/50 border-blue-500/20">
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl font-bold text-blue-100 mb-1">{currentUser.apiUsage.deployments.used}/{currentUser.apiUsage.deployments.limit}</div>
                        <div className="text-sm text-blue-300">Deployments</div>
                        <div className="text-xs text-blue-400 mt-1">This month</div>
                      </CardContent>
                    </Card>
                    <Card className="bg-slate-700/50 border-blue-500/20">
                      <CardContent className="p-4 text-center">
                        <div className="text-2xl font-bold text-blue-100 mb-1">{currentUser.apiUsage.collaborators.used}/{currentUser.apiUsage.collaborators.limit}</div>
                        <div className="text-sm text-blue-300">Collaborators</div>
                        <div className="text-xs text-blue-400 mt-1">Active team members</div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* API Tokens */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-blue-200">API Tokens</h3>
                      <SoundButton className="bg-blue-600 hover:bg-blue-700 text-white">
                        Generate New Token
                      </SoundButton>
                    </div>
                    <div className="space-y-3">
                      {currentUser.security.activeTokens.map((token) => (
                        <div key={token.id} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                          <div>
                            <p className="text-blue-200 font-medium">{token.name}</p>
                            <p className="text-sm text-blue-400">
                              Permissions: {token.permissions.join(', ')} • 
                              Last used: {new Date(token.lastUsed).toLocaleDateString()} • 
                              Expires: {new Date(token.expiresAt).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" className="text-blue-200 border-blue-500/50">
                              Edit
                            </Button>
                            <Button variant="outline" size="sm" className="text-red-400 border-red-400/50 hover:bg-red-400/10">
                              Revoke
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Integration Status */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-blue-200">Integration Status</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {[
                        { name: 'OpenAI API', status: 'connected', color: 'green' },
                        { name: 'GitHub', status: 'connected', color: 'green' },
                        { name: 'Vercel', status: 'disconnected', color: 'gray' },
                        { name: 'Netlify', status: 'disconnected', color: 'gray' }
                      ].map((integration, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className={`w-3 h-3 rounded-full bg-${integration.color}-400`}></div>
                            <span className="text-blue-200">{integration.name}</span>
                          </div>
                          <Badge className={`${integration.status === 'connected' ? 'bg-green-600' : 'bg-gray-600'} text-white`}>
                            {integration.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'preferences' && (
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-100 flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Preferences
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-blue-200 flex items-center gap-2">
                        <Palette className="h-4 w-4" />
                        Appearance
                      </h3>
                      <div className="space-y-3">
                        <div className="space-y-2">
                          <Label className="text-blue-200">Theme</Label>
                          <Select value={formData.preferences.theme} onValueChange={(value) => 
                            setFormData({...formData, preferences: {...formData.preferences, theme: value}})
                          }>
                            <SelectTrigger className="bg-slate-700 border-blue-500/30 text-blue-100">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="deep-blue-octopus">Deep Blue Octopus</SelectItem>
                              <SelectItem value="dark-professional">Dark Professional</SelectItem>
                              <SelectItem value="light">Light</SelectItem>
                              <SelectItem value="forest">Forest</SelectItem>
                              <SelectItem value="neon-cyber">Neon Cyber</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-blue-200">Font Size</Label>
                          <Select value={formData.preferences.fontSize.toString()} onValueChange={(value) => 
                            setFormData({...formData, preferences: {...formData.preferences, fontSize: parseInt(value)}})
                          }>
                            <SelectTrigger className="bg-slate-700 border-blue-500/30 text-blue-100">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="12">12px</SelectItem>
                              <SelectItem value="14">14px</SelectItem>
                              <SelectItem value="16">16px</SelectItem>
                              <SelectItem value="18">18px</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-blue-200 flex items-center gap-2">
                        <Volume2 className="h-4 w-4" />
                        Audio & Notifications
                      </h3>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label className="text-blue-200">Sound Effects</Label>
                          <Switch 
                            checked={formData.preferences.sounds}
                            onCheckedChange={(checked) => 
                              setFormData({...formData, preferences: {...formData.preferences, sounds: checked}})
                            }
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label className="text-blue-200">Notifications</Label>
                          <Switch 
                            checked={formData.preferences.notifications}
                            onCheckedChange={(checked) => 
                              setFormData({...formData, preferences: {...formData.preferences, notifications: checked}})
                            }
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label className="text-blue-200">Auto Save</Label>
                          <Switch 
                            checked={formData.preferences.autoSave}
                            onCheckedChange={(checked) => 
                              setFormData({...formData, preferences: {...formData.preferences, autoSave: checked}})
                            }
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-blue-500/30">
                    <h3 className="text-lg font-semibold text-blue-200 flex items-center gap-2 mb-4">
                      <Code className="h-4 w-4" />
                      Editor Settings
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="text-blue-200">Code Style</Label>
                        <Select value={formData.preferences.codeStyle} onValueChange={(value) => 
                          setFormData({...formData, preferences: {...formData.preferences, codeStyle: value}})
                        }>
                          <SelectTrigger className="bg-slate-700 border-blue-500/30 text-blue-100">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="standard">Standard</SelectItem>
                            <SelectItem value="google">Google</SelectItem>
                            <SelectItem value="airbnb">Airbnb</SelectItem>
                            <SelectItem value="prettier">Prettier</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-blue-200">Tab Size</Label>
                        <Select value={formData.preferences.tabSize.toString()} onValueChange={(value) => 
                          setFormData({...formData, preferences: {...formData.preferences, tabSize: parseInt(value)}})
                        }>
                          <SelectTrigger className="bg-slate-700 border-blue-500/30 text-blue-100">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="2">2 spaces</SelectItem>
                            <SelectItem value="4">4 spaces</SelectItem>
                            <SelectItem value="8">8 spaces</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'statistics' && (
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-100 flex items-center gap-2">
                    <Trophy className="h-5 w-5" />
                    Your Statistics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-slate-700/50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-400">{currentUser.statistics.projectsCreated}</div>
                      <div className="text-sm text-blue-300">Projects Created</div>
                    </div>
                    <div className="text-center p-4 bg-slate-700/50 rounded-lg">
                      <div className="text-2xl font-bold text-green-400">{currentUser.statistics.linesOfCode.toLocaleString()}</div>
                      <div className="text-sm text-green-300">Lines of Code</div>
                    </div>
                    <div className="text-center p-4 bg-slate-700/50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-400">{currentUser.statistics.timeSpent}h</div>
                      <div className="text-sm text-purple-300">Time Spent</div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-blue-200">Languages Used</h3>
                    <div className="grid grid-cols-2 gap-3">
                      {currentUser.statistics.languagesUsed.map((lang, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                          <span className="text-blue-200">{lang}</span>
                          <Badge variant={lang === currentUser.statistics.favoriteLanguage ? "default" : "secondary"}>
                            {lang === currentUser.statistics.favoriteLanguage ? 'Favorite' : 'Used'}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-blue-200">Current Streak</h3>
                    <div className="flex items-center gap-4 p-4 bg-slate-700/50 rounded-lg">
                      <div className="text-3xl">🔥</div>
                      <div>
                        <div className="text-xl font-bold text-orange-400">{currentUser.statistics.streak} days</div>
                        <div className="text-sm text-orange-300">Keep coding to maintain your streak!</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'achievements' && (
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-100 flex items-center gap-2">
                    <Award className="h-5 w-5" />
                    Achievements ({currentUser.achievements.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 gap-4">
                    {currentUser.achievements.map((achievement) => (
                      <div key={achievement.id} className="flex items-center gap-4 p-4 bg-slate-700/50 rounded-lg border border-blue-500/20">
                        <div className="text-2xl">{achievement.icon}</div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold text-blue-200">{achievement.name}</h3>
                            <Badge className={getRarityColor(achievement.rarity)}>
                              {achievement.rarity}
                            </Badge>
                          </div>
                          <p className="text-sm text-blue-300">{achievement.description}</p>
                          <p className="text-xs text-blue-400 mt-1">
                            Unlocked on {new Date(achievement.unlockedAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}