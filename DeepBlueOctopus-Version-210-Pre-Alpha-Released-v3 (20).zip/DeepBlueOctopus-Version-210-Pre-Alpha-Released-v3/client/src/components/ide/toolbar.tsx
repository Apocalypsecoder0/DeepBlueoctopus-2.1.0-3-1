import React, { useState } from "react";
import { Save, FolderOpen, FilePlus, Undo, Redo, Play, Settings, Palette, Package, Grid3X3, Download, Upload, Terminal, Search, GitBranch, Square, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useIDEState } from "@/hooks/use-ide-state";
import { useToast } from "@/hooks/use-toast";
import CategorizedToolbar from "./categorized-toolbar";
import PluginMarketplace from "./plugin-marketplace";
import pluginSystem from "@/lib/plugin-system";

export default function Toolbar() {
  const { createNewFile, saveCurrentFile, runCurrentFile } = useIDEState();
  const { toast } = useToast();
  const [showCategorizedToolbar, setShowCategorizedToolbar] = useState(false);
  const [showPluginMarketplace, setShowPluginMarketplace] = useState(false);
  const [activeTools, setActiveTools] = useState<string[]>([]);

  const handleToolAction = (toolId: string, action: () => void) => {
    action();
    
    // Toggle active state for visual feedback
    setActiveTools(prev => 
      prev.includes(toolId) 
        ? prev.filter(id => id !== toolId)
        : [...prev, toolId]
    );

    toast({
      title: "Tool Activated",
      description: `${toolId.replace('-', ' ')} has been activated`
    });
  };

  const getPluginTools = () => {
    return pluginSystem.getActivePlugins().map(plugin => ({
      id: plugin.manifest.id,
      name: plugin.manifest.displayName,
      icon: <Package className="h-4 w-4" />,
      description: plugin.manifest.description,
      action: () => console.log(`Plugin ${plugin.manifest.name} activated`),
      isPlugin: true
    }));
  };

  return (
    <>
      <div className="ide-sidebar border-b ide-border h-12 flex items-center justify-between px-4">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={createNewFile}
            className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
            title="New File"
          >
            <FilePlus className="h-4 w-4" />
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
            title="Open Folder"
          >
            <FolderOpen className="h-4 w-4" />
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={saveCurrentFile}
            className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
            title="Save"
          >
            <Save className="h-4 w-4" />
          </Button>
          
          <Separator orientation="vertical" className="h-6 bg-[var(--ide-border)]" />
          
          <Button
            variant="ghost"
            size="sm"
            className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
            title="Undo"
          >
            <Undo className="h-4 w-4" />
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
            title="Redo"
          >
            <Redo className="h-4 w-4" />
          </Button>
          
          <Separator orientation="vertical" className="h-6 bg-[var(--ide-border)]" />
          
          {/* Development Tools */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleToolAction('search', () => console.log('Search activated'))}
            className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
            title="Search"
          >
            <Search className="h-4 w-4" />
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleToolAction('git', () => console.log('Git panel opened'))}
            className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
            title="Version Control"
          >
            <GitBranch className="h-4 w-4" />
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleToolAction('terminal', () => console.log('Terminal opened'))}
            className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
            title="Terminal"
          >
            <Terminal className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant={showCategorizedToolbar ? "default" : "ghost"}
            size="sm"
            onClick={() => setShowCategorizedToolbar(!showCategorizedToolbar)}
            className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
            title="Categorized Tools"
          >
            <Grid3X3 className="h-4 w-4" />
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowPluginMarketplace(true)}
            className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
            title="Plugin Marketplace"
          >
            <Package className="h-4 w-4" />
          </Button>
          
          <Separator orientation="vertical" className="h-6 bg-[var(--ide-border)]" />
          
          <Button
            onClick={runCurrentFile}
            className="bg-[var(--ide-success)] text-[var(--ide-bg)] hover:bg-green-400 px-4 py-2 font-medium"
            title="Run Code"
          >
            <Play className="h-4 w-4 mr-2" />
            Run
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
            title="Settings"
          >
            <Settings className="h-4 w-4" />
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
            title="Theme Toggle"
          >
            <Palette className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Categorized Toolbar */}
      {showCategorizedToolbar && (
        <div className="border-b bg-background/50">
          <CategorizedToolbar
            onToolAction={handleToolAction}
            activeTools={activeTools}
            pluginTools={getPluginTools()}
          />
        </div>
      )}

      {/* Plugin Marketplace */}
      <PluginMarketplace 
        isOpen={showPluginMarketplace}
        onClose={() => setShowPluginMarketplace(false)}
      />
    </>
  );
}