import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Code2,
  Terminal,
  FileText,
  Wrench,
  Zap,
  BookOpen,
  Bug,
  Palette,
  Database,
  Globe,
  Package,
  Settings,
  Play,
  Download,
  Upload,
  Search,
  Monitor,
  Cpu,
  HardDrive,
  MemoryStick,
  Network,
  Layers,
  Coffee,
  Lightbulb
} from "lucide-react";

interface DeveloperToolkitProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CompilerSettings {
  language: string;
  version: string;
  flags: string[];
  outputFormat: string;
  optimization: string;
}

interface Tool {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: any;
  status: 'active' | 'inactive' | 'error';
  version?: string;
}

export default function DeveloperToolkit({ isOpen, onClose }: DeveloperToolkitProps) {
  const [activeTab, setActiveTab] = useState("compilers");
  const [selectedLanguage, setSelectedLanguage] = useState("javascript");
  const [code, setCode] = useState("");
  const [compilationResult, setCompilationResult] = useState("");
  const [isCompiling, setIsCompiling] = useState(false);

  const compilerLanguages = [
    { id: 'javascript', name: 'JavaScript', version: 'ES2023', compiler: 'V8' },
    { id: 'typescript', name: 'TypeScript', version: '5.3.0', compiler: 'TSC' },
    { id: 'python', name: 'Python', version: '3.12.0', compiler: 'CPython' },
    { id: 'java', name: 'Java', version: '21.0.0', compiler: 'OpenJDK' },
    { id: 'cpp', name: 'C++', version: 'C++23', compiler: 'GCC 13.2' },
    { id: 'c', name: 'C', version: 'C23', compiler: 'GCC 13.2' },
    { id: 'rust', name: 'Rust', version: '1.75.0', compiler: 'Rustc' },
    { id: 'go', name: 'Go', version: '1.21.5', compiler: 'gc' },
    { id: 'php', name: 'PHP', version: '8.3.0', compiler: 'Zend Engine' },
    { id: 'ruby', name: 'Ruby', version: '3.3.0', compiler: 'YARV' },
    { id: 'swift', name: 'Swift', version: '5.9.0', compiler: 'SwiftC' },
    { id: 'kotlin', name: 'Kotlin', version: '1.9.20', compiler: 'KotlinC' },
    { id: 'dart', name: 'Dart', version: '3.2.0', compiler: 'Dart VM' },
    { id: 'lua', name: 'Lua', version: '5.4.6', compiler: 'LuaJIT' },
    { id: 'scala', name: 'Scala', version: '3.3.1', compiler: 'Scalac' },
    { id: 'haskell', name: 'Haskell', version: '9.8.1', compiler: 'GHC' },
    { id: 'elixir', name: 'Elixir', version: '1.16.0', compiler: 'ExC' },
    { id: 'crystal', name: 'Crystal', version: '1.10.1', compiler: 'CrystalC' },
    { id: 'nim', name: 'Nim', version: '2.0.0', compiler: 'NimC' },
    { id: 'zig', name: 'Zig', version: '0.11.0', compiler: 'ZigC' },
  ];

  const devTools = [
    { id: 'compiler', name: 'Multi-Language Compiler', description: 'Compile and run code in 20+ languages', category: 'compilers', icon: Code2, status: 'active' as const, version: '2.1.0' },
    { id: 'debugger', name: 'Advanced Debugger', description: 'Debug with breakpoints, variable inspection', category: 'debugging', icon: Bug, status: 'active' as const, version: '1.8.0' },
    { id: 'formatter', name: 'Code Formatter', description: 'Format code according to style guidelines', category: 'tools', icon: Palette, status: 'active' as const, version: '1.5.0' },
    { id: 'linter', name: 'Code Linter', description: 'Static code analysis and error detection', category: 'tools', icon: Search, status: 'active' as const, version: '2.3.0' },
    { id: 'packager', name: 'Package Manager', description: 'Manage dependencies and packages', category: 'tools', icon: Package, status: 'active' as const, version: '3.1.0' },
    { id: 'profiler', name: 'Performance Profiler', description: 'Analyze application performance', category: 'monitoring', icon: Monitor, status: 'active' as const, version: '1.2.0' },
    { id: 'testing', name: 'Testing Framework', description: 'Unit and integration testing tools', category: 'testing', icon: Zap, status: 'active' as const, version: '2.0.0' },
    { id: 'documentation', name: 'Doc Generator', description: 'Generate API documentation', category: 'documentation', icon: BookOpen, status: 'active' as const, version: '1.7.0' },
    { id: 'database', name: 'Database Tools', description: 'Database management and query tools', category: 'database', icon: Database, status: 'active' as const, version: '2.5.0' },
    { id: 'api', name: 'API Testing', description: 'Test REST and GraphQL APIs', category: 'testing', icon: Globe, status: 'active' as const, version: '1.9.0' },
    { id: 'memory', name: 'Memory Analyzer', description: 'Memory usage and leak detection', category: 'monitoring', icon: MemoryStick, status: 'active' as const, version: '1.4.0' },
    { id: 'network', name: 'Network Monitor', description: 'Monitor network requests and responses', category: 'monitoring', icon: Network, status: 'active' as const, version: '1.6.0' },
  ];

  const libraries = [
    { name: 'React', description: 'A JavaScript library for building user interfaces', category: 'Frontend', version: '18.2.0' },
    { name: 'Vue.js', description: 'Progressive JavaScript Framework', category: 'Frontend', version: '3.4.0' },
    { name: 'Angular', description: 'Platform for building mobile and desktop web applications', category: 'Frontend', version: '17.0.0' },
    { name: 'Express.js', description: 'Fast, unopinionated, minimalist web framework for Node.js', category: 'Backend', version: '4.18.0' },
    { name: 'Django', description: 'High-level Python web framework', category: 'Backend', version: '5.0.0' },
    { name: 'Spring Boot', description: 'Java-based framework for building microservices', category: 'Backend', version: '3.2.0' },
    { name: 'ASP.NET Core', description: 'Cross-platform framework for building modern applications', category: 'Backend', version: '8.0.0' },
    { name: 'Flask', description: 'Lightweight WSGI web application framework', category: 'Backend', version: '3.0.0' },
    { name: 'FastAPI', description: 'Modern, fast web framework for building APIs with Python', category: 'Backend', version: '0.104.0' },
    { name: 'TensorFlow', description: 'End-to-end open source platform for machine learning', category: 'ML/AI', version: '2.15.0' },
    { name: 'PyTorch', description: 'Machine learning framework based on the Torch library', category: 'ML/AI', version: '2.1.0' },
    { name: 'OpenCV', description: 'Open source computer vision and machine learning library', category: 'ML/AI', version: '4.8.0' },
    { name: 'NumPy', description: 'Fundamental package for scientific computing with Python', category: 'Scientific', version: '1.26.0' },
    { name: 'Pandas', description: 'Data manipulation and analysis library', category: 'Data', version: '2.1.0' },
    { name: 'Matplotlib', description: 'Comprehensive library for creating static, animated visualizations', category: 'Visualization', version: '3.8.0' },
    { name: 'D3.js', description: 'JavaScript library for manipulating documents based on data', category: 'Visualization', version: '7.8.0' },
    { name: 'Chart.js', description: 'Simple yet flexible JavaScript charting library', category: 'Visualization', version: '4.4.0' },
    { name: 'Three.js', description: 'JavaScript 3D library', category: '3D Graphics', version: '0.158.0' },
    { name: 'Unity', description: 'Cross-platform game engine', category: 'Game Development', version: '2023.2.0' },
    { name: 'Unreal Engine', description: 'Suite of integrated tools for game developers', category: 'Game Development', version: '5.3.0' },
  ];

  const handleCompile = async () => {
    setIsCompiling(true);
    setCompilationResult("");
    
    try {
      // Simulate compilation process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const language = compilerLanguages.find(lang => lang.id === selectedLanguage);
      setCompilationResult(`✅ Compilation successful using ${language?.compiler} ${language?.version}
      
📊 Compilation Stats:
• Build time: 1.245s
• Memory usage: 45.2MB
• Output size: 2.8KB
• Optimizations: Level 2
• Warnings: 0
• Errors: 0

🚀 Ready for execution!`);
    } catch (error) {
      setCompilationResult(`❌ Compilation failed: ${error}`);
    } finally {
      setIsCompiling(false);
    }
  };

  const codeTemplates = {
    javascript: `// JavaScript Example
function fibonacci(n) {
    if (n <= 1) return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
}

console.log("Fibonacci(10):", fibonacci(10));`,
    
    python: `# Python Example
def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quick_sort(left) + middle + quick_sort(right)

print("Sorted:", quick_sort([3, 6, 8, 10, 1, 2, 1]))`,
    
    java: `// Java Example
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello from Java!");
        
        int[] numbers = {5, 2, 8, 1, 9};
        bubbleSort(numbers);
        
        System.out.print("Sorted array: ");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
    }
    
    static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n-1; i++) {
            for (int j = 0; j < n-i-1; j++) {
                if (arr[j] > arr[j+1]) {
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
            }
        }
    }
}`,
    
    cpp: `// C++ Example
#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    std::vector<int> numbers = {64, 34, 25, 12, 22, 11, 90};
    
    std::cout << "Original array: ";
    for (int n : numbers) std::cout << n << " ";
    
    std::sort(numbers.begin(), numbers.end());
    
    std::cout << "\\nSorted array: ";
    for (int n : numbers) std::cout << n << " ";
    
    return 0;
}`
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wrench className="h-5 w-5" />
            Developer Toolkit & Compiler Suite
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="compilers">Compilers</TabsTrigger>
            <TabsTrigger value="tools">Dev Tools</TabsTrigger>
            <TabsTrigger value="libraries">Libraries</TabsTrigger>
            <TabsTrigger value="documentation">Docs</TabsTrigger>
            <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
          </TabsList>

          <TabsContent value="compilers" className="flex-1">
            <div className="grid grid-cols-2 gap-4 h-full">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Code2 className="h-4 w-4" />
                      Multi-Language Compiler
                    </CardTitle>
                    <CardDescription>
                      Compile and execute code in 20+ programming languages
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Language</label>
                      <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {compilerLanguages.map((lang) => (
                            <SelectItem key={lang.id} value={lang.id}>
                              {lang.name} ({lang.version})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-sm font-medium">Source Code</label>
                      <Textarea
                        value={code || codeTemplates[selectedLanguage as keyof typeof codeTemplates] || ""}
                        onChange={(e) => setCode(e.target.value)}
                        placeholder="Enter your code here..."
                        className="h-64 font-mono text-sm"
                      />
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        onClick={handleCompile} 
                        disabled={isCompiling}
                        className="flex items-center gap-2"
                      >
                        <Play className="h-4 w-4" />
                        {isCompiling ? "Compiling..." : "Compile & Run"}
                      </Button>
                      <Button variant="outline" onClick={() => setCode("")}>
                        Clear
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Terminal className="h-4 w-4" />
                      Compilation Result
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-64 w-full border rounded p-4 font-mono text-sm">
                      {compilationResult || "No compilation results yet. Click 'Compile & Run' to start."}
                    </ScrollArea>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Available Compilers</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-48">
                      <div className="grid grid-cols-2 gap-2">
                        {compilerLanguages.map((lang) => (
                          <div key={lang.id} className="p-2 border rounded text-xs">
                            <div className="font-medium">{lang.name}</div>
                            <div className="text-muted-foreground">{lang.compiler}</div>
                            <Badge variant="secondary" className="text-xs mt-1">
                              {lang.version}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="tools" className="flex-1">
            <ScrollArea className="h-full">
              <div className="grid grid-cols-3 gap-4">
                {devTools.map((tool) => (
                  <Card key={tool.id} className="cursor-pointer hover:shadow-lg transition-all">
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <tool.icon className="h-8 w-8 text-blue-500" />
                        <Badge 
                          variant={tool.status === 'active' ? 'default' : 'secondary'}
                          className="text-xs"
                        >
                          {tool.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <CardTitle className="text-sm mb-1">{tool.name}</CardTitle>
                      <CardDescription className="text-xs mb-2">
                        {tool.description}
                      </CardDescription>
                      {tool.version && (
                        <Badge variant="outline" className="text-xs">
                          v{tool.version}
                        </Badge>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="libraries" className="flex-1">
            <ScrollArea className="h-full">
              <div className="grid grid-cols-2 gap-4">
                {libraries.map((lib, index) => (
                  <Card key={index} className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-sm">{lib.name}</h3>
                      <Badge variant="secondary" className="text-xs">
                        {lib.version}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">
                      {lib.description}
                    </p>
                    <Badge variant="outline" className="text-xs">
                      {lib.category}
                    </Badge>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="documentation" className="flex-1">
            <div className="grid grid-cols-2 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    Development Documentation
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-3">
                      <div className="p-3 border rounded">
                        <h4 className="font-medium text-sm">Getting Started Guide</h4>
                        <p className="text-xs text-muted-foreground">Complete setup and configuration guide</p>
                      </div>
                      <div className="p-3 border rounded">
                        <h4 className="font-medium text-sm">API Reference</h4>
                        <p className="text-xs text-muted-foreground">Complete API documentation with examples</p>
                      </div>
                      <div className="p-3 border rounded">
                        <h4 className="font-medium text-sm">Language Support</h4>
                        <p className="text-xs text-muted-foreground">Supported languages and their features</p>
                      </div>
                      <div className="p-3 border rounded">
                        <h4 className="font-medium text-sm">Best Practices</h4>
                        <p className="text-xs text-muted-foreground">Coding standards and guidelines</p>
                      </div>
                      <div className="p-3 border rounded">
                        <h4 className="font-medium text-sm">Troubleshooting</h4>
                        <p className="text-xs text-muted-foreground">Common issues and solutions</p>
                      </div>
                      <div className="p-3 border rounded">
                        <h4 className="font-medium text-sm">Advanced Features</h4>
                        <p className="text-xs text-muted-foreground">Expert-level functionality</p>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Coffee className="h-4 w-4" />
                    Quick Tips & Tricks
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-3">
                      <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded">
                        <div className="flex items-center gap-2 mb-1">
                          <Lightbulb className="h-3 w-3 text-blue-500" />
                          <span className="text-xs font-medium text-blue-700 dark:text-blue-300">Keyboard Shortcuts</span>
                        </div>
                        <p className="text-xs text-blue-600 dark:text-blue-400">
                          Use Ctrl+Shift+P for command palette, Ctrl+` for terminal
                        </p>
                      </div>
                      <div className="p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded">
                        <div className="flex items-center gap-2 mb-1">
                          <Lightbulb className="h-3 w-3 text-green-500" />
                          <span className="text-xs font-medium text-green-700 dark:text-green-300">Code Formatting</span>
                        </div>
                        <p className="text-xs text-green-600 dark:text-green-400">
                          Use Shift+Alt+F to format your code automatically
                        </p>
                      </div>
                      <div className="p-3 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded">
                        <div className="flex items-center gap-2 mb-1">
                          <Lightbulb className="h-3 w-3 text-purple-500" />
                          <span className="text-xs font-medium text-purple-700 dark:text-purple-300">Debugging</span>
                        </div>
                        <p className="text-xs text-purple-600 dark:text-purple-400">
                          Set breakpoints with F9, step through with F10/F11
                        </p>
                      </div>
                      <div className="p-3 bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded">
                        <div className="flex items-center gap-2 mb-1">
                          <Lightbulb className="h-3 w-3 text-orange-500" />
                          <span className="text-xs font-medium text-orange-700 dark:text-orange-300">Git Integration</span>
                        </div>
                        <p className="text-xs text-orange-600 dark:text-orange-400">
                          Use Ctrl+Shift+G for source control operations
                        </p>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="monitoring" className="flex-1">
            <div className="grid grid-cols-2 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Monitor className="h-4 w-4" />
                    System Monitoring
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 border rounded">
                      <div className="flex items-center gap-2">
                        <Cpu className="h-4 w-4 text-blue-500" />
                        <span className="text-sm">CPU Usage</span>
                      </div>
                      <Badge variant="secondary">23%</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded">
                      <div className="flex items-center gap-2">
                        <MemoryStick className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Memory Usage</span>
                      </div>
                      <Badge variant="secondary">67%</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded">
                      <div className="flex items-center gap-2">
                        <HardDrive className="h-4 w-4 text-purple-500" />
                        <span className="text-sm">Disk Usage</span>
                      </div>
                      <Badge variant="secondary">45%</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded">
                      <div className="flex items-center gap-2">
                        <Network className="h-4 w-4 text-orange-500" />
                        <span className="text-sm">Network I/O</span>
                      </div>
                      <Badge variant="secondary">12 MB/s</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Layers className="h-4 w-4" />
                    Performance Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 border rounded">
                      <div className="text-sm font-medium mb-1">Build Performance</div>
                      <div className="text-xs text-muted-foreground">
                        Average build time: 2.3s
                      </div>
                    </div>
                    <div className="p-3 border rounded">
                      <div className="text-sm font-medium mb-1">Memory Leaks</div>
                      <div className="text-xs text-muted-foreground">
                        No memory leaks detected
                      </div>
                    </div>
                    <div className="p-3 border rounded">
                      <div className="text-sm font-medium mb-1">Code Quality</div>
                      <div className="text-xs text-muted-foreground">
                        Score: 94/100
                      </div>
                    </div>
                    <div className="p-3 border rounded">
                      <div className="text-sm font-medium mb-1">Test Coverage</div>
                      <div className="text-xs text-muted-foreground">
                        Coverage: 87%
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="templates" className="flex-1">
            <ScrollArea className="h-full">
              <div className="grid grid-cols-3 gap-4">
                {Object.entries(codeTemplates).map(([lang, template]) => (
                  <Card key={lang} className="cursor-pointer hover:shadow-lg transition-all">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm capitalize">{lang} Template</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded overflow-hidden">
                        {template.substring(0, 100)}...
                      </pre>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="mt-2 w-full"
                        onClick={() => {
                          setSelectedLanguage(lang);
                          setCode(template);
                          setActiveTab("compilers");
                        }}
                      >
                        Use Template
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}