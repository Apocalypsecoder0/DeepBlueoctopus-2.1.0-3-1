import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Activity,
  AlertTriangle,
  CheckCircle2,
  Code,
  FileText,
  Play,
  RefreshCw,
  Search,
  Settings,
  Terminal,
  Wrench,
  Zap,
  Bug,
  Lightbulb,
  Monitor,
  Database,
  Wifi,
  Shield,
  Clock,
  Cpu,
  HardDrive,
  MemoryStick,
  Network
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface DiagnosticTest {
  id: string;
  name: string;
  description: string;
  category: string;
  status: 'passed' | 'failed' | 'warning' | 'running' | 'pending';
  lastRun: Date;
  duration: number;
  details?: string;
  fix?: string;
  critical: boolean;
}

interface ComponentHealth {
  id: string;
  name: string;
  status: 'healthy' | 'degraded' | 'unhealthy' | 'unknown';
  uptime: number;
  lastChecked: Date;
  metrics: {
    responseTime: number;
    errorRate: number;
    availability: number;
  };
  issues: string[];
}

const mockDiagnosticTests: DiagnosticTest[] = [
  {
    id: 'typescript-compilation',
    name: 'TypeScript Compilation',
    description: 'Check if TypeScript files compile without errors',
    category: 'compilation',
    status: 'failed',
    lastRun: new Date(),
    duration: 1250,
    details: 'ReferenceError: require is not defined in server routes',
    fix: 'Replace require() with import statements in ES modules',
    critical: true
  },
  {
    id: 'icon-imports',
    name: 'Icon Import Validation',
    description: 'Verify all lucide-react icons are properly imported',
    category: 'ui',
    status: 'warning',
    lastRun: new Date(),
    duration: 320,
    details: 'Some icon imports may be missing or deprecated',
    fix: 'Update icon imports to use correct lucide-react names',
    critical: false
  },
  {
    id: 'database-connection',
    name: 'Database Connection',
    description: 'Test PostgreSQL database connectivity',
    category: 'database',
    status: 'passed',
    lastRun: new Date(),
    duration: 450,
    details: 'Successfully connected to PostgreSQL database',
    critical: true
  },
  {
    id: 'api-endpoints',
    name: 'API Endpoints Health',
    description: 'Check all REST API endpoints are responding',
    category: 'api',
    status: 'passed',
    lastRun: new Date(),
    duration: 890,
    details: 'All API endpoints responding within acceptable limits',
    critical: true
  },
  {
    id: 'file-operations',
    name: 'File Operations',
    description: 'Test file upload, download, and management functions',
    category: 'filesystem',
    status: 'warning',
    lastRun: new Date(),
    duration: 670,
    details: 'File upload parameters missing in some operations',
    fix: 'Add missing path and projectId parameters to addFile calls',
    critical: false
  },
  {
    id: 'memory-usage',
    name: 'Memory Usage Analysis',
    description: 'Monitor application memory consumption',
    category: 'performance',
    status: 'passed',
    lastRun: new Date(),
    duration: 200,
    details: 'Memory usage within normal parameters (347MB)',
    critical: false
  },
  {
    id: 'tooltip-system',
    name: 'Tooltip System Performance',
    description: 'Check for infinite loops in tooltip components',
    category: 'ui',
    status: 'warning',
    lastRun: new Date(),
    duration: 150,
    details: 'Potential infinite loop detected in useTooltipTrigger hook',
    fix: 'Optimize tooltip dependency arrays and remove function references',
    critical: false
  },
  {
    id: 'websocket-connection',
    name: 'WebSocket Connection',
    description: 'Verify real-time communication channels',
    category: 'networking',
    status: 'failed',
    lastRun: new Date(),
    duration: 5000,
    details: 'WebSocket connection failing - network configuration issue',
    fix: 'Check Vite HMR configuration and network settings',
    critical: false
  }
];

const mockComponents: ComponentHealth[] = [
  {
    id: 'text-editor',
    name: 'Text Editor',
    status: 'healthy',
    uptime: 99.8,
    lastChecked: new Date(),
    metrics: { responseTime: 45, errorRate: 0.1, availability: 99.8 },
    issues: []
  },
  {
    id: 'typescript-compiler',
    name: 'TypeScript Compiler',
    status: 'degraded',
    uptime: 87.5,
    lastChecked: new Date(),
    metrics: { responseTime: 1250, errorRate: 12.5, availability: 87.5 },
    issues: ['Compilation errors in server routes', 'Module resolution issues']
  },
  {
    id: 'file-manager',
    name: 'File Manager',
    status: 'healthy',
    uptime: 98.9,
    lastChecked: new Date(),
    metrics: { responseTime: 120, errorRate: 1.1, availability: 98.9 },
    issues: []
  },
  {
    id: 'ai-assistant',
    name: 'AI Assistant',
    status: 'healthy',
    uptime: 95.2,
    lastChecked: new Date(),
    metrics: { responseTime: 2100, errorRate: 4.8, availability: 95.2 },
    issues: []
  },
  {
    id: 'terminal-panel',
    name: 'Terminal Panel',
    status: 'healthy',
    uptime: 99.1,
    lastChecked: new Date(),
    metrics: { responseTime: 67, errorRate: 0.9, availability: 99.1 },
    issues: []
  }
];

export default function FunctionDiagnostics() {
  const [activeTab, setActiveTab] = useState('overview');
  const [diagnosticTests, setDiagnosticTests] = useState<DiagnosticTest[]>(mockDiagnosticTests);
  const [components, setComponents] = useState<ComponentHealth[]>(mockComponents);
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const { toast } = useToast();

  const runDiagnostics = async () => {
    setIsRunningTests(true);
    
    // Simulate running diagnostic tests
    for (let i = 0; i < diagnosticTests.length; i++) {
      setDiagnosticTests(prev => prev.map((test, index) => 
        index === i ? { ...test, status: 'running' } : test
      ));
      
      // Simulate test execution time
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setDiagnosticTests(prev => prev.map((test, index) => 
        index === i ? { 
          ...test, 
          status: Math.random() > 0.3 ? 'passed' : 'warning',
          lastRun: new Date(),
          duration: Math.floor(Math.random() * 1000) + 100
        } : test
      ));
    }
    
    setIsRunningTests(false);
    toast({
      title: 'Diagnostics Complete',
      description: 'All diagnostic tests have been executed',
    });
  };

  const fixIssue = async (testId: string) => {
    const test = diagnosticTests.find(t => t.id === testId);
    if (!test || !test.fix) return;
    
    toast({
      title: 'Applying Fix',
      description: `Attempting to fix: ${test.name}`,
    });
    
    // Simulate fix application
    setTimeout(() => {
      setDiagnosticTests(prev => prev.map(t => 
        t.id === testId ? { ...t, status: 'passed', details: 'Issue has been resolved' } : t
      ));
      
      toast({
        title: 'Fix Applied',
        description: `${test.name} issue has been resolved`,
      });
    }, 2000);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':
      case 'healthy':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'warning':
      case 'degraded':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'failed':
      case 'unhealthy':
        return <Bug className="h-4 w-4 text-red-500" />;
      case 'running':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'compilation': return <Code className="h-4 w-4" />;
      case 'ui': return <Monitor className="h-4 w-4" />;
      case 'database': return <Database className="h-4 w-4" />;
      case 'api': return <Wifi className="h-4 w-4" />;
      case 'filesystem': return <FileText className="h-4 w-4" />;
      case 'performance': return <Cpu className="h-4 w-4" />;
      case 'networking': return <Network className="h-4 w-4" />;
      case 'security': return <Shield className="h-4 w-4" />;
      default: return <Settings className="h-4 w-4" />;
    }
  };

  const getOverallHealth = () => {
    const total = diagnosticTests.length;
    const passed = diagnosticTests.filter(t => t.status === 'passed').length;
    const warnings = diagnosticTests.filter(t => t.status === 'warning').length;
    const failed = diagnosticTests.filter(t => t.status === 'failed').length;
    
    return {
      score: Math.round((passed / total) * 100),
      passed,
      warnings,
      failed,
      total
    };
  };

  const filteredTests = selectedCategory === 'all' 
    ? diagnosticTests 
    : diagnosticTests.filter(t => t.category === selectedCategory);

  const categories = Array.from(new Set(diagnosticTests.map(t => t.category)));
  const health = getOverallHealth();

  return (
    <div className="w-full h-full bg-background overflow-hidden">
      <div className="border-b p-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/10 rounded-lg">
            <Activity className="h-6 w-6 text-emerald-500" />
          </div>
          <div>
            <h1 className="text-xl font-bold">Function Diagnostics</h1>
            <p className="text-sm text-muted-foreground">
              Automated testing and error detection system
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Badge variant={health.score > 80 ? "default" : health.score > 60 ? "secondary" : "destructive"}>
              {health.score}% Healthy
            </Badge>
            <Button onClick={runDiagnostics} disabled={isRunningTests}>
              <RefreshCw className={`h-4 w-4 mr-2 ${isRunningTests ? 'animate-spin' : ''}`} />
              Run Diagnostics
            </Button>
          </div>
        </div>
      </div>

      <div className="flex h-full">
        <div className="flex-1 overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
            <TabsList className="w-full justify-start border-b rounded-none h-12 bg-transparent">
              <TabsTrigger value="overview" className="gap-2">
                <Activity className="h-4 w-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="tests" className="gap-2">
                <Search className="h-4 w-4" />
                Tests
              </TabsTrigger>
              <TabsTrigger value="components" className="gap-2">
                <Monitor className="h-4 w-4" />
                Components
              </TabsTrigger>
              <TabsTrigger value="performance" className="gap-2">
                <Zap className="h-4 w-4" />
                Performance
              </TabsTrigger>
              <TabsTrigger value="fixes" className="gap-2">
                <Wrench className="h-4 w-4" />
                Auto-Fixes
              </TabsTrigger>
            </TabsList>

            <div className="p-4 h-full overflow-y-auto">
              <TabsContent value="overview" className="space-y-6 m-0">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">System Health</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{health.score}%</div>
                      <Progress value={health.score} className="mt-2" />
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                        Passed
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-green-600">{health.passed}</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-yellow-500" />
                        Warnings
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-yellow-600">{health.warnings}</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Bug className="h-4 w-4 text-red-500" />
                        Failed
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-red-600">{health.failed}</div>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Critical Issues</CardTitle>
                    <CardDescription>
                      High-priority issues that need immediate attention
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {diagnosticTests.filter(t => t.critical && t.status !== 'passed').map((test) => (
                        <Alert key={test.id}>
                          <AlertTriangle className="h-4 w-4" />
                          <AlertDescription>
                            <div className="flex items-center justify-between">
                              <div>
                                <strong>{test.name}:</strong> {test.details}
                              </div>
                              {test.fix && (
                                <Button size="sm" onClick={() => fixIssue(test.id)}>
                                  Auto-Fix
                                </Button>
                              )}
                            </div>
                          </AlertDescription>
                        </Alert>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Component Health Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {components.map((component) => (
                        <div key={component.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-3">
                            {getStatusIcon(component.status)}
                            <div>
                              <div className="font-medium">{component.name}</div>
                              <div className="text-sm text-muted-foreground">
                                {component.uptime}% uptime • {component.metrics.responseTime}ms avg response
                              </div>
                            </div>
                          </div>
                          <Badge variant={
                            component.status === 'healthy' ? 'default' :
                            component.status === 'degraded' ? 'secondary' : 'destructive'
                          }>
                            {component.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="tests" className="space-y-4 m-0">
                <div className="flex items-center gap-4">
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="px-3 py-2 border rounded-md bg-background"
                  >
                    <option value="all">All Categories</option>
                    {categories.map(category => (
                      <option key={category} value={category}>
                        {category.charAt(0).toUpperCase() + category.slice(1)}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-3">
                  {filteredTests.map((test) => (
                    <Card key={test.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              {getCategoryIcon(test.category)}
                              <h3 className="font-medium">{test.name}</h3>
                              {getStatusIcon(test.status)}
                              <Badge variant={
                                test.status === 'passed' ? 'default' :
                                test.status === 'warning' ? 'secondary' :
                                test.status === 'failed' ? 'destructive' : 'outline'
                              }>
                                {test.status}
                              </Badge>
                              {test.critical && (
                                <Badge variant="destructive">Critical</Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">
                              {test.description}
                            </p>
                            {test.details && (
                              <p className="text-sm mb-2">
                                <strong>Details:</strong> {test.details}
                              </p>
                            )}
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span>Last run: {test.lastRun.toLocaleTimeString()}</span>
                              <span>Duration: {test.duration}ms</span>
                              <span>Category: {test.category}</span>
                            </div>
                          </div>
                          <div className="ml-4">
                            {test.fix && test.status !== 'passed' && (
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => fixIssue(test.id)}
                              >
                                <Wrench className="h-4 w-4 mr-1" />
                                Fix
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="components" className="space-y-4 m-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {components.map((component) => (
                    <Card key={component.id}>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          {getStatusIcon(component.status)}
                          {component.name}
                        </CardTitle>
                        <CardDescription>
                          Last checked: {component.lastChecked.toLocaleTimeString()}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-sm">Uptime</span>
                            <span className="font-medium">{component.uptime}%</span>
                          </div>
                          <Progress value={component.uptime} />
                          
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <div className="text-muted-foreground">Response Time</div>
                              <div className="font-medium">{component.metrics.responseTime}ms</div>
                            </div>
                            <div>
                              <div className="text-muted-foreground">Error Rate</div>
                              <div className="font-medium">{component.metrics.errorRate}%</div>
                            </div>
                            <div>
                              <div className="text-muted-foreground">Availability</div>
                              <div className="font-medium">{component.metrics.availability}%</div>
                            </div>
                          </div>
                          
                          {component.issues.length > 0 && (
                            <div>
                              <div className="text-sm font-medium mb-1">Issues:</div>
                              <div className="space-y-1">
                                {component.issues.map((issue, index) => (
                                  <div key={index} className="text-xs text-muted-foreground">
                                    • {issue}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="performance" className="space-y-4 m-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Performance Metrics</CardTitle>
                    <CardDescription>
                      System performance monitoring and analysis
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <Cpu className="h-8 w-8 mx-auto mb-2 text-blue-500" />
                        <div className="text-2xl font-bold">23%</div>
                        <div className="text-sm text-muted-foreground">CPU Usage</div>
                      </div>
                      <div className="text-center">
                        <MemoryStick className="h-8 w-8 mx-auto mb-2 text-green-500" />
                        <div className="text-2xl font-bold">347MB</div>
                        <div className="text-sm text-muted-foreground">Memory Usage</div>
                      </div>
                      <div className="text-center">
                        <HardDrive className="h-8 w-8 mx-auto mb-2 text-purple-500" />
                        <div className="text-2xl font-bold">1.2GB</div>
                        <div className="text-sm text-muted-foreground">Disk Usage</div>
                      </div>
                      <div className="text-center">
                        <Network className="h-8 w-8 mx-auto mb-2 text-orange-500" />
                        <div className="text-2xl font-bold">45ms</div>
                        <div className="text-sm text-muted-foreground">Network Latency</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="fixes" className="space-y-4 m-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Automated Fixes</CardTitle>
                    <CardDescription>
                      Available automatic fixes for detected issues
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {diagnosticTests.filter(t => t.fix && t.status !== 'passed').map((test) => (
                        <div key={test.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <div className="font-medium">{test.name}</div>
                            <div className="text-sm text-muted-foreground">{test.fix}</div>
                          </div>
                          <Button onClick={() => fixIssue(test.id)}>
                            <Wrench className="h-4 w-4 mr-2" />
                            Apply Fix
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
}