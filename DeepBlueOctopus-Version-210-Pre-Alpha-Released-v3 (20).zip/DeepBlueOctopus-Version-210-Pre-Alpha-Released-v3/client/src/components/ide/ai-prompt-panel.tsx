import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Send, 
  Sparkles, 
  Code, 
  Bug, 
  FileText, 
  Zap, 
  Brain, 
  TestTube,
  Copy,
  Trash2,
  History
} from "lucide-react";

interface AIPromptPanelProps {
  className?: string;
}

interface AIMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  agent: string;
}

interface AIAgent {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  prompts: string[];
}

export default function AIPromptPanel({ className = "" }: AIPromptPanelProps) {
  const [messages, setMessages] = useState<AIMessage[]>([]);
  const [currentPrompt, setCurrentPrompt] = useState("");
  const [selectedAgent, setSelectedAgent] = useState("codecraft");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const agents: AIAgent[] = [
    {
      id: "codecraft",
      name: "CodeCraft",
      description: "General coding assistant for all programming tasks",
      icon: <Code className="w-4 h-4" />,
      color: "bg-blue-500",
      prompts: [
        "Write a function that...",
        "Optimize this code:",
        "Convert this to TypeScript:",
        "Add error handling to:",
        "Create a unit test for:"
      ]
    },
    {
      id: "bugseeker",
      name: "BugSeeker",
      description: "Specialized in finding and fixing bugs",
      icon: <Bug className="w-4 h-4" />,
      color: "bg-red-500",
      prompts: [
        "Debug this error:",
        "Why is this code failing?",
        "Find potential bugs in:",
        "Fix this compilation error:",
        "Analyze runtime issues:"
      ]
    },
    {
      id: "docmaster",
      name: "DocMaster",
      description: "Documentation and code explanation expert",
      icon: <FileText className="w-4 h-4" />,
      color: "bg-green-500",
      prompts: [
        "Document this function:",
        "Explain how this works:",
        "Write API documentation for:",
        "Create README for:",
        "Add inline comments to:"
      ]
    },
    {
      id: "speedboost",
      name: "SpeedBoost",
      description: "Performance optimization specialist",
      icon: <Zap className="w-4 h-4" />,
      color: "bg-yellow-500",
      prompts: [
        "Optimize performance of:",
        "Reduce memory usage in:",
        "Make this code faster:",
        "Analyze bottlenecks in:",
        "Improve algorithm efficiency:"
      ]
    },
    {
      id: "testcraft",
      name: "TestCraft",
      description: "Testing and quality assurance expert",
      icon: <TestTube className="w-4 h-4" />,
      color: "bg-purple-500",
      prompts: [
        "Write unit tests for:",
        "Create integration tests:",
        "Add edge case tests:",
        "Mock dependencies for:",
        "Test coverage analysis:"
      ]
    },
    {
      id: "architectai",
      name: "ArchitectAI",
      description: "Software architecture and design patterns",
      icon: <Brain className="w-4 h-4" />,
      color: "bg-indigo-500",
      prompts: [
        "Design architecture for:",
        "Suggest design pattern for:",
        "Refactor to clean architecture:",
        "Database schema design:",
        "API design recommendations:"
      ]
    }
  ];

  const currentAgent = agents.find(agent => agent.id === selectedAgent) || agents[0];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendPrompt = async () => {
    if (!currentPrompt.trim() || isProcessing) return;

    const userMessage: AIMessage = {
      id: `user-${Date.now()}`,
      type: 'user',
      content: currentPrompt,
      timestamp: new Date(),
      agent: selectedAgent
    };

    setMessages(prev => [...prev, userMessage]);
    const messageContent = currentPrompt;
    setCurrentPrompt("");
    setIsProcessing(true);

    try {
      // Create agent-specific prompts
      const agentPrompt = `As ${currentAgent.name} (${currentAgent.description}): ${messageContent}`;
      
      // Determine if this is a code-related request
      const isCodeRequest = messageContent.toLowerCase().includes('code') || 
                           messageContent.toLowerCase().includes('function') ||
                           messageContent.toLowerCase().includes('write') ||
                           messageContent.toLowerCase().includes('create') ||
                           selectedAgent === 'codecraft' ||
                           selectedAgent === 'testcraft';

      let response: Response;

      if (isCodeRequest && (selectedAgent === 'codecraft' || selectedAgent === 'testcraft')) {
        // Use code generation API for code creation requests
        response = await fetch('/api/openai/generate-code', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: messageContent,
            language: 'javascript', // Default language
            context: `Agent: ${currentAgent.name} - ${currentAgent.description}`,
            includeComments: true
          })
        });
      } else {
        // Use chat completion for general queries
        response = await fetch('/api/openai/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: agentPrompt,
            context: `This is a conversation with ${currentAgent.name} in the DeepBlue IDE AI prompt panel.`
          })
        });
      }

      if (!response.ok) {
        throw new Error(`API call failed: ${response.statusText}`);
      }

      const result = await response.json();
      
      const assistantMessage: AIMessage = {
        id: `assistant-${Date.now()}`,
        type: 'assistant',
        content: `[${currentAgent.name}] ${result.content || result.codeSnippet || 'I received your request but encountered an issue processing it.'}`,
        timestamp: new Date(),
        agent: selectedAgent
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('AI Prompt Panel error:', error);
      
      const errorMessage: AIMessage = {
        id: `assistant-${Date.now()}`,
        type: 'assistant',
        content: `[${currentAgent.name}] I encountered an error: ${error instanceof Error ? error.message : 'Unknown error'}. Please check your OpenAI API configuration.`,
        timestamp: new Date(),
        agent: selectedAgent
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendPrompt();
    }
  };

  const clearChat = () => {
    setMessages([]);
  };

  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
  };

  const insertPromptTemplate = (template: string) => {
    setCurrentPrompt(template);
    textareaRef.current?.focus();
  };

  return (
    <div className={`flex flex-col h-full ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-[var(--ide-border)]">
        <div className="flex items-center space-x-2">
          <Sparkles className="w-5 h-5 text-[var(--ide-accent)]" />
          <h3 className="text-sm font-medium text-[var(--ide-text)]">AI Assistant</h3>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowHistory(!showHistory)}
            className="text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)]"
          >
            <History className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearChat}
            className="text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)]"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Agent Selection */}
      <div className="p-3 border-b border-[var(--ide-border)]">
        <Select value={selectedAgent} onValueChange={setSelectedAgent}>
          <SelectTrigger className="w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {agents.map((agent) => (
              <SelectItem key={agent.id} value={agent.id}>
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${agent.color}`} />
                  <span>{agent.name}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <p className="text-xs text-[var(--ide-text-secondary)] mt-1">
          {currentAgent.description}
        </p>
      </div>

      {/* Quick Prompts */}
      <div className="p-3 border-b border-[var(--ide-border)]">
        <div className="text-xs text-[var(--ide-text-secondary)] mb-2">Quick Prompts:</div>
        <div className="flex flex-wrap gap-1">
          {currentAgent.prompts.slice(0, 3).map((prompt, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              onClick={() => insertPromptTemplate(prompt)}
              className="text-xs h-6 px-2"
            >
              {prompt}
            </Button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-3">
        <div className="space-y-3">
          {messages.length === 0 && (
            <div className="text-center text-[var(--ide-text-secondary)] text-sm py-8">
              <Sparkles className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>Start a conversation with your AI assistant!</p>
              <p className="text-xs mt-1">Choose an agent and ask a question</p>
            </div>
          )}
          
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] rounded-lg p-3 ${
                message.type === 'user' 
                  ? 'bg-[var(--ide-accent)] text-white' 
                  : 'bg-[var(--ide-bg-secondary)] text-[var(--ide-text)]'
              }`}>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center space-x-2">
                    {message.type === 'assistant' && (
                      <>
                        <div className={`w-2 h-2 rounded-full ${currentAgent.color}`} />
                        <span className="text-xs font-medium">{currentAgent.name}</span>
                      </>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyMessage(message.content)}
                    className="w-4 h-4 p-0 opacity-50 hover:opacity-100"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                <p className="text-xs opacity-70 mt-1">
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </div>
            </div>
          ))}
          
          {isProcessing && (
            <div className="flex justify-start">
              <div className="bg-[var(--ide-bg-secondary)] rounded-lg p-3 max-w-[80%]">
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${currentAgent.color}`} />
                  <span className="text-xs font-medium">{currentAgent.name}</span>
                </div>
                <div className="flex items-center space-x-2 mt-2">
                  <div className="w-2 h-2 bg-[var(--ide-accent)] rounded-full animate-pulse" />
                  <div className="w-2 h-2 bg-[var(--ide-accent)] rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                  <div className="w-2 h-2 bg-[var(--ide-accent)] rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
                  <span className="text-xs text-[var(--ide-text-secondary)]">Thinking...</span>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="p-3 border-t border-[var(--ide-border)]">
        <div className="flex space-x-2">
          <Textarea
            ref={textareaRef}
            value={currentPrompt}
            onChange={(e) => setCurrentPrompt(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={`Ask ${currentAgent.name} anything...`}
            className="min-h-[40px] max-h-[120px] resize-none"
            disabled={isProcessing}
          />
          <Button
            onClick={handleSendPrompt}
            disabled={!currentPrompt.trim() || isProcessing}
            className="px-3"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex items-center justify-between mt-2 text-xs text-[var(--ide-text-secondary)]">
          <span>Press Enter to send, Shift+Enter for new line</span>
          <Badge variant="outline" className="text-xs">
            {currentAgent.name}
          </Badge>
        </div>
      </div>
    </div>
  );
}