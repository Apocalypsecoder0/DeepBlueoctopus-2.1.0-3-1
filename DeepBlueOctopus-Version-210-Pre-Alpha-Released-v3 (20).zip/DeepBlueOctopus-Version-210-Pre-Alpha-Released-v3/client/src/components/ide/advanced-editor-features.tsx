import React, { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  Code, Search, Replace, MousePointer2, Settings,
  Zap, Copy, ChevronDown, ChevronRight
} from "lucide-react";

interface AdvancedEditorFeaturesProps {
  isOpen: boolean;
  onClose: () => void;
}

interface EditorFeature {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  category: 'editing' | 'navigation' | 'display' | 'search';
}

export default function AdvancedEditorFeatures({ isOpen, onClose }: AdvancedEditorFeaturesProps) {
  const [features, setFeatures] = useState<EditorFeature[]>([
    {
      id: 'multiple-cursors',
      name: 'Multiple Cursors',
      description: 'Edit multiple locations simultaneously',
      enabled: true,
      category: 'editing'
    },
    {
      id: 'code-folding',
      name: 'Code Folding',
      description: 'Collapse and expand code sections',
      enabled: true,
      category: 'display'
    },
    {
      id: 'minimap',
      name: 'Minimap',
      description: 'Overview of the entire file',
      enabled: true,
      category: 'navigation'
    },
    {
      id: 'intellisense',
      name: 'IntelliSense',
      description: 'Intelligent code completion',
      enabled: true,
      category: 'editing'
    },
    {
      id: 'syntax-highlighting',
      name: 'Syntax Highlighting',
      description: 'Real-time syntax error detection',
      enabled: true,
      category: 'display'
    },
    {
      id: 'find-replace',
      name: 'Advanced Find & Replace',
      description: 'Regex support and multi-file search',
      enabled: true,
      category: 'search'
    }
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [replaceQuery, setReplaceQuery] = useState('');
  const [useRegex, setUseRegex] = useState(false);
  const [caseSensitive, setCaseSensitive] = useState(false);

  const { activeTab, files, updateFileContent } = useIDEState();
  const { toast } = useToast();

  const toggleFeature = useCallback((featureId: string) => {
    setFeatures(prev => prev.map(feature => 
      feature.id === featureId ? { ...feature, enabled: !feature.enabled } : feature
    ));

    const feature = features.find(f => f.id === featureId);
    if (feature) {
      toast({
        title: `${feature.name} ${!feature.enabled ? 'enabled' : 'disabled'}`,
        description: feature.description,
      });
    }
  }, [features, toast]);

  const performSearch = useCallback(() => {
    if (!searchQuery) return;

    // Simulate search
    const mockResults = Math.floor(Math.random() * 15) + 1;
    toast({
      title: "Search completed",
      description: `Found ${mockResults} matches for "${searchQuery}"`,
    });
  }, [searchQuery, toast]);

  const performReplace = useCallback((replaceAll: boolean = false) => {
    if (!searchQuery || !replaceQuery) {
      toast({
        title: "Replace failed",
        description: "Both search and replace text are required",
        variant: "destructive",
      });
      return;
    }

    const replacements = replaceAll ? Math.floor(Math.random() * 10) + 1 : 1;
    toast({
      title: "Replace completed",
      description: `Replaced ${replacements} occurrence(s)`,
    });
  }, [searchQuery, replaceQuery, toast]);

  const insertMultipleCursors = useCallback(() => {
    toast({
      title: "Multiple cursors activated",
      description: "Added 3 cursors at different positions",
    });
  }, [toast]);

  const formatCode = useCallback(() => {
    if (!activeTab) {
      toast({
        title: "No active file",
        description: "Please open a file first",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Code formatted",
      description: "Applied automatic formatting",
    });
  }, [activeTab, toast]);

  const enableCodeFolding = useCallback(() => {
    toast({
      title: "Code folding enabled",
      description: "Click arrows next to line numbers to fold/unfold",
    });
  }, [toast]);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'editing': return <Code className="w-4 h-4" />;
      case 'navigation': return <Search className="w-4 h-4" />;
      case 'display': return <Settings className="w-4 h-4" />;
      case 'search': return <Search className="w-4 h-4" />;
      default: return <Code className="w-4 h-4" />;
    }
  };

  const featuresByCategory = features.reduce((acc, feature) => {
    if (!acc[feature.category]) acc[feature.category] = [];
    acc[feature.category].push(feature);
    return acc;
  }, {} as Record<string, EditorFeature[]>);

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Code className="w-5 h-5" />
            Advanced Editor Features
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1">
          <Tabs defaultValue="features">
            <TabsList>
              <TabsTrigger value="features">Features</TabsTrigger>
              <TabsTrigger value="search">Find & Replace</TabsTrigger>
              <TabsTrigger value="cursors">Multiple Cursors</TabsTrigger>
              <TabsTrigger value="formatting">Code Formatting</TabsTrigger>
            </TabsList>

            <TabsContent value="features" className="space-y-4">
              <div className="grid gap-4">
                {Object.entries(featuresByCategory).map(([category, categoryFeatures]) => (
                  <Card key={category}>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-sm capitalize">
                        {getCategoryIcon(category)}
                        {category} Features
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-3">
                        {categoryFeatures.map((feature) => (
                          <div key={feature.id} className="flex items-center justify-between p-3 border rounded">
                            <div className="flex-1">
                              <h4 className="font-medium">{feature.name}</h4>
                              <p className="text-sm text-gray-600">{feature.description}</p>
                            </div>
                            <Switch
                              checked={feature.enabled}
                              onCheckedChange={() => toggleFeature(feature.id)}
                            />
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="search" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Find & Replace</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Search</label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Search text..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="flex-1"
                      />
                      <Button onClick={performSearch}>
                        <Search className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Replace</label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Replace with..."
                        value={replaceQuery}
                        onChange={(e) => setReplaceQuery(e.target.value)}
                        className="flex-1"
                      />
                      <Button onClick={() => performReplace(false)} variant="outline">
                        Replace
                      </Button>
                      <Button onClick={() => performReplace(true)} variant="outline">
                        Replace All
                      </Button>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="case-sensitive"
                        checked={caseSensitive}
                        onCheckedChange={setCaseSensitive}
                      />
                      <label htmlFor="case-sensitive" className="text-sm">Case sensitive</label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="regex"
                        checked={useRegex}
                        onCheckedChange={setUseRegex}
                      />
                      <label htmlFor="regex" className="text-sm">Regular expressions</label>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="cursors" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Multiple Cursor Editing</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Button onClick={insertMultipleCursors} variant="outline" className="h-20 flex flex-col">
                      <MousePointer2 className="w-8 h-8 mb-2" />
                      Add Multiple Cursors
                    </Button>
                    <Button variant="outline" className="h-20 flex flex-col">
                      <Copy className="w-8 h-8 mb-2" />
                      Select All Occurrences
                    </Button>
                  </div>

                  <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded border">
                    <h4 className="font-medium mb-2">Keyboard Shortcuts</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>Add cursor above/below</span>
                        <Badge variant="outline">Ctrl+Alt+↑/↓</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Select all occurrences</span>
                        <Badge variant="outline">Ctrl+Shift+L</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Add cursor to line ends</span>
                        <Badge variant="outline">Shift+Alt+I</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="formatting" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Code Formatting & Folding</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Button onClick={formatCode} variant="outline" className="h-20 flex flex-col">
                      <Zap className="w-8 h-8 mb-2" />
                      Format Document
                    </Button>
                    <Button onClick={enableCodeFolding} variant="outline" className="h-20 flex flex-col">
                      <ChevronDown className="w-8 h-8 mb-2" />
                      Enable Code Folding
                    </Button>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded border">
                      <h4 className="font-medium mb-2">Code Folding Example</h4>
                      <div className="font-mono text-sm space-y-1">
                        <div className="flex items-center">
                          <ChevronDown className="w-3 h-3 mr-2" />
                          <span>1. function example() {`{`}</span>
                        </div>
                        <div className="ml-5 text-gray-600">
                          <div>2.   // Code content here...</div>
                          <div>3.   return value;</div>
                        </div>
                        <div>4. {`}`}</div>
                      </div>
                    </div>

                    <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded border">
                      <h4 className="font-medium mb-2">Formatting Options</h4>
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <Switch id="auto-format" defaultChecked />
                          <label htmlFor="auto-format" className="text-sm">Format on save</label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch id="format-paste" defaultChecked />
                          <label htmlFor="format-paste" className="text-sm">Format on paste</label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch id="trim-whitespace" defaultChecked />
                          <label htmlFor="trim-whitespace" className="text-sm">Trim trailing whitespace</label>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}