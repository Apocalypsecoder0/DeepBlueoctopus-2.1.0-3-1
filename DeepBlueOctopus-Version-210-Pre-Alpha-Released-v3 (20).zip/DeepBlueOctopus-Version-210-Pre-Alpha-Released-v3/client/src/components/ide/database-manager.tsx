import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { 
  Database, 
  Table, 
  Play, 
  Plus, 
  Edit, 
  Trash2, 
  Download, 
  Upload, 
  Search,
  Server,
  Key,
  Users,
  BarChart3,
  Settings,
  RefreshCw,
  Eye,
  EyeOff,
  CheckCircle,
  XCircle,
  Clock,
  HardDrive
} from "lucide-react";

interface DatabaseManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface DatabaseConnection {
  id: string;
  name: string;
  type: 'postgresql' | 'mysql' | 'sqlite' | 'mongodb';
  host: string;
  port: number;
  database: string;
  username: string;
  status: 'connected' | 'disconnected' | 'error';
  lastConnection?: string;
}

interface TableInfo {
  name: string;
  rows: number;
  size: string;
  created: string;
  schema: string;
}

interface QueryResult {
  columns: string[];
  data: any[][];
  executionTime: number;
  rowCount: number;
}

export default function DatabaseManager({ isOpen, onClose }: DatabaseManagerProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('connections');
  const [connections, setConnections] = useState<DatabaseConnection[]>([]);
  const [activeConnection, setActiveConnection] = useState<string | null>(null);
  const [tables, setTables] = useState<TableInfo[]>([]);
  const [queryText, setQueryText] = useState('');
  const [queryResult, setQueryResult] = useState<QueryResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [newConnection, setNewConnection] = useState({
    name: '',
    type: 'postgresql' as DatabaseConnection['type'],
    host: 'localhost',
    port: 5432,
    database: '',
    username: '',
    password: ''
  });

  useEffect(() => {
    if (isOpen) {
      loadConnections();
    }
  }, [isOpen]);

  const loadConnections = async () => {
    try {
      const response = await fetch('/api/database/connections');
      const data = await response.json();
      setConnections(data);
    } catch (error) {
      console.error('Failed to load connections:', error);
      // Load sample connections
      setConnections([
        {
          id: 'conn-1',
          name: 'Production Database',
          type: 'postgresql',
          host: 'localhost',
          port: 5432,
          database: 'deepblue_ide',
          username: 'postgres',
          status: 'connected',
          lastConnection: '2025-01-01T12:00:00Z'
        },
        {
          id: 'conn-2',
          name: 'Development DB',
          type: 'postgresql',
          host: 'dev.example.com',
          port: 5432,
          database: 'dev_db',
          username: 'dev_user',
          status: 'disconnected',
          lastConnection: '2024-12-30T10:30:00Z'
        }
      ]);
    }
  };

  const connectToDatabase = async (connectionId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/database/connect/${connectionId}`, {
        method: 'POST'
      });
      
      if (response.ok) {
        await loadConnections();
        setActiveConnection(connectionId);
        await loadTables(connectionId);
        
        toast({
          title: "Connected",
          description: "Successfully connected to database.",
        });
      }
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: "Failed to connect to database.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const loadTables = async (connectionId: string) => {
    try {
      const response = await fetch(`/api/database/${connectionId}/tables`);
      const data = await response.json();
      setTables(data);
    } catch (error) {
      console.error('Failed to load tables:', error);
      // Load sample tables
      setTables([
        { name: 'users', rows: 1250, size: '2.5 MB', created: '2024-12-01', schema: 'public' },
        { name: 'projects', rows: 340, size: '1.2 MB', created: '2024-12-05', schema: 'public' },
        { name: 'files', rows: 5680, size: '45.8 MB', created: '2024-12-10', schema: 'public' },
        { name: 'sessions', rows: 89, size: '512 KB', created: '2024-12-15', schema: 'public' }
      ]);
    }
  };

  const executeQuery = async () => {
    if (!queryText.trim() || !activeConnection) {
      toast({
        title: "Error",
        description: "Please enter a query and select a connection.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/database/${activeConnection}/query`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query: queryText })
      });
      
      if (response.ok) {
        const result = await response.json();
        setQueryResult(result);
        
        toast({
          title: "Query Executed",
          description: `Returned ${result.rowCount} rows in ${result.executionTime}ms`,
        });
      }
    } catch (error) {
      // Simulate query result for demo
      const sampleResult = {
        columns: ['id', 'name', 'email', 'created_at'],
        data: [
          [1, 'John Doe', 'john@example.com', '2024-12-01T10:00:00Z'],
          [2, 'Jane Smith', 'jane@example.com', '2024-12-02T11:00:00Z'],
          [3, 'Bob Johnson', 'bob@example.com', '2024-12-03T12:00:00Z']
        ],
        executionTime: 45,
        rowCount: 3
      };
      
      setQueryResult(sampleResult);
      
      toast({
        title: "Query Executed",
        description: `Returned ${sampleResult.rowCount} rows in ${sampleResult.executionTime}ms`,
      });
    } finally {
      setLoading(false);
    }
  };

  const createConnection = async () => {
    if (!newConnection.name || !newConnection.database) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/database/connections', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newConnection)
      });
      
      if (response.ok) {
        await loadConnections();
        setNewConnection({
          name: '',
          type: 'postgresql',
          host: 'localhost',
          port: 5432,
          database: '',
          username: '',
          password: ''
        });
        
        toast({
          title: "Connection Created",
          description: "Database connection created successfully.",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create connection.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: DatabaseConnection['status']) => {
    switch (status) {
      case 'connected': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'disconnected': return <XCircle className="w-4 h-4 text-gray-400" />;
      case 'error': return <XCircle className="w-4 h-4 text-red-400" />;
      default: return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getDatabaseIcon = (type: DatabaseConnection['type']) => {
    switch (type) {
      case 'postgresql': return <Database className="w-4 h-4 text-blue-400" />;
      case 'mysql': return <Database className="w-4 h-4 text-orange-400" />;
      case 'sqlite': return <HardDrive className="w-4 h-4 text-gray-400" />;
      case 'mongodb': return <Server className="w-4 h-4 text-green-400" />;
      default: return <Database className="w-4 h-4" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[95vh] bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <Database className="w-5 h-5" />
            Database Manager
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-5 bg-slate-800">
            <TabsTrigger value="connections">Connections</TabsTrigger>
            <TabsTrigger value="tables">Tables</TabsTrigger>
            <TabsTrigger value="query">Query Editor</TabsTrigger>
            <TabsTrigger value="backup">Backup/Restore</TabsTrigger>
            <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
          </TabsList>

          <TabsContent value="connections" className="flex-1">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
              {/* Existing Connections */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white">Database Connections</h3>
                  <Button
                    onClick={loadConnections}
                    variant="outline"
                    size="sm"
                    disabled={loading}
                  >
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                </div>
                
                <ScrollArea className="h-[500px]">
                  <div className="space-y-3">
                    {connections.map((conn) => (
                      <Card key={conn.id} className="bg-slate-800 border-slate-700">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {getDatabaseIcon(conn.type)}
                              <span className="font-medium text-white">{conn.name}</span>
                            </div>
                            {getStatusIcon(conn.status)}
                          </div>
                          
                          <div className="text-sm text-slate-400 space-y-1">
                            <p>{conn.type.toUpperCase()} • {conn.host}:{conn.port}</p>
                            <p>Database: {conn.database}</p>
                            <p>User: {conn.username}</p>
                            {conn.lastConnection && (
                              <p>Last: {new Date(conn.lastConnection).toLocaleString()}</p>
                            )}
                          </div>
                          
                          <div className="flex gap-2 mt-3">
                            <Button
                              onClick={() => connectToDatabase(conn.id)}
                              disabled={loading || conn.status === 'connected'}
                              size="sm"
                              className="bg-blue-600 hover:bg-blue-700"
                            >
                              {conn.status === 'connected' ? 'Connected' : 'Connect'}
                            </Button>
                            <Button variant="outline" size="sm">
                              <Edit className="w-3 h-3" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </div>

              {/* New Connection Form */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Create New Connection</h3>
                
                <Card className="bg-slate-800 border-slate-700">
                  <CardContent className="p-4 space-y-4">
                    <div>
                      <Label htmlFor="conn-name" className="text-white">Connection Name</Label>
                      <Input
                        id="conn-name"
                        value={newConnection.name}
                        onChange={(e) => setNewConnection({...newConnection, name: e.target.value})}
                        className="bg-slate-700 border-slate-600 text-white"
                        placeholder="Production Database"
                      />
                    </div>

                    <div>
                      <Label htmlFor="conn-type" className="text-white">Database Type</Label>
                      <select
                        id="conn-type"
                        value={newConnection.type}
                        onChange={(e) => setNewConnection({...newConnection, type: e.target.value as DatabaseConnection['type']})}
                        className="w-full bg-slate-700 border-slate-600 text-white rounded px-3 py-2"
                      >
                        <option value="postgresql">PostgreSQL</option>
                        <option value="mysql">MySQL</option>
                        <option value="sqlite">SQLite</option>
                        <option value="mongodb">MongoDB</option>
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="conn-host" className="text-white">Host</Label>
                        <Input
                          id="conn-host"
                          value={newConnection.host}
                          onChange={(e) => setNewConnection({...newConnection, host: e.target.value})}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                      <div>
                        <Label htmlFor="conn-port" className="text-white">Port</Label>
                        <Input
                          id="conn-port"
                          type="number"
                          value={newConnection.port}
                          onChange={(e) => setNewConnection({...newConnection, port: Number(e.target.value)})}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="conn-database" className="text-white">Database</Label>
                      <Input
                        id="conn-database"
                        value={newConnection.database}
                        onChange={(e) => setNewConnection({...newConnection, database: e.target.value})}
                        className="bg-slate-700 border-slate-600 text-white"
                        placeholder="database_name"
                      />
                    </div>

                    <div>
                      <Label htmlFor="conn-username" className="text-white">Username</Label>
                      <Input
                        id="conn-username"
                        value={newConnection.username}
                        onChange={(e) => setNewConnection({...newConnection, username: e.target.value})}
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>

                    <div>
                      <Label htmlFor="conn-password" className="text-white">Password</Label>
                      <div className="flex gap-2">
                        <Input
                          id="conn-password"
                          type={showPassword ? "text" : "password"}
                          value={newConnection.password}
                          onChange={(e) => setNewConnection({...newConnection, password: e.target.value})}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </Button>
                      </div>
                    </div>

                    <Button
                      onClick={createConnection}
                      disabled={loading}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                      Create Connection
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="tables" className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Database Tables</h3>
              {activeConnection && (
                <Badge className="bg-green-600">
                  Connected: {connections.find(c => c.id === activeConnection)?.name}
                </Badge>
              )}
            </div>

            {activeConnection ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {tables.map((table) => (
                  <Card key={table.name} className="bg-slate-800 border-slate-700">
                    <CardHeader className="pb-3">
                      <div className="flex items-center gap-2">
                        <Table className="w-4 h-4 text-blue-400" />
                        <CardTitle className="text-sm text-white">{table.name}</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-400">Rows:</span>
                        <span className="text-white">{table.rows.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-400">Size:</span>
                        <span className="text-white">{table.size}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-400">Created:</span>
                        <span className="text-white">{table.created}</span>
                      </div>
                      <div className="flex gap-2 mt-3">
                        <Button size="sm" variant="outline">
                          <Eye className="w-3 h-3" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="w-3 h-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="flex items-center justify-center h-64">
                <p className="text-slate-400">Connect to a database to view tables</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="query" className="flex-1 flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">SQL Query Editor</h3>
              <Button
                onClick={executeQuery}
                disabled={loading || !activeConnection}
                className="bg-green-600 hover:bg-green-700"
              >
                <Play className="w-4 h-4 mr-2" />
                Execute Query
              </Button>
            </div>

            <div className="flex-1 grid grid-rows-2 gap-4">
              <div>
                <Label htmlFor="query-editor" className="text-white mb-2 block">Query</Label>
                <Textarea
                  id="query-editor"
                  value={queryText}
                  onChange={(e) => setQueryText(e.target.value)}
                  className="h-full bg-slate-800 border-slate-600 text-white font-mono"
                  placeholder="SELECT * FROM users WHERE created_at > '2024-01-01';"
                />
              </div>

              <div>
                <Label className="text-white mb-2 block">Results</Label>
                <div className="bg-slate-800 border border-slate-600 rounded h-full overflow-auto">
                  {queryResult ? (
                    <div className="p-4">
                      <div className="mb-2 text-sm text-slate-400">
                        {queryResult.rowCount} rows returned in {queryResult.executionTime}ms
                      </div>
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b border-slate-600">
                            {queryResult.columns.map((col, idx) => (
                              <th key={idx} className="text-left p-2 text-white font-medium">
                                {col}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {queryResult.data.map((row, idx) => (
                            <tr key={idx} className="border-b border-slate-700">
                              {row.map((cell, cellIdx) => (
                                <td key={cellIdx} className="p-2 text-slate-300">
                                  {cell?.toString() || 'NULL'}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center h-full">
                      <p className="text-slate-400">Execute a query to see results</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="backup" className="flex-1">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Download className="w-4 h-4" />
                    Backup Database
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400">Create a backup of your database</p>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Create Backup
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Upload className="w-4 h-4" />
                    Restore Database
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400">Restore from a backup file</p>
                  <Button className="w-full bg-orange-600 hover:bg-orange-700">
                    Select Backup File
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="monitoring" className="flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <BarChart3 className="w-4 h-4 text-blue-400" />
                    <span className="text-sm font-medium text-white">Active Connections</span>
                  </div>
                  <p className="text-2xl font-bold text-white">12</p>
                  <p className="text-xs text-slate-400">Max: 100</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-4 h-4 text-green-400" />
                    <span className="text-sm font-medium text-white">Avg Query Time</span>
                  </div>
                  <p className="text-2xl font-bold text-white">45ms</p>
                  <p className="text-xs text-slate-400">Last hour</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <HardDrive className="w-4 h-4 text-yellow-400" />
                    <span className="text-sm font-medium text-white">Database Size</span>
                  </div>
                  <p className="text-2xl font-bold text-white">2.4GB</p>
                  <p className="text-xs text-slate-400">+12% this week</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span className="text-sm font-medium text-white">Health Status</span>
                  </div>
                  <p className="text-2xl font-bold text-green-400">Healthy</p>
                  <p className="text-xs text-slate-400">All systems operational</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}