import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Navigation, 
  Search, 
  Target, 
  FileText, 
  Hash, 
  Code2, 
  ArrowRight,
  MapPin,
  Zap,
  BookOpen,
  Link,
  ExternalLink
} from "lucide-react";

interface CodeNavigationProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Symbol {
  name: string;
  type: 'function' | 'class' | 'variable' | 'interface' | 'type';
  file: string;
  line: number;
  column: number;
  description?: string;
  parameters?: string[];
  returnType?: string;
}

interface Reference {
  file: string;
  line: number;
  column: number;
  context: string;
  type: 'definition' | 'usage' | 'import';
}

interface NavigationHistory {
  file: string;
  line: number;
  column: number;
  timestamp: Date;
  action: string;
}

export default function CodeNavigation({ isOpen, onClose }: CodeNavigationProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [symbols, setSymbols] = useState<Symbol[]>([
    {
      name: 'fibonacci',
      type: 'function',
      file: 'math-utils.ts',
      line: 15,
      column: 10,
      description: 'Calculates fibonacci sequence up to n',
      parameters: ['n: number'],
      returnType: 'number'
    },
    {
      name: 'UserInterface',
      type: 'interface',
      file: 'types.ts',
      line: 5,
      column: 1,
      description: 'User object interface definition'
    },
    {
      name: 'processUsers',
      type: 'function',
      file: 'user-service.ts',
      line: 22,
      column: 8,
      parameters: ['users: User[]'],
      returnType: 'ProcessedUser[]'
    },
    {
      name: 'ApiClient',
      type: 'class',
      file: 'api-client.ts',
      line: 10,
      column: 7,
      description: 'HTTP API client wrapper'
    },
    {
      name: 'CONFIG',
      type: 'variable',
      file: 'config.ts',
      line: 3,
      column: 7,
      description: 'Application configuration object'
    }
  ]);

  const [references, setReferences] = useState<Reference[]>([
    {
      file: 'main.ts',
      line: 8,
      column: 12,
      context: 'const result = fibonacci(10);',
      type: 'usage'
    },
    {
      file: 'test.spec.ts',
      line: 15,
      column: 25,
      context: 'expect(fibonacci(5)).toBe(5);',
      type: 'usage'
    },
    {
      file: 'math-utils.ts',
      line: 1,
      column: 1,
      context: 'export function fibonacci(n: number)',
      type: 'definition'
    }
  ]);

  const [navigationHistory, setNavigationHistory] = useState<NavigationHistory[]>([
    {
      file: 'main.ts',
      line: 1,
      column: 1,
      timestamp: new Date(Date.now() - 300000),
      action: 'File opened'
    },
    {
      file: 'types.ts',
      line: 5,
      column: 1,
      timestamp: new Date(Date.now() - 240000),
      action: 'Go to definition'
    },
    {
      file: 'user-service.ts',
      line: 22,
      column: 8,
      timestamp: new Date(Date.now() - 180000),
      action: 'Find references'
    },
    {
      file: 'api-client.ts',
      line: 10,
      column: 7,
      timestamp: new Date(Date.now() - 120000),
      action: 'Symbol search'
    }
  ]);

  const [quickAccess, setQuickAccess] = useState({
    recentFiles: [
      { name: 'main.ts', path: 'src/main.ts', lastAccessed: '2 minutes ago' },
      { name: 'types.ts', path: 'src/types.ts', lastAccessed: '5 minutes ago' },
      { name: 'user-service.ts', path: 'src/user-service.ts', lastAccessed: '8 minutes ago' },
      { name: 'api-client.ts', path: 'src/api-client.ts', lastAccessed: '12 minutes ago' }
    ],
    bookmarks: [
      { name: 'Main App Component', file: 'App.tsx', line: 25 },
      { name: 'API Configuration', file: 'config.ts', line: 15 },
      { name: 'Error Handler', file: 'error-handler.ts', line: 8 }
    ]
  });

  const filteredSymbols = symbols.filter(symbol =>
    symbol.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    symbol.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
    symbol.file.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const navigateToDefinition = (symbol: Symbol) => {
    const newHistoryEntry: NavigationHistory = {
      file: symbol.file,
      line: symbol.line,
      column: symbol.column,
      timestamp: new Date(),
      action: `Go to ${symbol.type}: ${symbol.name}`
    };
    setNavigationHistory(prev => [newHistoryEntry, ...prev.slice(0, 19)]);
  };

  const findReferences = (symbolName: string) => {
    // Simulate finding references
    const mockReferences: Reference[] = [
      {
        file: 'main.ts',
        line: Math.floor(Math.random() * 50) + 1,
        column: Math.floor(Math.random() * 20) + 1,
        context: `${symbolName}()`,
        type: 'usage'
      },
      {
        file: 'test.spec.ts',
        line: Math.floor(Math.random() * 30) + 1,
        column: Math.floor(Math.random() * 15) + 1,
        context: `expect(${symbolName}).toBeDefined()`,
        type: 'usage'
      }
    ];
    setReferences(mockReferences);
  };

  const getTypeIcon = (type: Symbol['type']) => {
    switch (type) {
      case 'function': return <Code2 className="h-3 w-3" />;
      case 'class': return <Hash className="h-3 w-3" />;
      case 'interface': return <FileText className="h-3 w-3" />;
      case 'variable': return <Target className="h-3 w-3" />;
      case 'type': return <BookOpen className="h-3 w-3" />;
      default: return <Code2 className="h-3 w-3" />;
    }
  };

  const getTypeColor = (type: Symbol['type']) => {
    switch (type) {
      case 'function': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'class': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'interface': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      case 'variable': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      case 'type': return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="w-[95vw] h-[95vh] bg-background rounded-lg border shadow-lg relative">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-2">
            <Navigation className="h-6 w-6 text-blue-500" />
            <div>
              <h2 className="text-xl font-bold">Code Navigation</h2>
              <p className="text-sm text-muted-foreground">Go to definition, find references, and symbol search</p>
            </div>
          </div>
          <Button onClick={onClose} variant="outline" size="sm">
            Close
          </Button>
        </div>

        <div className="flex h-[calc(100%-80px)]">
          <div className="flex-1 p-4 overflow-auto">
            <Tabs defaultValue="symbols" className="h-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="symbols">Symbol Search</TabsTrigger>
                <TabsTrigger value="references">Find References</TabsTrigger>
                <TabsTrigger value="history">Navigation History</TabsTrigger>
                <TabsTrigger value="quick">Quick Access</TabsTrigger>
              </TabsList>

              <TabsContent value="symbols" className="space-y-4">
                {/* Search Bar */}
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search symbols, functions, classes..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Button variant="outline">
                    Advanced
                  </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {/* Symbol Results */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Hash className="h-4 w-4" />
                        Symbols ({filteredSymbols.length})
                      </CardTitle>
                      <CardDescription>
                        Functions, classes, interfaces, and variables
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-96">
                        <div className="space-y-2">
                          {filteredSymbols.map((symbol, index) => (
                            <div 
                              key={index}
                              className="p-3 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                              onClick={() => navigateToDefinition(symbol)}
                            >
                              <div className="flex items-start justify-between">
                                <div className="flex items-center gap-2">
                                  {getTypeIcon(symbol.type)}
                                  <div>
                                    <div className="font-medium">{symbol.name}</div>
                                    <div className="text-sm text-muted-foreground">
                                      {symbol.file}:{symbol.line}:{symbol.column}
                                    </div>
                                    {symbol.description && (
                                      <div className="text-xs text-muted-foreground mt-1">
                                        {symbol.description}
                                      </div>
                                    )}
                                  </div>
                                </div>
                                <div className="flex flex-col items-end gap-1">
                                  <Badge className={getTypeColor(symbol.type)}>
                                    {symbol.type}
                                  </Badge>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      findReferences(symbol.name);
                                    }}
                                    className="h-6 text-xs"
                                  >
                                    Find Refs
                                  </Button>
                                </div>
                              </div>
                              
                              {symbol.parameters && (
                                <div className="mt-2 text-xs font-mono bg-muted p-2 rounded">
                                  {symbol.name}({symbol.parameters.join(', ')})
                                  {symbol.returnType && `: ${symbol.returnType}`}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>

                  {/* Symbol Details */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Target className="h-4 w-4" />
                        Symbol Details
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {filteredSymbols.length > 0 ? (
                        <div className="space-y-4">
                          <div className="p-4 bg-muted rounded-lg">
                            <div className="flex items-center gap-2 mb-2">
                              {getTypeIcon(filteredSymbols[0].type)}
                              <span className="font-medium">{filteredSymbols[0].name}</span>
                              <Badge className={getTypeColor(filteredSymbols[0].type)}>
                                {filteredSymbols[0].type}
                              </Badge>
                            </div>
                            <div className="text-sm text-muted-foreground space-y-1">
                              <div>File: {filteredSymbols[0].file}</div>
                              <div>Location: Line {filteredSymbols[0].line}, Column {filteredSymbols[0].column}</div>
                              {filteredSymbols[0].description && (
                                <div>Description: {filteredSymbols[0].description}</div>
                              )}
                            </div>
                          </div>

                          <div className="space-y-2">
                            <Button className="w-full" onClick={() => navigateToDefinition(filteredSymbols[0])}>
                              <ArrowRight className="h-4 w-4 mr-2" />
                              Go to Definition
                            </Button>
                            <Button variant="outline" className="w-full" onClick={() => findReferences(filteredSymbols[0].name)}>
                              <Search className="h-4 w-4 mr-2" />
                              Find All References
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center text-muted-foreground py-8">
                          {searchQuery ? 'No symbols found' : 'Select a symbol to view details'}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="references" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Link className="h-4 w-4" />
                      References ({references.length})
                    </CardTitle>
                    <CardDescription>
                      All usages of the selected symbol
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-96">
                      <div className="space-y-2">
                        {references.map((ref, index) => (
                          <div 
                            key={index}
                            className="p-3 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                          >
                            <div className="flex items-start justify-between">
                              <div>
                                <div className="font-medium">{ref.file}</div>
                                <div className="text-sm text-muted-foreground">
                                  Line {ref.line}, Column {ref.column}
                                </div>
                                <div className="text-xs font-mono bg-muted p-2 rounded mt-2">
                                  {ref.context}
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge variant={ref.type === 'definition' ? 'default' : 'secondary'}>
                                  {ref.type}
                                </Badge>
                                <ExternalLink className="h-3 w-3" />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="history" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      Navigation History
                    </CardTitle>
                    <CardDescription>
                      Recent navigation actions and file visits
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-96">
                      <div className="space-y-2">
                        {navigationHistory.map((entry, index) => (
                          <div 
                            key={index}
                            className="p-3 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                          >
                            <div className="flex items-start justify-between">
                              <div>
                                <div className="font-medium">{entry.action}</div>
                                <div className="text-sm text-muted-foreground">
                                  {entry.file} - Line {entry.line}
                                </div>
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {entry.timestamp.toLocaleTimeString()}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="quick" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Zap className="h-4 w-4" />
                        Recent Files
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {quickAccess.recentFiles.map((file, index) => (
                          <div 
                            key={index}
                            className="p-2 border rounded hover:bg-muted/50 cursor-pointer transition-colors"
                          >
                            <div className="flex items-center justify-between">
                              <div>
                                <div className="font-medium text-sm">{file.name}</div>
                                <div className="text-xs text-muted-foreground">{file.path}</div>
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {file.lastAccessed}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <BookOpen className="h-4 w-4" />
                        Bookmarks
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {quickAccess.bookmarks.map((bookmark, index) => (
                          <div 
                            key={index}
                            className="p-2 border rounded hover:bg-muted/50 cursor-pointer transition-colors"
                          >
                            <div className="font-medium text-sm">{bookmark.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {bookmark.file}:{bookmark.line}
                            </div>
                          </div>
                        ))}
                      </div>
                      <Button size="sm" variant="outline" className="w-full mt-4">
                        Add Bookmark
                      </Button>
                    </CardContent>
                  </Card>
                </div>

                {/* Keyboard Shortcuts */}
                <Card>
                  <CardHeader>
                    <CardTitle>Navigation Shortcuts</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 text-sm">
                      <div className="flex justify-between">
                        <span>Go to Definition</span>
                        <Badge variant="outline">F12</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Find References</span>
                        <Badge variant="outline">Shift+F12</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Go to Symbol</span>
                        <Badge variant="outline">Ctrl+Shift+O</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Go to File</span>
                        <Badge variant="outline">Ctrl+P</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Go Back</span>
                        <Badge variant="outline">Alt+Left</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Go Forward</span>
                        <Badge variant="outline">Alt+Right</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}