import { useState, useEffect, useRef } from "react";
import { Search, Play, FileText, Settings, GitBranch, Terminal, Folder, Save, Download, Upload, RefreshCw, Zap, Code2, Palette, Monitor } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useIDEState } from "@/hooks/use-ide-state";

interface Command {
  id: string;
  label: string;
  description: string;
  icon: React.ReactNode;
  action: () => void;
  category: string;
  keywords: string[];
  shortcut?: string;
}

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSettings: () => void;
}

export default function CommandPalette({ isOpen, onClose, onOpenSettings }: CommandPaletteProps) {
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const { createNewFile, saveCurrentFile, runCurrentFile } = useIDEState();

  const commands: Command[] = [
    // File commands
    {
      id: "file.new",
      label: "File: New File",
      description: "Create a new file",
      icon: <FileText className="h-4 w-4" />,
      action: () => { createNewFile(); onClose(); },
      category: "File",
      keywords: ["new", "create", "file"],
      shortcut: "Ctrl+N"
    },
    {
      id: "file.save",
      label: "File: Save",
      description: "Save the current file",
      icon: <Save className="h-4 w-4" />,
      action: () => { saveCurrentFile(); onClose(); },
      category: "File",
      keywords: ["save", "write"],
      shortcut: "Ctrl+S"
    },
    {
      id: "file.saveAll",
      label: "File: Save All",
      description: "Save all open files",
      icon: <Save className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "File",
      keywords: ["save", "all"],
      shortcut: "Ctrl+Shift+S"
    },
    {
      id: "file.open",
      label: "File: Open File",
      description: "Open a file",
      icon: <Folder className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "File",
      keywords: ["open", "file"],
      shortcut: "Ctrl+O"
    },

    // Edit commands
    {
      id: "edit.find",
      label: "Edit: Find",
      description: "Find text in current file",
      icon: <Search className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "Edit",
      keywords: ["find", "search"],
      shortcut: "Ctrl+F"
    },
    {
      id: "edit.replace",
      label: "Edit: Replace",
      description: "Find and replace text",
      icon: <RefreshCw className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "Edit",
      keywords: ["replace", "find"],
      shortcut: "Ctrl+H"
    },
    {
      id: "edit.formatDocument",
      label: "Format Document",
      description: "Format the entire document",
      icon: <Code2 className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "Edit",
      keywords: ["format", "document", "prettify"],
      shortcut: "Shift+Alt+F"
    },

    // View commands
    {
      id: "view.commandPalette",
      label: "View: Show Command Palette",
      description: "Show the command palette",
      icon: <Search className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "View",
      keywords: ["command", "palette"],
      shortcut: "Ctrl+Shift+P"
    },
    {
      id: "view.explorer",
      label: "View: Show Explorer",
      description: "Show the file explorer",
      icon: <Folder className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "View",
      keywords: ["explorer", "files"],
      shortcut: "Ctrl+Shift+E"
    },
    {
      id: "view.terminal",
      label: "View: Toggle Terminal",
      description: "Toggle the integrated terminal",
      icon: <Terminal className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "View",
      keywords: ["terminal", "console"],
      shortcut: "Ctrl+`"
    },
    {
      id: "view.settings",
      label: "Preferences: Open Settings",
      description: "Open the settings editor",
      icon: <Settings className="h-4 w-4" />,
      action: () => { onOpenSettings(); onClose(); },
      category: "View",
      keywords: ["settings", "preferences", "config"],
      shortcut: "Ctrl+,"
    },

    // Run commands
    {
      id: "run.file",
      label: "Run: Run File",
      description: "Run the current file",
      icon: <Play className="h-4 w-4" />,
      action: () => { runCurrentFile(); onClose(); },
      category: "Run",
      keywords: ["run", "execute"],
      shortcut: "F5"
    },
    {
      id: "run.debug",
      label: "Run: Start Debugging",
      description: "Start debugging session",
      icon: <Zap className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "Run",
      keywords: ["debug", "breakpoint"],
      shortcut: "F9"
    },

    // Git commands
    {
      id: "git.commit",
      label: "Git: Commit",
      description: "Commit staged changes",
      icon: <GitBranch className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "Source Control",
      keywords: ["git", "commit"],
      shortcut: "Ctrl+Enter"
    },
    {
      id: "git.push",
      label: "Git: Push",
      description: "Push commits to remote",
      icon: <Upload className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "Source Control",
      keywords: ["git", "push", "upload"]
    },
    {
      id: "git.pull",
      label: "Git: Pull",
      description: "Pull changes from remote",
      icon: <Download className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "Source Control",
      keywords: ["git", "pull", "download"]
    },

    // Theme commands
    {
      id: "theme.select",
      label: "Preferences: Color Theme",
      description: "Change the color theme",
      icon: <Palette className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "Preferences",
      keywords: ["theme", "color", "dark", "light"]
    },
    {
      id: "workbench.toggleZenMode",
      label: "View: Toggle Zen Mode",
      description: "Toggle zen mode for distraction-free coding",
      icon: <Monitor className="h-4 w-4" />,
      action: () => { onClose(); },
      category: "View",
      keywords: ["zen", "focus", "distraction"]
    }
  ];

  const filteredCommands = commands.filter(command => {
    if (!query) return true;
    const searchText = query.toLowerCase();
    return (
      command.label.toLowerCase().includes(searchText) ||
      command.description.toLowerCase().includes(searchText) ||
      command.keywords.some(keyword => keyword.toLowerCase().includes(searchText))
    );
  });

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      switch (e.key) {
        case "ArrowDown":
          e.preventDefault();
          setSelectedIndex(prev => Math.min(prev + 1, filteredCommands.length - 1));
          break;
        case "ArrowUp":
          e.preventDefault();
          setSelectedIndex(prev => Math.max(prev - 1, 0));
          break;
        case "Enter":
          e.preventDefault();
          if (filteredCommands[selectedIndex]) {
            filteredCommands[selectedIndex].action();
          }
          break;
        case "Escape":
          e.preventDefault();
          onClose();
          break;
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, selectedIndex, filteredCommands, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-start justify-center pt-20">
      <div className="bg-[var(--ide-panel)] border border-[var(--ide-border)] rounded-lg w-[600px] max-h-[500px] shadow-2xl overflow-hidden">
        {/* Search Input */}
        <div className="p-4 border-b border-[var(--ide-border)]">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-[var(--ide-text-secondary)]" />
            <Input
              ref={inputRef}
              placeholder="Type a command..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-10 bg-[var(--ide-bg)] border-[var(--ide-border)] text-[var(--ide-text)] text-base"
            />
          </div>
        </div>

        {/* Commands List */}
        <div className="max-h-[400px] overflow-auto">
          {filteredCommands.length === 0 ? (
            <div className="p-8 text-center text-[var(--ide-text-secondary)]">
              No commands found for "{query}"
            </div>
          ) : (
            <div className="py-2">
              {filteredCommands.map((command, index) => (
                <div
                  key={command.id}
                  className={`flex items-center px-4 py-3 cursor-pointer transition-colors ${
                    index === selectedIndex
                      ? "bg-[var(--ide-accent)] text-white"
                      : "hover:bg-[var(--ide-bg)] text-[var(--ide-text)]"
                  }`}
                  onClick={() => command.action()}
                  onMouseEnter={() => setSelectedIndex(index)}
                >
                  <div className="mr-3">{command.icon}</div>
                  <div className="flex-1">
                    <div className="font-medium">{command.label}</div>
                    <div className={`text-sm ${
                      index === selectedIndex ? "text-blue-100" : "text-[var(--ide-text-secondary)]"
                    }`}>
                      {command.description}
                    </div>
                  </div>
                  {command.shortcut && (
                    <div className={`text-xs px-2 py-1 rounded ${
                      index === selectedIndex 
                        ? "bg-blue-600 text-white" 
                        : "bg-[var(--ide-bg)] text-[var(--ide-text-secondary)]"
                    }`}>
                      {command.shortcut}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}