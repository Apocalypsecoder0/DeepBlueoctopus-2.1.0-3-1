import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Download, 
  Upload, 
  FileText, 
  FolderOpen, 
  Code2, 
  Package, 
  GitBranch,
  Database,
  Settings,
  Copy,
  ExternalLink,
  Archive,
  FileCode,
  Folder,
  ChevronRight
} from 'lucide-react';
import { useIDEState } from '@/hooks/use-ide-state';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface ImportExportManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ExportTarget {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  formats: string[];
  destination: string;
}

interface ImportSource {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  supportedFormats: string[];
  source: string;
}

export default function ImportExportManager({ isOpen, onClose }: ImportExportManagerProps) {
  const { files, currentProject, openTabs, activeTab } = useIDEState();
  const { toast } = useToast();
  const [activeAction, setActiveAction] = useState<'import' | 'export'>('export');
  const [selectedFiles, setSelectedFiles] = useState<number[]>([]);
  const [exportTarget, setExportTarget] = useState<string>('');
  const [importSource, setImportSource] = useState<string>('');
  const [exportFormat, setExportFormat] = useState<string>('zip');
  const [importData, setImportData] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);

  const exportTargets: ExportTarget[] = [
    {
      id: 'local-download',
      name: 'Local Download',
      description: 'Download files to your computer',
      icon: <Download className="h-4 w-4" />,
      formats: ['zip', 'tar.gz', 'json'],
      destination: 'Computer'
    },
    {
      id: 'github-gist',
      name: 'GitHub Gist',
      description: 'Create a GitHub Gist from selected files',
      icon: <GitBranch className="h-4 w-4" />,
      formats: ['gist'],
      destination: 'GitHub'
    },
    {
      id: 'code-snippet',
      name: 'Code Snippet',
      description: 'Export as formatted code snippet',
      icon: <Code2 className="h-4 w-4" />,
      formats: ['markdown', 'html', 'plain'],
      destination: 'Clipboard'
    },
    {
      id: 'project-template',
      name: 'Project Template',
      description: 'Save as reusable project template',
      icon: <Package className="h-4 w-4" />,
      formats: ['template'],
      destination: 'IDE Templates'
    },
    {
      id: 'database-backup',
      name: 'Database Backup',
      description: 'Export project to database',
      icon: <Database className="h-4 w-4" />,
      formats: ['sql', 'json'],
      destination: 'Database'
    },
    {
      id: 'external-tool',
      name: 'External Tool',
      description: 'Send to external development tool',
      icon: <ExternalLink className="h-4 w-4" />,
      formats: ['vscode', 'sublime', 'atom'],
      destination: 'External IDE'
    }
  ];

  const importSources: ImportSource[] = [
    {
      id: 'file-upload',
      name: 'File Upload',
      description: 'Upload files from your computer',
      icon: <Upload className="h-4 w-4" />,
      supportedFormats: ['zip', 'tar.gz', 'js', 'ts', 'py', 'java', 'cpp', 'html', 'css'],
      source: 'Computer'
    },
    {
      id: 'github-import',
      name: 'GitHub Repository',
      description: 'Import from GitHub repository',
      icon: <GitBranch className="h-4 w-4" />,
      supportedFormats: ['repository', 'branch', 'folder'],
      source: 'GitHub'
    },
    {
      id: 'code-paste',
      name: 'Code Paste',
      description: 'Import code from clipboard',
      icon: <Copy className="h-4 w-4" />,
      supportedFormats: ['text', 'code'],
      source: 'Clipboard'
    },
    {
      id: 'url-import',
      name: 'URL Import',
      description: 'Import code from URL',
      icon: <ExternalLink className="h-4 w-4" />,
      supportedFormats: ['raw', 'gist', 'pastebin'],
      source: 'URL'
    },
    {
      id: 'template-import',
      name: 'Project Template',
      description: 'Import from saved templates',
      icon: <Package className="h-4 w-4" />,
      supportedFormats: ['template'],
      source: 'IDE Templates'
    },
    {
      id: 'database-restore',
      name: 'Database Restore',
      description: 'Restore project from database',
      icon: <Database className="h-4 w-4" />,
      supportedFormats: ['sql', 'json'],
      source: 'Database'
    }
  ];

  const handleFileSelection = (fileId: number) => {
    setSelectedFiles(prev => 
      prev.includes(fileId) 
        ? prev.filter(id => id !== fileId)
        : [...prev, fileId]
    );
  };

  const handleSelectAll = () => {
    if (selectedFiles.length === files.length) {
      setSelectedFiles([]);
    } else {
      setSelectedFiles(files.map(f => f.id));
    }
  };

  const handleExport = async () => {
    if (!exportTarget || selectedFiles.length === 0) {
      toast({
        title: "Export Error",
        description: "Please select files and export target",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    try {
      const selectedFileData = files.filter(f => selectedFiles.includes(f.id));
      
      const exportData = {
        files: selectedFileData,
        project: currentProject,
        target: exportTarget,
        format: exportFormat,
        metadata: {
          exportDate: new Date().toISOString(),
          ideVersion: "2.1.0",
          totalFiles: selectedFileData.length
        }
      };

      switch (exportTarget) {
        case 'local-download':
          await handleLocalDownload(exportData);
          break;
        case 'github-gist':
          await handleGitHubGist(exportData);
          break;
        case 'code-snippet':
          await handleCodeSnippet(exportData);
          break;
        case 'project-template':
          await handleProjectTemplate(exportData);
          break;
        case 'database-backup':
          await handleDatabaseBackup(exportData);
          break;
        case 'external-tool':
          await handleExternalTool(exportData);
          break;
      }

      toast({
        title: "Export Successful",
        description: `Exported ${selectedFileData.length} files successfully`
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleImport = async () => {
    if (!importSource) {
      toast({
        title: "Import Error",
        description: "Please select an import source",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    try {
      switch (importSource) {
        case 'file-upload':
          await handleFileUpload();
          break;
        case 'github-import':
          await handleGitHubImport();
          break;
        case 'code-paste':
          await handleCodePaste();
          break;
        case 'url-import':
          await handleUrlImport();
          break;
        case 'template-import':
          await handleTemplateImport();
          break;
        case 'database-restore':
          await handleDatabaseRestore();
          break;
      }

      toast({
        title: "Import Successful",
        description: "Files imported successfully"
      });
    } catch (error) {
      toast({
        title: "Import Failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleLocalDownload = async (exportData: any) => {
    const response = await apiRequest('POST', '/api/export/download', exportData);
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = `${currentProject?.name || 'project'}.${exportFormat}`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  const handleGitHubGist = async (exportData: any) => {
    // Create GitHub Gist
    const gistData = {
      description: `Code from ${currentProject?.name || 'IDE Project'}`,
      public: false,
      files: {}
    };

    exportData.files.forEach((file: any) => {
      gistData.files[file.name] = {
        content: file.content
      };
    });

    // This would require GitHub API token
    console.log('GitHub Gist data prepared:', gistData);
    toast({
      title: "GitHub Integration",
      description: "GitHub Gist export prepared. API integration required.",
    });
  };

  const handleCodeSnippet = async (exportData: any) => {
    let snippet = '';
    
    if (exportFormat === 'markdown') {
      snippet = exportData.files.map((file: any) => 
        `## ${file.name}\n\`\`\`${file.language}\n${file.content}\n\`\`\``
      ).join('\n\n');
    } else if (exportFormat === 'html') {
      snippet = exportData.files.map((file: any) => 
        `<h3>${file.name}</h3><pre><code class="${file.language}">${file.content}</code></pre>`
      ).join('\n');
    } else {
      snippet = exportData.files.map((file: any) => 
        `=== ${file.name} ===\n${file.content}`
      ).join('\n\n');
    }

    await navigator.clipboard.writeText(snippet);
    toast({
      title: "Copied to Clipboard",
      description: "Code snippet copied successfully"
    });
  };

  const handleProjectTemplate = async (exportData: any) => {
    await apiRequest('POST', '/api/templates/save', {
      name: `${currentProject?.name || 'Project'} Template`,
      description: `Template created from ${currentProject?.name || 'IDE project'}`,
      files: exportData.files,
      metadata: exportData.metadata
    });
  };

  const handleDatabaseBackup = async (exportData: any) => {
    await apiRequest('POST', '/api/backup/create', exportData);
  };

  const handleExternalTool = async (exportData: any) => {
    // Generate compatible format for external tools
    const toolData = {
      format: exportFormat,
      files: exportData.files,
      workspace: {
        name: currentProject?.name,
        folders: exportData.files.filter((f: any) => f.isDirectory)
      }
    };

    console.log('External tool data prepared:', toolData);
    toast({
      title: "External Tool Export",
      description: "Export data prepared for external IDE"
    });
  };

  const handleFileUpload = async () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = true;
    input.accept = '.js,.ts,.py,.java,.cpp,.html,.css,.json,.md,.txt,.zip,.tar.gz';
    
    input.onchange = async (e) => {
      const files = (e.target as HTMLInputElement).files;
      if (files) {
        for (const file of Array.from(files)) {
          const content = await file.text();
          const language = getLanguageFromExtension(file.name);
          
          await apiRequest('POST', '/api/files', {
            name: file.name,
            path: `/${file.name}`,
            content,
            language,
            isDirectory: false,
            projectId: currentProject?.id || 1
          });
        }
      }
    };
    
    input.click();
  };

  const handleGitHubImport = async () => {
    // This would integrate with GitHub API
    console.log('GitHub import initiated');
    toast({
      title: "GitHub Integration",
      description: "GitHub import feature requires API setup"
    });
  };

  const handleCodePaste = async () => {
    if (importData.trim()) {
      const fileName = prompt('Enter filename for pasted code:') || 'pasted-code.txt';
      const language = getLanguageFromExtension(fileName);
      
      await apiRequest('POST', '/api/files', {
        name: fileName,
        path: `/${fileName}`,
        content: importData,
        language,
        isDirectory: false,
        projectId: currentProject?.id || 1
      });
    }
  };

  const handleUrlImport = async () => {
    const url = prompt('Enter URL to import from:');
    if (url) {
      try {
        const response = await fetch(url);
        const content = await response.text();
        const fileName = url.split('/').pop() || 'imported-file.txt';
        const language = getLanguageFromExtension(fileName);
        
        await apiRequest('POST', '/api/files', {
          name: fileName,
          path: `/${fileName}`,
          content,
          language,
          isDirectory: false,
          projectId: currentProject?.id || 1
        });
      } catch (error) {
        throw new Error('Failed to fetch from URL');
      }
    }
  };

  const handleTemplateImport = async () => {
    // Load available templates
    console.log('Template import initiated');
    toast({
      title: "Template Import",
      description: "Template selection interface would appear here"
    });
  };

  const handleDatabaseRestore = async () => {
    await apiRequest('POST', '/api/backup/restore', {
      source: 'database',
      projectId: currentProject?.id
    });
  };

  const getLanguageFromExtension = (fileName: string): string => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    const langMap: { [key: string]: string } = {
      'js': 'javascript',
      'ts': 'typescript',
      'py': 'python',
      'java': 'java',
      'cpp': 'cpp',
      'c': 'c',
      'html': 'html',
      'css': 'css',
      'json': 'json',
      'md': 'markdown',
      'txt': 'text'
    };
    return langMap[ext || ''] || 'text';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Archive className="h-5 w-5" />
            Import & Export Manager
          </DialogTitle>
          <DialogDescription>
            Move source code between different tools and locations
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeAction} onValueChange={(value) => setActiveAction(value as 'import' | 'export')}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="export" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Export Code
            </TabsTrigger>
            <TabsTrigger value="import" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              Import Code
            </TabsTrigger>
          </TabsList>

          <TabsContent value="export" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* File Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Select Files to Export
                  </CardTitle>
                  <CardDescription>
                    Choose which files to include in the export
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Files ({files.length})</Label>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={handleSelectAll}
                      >
                        {selectedFiles.length === files.length ? 'Deselect All' : 'Select All'}
                      </Button>
                    </div>
                    <div className="max-h-60 overflow-y-auto border rounded p-2 space-y-1">
                      {files.map((file) => (
                        <div
                          key={file.id}
                          className={`flex items-center gap-2 p-2 rounded cursor-pointer hover:bg-accent ${
                            selectedFiles.includes(file.id) ? 'bg-accent' : ''
                          }`}
                          onClick={() => handleFileSelection(file.id)}
                        >
                          <input
                            type="checkbox"
                            checked={selectedFiles.includes(file.id)}
                            onChange={() => handleFileSelection(file.id)}
                            className="mr-2"
                          />
                          {file.isDirectory ? (
                            <Folder className="h-4 w-4 text-blue-500" />
                          ) : (
                            <FileCode className="h-4 w-4 text-green-500" />
                          )}
                          <span className="text-sm">{file.name}</span>
                          <Badge variant="secondary" className="ml-auto text-xs">
                            {file.language}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Export Targets */}
              <Card>
                <CardHeader>
                  <CardTitle>Export Destination</CardTitle>
                  <CardDescription>
                    Choose where to export your code
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {exportTargets.map((target) => (
                      <div
                        key={target.id}
                        className={`flex items-center gap-3 p-3 border rounded cursor-pointer hover:bg-accent ${
                          exportTarget === target.id ? 'bg-accent border-primary' : ''
                        }`}
                        onClick={() => setExportTarget(target.id)}
                      >
                        <input
                          type="radio"
                          name="exportTarget"
                          value={target.id}
                          checked={exportTarget === target.id}
                          onChange={() => setExportTarget(target.id)}
                        />
                        <div className="flex items-center gap-2">
                          {target.icon}
                          <div>
                            <div className="font-medium text-sm">{target.name}</div>
                            <div className="text-xs text-muted-foreground">{target.description}</div>
                          </div>
                        </div>
                        <div className="ml-auto text-xs text-muted-foreground">
                          {target.destination}
                        </div>
                      </div>
                    ))}
                  </div>

                  {exportTarget && (
                    <div className="mt-4">
                      <Label>Export Format</Label>
                      <Select value={exportFormat} onValueChange={setExportFormat}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {exportTargets.find(t => t.id === exportTarget)?.formats.map((format) => (
                            <SelectItem key={format} value={format}>
                              {format.toUpperCase()}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button 
                onClick={handleExport}
                disabled={!exportTarget || selectedFiles.length === 0 || isProcessing}
              >
                {isProcessing ? 'Exporting...' : 'Export Files'}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="import" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Import Sources */}
              <Card>
                <CardHeader>
                  <CardTitle>Import Source</CardTitle>
                  <CardDescription>
                    Choose where to import code from
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {importSources.map((source) => (
                      <div
                        key={source.id}
                        className={`flex items-center gap-3 p-3 border rounded cursor-pointer hover:bg-accent ${
                          importSource === source.id ? 'bg-accent border-primary' : ''
                        }`}
                        onClick={() => setImportSource(source.id)}
                      >
                        <input
                          type="radio"
                          name="importSource"
                          value={source.id}
                          checked={importSource === source.id}
                          onChange={() => setImportSource(source.id)}
                        />
                        <div className="flex items-center gap-2">
                          {source.icon}
                          <div>
                            <div className="font-medium text-sm">{source.name}</div>
                            <div className="text-xs text-muted-foreground">{source.description}</div>
                          </div>
                        </div>
                        <div className="ml-auto text-xs text-muted-foreground">
                          {source.source}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Import Configuration */}
              <Card>
                <CardHeader>
                  <CardTitle>Import Configuration</CardTitle>
                  <CardDescription>
                    Configure import settings
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {importSource === 'code-paste' && (
                    <div className="space-y-2">
                      <Label>Paste Code Here</Label>
                      <Textarea
                        value={importData}
                        onChange={(e) => setImportData(e.target.value)}
                        placeholder="Paste your code here..."
                        rows={10}
                      />
                    </div>
                  )}

                  {importSource === 'url-import' && (
                    <div className="space-y-2">
                      <Label>URL to Import</Label>
                      <Input
                        placeholder="https://raw.githubusercontent.com/..."
                        value={importData}
                        onChange={(e) => setImportData(e.target.value)}
                      />
                    </div>
                  )}

                  {importSource === 'github-import' && (
                    <div className="space-y-2">
                      <Label>Repository URL</Label>
                      <Input
                        placeholder="https://github.com/user/repo"
                        value={importData}
                        onChange={(e) => setImportData(e.target.value)}
                      />
                    </div>
                  )}

                  {importSource && (
                    <div className="mt-4 p-3 bg-accent rounded">
                      <div className="text-sm font-medium">Supported Formats:</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {importSources.find(s => s.id === importSource)?.supportedFormats.join(', ')}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button 
                onClick={handleImport}
                disabled={!importSource || isProcessing}
              >
                {isProcessing ? 'Importing...' : 'Import Files'}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}