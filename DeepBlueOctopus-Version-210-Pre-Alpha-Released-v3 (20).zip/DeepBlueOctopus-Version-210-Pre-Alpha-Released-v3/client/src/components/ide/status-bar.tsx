import { GitBranch, AlertTriangle, XCircle, Wifi } from "lucide-react";
import { useIDEState } from "@/hooks/use-ide-state";

export default function StatusBar() {
  const { activeTab } = useIDEState();

  return (
    <div className="ide-accent text-white px-4 py-1 text-xs flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <GitBranch className="h-3 w-3" />
          <span>main</span>
        </div>
        
        <div className="flex items-center space-x-2">
          <AlertTriangle className="h-3 w-3 text-[var(--ide-warning)]" />
          <span>0 warnings</span>
        </div>
        
        <div className="flex items-center space-x-2">
          <XCircle className="h-3 w-3 text-[var(--ide-error)]" />
          <span>0 errors</span>
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        <span>Ln 1, Col 1</span>
        
        {activeTab && (
          <>
            <span>{activeTab.language.charAt(0).toUpperCase() + activeTab.language.slice(1)}</span>
            <span>UTF-8</span>
            <span>LF</span>
          </>
        )}
        
        <div className="flex items-center space-x-1">
          <Wifi className="h-3 w-3" />
          <span>Connected</span>
        </div>
      </div>
    </div>
  );
}
