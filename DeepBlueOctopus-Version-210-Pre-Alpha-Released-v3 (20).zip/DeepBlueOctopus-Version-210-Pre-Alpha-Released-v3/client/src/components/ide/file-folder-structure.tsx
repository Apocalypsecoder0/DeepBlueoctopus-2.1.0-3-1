import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  FolderOpen, 
  FolderPlus, 
  File, 
  FilePlus, 
  FileText, 
  Folder, 
  Search, 
  Download, 
  Upload, 
  Trash2, 
  Edit3, 
  Copy, 
  Move, 
  Archive, 
  Star, 
  Clock, 
  Grid, 
  List, 
  SortAsc, 
  SortDesc, 
  Filter, 
  Eye, 
  EyeOff, 
  Bookmark, 
  BookmarkPlus,
  Settings,
  Refresh,
  MoreHorizontal,
  FolderTree,
  Files,
  Database,
  Image,
  Code,
  Video,
  Music,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileArchive,
  Package
} from "lucide-react";

interface FileItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  path: string;
  size?: number;
  modified: Date;
  created: Date;
  extension?: string;
  isBookmarked: boolean;
  isHidden: boolean;
  permissions: {
    read: boolean;
    write: boolean;
    execute: boolean;
  };
  metadata: {
    encoding: string;
    lineCount?: number;
    language?: string;
    description?: string;
  };
  parent?: string;
  children?: string[];
}

interface FileTemplate {
  id: string;
  name: string;
  description: string;
  type: 'file' | 'folder';
  category: string;
  content?: string;
  structure?: FileTemplate[];
}

interface FileFolderStructureProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function FileFolderStructure({ isOpen, onClose }: FileFolderStructureProps) {
  const [activeTab, setActiveTab] = useState("explorer");
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [sortBy, setSortBy] = useState<'name' | 'date' | 'size' | 'type'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [currentPath, setCurrentPath] = useState("/");
  const [showHidden, setShowHidden] = useState(false);
  const [newItemName, setNewItemName] = useState("");
  const [newItemType, setNewItemType] = useState<'file' | 'folder'>('file');
  const [selectedTemplate, setSelectedTemplate] = useState("");

  const [files, setFiles] = useState<FileItem[]>([
    {
      id: "1",
      name: "src",
      type: "folder",
      path: "/src",
      modified: new Date(),
      created: new Date(),
      isBookmarked: true,
      isHidden: false,
      permissions: { read: true, write: true, execute: true },
      metadata: { encoding: "utf-8", description: "Source code directory" },
      children: ["2", "3", "4"]
    },
    {
      id: "2",
      name: "components",
      type: "folder",
      path: "/src/components",
      modified: new Date(),
      created: new Date(),
      isBookmarked: false,
      isHidden: false,
      permissions: { read: true, write: true, execute: true },
      metadata: { encoding: "utf-8", description: "React components" },
      parent: "1",
      children: ["5", "6"]
    },
    {
      id: "3",
      name: "utils",
      type: "folder",
      path: "/src/utils",
      modified: new Date(),
      created: new Date(),
      isBookmarked: false,
      isHidden: false,
      permissions: { read: true, write: true, execute: true },
      metadata: { encoding: "utf-8", description: "Utility functions" },
      parent: "1"
    },
    {
      id: "4",
      name: "main.tsx",
      type: "file",
      path: "/src/main.tsx",
      size: 1024,
      extension: "tsx",
      modified: new Date(),
      created: new Date(),
      isBookmarked: true,
      isHidden: false,
      permissions: { read: true, write: true, execute: false },
      metadata: { encoding: "utf-8", lineCount: 45, language: "typescript", description: "Main entry point" },
      parent: "1"
    },
    {
      id: "5",
      name: "Header.tsx",
      type: "file",
      path: "/src/components/Header.tsx",
      size: 512,
      extension: "tsx",
      modified: new Date(),
      created: new Date(),
      isBookmarked: false,
      isHidden: false,
      permissions: { read: true, write: true, execute: false },
      metadata: { encoding: "utf-8", lineCount: 25, language: "typescript" },
      parent: "2"
    }
  ]);

  const fileTemplates: FileTemplate[] = [
    {
      id: "react-component",
      name: "React Component",
      description: "Basic React TypeScript component",
      type: "file",
      category: "React",
      content: `import React from 'react';

interface Props {
  // Define your props here
}

const Component: React.FC<Props> = () => {
  return (
    <div>
      {/* Component content */}
    </div>
  );
};

export default Component;`
    },
    {
      id: "node-project",
      name: "Node.js Project",
      description: "Complete Node.js project structure",
      type: "folder",
      category: "Node.js",
      structure: [
        {
          id: "package-json",
          name: "package.json",
          type: "file",
          category: "Config",
          description: "Package configuration",
          content: `{
  "name": "new-project",
  "version": "1.0.0",
  "description": "",
  "main": "index.js",
  "scripts": {
    "start": "node index.js",
    "dev": "nodemon index.js"
  },
  "dependencies": {},
  "devDependencies": {}
}`
        }
      ]
    },
    {
      id: "python-script",
      name: "Python Script",
      description: "Basic Python script template",
      type: "file",
      category: "Python",
      content: `#!/usr/bin/env python3
"""
Script description
"""

def main():
    print("Hello, World!")

if __name__ == "__main__":
    main()`
    }
  ];

  const getFileIcon = (file: FileItem) => {
    if (file.type === 'folder') {
      return <Folder className="h-4 w-4 text-blue-500" />;
    }
    
    const ext = file.extension?.toLowerCase();
    switch (ext) {
      case 'js':
      case 'ts':
      case 'jsx':
      case 'tsx':
        return <FileCode className="h-4 w-4 text-yellow-500" />;
      case 'png':
      case 'jpg':
      case 'jpeg':
      case 'gif':
      case 'svg':
        return <FileImage className="h-4 w-4 text-green-500" />;
      case 'mp4':
      case 'avi':
      case 'mov':
        return <FileVideo className="h-4 w-4 text-purple-500" />;
      case 'mp3':
      case 'wav':
      case 'flac':
        return <FileAudio className="h-4 w-4 text-pink-500" />;
      case 'zip':
      case 'rar':
      case 'tar':
        return <FileArchive className="h-4 w-4 text-orange-500" />;
      default:
        return <FileText className="h-4 w-4 text-gray-500" />;
    }
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return '-';
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unitIndex = 0;
    
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  };

  const filteredFiles = files.filter(file => {
    const matchesSearch = file.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesHidden = showHidden || !file.isHidden;
    return matchesSearch && matchesHidden;
  });

  const sortedFiles = [...filteredFiles].sort((a, b) => {
    let comparison = 0;
    
    switch (sortBy) {
      case 'name':
        comparison = a.name.localeCompare(b.name);
        break;
      case 'date':
        comparison = a.modified.getTime() - b.modified.getTime();
        break;
      case 'size':
        comparison = (a.size || 0) - (b.size || 0);
        break;
      case 'type':
        comparison = a.type.localeCompare(b.type);
        break;
    }
    
    return sortOrder === 'asc' ? comparison : -comparison;
  });

  const createNewItem = () => {
    if (!newItemName.trim()) return;
    
    const newFile: FileItem = {
      id: Date.now().toString(),
      name: newItemName,
      type: newItemType,
      path: `${currentPath}/${newItemName}`,
      size: newItemType === 'file' ? 0 : undefined,
      modified: new Date(),
      created: new Date(),
      isBookmarked: false,
      isHidden: false,
      permissions: { read: true, write: true, execute: newItemType === 'folder' },
      metadata: { encoding: "utf-8" }
    };
    
    setFiles([...files, newFile]);
    setNewItemName("");
  };

  const toggleBookmark = (fileId: string) => {
    setFiles(files.map(file => 
      file.id === fileId 
        ? { ...file, isBookmarked: !file.isBookmarked }
        : file
    ));
  };

  const deleteItems = (itemIds: string[]) => {
    setFiles(files.filter(file => !itemIds.includes(file.id)));
    setSelectedItems([]);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh] bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 border-blue-500/20">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-white flex items-center gap-2">
            <FolderTree className="h-6 w-6 text-blue-400" />
            File & Folder Structure Manager
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
          <TabsList className="grid w-full grid-cols-5 bg-slate-800/50">
            <TabsTrigger value="explorer" className="text-white">
              <Files className="h-4 w-4 mr-2" />
              Explorer
            </TabsTrigger>
            <TabsTrigger value="templates" className="text-white">
              <Package className="h-4 w-4 mr-2" />
              Templates
            </TabsTrigger>
            <TabsTrigger value="bookmarks" className="text-white">
              <Bookmark className="h-4 w-4 mr-2" />
              Bookmarks
            </TabsTrigger>
            <TabsTrigger value="recent" className="text-white">
              <Clock className="h-4 w-4 mr-2" />
              Recent
            </TabsTrigger>
            <TabsTrigger value="settings" className="text-white">
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="explorer" className="h-full mt-4">
            <div className="grid grid-cols-12 gap-4 h-full">
              {/* Sidebar */}
              <div className="col-span-3 space-y-4">
                <Card className="bg-slate-800/50 border-slate-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white text-sm">Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex gap-2">
                      <Input
                        placeholder="New item name..."
                        value={newItemName}
                        onChange={(e) => setNewItemName(e.target.value)}
                        className="bg-slate-900 border-slate-600 text-white text-sm"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Select value={newItemType} onValueChange={(value: 'file' | 'folder') => setNewItemType(value)}>
                        <SelectTrigger className="bg-slate-900 border-slate-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="file">File</SelectItem>
                          <SelectItem value="folder">Folder</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button onClick={createNewItem} size="sm" className="bg-blue-600 hover:bg-blue-700">
                        <FilePlus className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-slate-800/50 border-slate-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white text-sm">Navigation</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="text-sm text-slate-300">
                      Current: <span className="text-blue-400">{currentPath}</span>
                    </div>
                    <div className="space-y-1">
                      <Button variant="ghost" size="sm" className="w-full justify-start text-white hover:bg-slate-700">
                        <Folder className="h-4 w-4 mr-2" />
                        Root
                      </Button>
                      <Button variant="ghost" size="sm" className="w-full justify-start text-white hover:bg-slate-700">
                        <Folder className="h-4 w-4 mr-2" />
                        src
                      </Button>
                      <Button variant="ghost" size="sm" className="w-full justify-start text-white hover:bg-slate-700 ml-4">
                        <Folder className="h-4 w-4 mr-2" />
                        components
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Main Content */}
              <div className="col-span-9">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                      <Input
                        placeholder="Search files and folders..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 bg-slate-900 border-slate-600 text-white w-64"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant={viewMode === 'list' ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setViewMode('list')}
                        className="text-white"
                      >
                        <List className="h-4 w-4" />
                      </Button>
                      <Button
                        variant={viewMode === 'grid' ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setViewMode('grid')}
                        className="text-white"
                      >
                        <Grid className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                      <SelectTrigger className="w-32 bg-slate-900 border-slate-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="name">Name</SelectItem>
                        <SelectItem value="date">Date</SelectItem>
                        <SelectItem value="size">Size</SelectItem>
                        <SelectItem value="type">Type</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                      className="text-white"
                    >
                      {sortOrder === 'asc' ? <SortAsc className="h-4 w-4" /> : <SortDesc className="h-4 w-4" />}
                    </Button>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        checked={showHidden}
                        onCheckedChange={(checked) => setShowHidden(checked as boolean)}
                      />
                      <Label className="text-white text-sm">Show hidden</Label>
                    </div>
                  </div>
                </div>

                <Card className="bg-slate-800/30 border-slate-700 h-[calc(100vh-200px)]">
                  <ScrollArea className="h-full">
                    <div className="p-4">
                      {viewMode === 'list' ? (
                        <div className="space-y-1">
                          {sortedFiles.map((file) => (
                            <div
                              key={file.id}
                              className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-700/50 transition-colors group"
                            >
                              <div className="flex items-center gap-3 flex-1">
                                <Checkbox
                                  checked={selectedItems.includes(file.id)}
                                  onCheckedChange={(checked) => {
                                    if (checked) {
                                      setSelectedItems([...selectedItems, file.id]);
                                    } else {
                                      setSelectedItems(selectedItems.filter(id => id !== file.id));
                                    }
                                  }}
                                />
                                {getFileIcon(file)}
                                <div className="flex-1">
                                  <div className="text-white font-medium">{file.name}</div>
                                  {file.metadata.description && (
                                    <div className="text-xs text-slate-400">{file.metadata.description}</div>
                                  )}
                                </div>
                                <div className="text-sm text-slate-400">
                                  {formatFileSize(file.size)}
                                </div>
                                <div className="text-sm text-slate-400">
                                  {file.modified.toLocaleDateString()}
                                </div>
                                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => toggleBookmark(file.id)}
                                    className="text-white hover:bg-slate-600"
                                  >
                                    {file.isBookmarked ? (
                                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                    ) : (
                                      <Star className="h-4 w-4" />
                                    )}
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-white hover:bg-slate-600"
                                  >
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="grid grid-cols-4 gap-4">
                          {sortedFiles.map((file) => (
                            <Card key={file.id} className="bg-slate-700/50 border-slate-600 hover:bg-slate-700 transition-colors group cursor-pointer">
                              <CardContent className="p-4">
                                <div className="flex flex-col items-center gap-2">
                                  <div className="text-4xl">
                                    {getFileIcon(file)}
                                  </div>
                                  <div className="text-white text-sm font-medium text-center">
                                    {file.name}
                                  </div>
                                  <div className="text-xs text-slate-400">
                                    {formatFileSize(file.size)}
                                  </div>
                                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => toggleBookmark(file.id)}
                                      className="text-white hover:bg-slate-600"
                                    >
                                      {file.isBookmarked ? (
                                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                      ) : (
                                        <Star className="h-4 w-4" />
                                      )}
                                    </Button>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </Card>

                {selectedItems.length > 0 && (
                  <div className="mt-4 flex items-center gap-2">
                    <Badge className="bg-blue-600 text-white">
                      {selectedItems.length} selected
                    </Badge>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => deleteItems(selectedItems)}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </Button>
                    <Button variant="ghost" size="sm" className="text-white">
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                    <Button variant="ghost" size="sm" className="text-white">
                      <Move className="h-4 w-4 mr-2" />
                      Move
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="templates" className="mt-4">
            <div className="grid grid-cols-3 gap-4">
              {fileTemplates.map((template) => (
                <Card key={template.id} className="bg-slate-800/50 border-slate-700 hover:bg-slate-800 transition-colors cursor-pointer">
                  <CardHeader>
                    <CardTitle className="text-white text-lg flex items-center gap-2">
                      {template.type === 'folder' ? (
                        <FolderPlus className="h-5 w-5 text-blue-400" />
                      ) : (
                        <FilePlus className="h-5 w-5 text-green-400" />
                      )}
                      {template.name}
                    </CardTitle>
                    <CardDescription className="text-slate-400">
                      {template.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <Badge className="bg-slate-700 text-white">
                        {template.category}
                      </Badge>
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                        Use Template
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="bookmarks" className="mt-4">
            <div className="space-y-2">
              {files.filter(file => file.isBookmarked).map((file) => (
                <div key={file.id} className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg">
                  {getFileIcon(file)}
                  <div className="flex-1">
                    <div className="text-white font-medium">{file.name}</div>
                    <div className="text-sm text-slate-400">{file.path}</div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleBookmark(file.id)}
                    className="text-white"
                  >
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  </Button>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="recent" className="mt-4">
            <div className="space-y-2">
              {files
                .sort((a, b) => b.modified.getTime() - a.modified.getTime())
                .slice(0, 10)
                .map((file) => (
                  <div key={file.id} className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg">
                    {getFileIcon(file)}
                    <div className="flex-1">
                      <div className="text-white font-medium">{file.name}</div>
                      <div className="text-sm text-slate-400">{file.path}</div>
                    </div>
                    <div className="text-sm text-slate-400">
                      {file.modified.toLocaleString()}
                    </div>
                  </div>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="settings" className="mt-4">
            <div className="grid grid-cols-2 gap-6">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">View Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-white">Show hidden files</Label>
                    <Checkbox
                      checked={showHidden}
                      onCheckedChange={(checked) => setShowHidden(checked as boolean)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label className="text-white">Default view mode</Label>
                    <Select value={viewMode} onValueChange={(value: 'list' | 'grid') => setViewMode(value)}>
                      <SelectTrigger className="w-32 bg-slate-900 border-slate-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="list">List</SelectItem>
                        <SelectItem value="grid">Grid</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">File Operations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Files
                  </Button>
                  <Button className="w-full bg-green-600 hover:bg-green-700">
                    <Download className="h-4 w-4 mr-2" />
                    Export Structure
                  </Button>
                  <Button className="w-full bg-purple-600 hover:bg-purple-700">
                    <Archive className="h-4 w-4 mr-2" />
                    Create Archive
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}