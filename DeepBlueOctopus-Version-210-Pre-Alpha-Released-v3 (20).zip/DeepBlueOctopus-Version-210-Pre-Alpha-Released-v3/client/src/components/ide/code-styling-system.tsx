import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import { SoundButton } from "@/components/ui/sound-system";
import { 
  X, 
  Save, 
  Download, 
  Upload, 
  Undo, 
  Redo, 
  Code, 
  Palette,
  Settings,
  Eye,
  EyeOff,
  Copy,
  Scissors,
  FileText,
  Printer,
  Share2,
  Archive,
  FolderOpen,
  Plus,
  Trash2,
  CheckCircle,
  AlertCircle,
  Info,
  Zap,
  Star,
  Filter,
  Search,
  RefreshCw,
  Brush,
  Type,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Indent,
  Outdent,
  Quote,
  List,
  ListOrdered,
  Bold,
  Italic,
  Underline
} from "lucide-react";

interface CodeStylingSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface StyleRule {
  id: string;
  name: string;
  language: string;
  category: string;
  description: string;
  rule: string;
  example: string;
  severity: 'error' | 'warning' | 'info' | 'suggestion';
  enabled: boolean;
  customizable: boolean;
  autoFix: boolean;
}

interface LanguageProfile {
  id: string;
  name: string;
  language: string;
  description: string;
  rules: string[];
  indentSize: number;
  indentType: 'spaces' | 'tabs';
  maxLineLength: number;
  insertFinalNewline: boolean;
  trimTrailingWhitespace: boolean;
  created: Date;
  modified: Date;
}

interface CommentingStyle {
  id: string;
  name: string;
  description: string;
  singleLine: string;
  multiLineStart: string;
  multiLineEnd: string;
  docBlockStart: string;
  docBlockEnd: string;
  docBlockPrefix: string;
  todoFormat: string;
  fixmeFormat: string;
  hackFormat: string;
  noteFormat: string;
  headerFormat: string;
  sectionFormat: string;
  functionDocFormat: string;
  classDocFormat: string;
  paramFormat: string;
  returnFormat: string;
  exampleFormat: string;
  authorFormat: string;
  dateFormat: string;
  versionFormat: string;
  sinceFormat: string;
  deprecatedFormat: string;
  seeAlsoFormat: string;
  throwsFormat: string;
  customTags: { [key: string]: string };
}

interface FormattingConfig {
  indentSize: number;
  indentType: 'spaces' | 'tabs';
  maxLineLength: number;
  insertFinalNewline: boolean;
  trimTrailingWhitespace: boolean;
  bracketSpacing: boolean;
  semiColons: boolean;
  singleQuotes: boolean;
  trailingCommas: boolean;
  printWidth: number;
  tabWidth: number;
  useTabs: boolean;
  endOfLine: 'lf' | 'crlf' | 'cr' | 'auto';
  quoteProps: 'as-needed' | 'consistent' | 'preserve';
  jsxSingleQuote: boolean;
  jsxBracketSameLine: boolean;
  arrowParens: 'always' | 'avoid';
  rangeStart: number;
  rangeEnd: number;
  requirePragma: boolean;
  insertPragma: boolean;
  proseWrap: 'always' | 'never' | 'preserve';
  htmlWhitespaceSensitivity: 'css' | 'strict' | 'ignore';
  embeddedLanguageFormatting: 'auto' | 'off';
}

export default function CodeStylingSystem({ isOpen, onClose }: CodeStylingSystemProps) {
  const [selectedLanguage, setSelectedLanguage] = useState('javascript');
  const [selectedProfile, setSelectedProfile] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState('formatting');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [showPreview, setShowPreview] = useState(true);
  const [autoFormatOnSave, setAutoFormatOnSave] = useState(true);
  const [realTimeFormatting, setRealTimeFormatting] = useState(false);
  const [customRules, setCustomRules] = useState<StyleRule[]>([]);
  const [profiles, setProfiles] = useState<LanguageProfile[]>([]);
  const [formattingConfig, setFormattingConfig] = useState<FormattingConfig>({
    indentSize: 2,
    indentType: 'spaces',
    maxLineLength: 120,
    insertFinalNewline: true,
    trimTrailingWhitespace: true,
    bracketSpacing: true,
    semiColons: true,
    singleQuotes: false,
    trailingCommas: false,
    printWidth: 80,
    tabWidth: 2,
    useTabs: false,
    endOfLine: 'lf',
    quoteProps: 'as-needed',
    jsxSingleQuote: false,
    jsxBracketSameLine: false,
    arrowParens: 'always',
    rangeStart: 0,
    rangeEnd: Number.POSITIVE_INFINITY,
    requirePragma: false,
    insertPragma: false,
    proseWrap: 'preserve',
    htmlWhitespaceSensitivity: 'css',
    embeddedLanguageFormatting: 'auto'
  });

  const [selectedCommentingStyle, setSelectedCommentingStyle] = useState('javascript-jsdoc');
  const [customCommentingStyle, setCustomCommentingStyle] = useState<CommentingStyle | null>(null);

  // Predefined commenting styles for different languages
  const commentingStyles: CommentingStyle[] = [
    {
      id: 'javascript-jsdoc',
      name: 'JavaScript JSDoc',
      description: 'Standard JSDoc documentation style for JavaScript and TypeScript',
      singleLine: '// ',
      multiLineStart: '/* ',
      multiLineEnd: ' */',
      docBlockStart: '/**',
      docBlockEnd: ' */',
      docBlockPrefix: ' * ',
      todoFormat: '// TODO: ',
      fixmeFormat: '// FIXME: ',
      hackFormat: '// HACK: ',
      noteFormat: '// NOTE: ',
      headerFormat: '/**\n * {title}\n * {description}\n * \n * @author {author}\n * @version {version}\n * @since {date}\n */',
      sectionFormat: '// ========================================\n// {title}\n// ========================================',
      functionDocFormat: '/**\n * {description}\n * \n * @param {{type}} {name} - {description}\n * @returns {{type}} {description}\n * @throws {{type}} {description}\n * @example\n * {example}\n */',
      classDocFormat: '/**\n * {description}\n * \n * @class {name}\n * @extends {parent}\n * @implements {interface}\n * @author {author}\n * @since {version}\n */',
      paramFormat: '@param {{type}} {name} - {description}',
      returnFormat: '@returns {{type}} {description}',
      exampleFormat: '@example\n * {code}',
      authorFormat: '@author {name} <{email}>',
      dateFormat: '@since {date}',
      versionFormat: '@version {version}',
      sinceFormat: '@since {version}',
      deprecatedFormat: '@deprecated {reason}',
      seeAlsoFormat: '@see {reference}',
      throwsFormat: '@throws {{type}} {description}',
      customTags: {
        module: '@module {name}',
        namespace: '@namespace {name}',
        memberof: '@memberof {parent}',
        static: '@static',
        readonly: '@readonly',
        async: '@async',
        generator: '@generator',
        override: '@override',
        abstract: '@abstract',
        private: '@private',
        protected: '@protected',
        public: '@public'
      }
    },
    {
      id: 'python-docstring',
      name: 'Python Docstring',
      description: 'Python PEP 257 compliant docstring style',
      singleLine: '# ',
      multiLineStart: '""" ',
      multiLineEnd: ' """',
      docBlockStart: '"""',
      docBlockEnd: '"""',
      docBlockPrefix: '',
      todoFormat: '# TODO: ',
      fixmeFormat: '# FIXME: ',
      hackFormat: '# HACK: ',
      noteFormat: '# NOTE: ',
      headerFormat: '"""\n{title}\n\n{description}\n\nAuthor: {author}\nVersion: {version}\nDate: {date}\n"""',
      sectionFormat: '# ==========================================\n# {title}\n# ==========================================',
      functionDocFormat: '"""\n{description}\n\nArgs:\n    {name} ({type}): {description}\n\nReturns:\n    {type}: {description}\n\nRaises:\n    {type}: {description}\n\nExample:\n    {example}\n"""',
      classDocFormat: '"""\n{description}\n\nAttributes:\n    {name} ({type}): {description}\n\nMethods:\n    {name}: {description}\n"""',
      paramFormat: '{name} ({type}): {description}',
      returnFormat: '{type}: {description}',
      exampleFormat: 'Example:\n    {code}',
      authorFormat: 'Author: {name} <{email}>',
      dateFormat: 'Date: {date}',
      versionFormat: 'Version: {version}',
      sinceFormat: 'Since: {version}',
      deprecatedFormat: 'Deprecated: {reason}',
      seeAlsoFormat: 'See Also: {reference}',
      throwsFormat: '{type}: {description}',
      customTags: {
        module: 'Module: {name}',
        package: 'Package: {name}',
        copyright: 'Copyright: {text}',
        license: 'License: {text}',
        maintainer: 'Maintainer: {name}',
        status: 'Status: {status}',
        platform: 'Platform: {platform}'
      }
    },
    {
      id: 'java-javadoc',
      name: 'Java Javadoc',
      description: 'Standard Javadoc documentation style for Java',
      singleLine: '// ',
      multiLineStart: '/* ',
      multiLineEnd: ' */',
      docBlockStart: '/**',
      docBlockEnd: ' */',
      docBlockPrefix: ' * ',
      todoFormat: '// TODO: ',
      fixmeFormat: '// FIXME: ',
      hackFormat: '// HACK: ',
      noteFormat: '// NOTE: ',
      headerFormat: '/**\n * {title}\n * {description}\n * \n * @author {author}\n * @version {version}\n * @since {date}\n */',
      sectionFormat: '// ========================================\n// {title}\n// ========================================',
      functionDocFormat: '/**\n * {description}\n * \n * @param {name} {description}\n * @return {description}\n * @throws {type} {description}\n * @see {reference}\n * @since {version}\n */',
      classDocFormat: '/**\n * {description}\n * \n * @author {author}\n * @version {version}\n * @since {date}\n * @see {reference}\n */',
      paramFormat: '@param {name} {description}',
      returnFormat: '@return {description}',
      exampleFormat: '@code\n * {code}\n * @endcode',
      authorFormat: '@author {name}',
      dateFormat: '@since {date}',
      versionFormat: '@version {version}',
      sinceFormat: '@since {version}',
      deprecatedFormat: '@deprecated {reason}',
      seeAlsoFormat: '@see {reference}',
      throwsFormat: '@throws {type} {description}',
      customTags: {
        apiNote: '@apiNote {note}',
        implSpec: '@implSpec {specification}',
        implNote: '@implNote {note}',
        inheritDoc: '@inheritDoc',
        link: '@link {reference}',
        linkplain: '@linkplain {reference}',
        literal: '@literal {text}',
        code: '@code {code}',
        value: '@value {field}',
        serial: '@serial {description}',
        serialData: '@serialData {description}',
        serialField: '@serialField {description}'
      }
    },
    {
      id: 'csharp-xmldoc',
      name: 'C# XML Documentation',
      description: 'Microsoft XML documentation style for C#',
      singleLine: '// ',
      multiLineStart: '/* ',
      multiLineEnd: ' */',
      docBlockStart: '/// <summary>',
      docBlockEnd: '/// </summary>',
      docBlockPrefix: '/// ',
      todoFormat: '// TODO: ',
      fixmeFormat: '// FIXME: ',
      hackFormat: '// HACK: ',
      noteFormat: '// NOTE: ',
      headerFormat: '/// <summary>\n/// {title}\n/// {description}\n/// </summary>\n/// <author>{author}</author>\n/// <version>{version}</version>\n/// <date>{date}</date>',
      sectionFormat: '// ========================================\n// {title}\n// ========================================',
      functionDocFormat: '/// <summary>\n/// {description}\n/// </summary>\n/// <param name="{name}">{description}</param>\n/// <returns>{description}</returns>\n/// <exception cref="{type}">{description}</exception>\n/// <example>\n/// {example}\n/// </example>',
      classDocFormat: '/// <summary>\n/// {description}\n/// </summary>\n/// <author>{author}</author>\n/// <version>{version}</version>',
      paramFormat: '<param name="{name}">{description}</param>',
      returnFormat: '<returns>{description}</returns>',
      exampleFormat: '<example>\n{code}\n</example>',
      authorFormat: '<author>{name}</author>',
      dateFormat: '<date>{date}</date>',
      versionFormat: '<version>{version}</version>',
      sinceFormat: '<since>{version}</since>',
      deprecatedFormat: '<obsolete>{reason}</obsolete>',
      seeAlsoFormat: '<seealso cref="{reference}"/>',
      throwsFormat: '<exception cref="{type}">{description}</exception>',
      customTags: {
        remarks: '<remarks>{text}</remarks>',
        value: '<value>{description}</value>',
        permission: '<permission cref="{type}">{description}</permission>',
        include: '<include file="{file}" path="{path}"/>',
        inheritdoc: '<inheritdoc/>',
        typeparam: '<typeparam name="{name}">{description}</typeparam>',
        typeparamref: '<typeparamref name="{name}"/>',
        paramref: '<paramref name="{name}"/>',
        c: '<c>{code}</c>',
        code: '<code>{code}</code>',
        list: '<list type="{type}">{items}</list>',
        para: '<para>{text}</para>'
      }
    },
    {
      id: 'cpp-doxygen',
      name: 'C++ Doxygen',
      description: 'Doxygen documentation style for C/C++',
      singleLine: '// ',
      multiLineStart: '/* ',
      multiLineEnd: ' */',
      docBlockStart: '/**',
      docBlockEnd: ' */',
      docBlockPrefix: ' * ',
      todoFormat: '// TODO: ',
      fixmeFormat: '// FIXME: ',
      hackFormat: '// HACK: ',
      noteFormat: '// NOTE: ',
      headerFormat: '/**\n * \\file {filename}\n * \\brief {title}\n * \\details {description}\n * \\author {author}\n * \\version {version}\n * \\date {date}\n */',
      sectionFormat: '// ========================================\n// {title}\n// ========================================',
      functionDocFormat: '/**\n * \\brief {description}\n * \\param {name} {description}\n * \\return {description}\n * \\throw {type} {description}\n * \\code\n * {example}\n * \\endcode\n */',
      classDocFormat: '/**\n * \\class {name}\n * \\brief {description}\n * \\author {author}\n * \\version {version}\n */',
      paramFormat: '\\param {name} {description}',
      returnFormat: '\\return {description}',
      exampleFormat: '\\code\n{code}\n\\endcode',
      authorFormat: '\\author {name}',
      dateFormat: '\\date {date}',
      versionFormat: '\\version {version}',
      sinceFormat: '\\since {version}',
      deprecatedFormat: '\\deprecated {reason}',
      seeAlsoFormat: '\\see {reference}',
      throwsFormat: '\\throw {type} {description}',
      customTags: {
        file: '\\file {filename}',
        brief: '\\brief {description}',
        details: '\\details {description}',
        namespace: '\\namespace {name}',
        typedef: '\\typedef {type}',
        struct: '\\struct {name}',
        union: '\\union {name}',
        enum: '\\enum {name}',
        var: '\\var {name}',
        def: '\\def {name}',
        fn: '\\fn {signature}',
        overload: '\\overload',
        memberof: '\\memberof {class}',
        relates: '\\relates {class}',
        relatesalso: '\\relatesalso {class}'
      }
    },
    {
      id: 'rust-rustdoc',
      name: 'Rust Documentation',
      description: 'Rust standard documentation style',
      singleLine: '// ',
      multiLineStart: '/* ',
      multiLineEnd: ' */',
      docBlockStart: '///',
      docBlockEnd: '',
      docBlockPrefix: '/// ',
      todoFormat: '// TODO: ',
      fixmeFormat: '// FIXME: ',
      hackFormat: '// HACK: ',
      noteFormat: '// NOTE: ',
      headerFormat: '//! {title}\n//!\n//! {description}\n//!\n//! # Author\n//! {author}\n//!\n//! # Version\n//! {version}',
      sectionFormat: '// ========================================\n// {title}\n// ========================================',
      functionDocFormat: '/// {description}\n///\n/// # Arguments\n///\n/// * `{name}` - {description}\n///\n/// # Returns\n///\n/// {description}\n///\n/// # Errors\n///\n/// {description}\n///\n/// # Examples\n///\n/// ```\n/// {example}\n/// ```',
      classDocFormat: '/// {description}\n///\n/// # Examples\n///\n/// ```\n/// {example}\n/// ```',
      paramFormat: '* `{name}` - {description}',
      returnFormat: '{description}',
      exampleFormat: '# Examples\n\n```\n{code}\n```',
      authorFormat: '# Author\n{name}',
      dateFormat: '# Date\n{date}',
      versionFormat: '# Version\n{version}',
      sinceFormat: '# Since\n{version}',
      deprecatedFormat: '# Deprecated\n{reason}',
      seeAlsoFormat: '# See also\n[{reference}]',
      throwsFormat: '# Errors\n{description}',
      customTags: {
        panic: '# Panics\n{description}',
        safety: '# Safety\n{description}',
        abort: '# Aborts\n{description}',
        undefined: '# Undefined Behavior\n{description}',
        implementation: '# Implementation Notes\n{description}',
        platform: '# Platform-specific\n{description}',
        feature: '# Feature\n{description}',
        stability: '# Stability\n{description}'
      }
    }
  ]

  const languages = [
    'javascript', 'typescript', 'python', 'java', 'csharp', 'cpp', 'c', 'rust', 
    'go', 'php', 'ruby', 'swift', 'kotlin', 'dart', 'scala', 'haskell', 'elixir',
    'crystal', 'nim', 'zig', 'lua', 'perl', 'r', 'julia', 'html', 'css', 'scss',
    'less', 'json', 'yaml', 'xml', 'markdown', 'sql', 'bash', 'powershell'
  ];

  const categories = [
    'formatting', 'naming', 'complexity', 'security', 'performance', 
    'best-practices', 'documentation', 'imports', 'variables', 'functions',
    'classes', 'errors', 'testing', 'accessibility', 'compatibility', 'commenting'
  ];

  const severityColors = {
    error: '#ff4757',
    warning: '#ffa502',
    info: '#3742fa',
    suggestion: '#2ed573'
  };

  const defaultRules: StyleRule[] = [
    {
      id: 'js-indent',
      name: 'Consistent Indentation',
      language: 'javascript',
      category: 'formatting',
      description: 'Enforce consistent indentation using spaces or tabs',
      rule: 'indent',
      example: `// Good\nfunction example() {\n  return true;\n}\n\n// Bad\nfunction example() {\n    return true;\n}`,
      severity: 'error',
      enabled: true,
      customizable: true,
      autoFix: true
    },
    {
      id: 'js-semicolon',
      name: 'Semicolon Usage',
      language: 'javascript',
      category: 'formatting',
      description: 'Require or disallow semicolons',
      rule: 'semi',
      example: `// Good\nconst x = 1;\n\n// Bad\nconst x = 1`,
      severity: 'warning',
      enabled: true,
      customizable: true,
      autoFix: true
    },
    {
      id: 'js-quotes',
      name: 'Quote Style',
      language: 'javascript',
      category: 'formatting',
      description: 'Enforce consistent quote style',
      rule: 'quotes',
      example: `// Good\nconst str = "hello";\n\n// Bad\nconst str = 'hello';`,
      severity: 'warning',
      enabled: true,
      customizable: true,
      autoFix: true
    },
    {
      id: 'js-no-unused-vars',
      name: 'No Unused Variables',
      language: 'javascript',
      category: 'best-practices',
      description: 'Disallow unused variables',
      rule: 'no-unused-vars',
      example: `// Good\nconst x = 1;\nconsole.log(x);\n\n// Bad\nconst y = 2; // unused`,
      severity: 'warning',
      enabled: true,
      customizable: false,
      autoFix: false
    },
    {
      id: 'py-indent',
      name: 'PEP 8 Indentation',
      language: 'python',
      category: 'formatting',
      description: 'Use 4 spaces for indentation as per PEP 8',
      rule: 'E111',
      example: `# Good\ndef example():\n    return True\n\n# Bad\ndef example():\n  return True`,
      severity: 'error',
      enabled: true,
      customizable: true,
      autoFix: true
    },
    {
      id: 'py-line-length',
      name: 'Maximum Line Length',
      language: 'python',
      category: 'formatting',
      description: 'Limit line length to 79 characters',
      rule: 'E501',
      example: `# Good\nshort_line = "This is within limits"\n\n# Bad\nvery_long_line = "This line exceeds the maximum length limit and should be broken into multiple lines"`,
      severity: 'warning',
      enabled: true,
      customizable: true,
      autoFix: false
    },
    {
      id: 'java-naming',
      name: 'CamelCase Naming',
      language: 'java',
      category: 'naming',
      description: 'Use camelCase for variable and method names',
      rule: 'CamelCase',
      example: `// Good\nString userName = "john";\n\n// Bad\nString user_name = "john";`,
      severity: 'warning',
      enabled: true,
      customizable: false,
      autoFix: false
    },
    {
      id: 'css-property-order',
      name: 'Property Ordering',
      language: 'css',
      category: 'formatting',
      description: 'Order CSS properties alphabetically',
      rule: 'order/properties-alphabetical-order',
      example: `.example {\n  background: white;\n  color: black;\n  margin: 10px;\n  padding: 5px;\n}`,
      severity: 'suggestion',
      enabled: false,
      customizable: true,
      autoFix: true
    }
  ];

  const previewCode = {
    javascript: `function calculateTotal(items, tax = 0.08) {
  const subtotal = items.reduce((sum, item) => {
    return sum + (item.price * item.quantity);
  }, 0);
  
  const taxAmount = subtotal * tax;
  const total = subtotal + taxAmount;
  
  return {
    subtotal: subtotal.toFixed(2),
    tax: taxAmount.toFixed(2),
    total: total.toFixed(2)
  };
}

// Usage example
const cartItems = [
  { name: "Widget", price: 12.99, quantity: 2 },
  { name: "Gadget", price: 25.50, quantity: 1 }
];

const result = calculateTotal(cartItems);
console.log(\`Total: $\${result.total}\`);`,
    
    python: `def calculate_fibonacci(n):
    """Calculate the nth Fibonacci number."""
    if n <= 1:
        return n
    
    a, b = 0, 1
    for i in range(2, n + 1):
        a, b = b, a + b
    
    return b

def main():
    """Main function to demonstrate Fibonacci calculation."""
    numbers = [5, 10, 15, 20]
    
    for num in numbers:
        fib_value = calculate_fibonacci(num)
        print(f"Fibonacci({num}) = {fib_value}")

if __name__ == "__main__":
    main()`,
    
    java: `public class StringUtils {
    
    public static String reverseString(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        
        StringBuilder reversed = new StringBuilder();
        for (int i = input.length() - 1; i >= 0; i--) {
            reversed.append(input.charAt(i));
        }
        
        return reversed.toString();
    }
    
    public static boolean isPalindrome(String input) {
        String cleaned = input.toLowerCase().replaceAll("[^a-zA-Z0-9]", "");
        String reversed = reverseString(cleaned);
        return cleaned.equals(reversed);
    }
    
    public static void main(String[] args) {
        String text = "A man a plan a canal Panama";
        System.out.println("Is palindrome: " + isPalindrome(text));
    }
}`
  };

  const filteredRules = defaultRules.filter(rule => {
    const matchesLanguage = rule.language === selectedLanguage;
    const matchesSearch = rule.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         rule.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSeverity = filterSeverity === 'all' || rule.severity === filterSeverity;
    
    return matchesLanguage && matchesSearch && matchesSeverity;
  });

  const createProfile = () => {
    const newProfile: LanguageProfile = {
      id: `profile-${Date.now()}`,
      name: `${selectedLanguage} Profile`,
      language: selectedLanguage,
      description: `Custom styling profile for ${selectedLanguage}`,
      rules: filteredRules.filter(r => r.enabled).map(r => r.id),
      indentSize: formattingConfig.indentSize,
      indentType: formattingConfig.indentType,
      maxLineLength: formattingConfig.maxLineLength,
      insertFinalNewline: formattingConfig.insertFinalNewline,
      trimTrailingWhitespace: formattingConfig.trimTrailingWhitespace,
      created: new Date(),
      modified: new Date()
    };

    setProfiles(prev => [...prev, newProfile]);
    setSelectedProfile(newProfile.id);
  };

  const exportConfiguration = () => {
    const config = {
      language: selectedLanguage,
      rules: filteredRules.filter(r => r.enabled),
      formatting: formattingConfig,
      profiles: profiles,
      meta: {
        version: '1.0',
        exported: new Date().toISOString(),
        tool: 'DeepBlue IDE Code Styling System'
      }
    };

    const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `code-style-${selectedLanguage}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const formatCode = (code: string): string => {
    // Simplified formatting logic for demonstration
    let formatted = code;
    
    if (formattingConfig.trimTrailingWhitespace) {
      formatted = formatted.replace(/[ \t]+$/gm, '');
    }
    
    if (formattingConfig.insertFinalNewline && !formatted.endsWith('\n')) {
      formatted += '\n';
    }
    
    return formatted;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <Card className="w-[95vw] h-[95vh] max-w-none max-h-none bg-[var(--ide-surface)] border-[var(--ide-border)]">
        <CardHeader className="flex flex-row items-center justify-between py-3 px-4 border-b border-[var(--ide-border)]">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Brush className="h-5 w-5 text-[var(--ide-accent)]" />
              <h2 className="text-lg font-semibold text-[var(--ide-text)]">Code Styling System</h2>
            </div>
            
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map(lang => (
                  <SelectItem key={lang} value={lang}>
                    {lang.charAt(0).toUpperCase() + lang.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Badge variant="outline" className="text-[var(--ide-text)]">
              {filteredRules.length} Rules • {filteredRules.filter(r => r.enabled).length} Active
            </Badge>
          </div>

          <div className="flex items-center gap-2">
            <TooltipWrapper
              title="Save Configuration"
              content="Save the current styling configuration for this language"
              type="feature"
            >
              <SoundButton variant="outline" size="sm" onClick={createProfile}>
                <Save className="h-4 w-4" />
              </SoundButton>
            </TooltipWrapper>

            <TooltipWrapper
              title="Export Configuration"
              content="Export styling rules and configuration as JSON file"
              type="feature"
            >
              <SoundButton variant="outline" size="sm" onClick={exportConfiguration}>
                <Download className="h-4 w-4" />
              </SoundButton>
            </TooltipWrapper>

            <SoundButton variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </SoundButton>
          </div>
        </CardHeader>

        <CardContent className="p-0 h-full">
          <div className="flex h-full">
            {/* Configuration Panel */}
            <div className="w-80 border-r border-[var(--ide-border)] bg-[var(--ide-surface-secondary)] flex flex-col">
              <Tabs value={activeCategory} onValueChange={setActiveCategory} className="h-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="rules">Rules</TabsTrigger>
                  <TabsTrigger value="formatting">Format</TabsTrigger>
                  <TabsTrigger value="commenting">Comments</TabsTrigger>
                  <TabsTrigger value="profiles">Profiles</TabsTrigger>
                </TabsList>

                <TabsContent value="rules" className="flex-1 p-4 space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Search className="h-4 w-4 text-[var(--ide-text-secondary)]" />
                      <Input
                        placeholder="Search rules..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="flex-1"
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <Filter className="h-4 w-4 text-[var(--ide-text-secondary)]" />
                      <Select value={filterSeverity} onValueChange={setFilterSeverity}>
                        <SelectTrigger className="flex-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Severities</SelectItem>
                          <SelectItem value="error">Errors</SelectItem>
                          <SelectItem value="warning">Warnings</SelectItem>
                          <SelectItem value="info">Info</SelectItem>
                          <SelectItem value="suggestion">Suggestions</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <ScrollArea className="h-[500px]">
                      <div className="space-y-3">
                        {categories.map(category => {
                          const categoryRules = filteredRules.filter(r => r.category === category);
                          if (categoryRules.length === 0) return null;

                          return (
                            <div key={category} className="space-y-2">
                              <h4 className="text-sm font-medium text-[var(--ide-text)] capitalize">
                                {category.replace('-', ' ')}
                              </h4>
                              {categoryRules.map(rule => (
                                <div key={rule.id} className="p-3 rounded bg-[var(--ide-surface)] border border-[var(--ide-border)]">
                                  <div className="flex items-start justify-between">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2">
                                        <h5 className="text-sm font-medium text-[var(--ide-text)]">{rule.name}</h5>
                                        <div 
                                          className="w-2 h-2 rounded-full"
                                          style={{ backgroundColor: severityColors[rule.severity] }}
                                        />
                                        {rule.autoFix && (
                                          <Zap className="h-3 w-3 text-[var(--ide-accent)]" />
                                        )}
                                      </div>
                                      <p className="text-xs text-[var(--ide-text-secondary)] mt-1">
                                        {rule.description}
                                      </p>
                                      <Badge variant="outline" className="text-xs mt-2">
                                        {rule.rule}
                                      </Badge>
                                    </div>
                                    <Switch
                                      checked={rule.enabled}
                                      onCheckedChange={(checked) => {
                                        // Update rule enabled state
                                        rule.enabled = checked;
                                      }}
                                    />
                                  </div>
                                </div>
                              ))}
                            </div>
                          );
                        })}
                      </div>
                    </ScrollArea>
                  </div>
                </TabsContent>

                <TabsContent value="formatting" className="flex-1 p-4 space-y-4">
                  <ScrollArea className="h-[600px]">
                    <div className="space-y-4">
                      <h4 className="text-sm font-medium text-[var(--ide-text)]">Indentation</h4>
                      
                      <div className="space-y-3">
                        <div>
                          <Label className="text-xs text-[var(--ide-text-secondary)]">Indent Type</Label>
                          <Select 
                            value={formattingConfig.indentType} 
                            onValueChange={(value: 'spaces' | 'tabs') => 
                              setFormattingConfig(prev => ({ ...prev, indentType: value }))
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="spaces">Spaces</SelectItem>
                              <SelectItem value="tabs">Tabs</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label className="text-xs text-[var(--ide-text-secondary)]">
                            Indent Size: {formattingConfig.indentSize}
                          </Label>
                          <Slider
                            value={[formattingConfig.indentSize]}
                            onValueChange={([value]) => 
                              setFormattingConfig(prev => ({ ...prev, indentSize: value }))
                            }
                            min={1}
                            max={8}
                            step={1}
                            className="mt-2"
                          />
                        </div>

                        <div>
                          <Label className="text-xs text-[var(--ide-text-secondary)]">
                            Max Line Length: {formattingConfig.maxLineLength}
                          </Label>
                          <Slider
                            value={[formattingConfig.maxLineLength]}
                            onValueChange={([value]) => 
                              setFormattingConfig(prev => ({ ...prev, maxLineLength: value }))
                            }
                            min={80}
                            max={200}
                            step={10}
                            className="mt-2"
                          />
                        </div>
                      </div>

                      <Separator />

                      <h4 className="text-sm font-medium text-[var(--ide-text)]">Formatting Options</h4>
                      
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label className="text-xs text-[var(--ide-text-secondary)]">Insert Final Newline</Label>
                          <Switch
                            checked={formattingConfig.insertFinalNewline}
                            onCheckedChange={(checked) => 
                              setFormattingConfig(prev => ({ ...prev, insertFinalNewline: checked }))
                            }
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <Label className="text-xs text-[var(--ide-text-secondary)]">Trim Trailing Whitespace</Label>
                          <Switch
                            checked={formattingConfig.trimTrailingWhitespace}
                            onCheckedChange={(checked) => 
                              setFormattingConfig(prev => ({ ...prev, trimTrailingWhitespace: checked }))
                            }
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <Label className="text-xs text-[var(--ide-text-secondary)]">Bracket Spacing</Label>
                          <Switch
                            checked={formattingConfig.bracketSpacing}
                            onCheckedChange={(checked) => 
                              setFormattingConfig(prev => ({ ...prev, bracketSpacing: checked }))
                            }
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <Label className="text-xs text-[var(--ide-text-secondary)]">Single Quotes</Label>
                          <Switch
                            checked={formattingConfig.singleQuotes}
                            onCheckedChange={(checked) => 
                              setFormattingConfig(prev => ({ ...prev, singleQuotes: checked }))
                            }
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <Label className="text-xs text-[var(--ide-text-secondary)]">Semicolons</Label>
                          <Switch
                            checked={formattingConfig.semiColons}
                            onCheckedChange={(checked) => 
                              setFormattingConfig(prev => ({ ...prev, semiColons: checked }))
                            }
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <Label className="text-xs text-[var(--ide-text-secondary)]">Trailing Commas</Label>
                          <Switch
                            checked={formattingConfig.trailingCommas}
                            onCheckedChange={(checked) => 
                              setFormattingConfig(prev => ({ ...prev, trailingCommas: checked }))
                            }
                          />
                        </div>
                      </div>

                      <Separator />

                      <h4 className="text-sm font-medium text-[var(--ide-text)]">Auto-Formatting</h4>
                      
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label className="text-xs text-[var(--ide-text-secondary)]">Format on Save</Label>
                          <Switch
                            checked={autoFormatOnSave}
                            onCheckedChange={setAutoFormatOnSave}
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <Label className="text-xs text-[var(--ide-text-secondary)]">Real-time Formatting</Label>
                          <Switch
                            checked={realTimeFormatting}
                            onCheckedChange={setRealTimeFormatting}
                          />
                        </div>
                      </div>
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="commenting" className="flex-1 p-4 space-y-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-medium text-[var(--ide-text)]">Commenting Styles</h4>
                      <Badge variant="outline" className="text-xs">
                        {commentingStyles.length} styles
                      </Badge>
                    </div>

                    <div className="space-y-3">
                      <label className="text-xs font-medium text-[var(--ide-text-secondary)]">
                        Language-Specific Style
                      </label>
                      <Select value={selectedCommentingStyle} onValueChange={setSelectedCommentingStyle}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select commenting style" />
                        </SelectTrigger>
                        <SelectContent>
                          {commentingStyles.map(style => (
                            <SelectItem key={style.id} value={style.id}>
                              {style.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-[var(--ide-text-secondary)]">
                        {commentingStyles.find(s => s.id === selectedCommentingStyle)?.description}
                      </p>
                    </div>

                    <ScrollArea className="h-[400px]">
                      <div className="space-y-4">
                        {(() => {
                          const currentStyle = commentingStyles.find(s => s.id === selectedCommentingStyle);
                          if (!currentStyle) return null;

                          return (
                            <div className="space-y-4">
                              {/* Basic Comment Formats */}
                              <div className="space-y-3">
                                <h5 className="text-xs font-medium text-[var(--ide-text)] border-b border-[var(--ide-border)] pb-1">
                                  Basic Comments
                                </h5>
                                
                                <div className="grid grid-cols-1 gap-3">
                                  <div className="space-y-1">
                                    <label className="text-xs text-[var(--ide-text-secondary)]">Single Line</label>
                                    <div className="p-2 bg-[var(--ide-surface)] rounded border text-xs font-mono text-[var(--ide-text)]">
                                      {currentStyle.singleLine}This is a single line comment
                                    </div>
                                  </div>
                                  
                                  <div className="space-y-1">
                                    <label className="text-xs text-[var(--ide-text-secondary)]">Multi Line</label>
                                    <div className="p-2 bg-[var(--ide-surface)] rounded border text-xs font-mono text-[var(--ide-text)]">
                                      {currentStyle.multiLineStart}This is a<br />
                                      multi-line comment{currentStyle.multiLineEnd}
                                    </div>
                                  </div>
                                  
                                  <div className="space-y-1">
                                    <label className="text-xs text-[var(--ide-text-secondary)]">Documentation Block</label>
                                    <div className="p-2 bg-[var(--ide-surface)] rounded border text-xs font-mono text-[var(--ide-text)]">
                                      {currentStyle.docBlockStart}<br />
                                      {currentStyle.docBlockPrefix}Function description here<br />
                                      {currentStyle.docBlockEnd}
                                    </div>
                                  </div>
                                </div>
                              </div>

                              {/* Special Comment Types */}
                              <div className="space-y-3">
                                <h5 className="text-xs font-medium text-[var(--ide-text)] border-b border-[var(--ide-border)] pb-1">
                                  Special Comments
                                </h5>
                                
                                <div className="grid grid-cols-2 gap-2">
                                  <div className="space-y-1">
                                    <label className="text-xs text-[var(--ide-text-secondary)]">TODO</label>
                                    <div className="p-2 bg-[var(--ide-surface)] rounded border text-xs font-mono text-[var(--ide-text)]">
                                      {currentStyle.todoFormat}Implement feature
                                    </div>
                                  </div>
                                  
                                  <div className="space-y-1">
                                    <label className="text-xs text-[var(--ide-text-secondary)]">FIXME</label>
                                    <div className="p-2 bg-[var(--ide-surface)] rounded border text-xs font-mono text-[var(--ide-text)]">
                                      {currentStyle.fixmeFormat}Fix this bug
                                    </div>
                                  </div>
                                  
                                  <div className="space-y-1">
                                    <label className="text-xs text-[var(--ide-text-secondary)]">HACK</label>
                                    <div className="p-2 bg-[var(--ide-surface)] rounded border text-xs font-mono text-[var(--ide-text)]">
                                      {currentStyle.hackFormat}Temporary solution
                                    </div>
                                  </div>
                                  
                                  <div className="space-y-1">
                                    <label className="text-xs text-[var(--ide-text-secondary)]">NOTE</label>
                                    <div className="p-2 bg-[var(--ide-surface)] rounded border text-xs font-mono text-[var(--ide-text)]">
                                      {currentStyle.noteFormat}Important note
                                    </div>
                                  </div>
                                </div>
                              </div>

                              {/* Documentation Formats */}
                              <div className="space-y-3">
                                <h5 className="text-xs font-medium text-[var(--ide-text)] border-b border-[var(--ide-border)] pb-1">
                                  Documentation Templates
                                </h5>
                                
                                <div className="space-y-3">
                                  <div className="space-y-1">
                                    <label className="text-xs text-[var(--ide-text-secondary)]">Function Documentation</label>
                                    <div className="p-2 bg-[var(--ide-surface)] rounded border text-xs font-mono text-[var(--ide-text)] whitespace-pre-line">
                                      {currentStyle.functionDocFormat
                                        .replace('{description}', 'Function description')
                                        .replace('{name}', 'paramName')
                                        .replace('{type}', 'string')
                                        .replace('{example}', 'example code here')}
                                    </div>
                                  </div>
                                  
                                  <div className="space-y-1">
                                    <label className="text-xs text-[var(--ide-text-secondary)]">Class Documentation</label>
                                    <div className="p-2 bg-[var(--ide-surface)] rounded border text-xs font-mono text-[var(--ide-text)] whitespace-pre-line">
                                      {currentStyle.classDocFormat
                                        .replace('{description}', 'Class description')
                                        .replace('{name}', 'ClassName')
                                        .replace('{author}', 'Author Name')}
                                    </div>
                                  </div>
                                  
                                  <div className="space-y-1">
                                    <label className="text-xs text-[var(--ide-text-secondary)]">File Header</label>
                                    <div className="p-2 bg-[var(--ide-surface)] rounded border text-xs font-mono text-[var(--ide-text)] whitespace-pre-line">
                                      {currentStyle.headerFormat
                                        .replace('{title}', 'File Title')
                                        .replace('{description}', 'File description')
                                        .replace('{author}', 'Author Name')
                                        .replace('{version}', '1.0.0')
                                        .replace('{date}', new Date().toLocaleDateString())}
                                    </div>
                                  </div>
                                </div>
                              </div>

                              {/* Custom Tags */}
                              <div className="space-y-3">
                                <h5 className="text-xs font-medium text-[var(--ide-text)] border-b border-[var(--ide-border)] pb-1">
                                  Custom Tags ({Object.keys(currentStyle.customTags).length})
                                </h5>
                                
                                <div className="grid grid-cols-1 gap-2 max-h-32 overflow-y-auto">
                                  {Object.entries(currentStyle.customTags).map(([key, value]) => (
                                    <div key={key} className="flex items-center justify-between p-2 bg-[var(--ide-surface)] rounded border">
                                      <span className="text-xs font-medium text-[var(--ide-text)]">{key}</span>
                                      <span className="text-xs font-mono text-[var(--ide-text-secondary)]">{value}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          );
                        })()}
                      </div>
                    </ScrollArea>

                    <div className="flex items-center justify-between pt-2 border-t border-[var(--ide-border)]">
                      <div className="flex items-center gap-2">
                        <SoundButton size="sm" variant="outline">
                          <Plus className="h-3 w-3 mr-1" />
                          Create Custom
                        </SoundButton>
                        <SoundButton size="sm" variant="outline">
                          <Download className="h-3 w-3 mr-1" />
                          Export
                        </SoundButton>
                      </div>
                      <SoundButton size="sm">
                        <Save className="h-3 w-3 mr-1" />
                        Apply Style
                      </SoundButton>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="profiles" className="flex-1 p-4 space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-medium text-[var(--ide-text)]">Saved Profiles</h4>
                      <SoundButton size="sm" onClick={createProfile}>
                        <Plus className="h-3 w-3 mr-1" />
                        Create
                      </SoundButton>
                    </div>

                    <ScrollArea className="h-[500px]">
                      {profiles.length === 0 ? (
                        <div className="text-center py-8">
                          <Settings className="h-8 w-8 text-[var(--ide-text-secondary)] mx-auto mb-2" />
                          <p className="text-sm text-[var(--ide-text-secondary)]">No profiles created yet</p>
                          <p className="text-xs text-[var(--ide-text-secondary)] mt-1">
                            Create a profile to save your styling configuration
                          </p>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {profiles.map(profile => (
                            <div 
                              key={profile.id} 
                              className={`p-3 rounded border cursor-pointer transition-colors ${
                                selectedProfile === profile.id 
                                  ? 'bg-[var(--ide-accent)]/20 border-[var(--ide-accent)]' 
                                  : 'bg-[var(--ide-surface)] border-[var(--ide-border)] hover:bg-[var(--ide-surface-secondary)]'
                              }`}
                              onClick={() => setSelectedProfile(profile.id)}
                            >
                              <div className="flex items-start justify-between">
                                <div className="flex-1">
                                  <h5 className="text-sm font-medium text-[var(--ide-text)]">{profile.name}</h5>
                                  <p className="text-xs text-[var(--ide-text-secondary)] mt-1">
                                    {profile.description}
                                  </p>
                                  <div className="flex items-center gap-2 mt-2">
                                    <Badge variant="outline" className="text-xs">
                                      {profile.language}
                                    </Badge>
                                    <Badge variant="outline" className="text-xs">
                                      {profile.rules.length} rules
                                    </Badge>
                                  </div>
                                </div>
                                <SoundButton size="sm" variant="ghost">
                                  <Trash2 className="h-3 w-3" />
                                </SoundButton>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </ScrollArea>
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Code Preview Panel */}
            <div className="flex-1 flex flex-col">
              {/* Preview Header */}
              <div className="border-b border-[var(--ide-border)] p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4 text-[var(--ide-accent)]" />
                    <h3 className="text-sm font-medium text-[var(--ide-text)]">Code Preview</h3>
                    <Badge variant="outline" className="text-xs">
                      {selectedLanguage}
                    </Badge>
                  </div>

                  <div className="flex items-center gap-2">
                    <TooltipWrapper
                      title="Format Code"
                      content="Apply current formatting rules to the preview code"
                      type="tip"
                    >
                      <SoundButton size="sm" variant="outline">
                        <Brush className="h-3 w-3" />
                      </SoundButton>
                    </TooltipWrapper>

                    <TooltipWrapper
                      title="Copy Code"
                      content="Copy the formatted code to clipboard"
                      type="tip"
                    >
                      <SoundButton size="sm" variant="outline">
                        <Copy className="h-3 w-3" />
                      </SoundButton>
                    </TooltipWrapper>

                    <Switch
                      checked={showPreview}
                      onCheckedChange={setShowPreview}
                    />
                  </div>
                </div>
              </div>

              {/* Code Display */}
              {showPreview && (
                <div className="flex-1 p-4">
                  <div className="h-full rounded border border-[var(--ide-border)] bg-[var(--ide-background)]">
                    <pre className="h-full p-4 overflow-auto text-sm font-mono text-[var(--ide-text)]">
                      <code>
                        {previewCode[selectedLanguage as keyof typeof previewCode] || '// No preview available for this language'}
                      </code>
                    </pre>
                  </div>
                </div>
              )}

              {/* Status Bar */}
              <div className="border-t border-[var(--ide-border)] p-2">
                <div className="flex items-center justify-between text-xs text-[var(--ide-text-secondary)]">
                  <div className="flex items-center gap-4">
                    <span>Language: {selectedLanguage}</span>
                    <span>Rules: {filteredRules.filter(r => r.enabled).length} active</span>
                    <span>Auto-format: {autoFormatOnSave ? 'ON' : 'OFF'}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span>Indent: {formattingConfig.indentSize} {formattingConfig.indentType}</span>
                    <span>Max length: {formattingConfig.maxLineLength}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}