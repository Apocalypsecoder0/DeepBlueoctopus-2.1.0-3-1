import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";
import { 
  Shield, Lock, Key, AlertTriangle, CheckCircle, 
  Eye, EyeOff, Scan, UserCheck, Database,
  FileCheck, Globe, Wifi, Settings, Zap
} from "lucide-react";

interface ComprehensiveSecuritySystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SecurityCheck {
  id: string;
  name: string;
  category: 'authentication' | 'encryption' | 'network' | 'files' | 'dependencies';
  status: 'passed' | 'failed' | 'warning' | 'checking';
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  recommendation?: string;
  lastChecked: Date;
}

interface SecurityMetric {
  name: string;
  value: number;
  maxValue: number;
  status: 'good' | 'warning' | 'critical';
  trend: 'up' | 'down' | 'stable';
}

const SECURITY_CHECKS: SecurityCheck[] = [
  {
    id: 'auth-strength',
    name: 'Password Strength Policy',
    category: 'authentication',
    status: 'passed',
    severity: 'high',
    description: 'Strong password requirements are enforced',
    recommendation: 'Consider implementing MFA for additional security',
    lastChecked: new Date()
  },
  {
    id: 'ssl-cert',
    name: 'SSL Certificate Validation',
    category: 'network',
    status: 'passed',
    severity: 'critical',
    description: 'Valid SSL certificate with proper encryption',
    lastChecked: new Date()
  },
  {
    id: 'dependency-audit',
    name: 'Dependency Vulnerability Scan',
    category: 'dependencies',
    status: 'warning',
    severity: 'medium',
    description: '2 dependencies have known vulnerabilities',
    recommendation: 'Update lodash to version 4.17.21 and axios to version 1.6.0',
    lastChecked: new Date()
  },
  {
    id: 'file-permissions',
    name: 'File Permission Security',
    category: 'files',
    status: 'passed',
    severity: 'medium',
    description: 'Proper file access controls are in place',
    lastChecked: new Date()
  },
  {
    id: 'data-encryption',
    name: 'Data Encryption at Rest',
    category: 'encryption',
    status: 'failed',
    severity: 'high',
    description: 'Sensitive data is not encrypted in storage',
    recommendation: 'Enable database encryption and encrypt sensitive file contents',
    lastChecked: new Date()
  }
];

const SECURITY_METRICS: SecurityMetric[] = [
  {
    name: 'Security Score',
    value: 85,
    maxValue: 100,
    status: 'good',
    trend: 'up'
  },
  {
    name: 'Vulnerabilities',
    value: 3,
    maxValue: 0,
    status: 'warning',
    trend: 'down'
  },
  {
    name: 'Access Attempts',
    value: 12,
    maxValue: 50,
    status: 'good',
    trend: 'stable'
  },
  {
    name: 'Encryption Coverage',
    value: 78,
    maxValue: 100,
    status: 'warning',
    trend: 'up'
  }
];

export default function ComprehensiveSecuritySystem({ isOpen, onClose }: ComprehensiveSecuritySystemProps) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [checks, setChecks] = useState<SecurityCheck[]>(SECURITY_CHECKS);
  const [metrics, setMetrics] = useState<SecurityMetric[]>(SECURITY_METRICS);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [autoScan, setAutoScan] = useState(true);
  const [encryptionEnabled, setEncryptionEnabled] = useState(false);
  const [mfaEnabled, setMfaEnabled] = useState(false);
  const [accessLogsEnabled, setAccessLogsEnabled] = useState(true);

  const { toast } = useToast();

  useEffect(() => {
    if (!isOpen) return;

    // Simulate real-time security monitoring
    const interval = setInterval(() => {
      setMetrics(prev => prev.map(metric => ({
        ...metric,
        value: Math.max(0, Math.min(metric.maxValue, 
          metric.value + (Math.random() - 0.5) * 5
        ))
      })));
    }, 3000);

    return () => clearInterval(interval);
  }, [isOpen]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'checking': return <Scan className="w-4 h-4 text-blue-500 animate-spin" />;
      default: return <Shield className="w-4 h-4 text-gray-500" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'authentication': return <UserCheck className="w-4 h-4" />;
      case 'encryption': return <Lock className="w-4 h-4" />;
      case 'network': return <Globe className="w-4 h-4" />;
      case 'files': return <FileCheck className="w-4 h-4" />;
      case 'dependencies': return <Database className="w-4 h-4" />;
      default: return <Shield className="w-4 h-4" />;
    }
  };

  const runSecurityScan = async () => {
    setIsScanning(true);
    setScanProgress(0);

    // Simulate comprehensive security scan
    const scanSteps = [
      'Checking authentication systems...',
      'Scanning for vulnerabilities...',
      'Verifying encryption status...',
      'Analyzing network security...',
      'Auditing file permissions...',
      'Finalizing security report...'
    ];

    for (let i = 0; i < scanSteps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800));
      setScanProgress(((i + 1) / scanSteps.length) * 100);
      
      toast({
        title: "Security Scan",
        description: scanSteps[i],
      });
    }

    // Update check results
    setChecks(prev => prev.map(check => ({
      ...check,
      status: Math.random() > 0.3 ? 'passed' : (Math.random() > 0.5 ? 'warning' : 'failed'),
      lastChecked: new Date()
    })));

    setIsScanning(false);
    toast({
      title: "Security Scan Complete",
      description: "Comprehensive security analysis finished",
    });
  };

  const fixSecurityIssue = (checkId: string) => {
    setChecks(prev => prev.map(check => 
      check.id === checkId 
        ? { ...check, status: 'passed' as const, lastChecked: new Date() }
        : check
    ));

    toast({
      title: "Security Issue Fixed",
      description: "Security configuration has been updated",
    });
  };

  const enableEncryption = () => {
    setEncryptionEnabled(true);
    toast({
      title: "Encryption Enabled",
      description: "Data encryption has been activated",
    });
  };

  const enableMFA = () => {
    setMfaEnabled(true);
    toast({
      title: "MFA Enabled",
      description: "Multi-factor authentication is now active",
    });
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Comprehensive Security System
            <Badge variant="outline" className="ml-2">
              {checks.filter(c => c.status === 'passed').length}/{checks.length} Passed
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex flex-col gap-4 overflow-hidden">
          {/* Security Overview */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {metrics.map((metric) => (
              <Card key={metric.name}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">{metric.name}</span>
                    <div className={`w-2 h-2 rounded-full ${
                      metric.status === 'good' ? 'bg-green-500' :
                      metric.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                    }`} />
                  </div>
                  <div className="space-y-2">
                    <div className="text-2xl font-bold">
                      {metric.name === 'Security Score' || metric.name === 'Encryption Coverage' 
                        ? `${metric.value}%` 
                        : metric.value.toString()
                      }
                    </div>
                    {metric.name === 'Security Score' || metric.name === 'Encryption Coverage' ? (
                      <Progress value={metric.value} className="w-full h-2" />
                    ) : (
                      <div className="text-xs text-gray-600">
                        Target: {metric.maxValue}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
              <TabsTrigger value="scans">Security Scans</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
              <TabsTrigger value="logs">Access Logs</TabsTrigger>
              <TabsTrigger value="reports">Reports</TabsTrigger>
            </TabsList>
            
            <TabsContent value="dashboard" className="flex-1 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Security Status Overview</h3>
                <Button 
                  onClick={runSecurityScan}
                  disabled={isScanning}
                >
                  <Scan className={`w-4 h-4 mr-2 ${isScanning ? 'animate-spin' : ''}`} />
                  {isScanning ? 'Scanning...' : 'Run Security Scan'}
                </Button>
              </div>

              {isScanning && (
                <Card>
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Security Scan Progress</span>
                        <span className="text-sm">{Math.round(scanProgress)}%</span>
                      </div>
                      <Progress value={scanProgress} className="w-full" />
                    </div>
                  </CardContent>
                </Card>
              )}

              <ScrollArea className="flex-1">
                <div className="space-y-3">
                  {checks.map((check) => (
                    <Card key={check.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-3 flex-1">
                            <div className="flex items-center gap-2">
                              {getCategoryIcon(check.category)}
                              {getStatusIcon(check.status)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <h4 className="font-medium">{check.name}</h4>
                                <Badge className={getSeverityColor(check.severity)}>
                                  {check.severity}
                                </Badge>
                                <Badge variant="outline" className="capitalize">
                                  {check.category}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-600 mb-2">{check.description}</p>
                              {check.recommendation && check.status !== 'passed' && (
                                <div className="text-sm bg-blue-50 p-2 rounded border-l-4 border-blue-400">
                                  <strong>Recommendation:</strong> {check.recommendation}
                                </div>
                              )}
                              <div className="text-xs text-gray-500 mt-2">
                                Last checked: {check.lastChecked.toLocaleString()}
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            {check.status !== 'passed' && (
                              <Button 
                                size="sm" 
                                onClick={() => fixSecurityIssue(check.id)}
                              >
                                Fix Issue
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="scans" className="flex-1 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Automated Scans</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-sm font-medium">Auto Security Scans</Label>
                        <p className="text-xs text-gray-600">Run scans every 6 hours</p>
                      </div>
                      <Switch
                        checked={autoScan}
                        onCheckedChange={setAutoScan}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Button className="w-full" onClick={runSecurityScan}>
                        <Scan className="w-4 h-4 mr-2" />
                        Full Security Scan
                      </Button>
                      <Button variant="outline" className="w-full">
                        <Database className="w-4 h-4 mr-2" />
                        Dependency Audit
                      </Button>
                      <Button variant="outline" className="w-full">
                        <Globe className="w-4 h-4 mr-2" />
                        Network Security Check
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Scan History</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center text-sm">
                        <span>Full Security Scan</span>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-green-100 text-green-800">Passed</Badge>
                          <span className="text-gray-500">2 hours ago</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span>Dependency Audit</span>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-yellow-100 text-yellow-800">Warning</Badge>
                          <span className="text-gray-500">6 hours ago</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span>Network Security</span>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-green-100 text-green-800">Passed</Badge>
                          <span className="text-gray-500">1 day ago</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="settings" className="flex-1 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Authentication & Access</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-sm font-medium">Multi-Factor Authentication</Label>
                        <p className="text-xs text-gray-600">Add extra security layer</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={mfaEnabled}
                          onCheckedChange={setMfaEnabled}
                        />
                        {!mfaEnabled && (
                          <Button size="sm" onClick={enableMFA}>
                            Enable
                          </Button>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-sm font-medium">Access Logging</Label>
                        <p className="text-xs text-gray-600">Log all access attempts</p>
                      </div>
                      <Switch
                        checked={accessLogsEnabled}
                        onCheckedChange={setAccessLogsEnabled}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Session Management</Label>
                      <div className="grid grid-cols-2 gap-2">
                        <Button variant="outline" size="sm">
                          <UserCheck className="w-4 h-4 mr-2" />
                          Active Sessions
                        </Button>
                        <Button variant="outline" size="sm">
                          <Key className="w-4 h-4 mr-2" />
                          API Keys
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Data Protection</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-sm font-medium">Data Encryption</Label>
                        <p className="text-xs text-gray-600">Encrypt sensitive data</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={encryptionEnabled}
                          onCheckedChange={setEncryptionEnabled}
                        />
                        {!encryptionEnabled && (
                          <Button size="sm" onClick={enableEncryption}>
                            Enable
                          </Button>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Backup & Recovery</Label>
                      <div className="grid grid-cols-2 gap-2">
                        <Button variant="outline" size="sm">
                          <Database className="w-4 h-4 mr-2" />
                          Backup Now
                        </Button>
                        <Button variant="outline" size="sm">
                          <Zap className="w-4 h-4 mr-2" />
                          Recovery
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Security Policies</Label>
                      <Button variant="outline" className="w-full" size="sm">
                        <FileCheck className="w-4 h-4 mr-2" />
                        Configure Policies
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="logs" className="flex-1">
              <ScrollArea className="flex-1">
                <div className="space-y-2">
                  {Array.from({ length: 10 }, (_, i) => (
                    <Card key={i}>
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <UserCheck className="w-4 h-4 text-blue-500" />
                            <div>
                              <span className="text-sm font-medium">
                                User login attempt from 192.168.1.{100 + i}
                              </span>
                              <div className="text-xs text-gray-600">
                                {new Date(Date.now() - i * 300000).toLocaleString()}
                              </div>
                            </div>
                          </div>
                          <Badge className={i % 3 === 0 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}>
                            {i % 3 === 0 ? 'Failed' : 'Success'}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="reports" className="flex-1 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Security Report Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span>Overall Security Score</span>
                        <Badge className="bg-green-100 text-green-800">85/100</Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Critical Issues</span>
                        <Badge className="bg-red-100 text-red-800">1</Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Warnings</span>
                        <Badge className="bg-yellow-100 text-yellow-800">2</Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Passed Checks</span>
                        <Badge className="bg-green-100 text-green-800">3</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Generate Reports</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button variant="outline" className="w-full">
                      <FileCheck className="w-4 h-4 mr-2" />
                      Security Assessment Report
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Database className="w-4 h-4 mr-2" />
                      Compliance Report
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Shield className="w-4 h-4 mr-2" />
                      Vulnerability Report
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="flex items-center justify-between pt-4 border-t">
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Shield className="w-4 h-4" />
              <span>Security System Active</span>
            </div>
            <div className="flex items-center gap-1">
              <CheckCircle className="w-4 h-4" />
              <span>Real-time Monitoring</span>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            <Button>
              <Settings className="w-4 h-4 mr-2" />
              Security Settings
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}