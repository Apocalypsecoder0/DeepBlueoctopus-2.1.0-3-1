import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  FileText, 
  Code2, 
  Palette, 
  Database, 
  Globe, 
  Settings, 
  Puzzle,
  Terminal,
  GitBranch,
  Bug,
  Zap,
  Search,
  Download,
  Upload,
  Play,
  Pause,
  Square,
  RefreshCw,
  Save,
  FolderOpen,
  Plus,
  ChevronDown,
  Package,
  Wrench,
  Paintbrush,
  Server,
  Shield,
  Cpu,
  Brain,
  Gamepad2,
  Smartphone,
  Monitor,
  Cloud,
  Archive,
  PuzzleIcon,
  Component
} from 'lucide-react';

interface ToolCategory {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
  description: string;
  tools: Tool[];
}

interface Tool {
  id: string;
  name: string;
  icon: React.ReactNode;
  shortcut?: string;
  description: string;
  action: () => void;
  isActive?: boolean;
  isPremium?: boolean;
  isPlugin?: boolean;
}

interface CategorizedToolbarProps {
  onToolAction: (toolId: string, action: () => void) => void;
  activeTools: string[];
  pluginTools: Tool[];
}

export default function CategorizedToolbar({ 
  onToolAction, 
  activeTools, 
  pluginTools = [] 
}: CategorizedToolbarProps) {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'compact' | 'expanded'>('compact');

  const categories: ToolCategory[] = [
    {
      id: 'file-management',
      name: 'File Management',
      icon: <FolderOpen className="h-4 w-4" />,
      color: 'bg-blue-500',
      description: 'File operations and project management',
      tools: [
        {
          id: 'new-file',
          name: 'New File',
          icon: <FileText className="h-4 w-4" />,
          shortcut: 'Ctrl+N',
          description: 'Create a new file',
          action: () => console.log('New file created')
        },
        {
          id: 'open-file',
          name: 'Open File',
          icon: <FolderOpen className="h-4 w-4" />,
          shortcut: 'Ctrl+O',
          description: 'Open an existing file',
          action: () => console.log('File opened')
        },
        {
          id: 'save-file',
          name: 'Save',
          icon: <Save className="h-4 w-4" />,
          shortcut: 'Ctrl+S',
          description: 'Save current file',
          action: () => console.log('File saved')
        },
        {
          id: 'import-export',
          name: 'Import/Export',
          icon: <Archive className="h-4 w-4" />,
          shortcut: 'Ctrl+Shift+I',
          description: 'Import and export files',
          action: () => console.log('Import/Export manager opened')
        }
      ]
    },
    {
      id: 'code-editing',
      name: 'Code Editing',
      icon: <Code2 className="h-4 w-4" />,
      color: 'bg-green-500',
      description: 'Code editing and refactoring tools',
      tools: [
        {
          id: 'format-code',
          name: 'Format Code',
          icon: <Paintbrush className="h-4 w-4" />,
          shortcut: 'Shift+Alt+F',
          description: 'Format and beautify code',
          action: () => console.log('Code formatted')
        },
        {
          id: 'find-replace',
          name: 'Find & Replace',
          icon: <Search className="h-4 w-4" />,
          shortcut: 'Ctrl+H',
          description: 'Find and replace text',
          action: () => console.log('Find & Replace opened')
        },
        {
          id: 'code-refactor',
          name: 'Refactor',
          icon: <RefreshCw className="h-4 w-4" />,
          shortcut: 'Ctrl+Shift+R',
          description: 'Refactor code structure',
          action: () => console.log('Code refactoring started')
        },
        {
          id: 'intellisense',
          name: 'IntelliSense',
          icon: <Brain className="h-4 w-4" />,
          shortcut: 'Ctrl+Space',
          description: 'Intelligent code completion',
          action: () => console.log('IntelliSense activated')
        }
      ]
    },
    {
      id: 'debugging',
      name: 'Debugging',
      icon: <Bug className="h-4 w-4" />,
      color: 'bg-red-500',
      description: 'Debugging and testing tools',
      tools: [
        {
          id: 'debug-start',
          name: 'Start Debug',
          icon: <Play className="h-4 w-4" />,
          shortcut: 'F5',
          description: 'Start debugging session',
          action: () => console.log('Debug session started')
        },
        {
          id: 'debug-pause',
          name: 'Pause Debug',
          icon: <Pause className="h-4 w-4" />,
          shortcut: 'F6',
          description: 'Pause debugging execution',
          action: () => console.log('Debug session paused')
        },
        {
          id: 'debug-stop',
          name: 'Stop Debug',
          icon: <Square className="h-4 w-4" />,
          shortcut: 'Shift+F5',
          description: 'Stop debugging session',
          action: () => console.log('Debug session stopped')
        },
        {
          id: 'test-runner',
          name: 'Test Runner',
          icon: <Zap className="h-4 w-4" />,
          shortcut: 'Ctrl+Shift+T',
          description: 'Run unit tests',
          action: () => console.log('Tests running')
        }
      ]
    },
    {
      id: 'version-control',
      name: 'Version Control',
      icon: <GitBranch className="h-4 w-4" />,
      color: 'bg-purple-500',
      description: 'Git and version control operations',
      tools: [
        {
          id: 'git-commit',
          name: 'Commit',
          icon: <GitBranch className="h-4 w-4" />,
          shortcut: 'Ctrl+Shift+G',
          description: 'Commit changes to repository',
          action: () => console.log('Git commit initiated')
        },
        {
          id: 'git-push',
          name: 'Push',
          icon: <Upload className="h-4 w-4" />,
          description: 'Push changes to remote repository',
          action: () => console.log('Git push initiated')
        },
        {
          id: 'git-pull',
          name: 'Pull',
          icon: <Download className="h-4 w-4" />,
          description: 'Pull changes from remote repository',
          action: () => console.log('Git pull initiated')
        },
        {
          id: 'github-integration',
          name: 'GitHub',
          icon: <Globe className="h-4 w-4" />,
          shortcut: 'Ctrl+Shift+H',
          description: 'GitHub integration and management',
          action: () => console.log('GitHub integration opened')
        }
      ]
    },
    {
      id: 'terminal-tools',
      name: 'Terminal & Build',
      icon: <Terminal className="h-4 w-4" />,
      color: 'bg-yellow-500',
      description: 'Terminal, build and deployment tools',
      tools: [
        {
          id: 'terminal',
          name: 'Terminal',
          icon: <Terminal className="h-4 w-4" />,
          shortcut: 'Ctrl+`',
          description: 'Open integrated terminal',
          action: () => console.log('Terminal opened')
        },
        {
          id: 'build-project',
          name: 'Build',
          icon: <Package className="h-4 w-4" />,
          shortcut: 'Ctrl+Shift+B',
          description: 'Build the project',
          action: () => console.log('Project build started')
        },
        {
          id: 'deploy-manager',
          name: 'Deploy',
          icon: <Cloud className="h-4 w-4" />,
          shortcut: 'Ctrl+Shift+Y',
          description: 'Deploy to cloud platforms',
          action: () => console.log('Deployment manager opened')
        },
        {
          id: 'package-manager',
          name: 'Packages',
          icon: <Package className="h-4 w-4" />,
          shortcut: 'Ctrl+Shift+N',
          description: 'Manage project dependencies',
          action: () => console.log('Package manager opened')
        }
      ]
    },
    {
      id: 'ai-tools',
      name: 'AI & Intelligence',
      icon: <Brain className="h-4 w-4" />,
      color: 'bg-cyan-500',
      description: 'AI-powered development assistance',
      tools: [
        {
          id: 'ai-assistant',
          name: 'AI Assistant',
          icon: <Brain className="h-4 w-4" />,
          shortcut: 'Ctrl+Alt+A',
          description: 'AI-powered code assistance',
          action: () => console.log('AI assistant activated'),
          isPremium: true
        },
        {
          id: 'code-suggestions',
          name: 'Smart Suggestions',
          icon: <Zap className="h-4 w-4" />,
          shortcut: 'Ctrl+Alt+I',
          description: 'Context-aware code suggestions',
          action: () => console.log('Smart suggestions opened'),
          isPremium: true
        },
        {
          id: 'bug-seeker',
          name: 'Bug Seeker',
          icon: <Bug className="h-4 w-4" />,
          description: 'AI-powered bug detection',
          action: () => console.log('Bug seeker activated'),
          isPremium: true
        },
        {
          id: 'doc-master',
          name: 'Doc Master',
          icon: <FileText className="h-4 w-4" />,
          description: 'Automatic documentation generation',
          action: () => console.log('Doc master activated'),
          isPremium: true
        }
      ]
    },
    {
      id: 'design-tools',
      name: 'Design & UI',
      icon: <Palette className="h-4 w-4" />,
      color: 'bg-pink-500',
      description: 'Design and user interface tools',
      tools: [
        {
          id: 'theme-editor',
          name: 'Theme Editor',
          icon: <Palette className="h-4 w-4" />,
          description: 'Customize IDE themes',
          action: () => console.log('Theme editor opened')
        },
        {
          id: 'uml-designer',
          name: 'UML Designer',
          icon: <Component className="h-4 w-4" />,
          description: 'Create UML diagrams',
          action: () => console.log('UML designer opened')
        },
        {
          id: 'autocad-blueprint',
          name: 'AutoCAD Blueprint',
          icon: <Monitor className="h-4 w-4" />,
          shortcut: 'Ctrl+Alt+B',
          description: 'Technical drawing and blueprints',
          action: () => console.log('AutoCAD blueprint opened')
        },
        {
          id: 'object-studio',
          name: '3D Object Studio',
          icon: <Gamepad2 className="h-4 w-4" />,
          description: '3D modeling and animation',
          action: () => console.log('3D Object Studio opened'),
          isPremium: true
        }
      ]
    },
    {
      id: 'database-tools',
      name: 'Database',
      icon: <Database className="h-4 w-4" />,
      color: 'bg-indigo-500',
      description: 'Database management and design tools',
      tools: [
        {
          id: 'database-manager',
          name: 'Database Manager',
          icon: <Database className="h-4 w-4" />,
          shortcut: 'Ctrl+Shift+D',
          description: 'Manage database connections',
          action: () => console.log('Database manager opened')
        },
        {
          id: 'schema-designer',
          name: 'Schema Designer',
          icon: <Settings className="h-4 w-4" />,
          description: 'Design database schemas',
          action: () => console.log('Schema designer opened')
        },
        {
          id: 'sql-editor',
          name: 'SQL Editor',
          icon: <Code2 className="h-4 w-4" />,
          description: 'Execute SQL queries',
          action: () => console.log('SQL editor opened')
        },
        {
          id: 'api-client',
          name: 'API Client',
          icon: <Globe className="h-4 w-4" />,
          description: 'Test REST APIs',
          action: () => console.log('API client opened')
        }
      ]
    },
    {
      id: 'mobile-game',
      name: 'Mobile & Game',
      icon: <Smartphone className="h-4 w-4" />,
      color: 'bg-orange-500',
      description: 'Mobile and game development tools',
      tools: [
        {
          id: 'mobile-framework',
          name: 'Mobile Framework',
          icon: <Smartphone className="h-4 w-4" />,
          description: 'Mobile app development tools',
          action: () => console.log('Mobile framework opened')
        },
        {
          id: 'game-engine',
          name: 'Game Engine',
          icon: <Gamepad2 className="h-4 w-4" />,
          description: 'Game development environment',
          action: () => console.log('Game engine opened')
        },
        {
          id: 'game-studio',
          name: 'Game Studio',
          icon: <Monitor className="h-4 w-4" />,
          shortcut: 'Ctrl+Alt+G',
          description: 'Advanced game development studio',
          action: () => console.log('Game studio opened'),
          isPremium: true
        },
        {
          id: 'controller-test',
          name: 'Controller Test',
          icon: <Gamepad2 className="h-4 w-4" />,
          description: 'Test game controllers',
          action: () => console.log('Controller test opened')
        }
      ]
    },
    {
      id: 'performance-security',
      name: 'Performance & Security',
      icon: <Shield className="h-4 w-4" />,
      color: 'bg-gray-500',
      description: 'Performance monitoring and security tools',
      tools: [
        {
          id: 'performance-monitor',
          name: 'Performance Monitor',
          icon: <Cpu className="h-4 w-4" />,
          shortcut: 'Ctrl+Shift+R',
          description: 'Monitor system performance',
          action: () => console.log('Performance monitor opened')
        },
        {
          id: 'security-scanner',
          name: 'Security Scanner',
          icon: <Shield className="h-4 w-4" />,
          description: 'Scan for security vulnerabilities',
          action: () => console.log('Security scanner opened'),
          isPremium: true
        },
        {
          id: 'memory-analyzer',
          name: 'Memory Analyzer',
          icon: <Cpu className="h-4 w-4" />,
          description: 'Analyze memory usage and leaks',
          action: () => console.log('Memory analyzer opened')
        },
        {
          id: 'error-logger',
          name: 'Error Logger',
          icon: <Bug className="h-4 w-4" />,
          shortcut: 'Ctrl+Shift+E',
          description: 'Track and log errors',
          action: () => console.log('Error logger opened')
        }
      ]
    },
    {
      id: 'plugins',
      name: 'Plugins',
      icon: <PuzzleIcon className="h-4 w-4" />,
      color: 'bg-emerald-500',
      description: 'Installed plugins and extensions',
      tools: [
        {
          id: 'plugin-manager',
          name: 'Plugin Manager',
          icon: <Puzzle className="h-4 w-4" />,
          shortcut: 'Ctrl+Shift+P',
          description: 'Manage IDE plugins',
          action: () => console.log('Plugin manager opened')
        },
        {
          id: 'extension-marketplace',
          name: 'Marketplace',
          icon: <Package className="h-4 w-4" />,
          description: 'Browse extension marketplace',
          action: () => console.log('Extension marketplace opened')
        },
        ...pluginTools.map(tool => ({
          ...tool,
          isPlugin: true
        }))
      ]
    }
  ];

  const handleToolClick = (tool: Tool) => {
    onToolAction(tool.id, tool.action);
  };

  const toggleCategory = (categoryId: string) => {
    setExpandedCategory(expandedCategory === categoryId ? null : categoryId);
  };

  return (
    <TooltipProvider>
      <div className="h-full border-r bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        {/* Toolbar Header */}
        <div className="flex items-center justify-between p-2 border-b">
          <h2 className="text-sm font-semibold">Tools</h2>
          <div className="flex items-center gap-1">
            <Button
              variant={viewMode === 'compact' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('compact')}
              className="h-6 px-2 text-xs"
            >
              Compact
            </Button>
            <Button
              variant={viewMode === 'expanded' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('expanded')}
              className="h-6 px-2 text-xs"
            >
              Expanded
            </Button>
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {categories.map((category) => (
              <div key={category.id} className="space-y-1">
                {/* Category Header */}
                <div className="flex items-center justify-between">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleCategory(category.id)}
                    className="flex-1 justify-start h-8 px-2"
                  >
                    <div className={`w-2 h-2 rounded-full mr-2 ${category.color}`} />
                    {category.icon}
                    <span className="ml-2 text-xs font-medium">{category.name}</span>
                    <Badge variant="secondary" className="ml-auto text-xs">
                      {category.tools.length}
                    </Badge>
                    <ChevronDown 
                      className={`h-3 w-3 ml-1 transition-transform ${
                        expandedCategory === category.id ? 'rotate-180' : ''
                      }`} 
                    />
                  </Button>
                </div>

                {/* Category Tools */}
                {(expandedCategory === category.id || viewMode === 'expanded') && (
                  <div className="ml-4 space-y-1">
                    {category.tools.map((tool) => (
                      <div key={tool.id}>
                        {viewMode === 'compact' ? (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant={activeTools.includes(tool.id) ? 'default' : 'ghost'}
                                size="sm"
                                onClick={() => handleToolClick(tool)}
                                className="w-full justify-start h-7 px-2 text-xs"
                              >
                                {tool.icon}
                                <span className="ml-2 truncate">{tool.name}</span>
                                {tool.isPremium && (
                                  <Badge variant="secondary" className="ml-auto text-xs">
                                    Pro
                                  </Badge>
                                )}
                                {tool.isPlugin && (
                                  <Badge variant="outline" className="ml-auto text-xs">
                                    Plugin
                                  </Badge>
                                )}
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent side="right">
                              <div className="text-xs">
                                <div className="font-medium">{tool.name}</div>
                                <div className="text-muted-foreground">{tool.description}</div>
                                {tool.shortcut && (
                                  <div className="text-xs mt-1 font-mono bg-accent px-1 rounded">
                                    {tool.shortcut}
                                  </div>
                                )}
                              </div>
                            </TooltipContent>
                          </Tooltip>
                        ) : (
                          <div className="bg-accent/50 rounded p-2 space-y-1">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                {tool.icon}
                                <span className="text-xs font-medium">{tool.name}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                {tool.isPremium && (
                                  <Badge variant="secondary" className="text-xs">Pro</Badge>
                                )}
                                {tool.isPlugin && (
                                  <Badge variant="outline" className="text-xs">Plugin</Badge>
                                )}
                              </div>
                            </div>
                            <p className="text-xs text-muted-foreground">{tool.description}</p>
                            <div className="flex items-center justify-between">
                              <Button
                                variant={activeTools.includes(tool.id) ? 'default' : 'outline'}
                                size="sm"
                                onClick={() => handleToolClick(tool)}
                                className="h-6 px-2 text-xs"
                              >
                                Open
                              </Button>
                              {tool.shortcut && (
                                <Badge variant="outline" className="text-xs font-mono">
                                  {tool.shortcut}
                                </Badge>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {category.id !== 'plugins' && <Separator className="my-2" />}
              </div>
            ))}
          </div>
        </ScrollArea>

        {/* Quick Actions */}
        <div className="border-t p-2">
          <div className="text-xs text-muted-foreground mb-2">Quick Actions</div>
          <div className="grid grid-cols-4 gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 p-1">
                  <Plus className="h-3 w-3" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Add Plugin</p>
              </TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 p-1">
                  <Settings className="h-3 w-3" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Toolbar Settings</p>
              </TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 p-1">
                  <Package className="h-3 w-3" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Plugin Store</p>
              </TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 p-1">
                  <Wrench className="h-3 w-3" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Developer Tools</p>
              </TooltipContent>
            </Tooltip>
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
}