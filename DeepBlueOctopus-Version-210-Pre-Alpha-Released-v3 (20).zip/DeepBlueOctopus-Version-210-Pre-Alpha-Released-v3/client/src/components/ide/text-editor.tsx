import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Save, 
  Download, 
  Upload, 
  Copy, 
  FileText, 
  Type,
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  List,
  ListOrdered,
  Undo,
  Redo,
  Search,
  Replace,
  Printer,
  Eye,
  Edit3,
  Settings,
  File,
  FolderOpen,
  Clock,
  Hash,
  Quote,
  Link,
  Image,
  Code,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Palette,
  ZoomIn,
  ZoomOut,
  Monitor
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useIDEState } from '@/hooks/use-ide-state';

interface TextDocument {
  id: string;
  name: string;
  content: string;
  format: 'plain' | 'markdown' | 'html' | 'rich';
  lastModified: Date;
  wordCount: number;
  charCount: number;
  saved: boolean;
}

interface FormatOptions {
  bold: boolean;
  italic: boolean;
  underline: boolean;
  fontSize: number;
  fontFamily: string;
  textAlign: 'left' | 'center' | 'right' | 'justify';
  lineHeight: number;
}

const defaultFormatOptions: FormatOptions = {
  bold: false,
  italic: false,
  underline: false,
  fontSize: 14,
  fontFamily: 'Inter',
  textAlign: 'left',
  lineHeight: 1.5
};

const fontFamilies = [
  'Inter', 'Arial', 'Helvetica', 'Times New Roman', 'Georgia', 
  'Courier New', 'Monaco', 'Consolas', 'Roboto', 'Open Sans'
];

const documentTemplates = [
  {
    name: 'Blank Document',
    format: 'plain' as const,
    content: ''
  },
  {
    name: 'Project README',
    format: 'markdown' as const,
    content: `# Project Title

## Description
A brief description of your project.

## Installation
\`\`\`bash
npm install
\`\`\`

## Usage
\`\`\`javascript
import { MyComponent } from './src/component';
\`\`\`

## Features
- Feature 1
- Feature 2
- Feature 3

## Contributing
Contributions are welcome! Please read our contributing guidelines.

## License
MIT License`
  },
  {
    name: 'HTML Document',
    format: 'html' as const,
    content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            line-height: 1.6;
        }
        h1 { color: #2c3e50; }
        .highlight { background-color: #f1c40f; }
    </style>
</head>
<body>
    <h1>Welcome to My Document</h1>
    <p>This is a sample HTML document with basic styling.</p>
    <p class="highlight">You can edit this content as needed.</p>
</body>
</html>`
  },
  {
    name: 'Meeting Notes',
    format: 'markdown' as const,
    content: `# Meeting Notes - ${new Date().toLocaleDateString()}

## Attendees
- [Name 1]
- [Name 2]
- [Name 3]

## Agenda
1. Topic 1
2. Topic 2
3. Next Steps

## Discussion Points

### Topic 1
- Key point 1
- Key point 2

### Topic 2
- Important decision
- Action items

## Action Items
- [ ] Task 1 - Assigned to [Name]
- [ ] Task 2 - Assigned to [Name]
- [ ] Task 3 - Deadline: [Date]

## Next Meeting
Date: [Date]
Time: [Time]
Location: [Location/Link]`
  },
  {
    name: 'Code Documentation',
    format: 'markdown' as const,
    content: `# API Documentation

## Overview
This document describes the API endpoints and usage.

## Authentication
All requests require an API key:
\`\`\`
Authorization: Bearer YOUR_API_KEY
\`\`\`

## Endpoints

### GET /api/users
Returns a list of users.

**Parameters:**
- \`limit\` (optional): Number of results to return
- \`offset\` (optional): Number of results to skip

**Response:**
\`\`\`json
{
  "users": [
    {
      "id": 1,
      "name": "John Doe",
      "email": "john@example.com"
    }
  ],
  "total": 100
}
\`\`\`

### POST /api/users
Creates a new user.

**Request Body:**
\`\`\`json
{
  "name": "Jane Doe",
  "email": "jane@example.com"
}
\`\`\``
  }
];

export default function TextEditor() {
  const [activeTab, setActiveTab] = useState('editor');
  const [currentDocument, setCurrentDocument] = useState<TextDocument>({
    id: '1',
    name: 'Untitled Document',
    content: '',
    format: 'plain',
    lastModified: new Date(),
    wordCount: 0,
    charCount: 0,
    saved: true
  });
  const [documents, setDocuments] = useState<TextDocument[]>([]);
  const [formatOptions, setFormatOptions] = useState<FormatOptions>(defaultFormatOptions);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [undoStack, setUndoStack] = useState<string[]>([]);
  const [redoStack, setRedoStack] = useState<string[]>([]);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();
  const { addFile } = useIDEState();

  useEffect(() => {
    // Initialize with first document
    if (documents.length === 0) {
      const initialDoc = { ...currentDocument };
      setDocuments([initialDoc]);
    }
  }, []);

  useEffect(() => {
    // Update word and character count
    const words = currentDocument.content.trim().split(/\s+/).filter(word => word.length > 0);
    setCurrentDocument(prev => ({
      ...prev,
      wordCount: words.length,
      charCount: prev.content.length,
      lastModified: new Date()
    }));
  }, [currentDocument.content]);

  const handleContentChange = (content: string) => {
    // Add to undo stack
    setUndoStack(prev => [...prev.slice(-19), currentDocument.content]);
    setRedoStack([]);
    
    setCurrentDocument(prev => ({
      ...prev,
      content,
      saved: false
    }));
  };

  const handleUndo = () => {
    if (undoStack.length > 0) {
      const lastContent = undoStack[undoStack.length - 1];
      setRedoStack(prev => [...prev, currentDocument.content]);
      setUndoStack(prev => prev.slice(0, -1));
      setCurrentDocument(prev => ({ ...prev, content: lastContent }));
    }
  };

  const handleRedo = () => {
    if (redoStack.length > 0) {
      const nextContent = redoStack[redoStack.length - 1];
      setUndoStack(prev => [...prev, currentDocument.content]);
      setRedoStack(prev => prev.slice(0, -1));
      setCurrentDocument(prev => ({ ...prev, content: nextContent }));
    }
  };

  const handleSave = () => {
    setCurrentDocument(prev => ({ ...prev, saved: true }));
    
    // Save to IDE state if available
    if (addFile) {
      const extension = currentDocument.format === 'markdown' ? '.md' : 
                      currentDocument.format === 'html' ? '.html' : '.txt';
      addFile(currentDocument.name + extension, currentDocument.content);
    }
    
    toast({
      title: 'Document Saved',
      description: `${currentDocument.name} has been saved successfully`,
    });
  };

  const handleDownload = () => {
    const extension = currentDocument.format === 'markdown' ? '.md' : 
                     currentDocument.format === 'html' ? '.html' : '.txt';
    const mimeType = currentDocument.format === 'html' ? 'text/html' : 'text/plain';
    
    const blob = new Blob([currentDocument.content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = currentDocument.name + extension;
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: 'Document Downloaded',
      description: `${currentDocument.name}${extension} has been downloaded`,
    });
  };

  const handleLoadTemplate = (template: typeof documentTemplates[0]) => {
    const newDoc: TextDocument = {
      id: Date.now().toString(),
      name: template.name,
      content: template.content,
      format: template.format,
      lastModified: new Date(),
      wordCount: 0,
      charCount: 0,
      saved: false
    };
    setCurrentDocument(newDoc);
    setDocuments(prev => [...prev, newDoc]);
    
    toast({
      title: 'Template Loaded',
      description: `${template.name} template loaded successfully`,
    });
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const format = file.name.endsWith('.md') ? 'markdown' :
                    file.name.endsWith('.html') ? 'html' : 'plain';
      
      const newDoc: TextDocument = {
        id: Date.now().toString(),
        name: file.name.replace(/\.[^/.]+$/, ''),
        content,
        format,
        lastModified: new Date(),
        wordCount: 0,
        charCount: 0,
        saved: true
      };
      
      setCurrentDocument(newDoc);
      setDocuments(prev => [...prev, newDoc]);
      
      toast({
        title: 'File Uploaded',
        description: `${file.name} uploaded successfully`,
      });
    };
    reader.readAsText(file);
  };

  const handleFindReplace = () => {
    if (!findText) return;
    
    const newContent = currentDocument.content.replace(
      new RegExp(findText, 'g'), 
      replaceText
    );
    
    handleContentChange(newContent);
    
    toast({
      title: 'Find & Replace',
      description: `Replaced "${findText}" with "${replaceText}"`,
    });
  };

  const handleFormatChange = (key: keyof FormatOptions, value: any) => {
    setFormatOptions(prev => ({ ...prev, [key]: value }));
  };

  const getEditorStyle = () => ({
    fontSize: `${formatOptions.fontSize}px`,
    fontFamily: formatOptions.fontFamily,
    fontWeight: formatOptions.bold ? 'bold' : 'normal',
    fontStyle: formatOptions.italic ? 'italic' : 'normal',
    textDecoration: formatOptions.underline ? 'underline' : 'none',
    textAlign: formatOptions.textAlign,
    lineHeight: formatOptions.lineHeight,
    transform: `scale(${zoomLevel / 100})`,
    transformOrigin: 'top left',
    width: `${100 * (100 / zoomLevel)}%`,
    height: `${100 * (100 / zoomLevel)}%`
  });

  const renderPreview = () => {
    if (currentDocument.format === 'markdown') {
      // Simple markdown preview (in a real app, you'd use a proper markdown parser)
      const htmlContent = currentDocument.content
        .replace(/^# (.*$)/gm, '<h1>$1</h1>')
        .replace(/^## (.*$)/gm, '<h2>$1</h2>')
        .replace(/^### (.*$)/gm, '<h3>$1</h3>')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/\n/g, '<br>');
      
      return <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: htmlContent }} />;
    } else if (currentDocument.format === 'html') {
      return <div dangerouslySetInnerHTML={{ __html: currentDocument.content }} />;
    } else {
      return <pre className="whitespace-pre-wrap font-mono">{currentDocument.content}</pre>;
    }
  };

  return (
    <div className="w-full h-full bg-background overflow-hidden">
      <div className="border-b p-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-500/10 rounded-lg">
            <FileText className="h-6 w-6 text-blue-500" />
          </div>
          <div>
            <h1 className="text-xl font-bold">Advanced Text Editor</h1>
            <p className="text-sm text-muted-foreground">
              Professional text editing with multiple format support
            </p>
          </div>
        </div>
      </div>

      <div className="flex h-full">
        {/* Main Content */}
        <div className="flex-1 overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
            <TabsList className="w-full justify-start border-b rounded-none h-12 bg-transparent">
              <TabsTrigger value="editor" className="gap-2">
                <Edit3 className="h-4 w-4" />
                Editor
              </TabsTrigger>
              <TabsTrigger value="preview" className="gap-2">
                <Eye className="h-4 w-4" />
                Preview
              </TabsTrigger>
              <TabsTrigger value="templates" className="gap-2">
                <File className="h-4 w-4" />
                Templates
              </TabsTrigger>
              <TabsTrigger value="settings" className="gap-2">
                <Settings className="h-4 w-4" />
                Settings
              </TabsTrigger>
            </TabsList>

            {/* Toolbar */}
            <div className="border-b p-2">
              <div className="flex items-center gap-2 flex-wrap">
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSave}
                    disabled={currentDocument.saved}
                  >
                    <Save className="h-4 w-4 mr-1" />
                    Save
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleDownload}>
                    <Download className="h-4 w-4 mr-1" />
                    Download
                  </Button>
                  <label className="cursor-pointer">
                    <Button variant="outline" size="sm" asChild>
                      <span>
                        <Upload className="h-4 w-4 mr-1" />
                        Upload
                      </span>
                    </Button>
                    <input
                      type="file"
                      accept=".txt,.md,.html"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                <Separator orientation="vertical" className="h-6" />

                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleUndo}
                    disabled={undoStack.length === 0}
                  >
                    <Undo className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRedo}
                    disabled={redoStack.length === 0}
                  >
                    <Redo className="h-4 w-4" />
                  </Button>
                </div>

                <Separator orientation="vertical" className="h-6" />

                <div className="flex items-center gap-1">
                  <Button
                    variant={formatOptions.bold ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleFormatChange('bold', !formatOptions.bold)}
                  >
                    <Bold className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={formatOptions.italic ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleFormatChange('italic', !formatOptions.italic)}
                  >
                    <Italic className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={formatOptions.underline ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleFormatChange('underline', !formatOptions.underline)}
                  >
                    <Underline className="h-4 w-4" />
                  </Button>
                </div>

                <Separator orientation="vertical" className="h-6" />

                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowFindReplace(!showFindReplace)}
                  >
                    <Search className="h-4 w-4 mr-1" />
                    Find
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsPreviewMode(!isPreviewMode)}
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    Preview
                  </Button>
                </div>

                <Separator orientation="vertical" className="h-6" />

                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setZoomLevel(Math.max(50, zoomLevel - 10))}
                  >
                    <ZoomOut className="h-4 w-4" />
                  </Button>
                  <span className="text-sm font-mono min-w-[50px] text-center">{zoomLevel}%</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setZoomLevel(Math.min(200, zoomLevel + 10))}
                  >
                    <ZoomIn className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Find & Replace Bar */}
              {showFindReplace && (
                <div className="flex items-center gap-2 mt-2 p-2 bg-muted rounded">
                  <Input
                    placeholder="Find text..."
                    value={findText}
                    onChange={(e) => setFindText(e.target.value)}
                    className="w-48"
                  />
                  <Input
                    placeholder="Replace with..."
                    value={replaceText}
                    onChange={(e) => setReplaceText(e.target.value)}
                    className="w-48"
                  />
                  <Button size="sm" onClick={handleFindReplace}>
                    <Replace className="h-4 w-4 mr-1" />
                    Replace All
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowFindReplace(false)}
                  >
                    ×
                  </Button>
                </div>
              )}
            </div>

            <div className="p-4 h-full overflow-y-auto">
              <TabsContent value="editor" className="space-y-4 m-0 h-full">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <Input
                      value={currentDocument.name}
                      onChange={(e) => setCurrentDocument(prev => ({ ...prev, name: e.target.value, saved: false }))}
                      className="w-64"
                    />
                    <Select 
                      value={currentDocument.format} 
                      onValueChange={(value: any) => setCurrentDocument(prev => ({ ...prev, format: value }))}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="plain">Plain Text</SelectItem>
                        <SelectItem value="markdown">Markdown</SelectItem>
                        <SelectItem value="html">HTML</SelectItem>
                        <SelectItem value="rich">Rich Text</SelectItem>
                      </SelectContent>
                    </Select>
                    <Badge variant={currentDocument.saved ? "default" : "destructive"}>
                      {currentDocument.saved ? 'Saved' : 'Unsaved'}
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {currentDocument.wordCount} words • {currentDocument.charCount} characters
                  </div>
                </div>

                <div className="h-[600px] relative">
                  {isPreviewMode ? (
                    <div className="h-full border rounded-lg p-4 overflow-y-auto bg-white dark:bg-gray-900">
                      {renderPreview()}
                    </div>
                  ) : (
                    <Textarea
                      ref={textareaRef}
                      value={currentDocument.content}
                      onChange={(e) => handleContentChange(e.target.value)}
                      placeholder="Start typing your document..."
                      className="h-full resize-none font-mono"
                      style={getEditorStyle()}
                    />
                  )}
                </div>
              </TabsContent>

              <TabsContent value="preview" className="space-y-4 m-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Document Preview</CardTitle>
                    <CardDescription>
                      Preview your document as it will appear when exported
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="border rounded-lg p-4 min-h-[400px] bg-white dark:bg-gray-900">
                      {renderPreview()}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="templates" className="space-y-4 m-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Document Templates</CardTitle>
                    <CardDescription>
                      Choose from pre-built templates to get started quickly
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      {documentTemplates.map((template, index) => (
                        <div key={index} className="border rounded-lg p-4 cursor-pointer hover:bg-muted transition-colors"
                             onClick={() => handleLoadTemplate(template)}>
                          <div className="flex items-center gap-2 mb-2">
                            <FileText className="h-5 w-5" />
                            <h3 className="font-medium">{template.name}</h3>
                            <Badge variant="outline">{template.format}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {template.content.substring(0, 100)}...
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="settings" className="space-y-4 m-0">
                <Card>
                  <CardHeader>
                    <CardTitle>Editor Settings</CardTitle>
                    <CardDescription>
                      Customize the appearance and behavior of the text editor
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Font Family</label>
                        <Select 
                          value={formatOptions.fontFamily} 
                          onValueChange={(value) => handleFormatChange('fontFamily', value)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {fontFamilies.map(font => (
                              <SelectItem key={font} value={font}>{font}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">Font Size</label>
                        <Select 
                          value={formatOptions.fontSize.toString()} 
                          onValueChange={(value) => handleFormatChange('fontSize', parseInt(value))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {[10, 12, 14, 16, 18, 20, 24, 28, 32].map(size => (
                              <SelectItem key={size} value={size.toString()}>{size}px</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">Text Alignment</label>
                        <Select 
                          value={formatOptions.textAlign} 
                          onValueChange={(value: any) => handleFormatChange('textAlign', value)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="left">Left</SelectItem>
                            <SelectItem value="center">Center</SelectItem>
                            <SelectItem value="right">Right</SelectItem>
                            <SelectItem value="justify">Justify</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">Line Height</label>
                        <Select 
                          value={formatOptions.lineHeight.toString()} 
                          onValueChange={(value) => handleFormatChange('lineHeight', parseFloat(value))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">1.0</SelectItem>
                            <SelectItem value="1.2">1.2</SelectItem>
                            <SelectItem value="1.5">1.5</SelectItem>
                            <SelectItem value="1.8">1.8</SelectItem>
                            <SelectItem value="2">2.0</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-3">
                      <h4 className="text-sm font-medium">Document Statistics</h4>
                      <div className="grid grid-cols-4 gap-4 text-sm">
                        <div>
                          <div className="text-muted-foreground">Words</div>
                          <div className="font-medium">{currentDocument.wordCount}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Characters</div>
                          <div className="font-medium">{currentDocument.charCount}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Format</div>
                          <div className="font-medium capitalize">{currentDocument.format}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Modified</div>
                          <div className="font-medium">{currentDocument.lastModified.toLocaleTimeString()}</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
}