import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { 
  Code2, 
  Download, 
  Settings, 
  Play, 
  Square, 
  RefreshCw, 
  FileText, 
  Terminal,
  CheckCircle,
  XCircle,
  Clock,
  Zap,
  Package,
  Globe
} from 'lucide-react';

interface CompilerConfig {
  id: string;
  name: string;
  language: string;
  version: string;
  command: string;
  extensions: string[];
  flags: string[];
  installed: boolean;
  category: 'compiled' | 'interpreted' | 'hybrid';
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  popularity: number;
  description: string;
  icon: string;
  installSize: string;
  officialSite: string;
}

interface CompilationResult {
  success: boolean;
  output: string;
  errors: string;
  executionTime: number;
  memoryUsage: string;
  warnings: string[];
}

const LANGUAGE_COMPILERS: CompilerConfig[] = [
  // Compiled Languages
  {
    id: 'gcc',
    name: 'GCC (GNU Compiler Collection)',
    language: 'C/C++',
    version: '11.4.0',
    command: 'gcc',
    extensions: ['.c', '.cpp', '.cc', '.cxx'],
    flags: ['-O2', '-Wall', '-Wextra', '-std=c17', '-std=c++20'],
    installed: true,
    category: 'compiled',
    difficulty: 'intermediate',
    popularity: 95,
    description: 'Industry-standard C/C++ compiler with optimization support',
    icon: '⚙️',
    installSize: '45 MB',
    officialSite: 'https://gcc.gnu.org'
  },
  {
    id: 'clang',
    name: 'Clang/LLVM',
    language: 'C/C++',
    version: '14.0.0',
    command: 'clang',
    extensions: ['.c', '.cpp', '.cc', '.cxx'],
    flags: ['-O2', '-Wall', '-Wextra', '-std=c17', '-std=c++20'],
    installed: false,
    category: 'compiled',
    difficulty: 'intermediate',
    popularity: 88,
    description: 'Modern C/C++ compiler with excellent diagnostics',
    icon: '🔧',
    installSize: '62 MB',
    officialSite: 'https://clang.llvm.org'
  },
  {
    id: 'rustc',
    name: 'Rust Compiler',
    language: 'Rust',
    version: '1.75.0',
    command: 'rustc',
    extensions: ['.rs'],
    flags: ['-O', '--edition=2021', '-C', 'debuginfo=2'],
    installed: true,
    category: 'compiled',
    difficulty: 'advanced',
    popularity: 85,
    description: 'Memory-safe systems programming language compiler',
    icon: '🦀',
    installSize: '156 MB',
    officialSite: 'https://www.rust-lang.org'
  },
  {
    id: 'go',
    name: 'Go Compiler',
    language: 'Go',
    version: '1.21.5',
    command: 'go',
    extensions: ['.go'],
    flags: ['build', '-v', '-x'],
    installed: true,
    category: 'compiled',
    difficulty: 'beginner',
    popularity: 82,
    description: 'Fast compilation and efficient execution for Go programs',
    icon: '🐹',
    installSize: '134 MB',
    officialSite: 'https://golang.org'
  },
  {
    id: 'javac',
    name: 'Java Compiler',
    language: 'Java',
    version: '17.0.8',
    command: 'javac',
    extensions: ['.java'],
    flags: ['-cp', '.', '-Xlint:all'],
    installed: true,
    category: 'hybrid',
    difficulty: 'intermediate',
    popularity: 90,
    description: 'Oracle JDK compiler for Java bytecode generation',
    icon: '☕',
    installSize: '298 MB',
    officialSite: 'https://www.oracle.com/java'
  },
  {
    id: 'dotnet',
    name: '.NET Compiler',
    language: 'C#',
    version: '7.0.404',
    command: 'dotnet',
    extensions: ['.cs'],
    flags: ['build', '--configuration', 'Release'],
    installed: false,
    category: 'hybrid',
    difficulty: 'intermediate',
    popularity: 78,
    description: 'Microsoft .NET compiler for C# and F# languages',
    icon: '🔷',
    installSize: '445 MB',
    officialSite: 'https://dotnet.microsoft.com'
  },
  {
    id: 'swift',
    name: 'Swift Compiler',
    language: 'Swift',
    version: '5.9.2',
    command: 'swiftc',
    extensions: ['.swift'],
    flags: ['-O', '-whole-module-optimization'],
    installed: false,
    category: 'compiled',
    difficulty: 'intermediate',
    popularity: 72,
    description: 'Apple Swift compiler for iOS and macOS development',
    icon: '🦉',
    installSize: '234 MB',
    officialSite: 'https://swift.org'
  },
  {
    id: 'kotlin',
    name: 'Kotlin Compiler',
    language: 'Kotlin',
    version: '1.9.21',
    command: 'kotlinc',
    extensions: ['.kt', '.kts'],
    flags: ['-cp', '.', '-d', 'out'],
    installed: false,
    category: 'hybrid',
    difficulty: 'intermediate',
    popularity: 76,
    description: 'JetBrains Kotlin compiler for JVM and native targets',
    icon: '🚀',
    installSize: '187 MB',
    officialSite: 'https://kotlinlang.org'
  },
  // Interpreted Languages
  {
    id: 'python',
    name: 'Python Interpreter',
    language: 'Python',
    version: '3.11.7',
    command: 'python3',
    extensions: ['.py', '.pyw'],
    flags: ['-O', '-B', '-u'],
    installed: true,
    category: 'interpreted',
    difficulty: 'beginner',
    popularity: 98,
    description: 'High-level programming language interpreter with extensive libraries',
    icon: '🐍',
    installSize: '67 MB',
    officialSite: 'https://www.python.org'
  },
  {
    id: 'nodejs',
    name: 'Node.js Runtime',
    language: 'JavaScript',
    version: '20.10.0',
    command: 'node',
    extensions: ['.js', '.mjs', '.cjs'],
    flags: ['--experimental-modules', '--max-old-space-size=4096'],
    installed: true,
    category: 'interpreted',
    difficulty: 'beginner',
    popularity: 96,
    description: 'JavaScript runtime built on Chrome V8 engine',
    icon: '🟢',
    installSize: '89 MB',
    officialSite: 'https://nodejs.org'
  },
  {
    id: 'ruby',
    name: 'Ruby Interpreter',
    language: 'Ruby',
    version: '3.2.0',
    command: 'ruby',
    extensions: ['.rb', '.rbw'],
    flags: ['-W0', '--jit'],
    installed: false,
    category: 'interpreted',
    difficulty: 'beginner',
    popularity: 68,
    description: 'Dynamic programming language focused on simplicity',
    icon: '💎',
    installSize: '45 MB',
    officialSite: 'https://www.ruby-lang.org'
  },
  {
    id: 'php',
    name: 'PHP Interpreter',
    language: 'PHP',
    version: '8.2.13',
    command: 'php',
    extensions: ['.php', '.phtml'],
    flags: ['-f', '-d', 'error_reporting=E_ALL'],
    installed: false,
    category: 'interpreted',
    difficulty: 'beginner',
    popularity: 74,
    description: 'Server-side scripting language for web development',
    icon: '🐘',
    installSize: '78 MB',
    officialSite: 'https://www.php.net'
  },
  {
    id: 'lua',
    name: 'Lua Interpreter',
    language: 'Lua',
    version: '5.4.6',
    command: 'lua',
    extensions: ['.lua'],
    flags: ['-i', '-e'],
    installed: false,
    category: 'interpreted',
    difficulty: 'intermediate',
    popularity: 58,
    description: 'Lightweight scripting language for embedding',
    icon: '🌙',
    installSize: '12 MB',
    officialSite: 'https://www.lua.org'
  },
  {
    id: 'dart',
    name: 'Dart Compiler',
    language: 'Dart',
    version: '3.2.4',
    command: 'dart',
    extensions: ['.dart'],
    flags: ['compile', 'exe', '--optimization-level=2'],
    installed: false,
    category: 'hybrid',
    difficulty: 'intermediate',
    popularity: 70,
    description: 'Google Dart compiler for Flutter and web development',
    icon: '🎯',
    installSize: '167 MB',
    officialSite: 'https://dart.dev'
  }
];

interface LanguageCompilerManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function LanguageCompilerManager({ isOpen, onClose }: LanguageCompilerManagerProps) {
  const [compilers, setCompilers] = useState<CompilerConfig[]>(LANGUAGE_COMPILERS);
  const [selectedCompiler, setSelectedCompiler] = useState<CompilerConfig | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [isInstalling, setIsInstalling] = useState<string | null>(null);
  const [installProgress, setInstallProgress] = useState(0);
  const [testCode, setTestCode] = useState('');
  const [compilationResult, setCompilationResult] = useState<CompilationResult | null>(null);
  const [isCompiling, setIsCompiling] = useState(false);
  const { toast } = useToast();

  const filteredCompilers = compilers.filter(compiler => {
    const matchesSearch = compiler.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         compiler.language.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === 'all' || compiler.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const installedCount = compilers.filter(c => c.installed).length;
  const availableCount = compilers.length - installedCount;

  const handleInstallCompiler = async (compilerId: string) => {
    setIsInstalling(compilerId);
    setInstallProgress(0);

    // Simulate installation process
    const steps = [
      'Downloading compiler package...',
      'Extracting files...',
      'Installing dependencies...',
      'Configuring environment...',
      'Verifying installation...',
      'Updating package registry...'
    ];

    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800));
      setInstallProgress((i + 1) * (100 / steps.length));
      
      if (i === 3) {
        toast({
          title: "Installation Progress",
          description: steps[i],
        });
      }
    }

    setCompilers(prev => prev.map(c => 
      c.id === compilerId ? { ...c, installed: true } : c
    ));

    setIsInstalling(null);
    setInstallProgress(0);

    const compiler = compilers.find(c => c.id === compilerId);
    toast({
      title: "Installation Complete",
      description: `${compiler?.name} has been successfully installed and configured.`,
    });
  };

  const handleUninstallCompiler = (compilerId: string) => {
    setCompilers(prev => prev.map(c => 
      c.id === compilerId ? { ...c, installed: false } : c
    ));

    const compiler = compilers.find(c => c.id === compilerId);
    toast({
      title: "Compiler Uninstalled",
      description: `${compiler?.name} has been removed from the system.`,
      variant: "destructive",
    });
  };

  const handleTestCompiler = async () => {
    if (!selectedCompiler || !testCode.trim()) {
      toast({
        title: "Test Error",
        description: "Please select a compiler and enter test code.",
        variant: "destructive",
      });
      return;
    }

    setIsCompiling(true);
    
    // Simulate compilation
    await new Promise(resolve => setTimeout(resolve, 1500));

    const mockResult: CompilationResult = {
      success: Math.random() > 0.2, // 80% success rate
      output: testCode.includes('Hello') ? 'Hello, World!\nProgram executed successfully.' : 'Output generated successfully.',
      errors: Math.random() > 0.8 ? 'Warning: unused variable detected' : '',
      executionTime: Math.round(Math.random() * 2000 + 100),
      memoryUsage: `${Math.round(Math.random() * 50 + 10)} MB`,
      warnings: Math.random() > 0.6 ? ['Optimization suggestion: use const instead of let'] : []
    };

    setCompilationResult(mockResult);
    setIsCompiling(false);

    toast({
      title: mockResult.success ? "Compilation Successful" : "Compilation Failed",
      description: `${selectedCompiler.name} processed the code in ${mockResult.executionTime}ms`,
      variant: mockResult.success ? "default" : "destructive",
    });
  };

  const getTestCodeExample = (language: string): string => {
    const examples: Record<string, string> = {
      'C/C++': '#include <stdio.h>\n\nint main() {\n    printf("Hello, World!\\n");\n    return 0;\n}',
      'Rust': 'fn main() {\n    println!("Hello, World!");\n}',
      'Go': 'package main\n\nimport "fmt"\n\nfunc main() {\n    fmt.Println("Hello, World!")\n}',
      'Java': 'public class HelloWorld {\n    public static void main(String[] args) {\n        System.out.println("Hello, World!");\n    }\n}',
      'C#': 'using System;\n\nclass Program {\n    static void Main() {\n        Console.WriteLine("Hello, World!");\n    }\n}',
      'Python': 'print("Hello, World!")\n\n# Calculate factorial\ndef factorial(n):\n    return 1 if n <= 1 else n * factorial(n-1)\n\nprint(f"5! = {factorial(5)}")',
      'JavaScript': 'console.log("Hello, World!");\n\n// Arrow function example\nconst greet = (name) => `Hello, ${name}!`;\nconsole.log(greet("Developer"));',
      'Swift': 'import Foundation\n\nprint("Hello, World!")\n\n// Optional example\nlet name: String? = "Swift"\nif let unwrapped = name {\n    print("Hello, \\(unwrapped)!")\n}',
      'Kotlin': 'fun main() {\n    println("Hello, World!")\n    \n    // Extension function\n    fun String.greet() = "Hello, $this!"\n    println("Kotlin".greet())\n}',
      'Ruby': 'puts "Hello, World!"\n\n# Block example\n5.times do |i|\n  puts "Iteration #{i + 1}"\nend',
      'PHP': '<?php\necho "Hello, World!\\n";\n\n// Array example\n$languages = ["PHP", "JavaScript", "Python"];\nforeach ($languages as $lang) {\n    echo "I love $lang!\\n";\n}\n?>',
      'Dart': 'void main() {\n  print("Hello, World!");\n  \n  // List example\n  var numbers = [1, 2, 3, 4, 5];\n  numbers.forEach((n) => print("Number: $n"));\n}'
    };
    return examples[language] || `// ${language} code example\nconsole.log("Hello, World!");`;
  };

  useEffect(() => {
    if (selectedCompiler) {
      setTestCode(getTestCodeExample(selectedCompiler.language));
    }
  }, [selectedCompiler]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Code2 className="w-5 h-5" />
            Language Compiler Manager
            <Badge variant="outline" className="ml-auto">
              {installedCount} Installed • {availableCount} Available
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="compilers" className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="compilers">Compilers</TabsTrigger>
            <TabsTrigger value="installed">Installed</TabsTrigger>
            <TabsTrigger value="testing">Code Testing</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="compilers" className="flex-1 flex flex-col space-y-4">
            <div className="flex gap-4">
              <Input
                placeholder="Search compilers and languages..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-1"
              />
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="compiled">Compiled</SelectItem>
                  <SelectItem value="interpreted">Interpreted</SelectItem>
                  <SelectItem value="hybrid">Hybrid</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <ScrollArea className="flex-1">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredCompilers.map((compiler) => (
                  <Card key={compiler.id} className="relative">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{compiler.icon}</span>
                          <div>
                            <CardTitle className="text-sm">{compiler.name}</CardTitle>
                            <p className="text-xs text-muted-foreground">{compiler.language}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          {compiler.installed ? (
                            <Badge variant="default" className="text-xs">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Installed
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-xs">
                              Available
                            </Badge>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-3">
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>v{compiler.version}</span>
                        <span>{compiler.installSize}</span>
                      </div>
                      
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {compiler.description}
                      </p>
                      
                      <div className="flex items-center gap-2">
                        <Progress value={compiler.popularity} className="flex-1 h-1" />
                        <span className="text-xs text-muted-foreground">{compiler.popularity}%</span>
                      </div>
                      
                      <div className="flex gap-2">
                        {compiler.installed ? (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleUninstallCompiler(compiler.id)}
                              className="text-xs"
                            >
                              Uninstall
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => setSelectedCompiler(compiler)}
                              className="text-xs"
                            >
                              <Play className="w-3 h-3 mr-1" />
                              Test
                            </Button>
                          </>
                        ) : (
                          <Button
                            size="sm"
                            onClick={() => handleInstallCompiler(compiler.id)}
                            disabled={isInstalling === compiler.id}
                            className="text-xs w-full"
                          >
                            {isInstalling === compiler.id ? (
                              <>
                                <RefreshCw className="w-3 h-3 mr-1 animate-spin" />
                                Installing...
                              </>
                            ) : (
                              <>
                                <Download className="w-3 h-3 mr-1" />
                                Install
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                      
                      {isInstalling === compiler.id && (
                        <Progress value={installProgress} className="h-1" />
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="installed" className="flex-1 flex flex-col space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {compilers.filter(c => c.installed).map((compiler) => (
                <Card key={compiler.id}>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{compiler.icon}</span>
                      <div>
                        <CardTitle className="text-sm">{compiler.name}</CardTitle>
                        <p className="text-xs text-muted-foreground">{compiler.language} v{compiler.version}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span>Command:</span>
                        <code className="bg-muted px-1 rounded">{compiler.command}</code>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Extensions:</span>
                        <span>{compiler.extensions.join(', ')}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Category:</span>
                        <Badge variant="outline" className="text-xs capitalize">
                          {compiler.category}
                        </Badge>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => setSelectedCompiler(compiler)}
                        className="w-full text-xs"
                      >
                        <Terminal className="w-3 h-3 mr-1" />
                        Open Testing Console
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="testing" className="flex-1 flex flex-col space-y-4">
            <div className="flex gap-4">
              <Select
                value={selectedCompiler?.id || ''}
                onValueChange={(value) => {
                  const compiler = compilers.find(c => c.id === value);
                  setSelectedCompiler(compiler || null);
                }}
              >
                <SelectTrigger className="w-64">
                  <SelectValue placeholder="Select compiler to test" />
                </SelectTrigger>
                <SelectContent>
                  {compilers.filter(c => c.installed).map((compiler) => (
                    <SelectItem key={compiler.id} value={compiler.id}>
                      <div className="flex items-center gap-2">
                        <span>{compiler.icon}</span>
                        <span>{compiler.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Button
                onClick={handleTestCompiler}
                disabled={!selectedCompiler || isCompiling}
                className="ml-auto"
              >
                {isCompiling ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Compiling...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Compile & Run
                  </>
                )}
              </Button>
            </div>

            {selectedCompiler && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 flex-1">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Test Code ({selectedCompiler.language})</label>
                  <Textarea
                    value={testCode}
                    onChange={(e) => setTestCode(e.target.value)}
                    placeholder={`Enter ${selectedCompiler.language} code to test...`}
                    className="font-mono text-sm min-h-[300px]"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Compilation Results</label>
                  <Card className="min-h-[300px]">
                    <CardContent className="p-4">
                      {compilationResult ? (
                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            {compilationResult.success ? (
                              <CheckCircle className="w-4 h-4 text-green-500" />
                            ) : (
                              <XCircle className="w-4 h-4 text-red-500" />
                            )}
                            <span className="font-medium">
                              {compilationResult.success ? 'Success' : 'Failed'}
                            </span>
                            <Badge variant="outline" className="ml-auto">
                              <Clock className="w-3 h-3 mr-1" />
                              {compilationResult.executionTime}ms
                            </Badge>
                          </div>

                          {compilationResult.output && (
                            <div>
                              <h4 className="text-sm font-medium mb-1">Output:</h4>
                              <pre className="text-xs bg-muted p-2 rounded border overflow-auto">
                                {compilationResult.output}
                              </pre>
                            </div>
                          )}

                          {compilationResult.errors && (
                            <div>
                              <h4 className="text-sm font-medium mb-1 text-red-600">Errors:</h4>
                              <pre className="text-xs bg-red-50 p-2 rounded border text-red-600 overflow-auto">
                                {compilationResult.errors}
                              </pre>
                            </div>
                          )}

                          {compilationResult.warnings.length > 0 && (
                            <div>
                              <h4 className="text-sm font-medium mb-1 text-yellow-600">Warnings:</h4>
                              <ul className="text-xs space-y-1">
                                {compilationResult.warnings.map((warning, index) => (
                                  <li key={index} className="text-yellow-600">• {warning}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          <div className="flex gap-4 text-xs text-muted-foreground">
                            <span>Memory: {compilationResult.memoryUsage}</span>
                            <span>Time: {compilationResult.executionTime}ms</span>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center h-full text-muted-foreground">
                          <div className="text-center">
                            <Terminal className="w-8 h-8 mx-auto mb-2 opacity-50" />
                            <p className="text-sm">Run a compilation to see results</p>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="settings" className="flex-1 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Compiler Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Default Optimization Level</label>
                    <Select defaultValue="O2">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="O0">No optimization (-O0)</SelectItem>
                        <SelectItem value="O1">Basic optimization (-O1)</SelectItem>
                        <SelectItem value="O2">Standard optimization (-O2)</SelectItem>
                        <SelectItem value="O3">Maximum optimization (-O3)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Warning Level</label>
                    <Select defaultValue="all">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No warnings</SelectItem>
                        <SelectItem value="basic">Basic warnings</SelectItem>
                        <SelectItem value="all">All warnings (-Wall)</SelectItem>
                        <SelectItem value="extra">Extra warnings (-Wextra)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">System Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Total Compilers:</span>
                    <span>{compilers.length}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Installed:</span>
                    <span className="text-green-600">{installedCount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Available:</span>
                    <span className="text-blue-600">{availableCount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Disk Usage:</span>
                    <span>{Math.round(compilers.filter(c => c.installed).reduce((acc, c) => acc + parseInt(c.installSize), 0))} MB</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Update All Compilers
                  </Button>
                  <Button variant="outline" size="sm">
                    <Package className="w-4 h-4 mr-2" />
                    Install Popular Pack
                  </Button>
                  <Button variant="outline" size="sm">
                    <Globe className="w-4 h-4 mr-2" />
                    Check Online Registry
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}