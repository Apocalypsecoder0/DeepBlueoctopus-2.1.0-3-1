import React, { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  Palette, Monitor, Download, Upload, Copy,
  Eye, Settings, RefreshCw, Plus, Edit,
  Trash2, Star, Sun, Moon, Contrast
} from "lucide-react";

interface TerminalThemesProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TerminalTheme {
  id: string;
  name: string;
  description: string;
  author: string;
  category: 'dark' | 'light' | 'high-contrast' | 'custom';
  isBuiltIn: boolean;
  isFavorite: boolean;
  colors: {
    background: string;
    foreground: string;
    cursor: string;
    selection: string;
    black: string;
    red: string;
    green: string;
    yellow: string;
    blue: string;
    magenta: string;
    cyan: string;
    white: string;
    brightBlack: string;
    brightRed: string;
    brightGreen: string;
    brightYellow: string;
    brightBlue: string;
    brightMagenta: string;
    brightCyan: string;
    brightWhite: string;
  };
  font: {
    family: string;
    size: number;
    weight: number;
    lineHeight: number;
  };
  settings: {
    cursorStyle: 'block' | 'line' | 'underline';
    cursorBlink: boolean;
    scrollback: number;
    bellStyle: 'none' | 'sound' | 'visual';
    transparency: number;
  };
}

export default function TerminalThemes({ isOpen, onClose }: TerminalThemesProps) {
  const [themes, setThemes] = useState<TerminalTheme[]>([
    {
      id: '1',
      name: 'DeepBlue Ocean',
      description: 'Deep ocean theme with blue gradients and bioluminescent accents',
      author: 'DeepBlue IDE',
      category: 'dark',
      isBuiltIn: true,
      isFavorite: true,
      colors: {
        background: '#0B1426',
        foreground: '#E6F3FF',
        cursor: '#00D4FF',
        selection: '#1E3A8A50',
        black: '#0B1426',
        red: '#FF6B6B',
        green: '#4ECDC4',
        yellow: '#FFE66D',
        blue: '#4DABF7',
        magenta: '#845EC2',
        cyan: '#00D4FF',
        white: '#E6F3FF',
        brightBlack: '#374151',
        brightRed: '#FCA5A5',
        brightGreen: '#6EE7B7',
        brightYellow: '#FDE68A',
        brightBlue: '#93C5FD',
        brightMagenta: '#C4B5FD',
        brightCyan: '#7DD3FC',
        brightWhite: '#F9FAFB'
      },
      font: {
        family: 'JetBrains Mono',
        size: 14,
        weight: 400,
        lineHeight: 1.5
      },
      settings: {
        cursorStyle: 'block',
        cursorBlink: true,
        scrollback: 1000,
        bellStyle: 'visual',
        transparency: 95
      }
    },
    {
      id: '2',
      name: 'Dracula',
      description: 'A dark theme with purple accents',
      author: 'Dracula Theme',
      category: 'dark',
      isBuiltIn: true,
      isFavorite: false,
      colors: {
        background: '#282A36',
        foreground: '#F8F8F2',
        cursor: '#F8F8F0',
        selection: '#44475A',
        black: '#21222C',
        red: '#FF5555',
        green: '#50FA7B',
        yellow: '#F1FA8C',
        blue: '#BD93F9',
        magenta: '#FF79C6',
        cyan: '#8BE9FD',
        white: '#F8F8F2',
        brightBlack: '#6272A4',
        brightRed: '#FF6E6E',
        brightGreen: '#69FF94',
        brightYellow: '#FFFFA5',
        brightBlue: '#D6ACFF',
        brightMagenta: '#FF92DF',
        brightCyan: '#A4FFFF',
        brightWhite: '#FFFFFF'
      },
      font: {
        family: 'Fira Code',
        size: 14,
        weight: 400,
        lineHeight: 1.4
      },
      settings: {
        cursorStyle: 'line',
        cursorBlink: true,
        scrollback: 5000,
        bellStyle: 'none',
        transparency: 100
      }
    },
    {
      id: '3',
      name: 'Solarized Light',
      description: 'A light theme with warm colors',
      author: 'Ethan Schoonover',
      category: 'light',
      isBuiltIn: true,
      isFavorite: false,
      colors: {
        background: '#FDF6E3',
        foreground: '#657B83',
        cursor: '#586E75',
        selection: '#EEE8D5',
        black: '#073642',
        red: '#DC322F',
        green: '#859900',
        yellow: '#B58900',
        blue: '#268BD2',
        magenta: '#D33682',
        cyan: '#2AA198',
        white: '#EEE8D5',
        brightBlack: '#002B36',
        brightRed: '#CB4B16',
        brightGreen: '#586E75',
        brightYellow: '#657B83',
        brightBlue: '#839496',
        brightMagenta: '#6C71C4',
        brightCyan: '#93A1A1',
        brightWhite: '#FDF6E3'
      },
      font: {
        family: 'Source Code Pro',
        size: 13,
        weight: 400,
        lineHeight: 1.6
      },
      settings: {
        cursorStyle: 'underline',
        cursorBlink: false,
        scrollback: 2000,
        bellStyle: 'sound',
        transparency: 100
      }
    }
  ]);

  const [selectedTheme, setSelectedTheme] = useState<TerminalTheme>(themes[0]);
  const [isEditing, setIsEditing] = useState(false);
  const [editingTheme, setEditingTheme] = useState<Partial<TerminalTheme>>({});
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const { toast } = useToast();

  const filteredThemes = themes.filter(theme => 
    filterCategory === 'all' || theme.category === filterCategory
  );

  const handleApplyTheme = useCallback((theme: TerminalTheme) => {
    setSelectedTheme(theme);
    toast({
      title: "Theme applied",
      description: `${theme.name} theme has been applied to the terminal`,
    });
  }, [toast]);

  const handleCreateTheme = useCallback(() => {
    setEditingTheme({
      name: '',
      description: '',
      author: 'Custom',
      category: 'custom',
      isBuiltIn: false,
      isFavorite: false,
      colors: { ...themes[0].colors },
      font: { ...themes[0].font },
      settings: { ...themes[0].settings }
    });
    setIsEditing(true);
  }, [themes]);

  const handleEditTheme = useCallback((theme: TerminalTheme) => {
    if (theme.isBuiltIn) {
      // Create a copy for editing
      setEditingTheme({
        ...theme,
        id: undefined,
        name: `${theme.name} Copy`,
        isBuiltIn: false,
        author: 'Custom'
      });
    } else {
      setEditingTheme(theme);
    }
    setIsEditing(true);
  }, []);

  const handleSaveTheme = useCallback(() => {
    if (!editingTheme.name) {
      toast({
        title: "Validation error",
        description: "Theme name is required",
        variant: "destructive",
      });
      return;
    }

    const theme: TerminalTheme = {
      id: editingTheme.id || Date.now().toString(),
      name: editingTheme.name!,
      description: editingTheme.description || '',
      author: editingTheme.author || 'Custom',
      category: editingTheme.category || 'custom',
      isBuiltIn: editingTheme.isBuiltIn || false,
      isFavorite: editingTheme.isFavorite || false,
      colors: editingTheme.colors || themes[0].colors,
      font: editingTheme.font || themes[0].font,
      settings: editingTheme.settings || themes[0].settings
    };

    if (editingTheme.id) {
      setThemes(prev => prev.map(t => t.id === theme.id ? theme : t));
      toast({
        title: "Theme updated",
        description: "Theme has been updated successfully",
      });
    } else {
      setThemes(prev => [...prev, theme]);
      toast({
        title: "Theme created",
        description: "New theme has been created successfully",
      });
    }

    setIsEditing(false);
    setEditingTheme({});
  }, [editingTheme, themes, toast]);

  const handleDeleteTheme = useCallback((themeId: string) => {
    setThemes(prev => prev.filter(t => t.id !== themeId));
    toast({
      title: "Theme deleted",
      description: "Theme has been deleted",
    });
  }, [toast]);

  const handleToggleFavorite = useCallback((themeId: string) => {
    setThemes(prev => prev.map(t => 
      t.id === themeId ? { ...t, isFavorite: !t.isFavorite } : t
    ));
  }, []);

  const renderThemePreview = (theme: TerminalTheme) => (
    <div 
      className="h-32 rounded-lg p-3 font-mono text-sm overflow-hidden"
      style={{ 
        backgroundColor: theme.colors.background,
        color: theme.colors.foreground,
        fontFamily: theme.font.family,
        fontSize: `${theme.font.size}px`,
        lineHeight: theme.font.lineHeight
      }}
    >
      <div style={{ color: theme.colors.green }}>$ npm start</div>
      <div style={{ color: theme.colors.blue }}>Starting development server...</div>
      <div style={{ color: theme.colors.yellow }}>⚠ Warning: Development mode</div>
      <div style={{ color: theme.colors.cyan }}>✓ Server running on http://localhost:3000</div>
      <div style={{ color: theme.colors.magenta }}>◐ Watching for changes...</div>
    </div>
  );

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Palette className="w-5 h-5" />
            Terminal Themes
            <Badge variant="outline">
              {themes.length} themes
            </Badge>
          </DialogTitle>
        </DialogHeader>

        {!isEditing ? (
          <Tabs defaultValue="browse" className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="browse">Browse Themes</TabsTrigger>
              <TabsTrigger value="preview">Preview & Apply</TabsTrigger>
              <TabsTrigger value="manage">Manage Themes</TabsTrigger>
            </TabsList>

            <TabsContent value="browse" className="flex-1 flex flex-col space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <select
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                    className="px-3 py-2 border rounded-md"
                  >
                    <option value="all">All Categories</option>
                    <option value="dark">Dark Themes</option>
                    <option value="light">Light Themes</option>
                    <option value="high-contrast">High Contrast</option>
                    <option value="custom">Custom Themes</option>
                  </select>
                </div>
                <Button onClick={handleCreateTheme}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Theme
                </Button>
              </div>

              <ScrollArea className="flex-1">
                <div className="grid grid-cols-2 gap-4">
                  {filteredThemes.map((theme) => (
                    <Card key={theme.id} className="group">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="flex items-center gap-2 text-lg">
                              {theme.name}
                              {theme.isFavorite && (
                                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                              )}
                              <Badge variant="outline">{theme.category}</Badge>
                              {theme.isBuiltIn && (
                                <Badge variant="secondary">Built-in</Badge>
                              )}
                            </CardTitle>
                            <p className="text-sm text-gray-500 mt-1">
                              {theme.description}
                            </p>
                            <p className="text-xs text-gray-400 mt-1">
                              by {theme.author}
                            </p>
                          </div>
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleToggleFavorite(theme.id)}
                            >
                              <Star className={`w-4 h-4 ${theme.isFavorite ? 'text-yellow-500 fill-current' : ''}`} />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditTheme(theme)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            {!theme.isBuiltIn && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteTheme(theme.id)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        {renderThemePreview(theme)}
                        <div className="flex items-center justify-between mt-3">
                          <div className="text-sm text-gray-500">
                            {theme.font.family} {theme.font.size}px
                          </div>
                          <Button
                            size="sm"
                            onClick={() => handleApplyTheme(theme)}
                            className={selectedTheme.id === theme.id ? 'bg-blue-600' : ''}
                          >
                            {selectedTheme.id === theme.id ? 'Applied' : 'Apply'}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="preview" className="flex-1 flex flex-col space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    Current Theme: {selectedTheme.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium mb-3">Terminal Preview</h4>
                      <div className="border rounded-lg overflow-hidden">
                        {renderThemePreview(selectedTheme)}
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium mb-3">Theme Details</h4>
                      <div className="space-y-3 text-sm">
                        <div>
                          <span className="font-medium">Category:</span> {selectedTheme.category}
                        </div>
                        <div>
                          <span className="font-medium">Font:</span> {selectedTheme.font.family} {selectedTheme.font.size}px
                        </div>
                        <div>
                          <span className="font-medium">Cursor:</span> {selectedTheme.settings.cursorStyle}
                        </div>
                        <div>
                          <span className="font-medium">Transparency:</span> {selectedTheme.settings.transparency}%
                        </div>
                        <div>
                          <span className="font-medium">Scrollback:</span> {selectedTheme.settings.scrollback} lines
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Color Palette</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-8 gap-2">
                    {Object.entries(selectedTheme.colors).map(([name, color]) => (
                      <div key={name} className="text-center">
                        <div
                          className="w-8 h-8 rounded border mx-auto mb-1"
                          style={{ backgroundColor: color }}
                        />
                        <span className="text-xs text-gray-500">{name}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="manage" className="flex-1 flex flex-col space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <Palette className="w-8 h-8 mx-auto mb-2 text-blue-500" />
                    <p className="text-2xl font-bold">{themes.length}</p>
                    <p className="text-sm text-gray-500">Total Themes</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <Star className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
                    <p className="text-2xl font-bold">{themes.filter(t => t.isFavorite).length}</p>
                    <p className="text-sm text-gray-500">Favorites</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <Settings className="w-8 h-8 mx-auto mb-2 text-green-500" />
                    <p className="text-2xl font-bold">{themes.filter(t => !t.isBuiltIn).length}</p>
                    <p className="text-sm text-gray-500">Custom</p>
                  </CardContent>
                </Card>
              </div>

              <div className="flex gap-4">
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export Themes
                </Button>
                <Button variant="outline">
                  <Upload className="w-4 h-4 mr-2" />
                  Import Themes
                </Button>
                <Button variant="outline">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Reset to Defaults
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        ) : (
          <div className="flex-1 flex flex-col space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">
                {editingTheme.id ? 'Edit Theme' : 'Create New Theme'}
              </h3>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSaveTheme}>
                  Save Theme
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Theme Name *</label>
                  <Input
                    value={editingTheme.name || ''}
                    onChange={(e) => setEditingTheme(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter theme name"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">Description</label>
                  <Input
                    value={editingTheme.description || ''}
                    onChange={(e) => setEditingTheme(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Theme description"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Category</label>
                    <select
                      value={editingTheme.category || 'custom'}
                      onChange={(e) => setEditingTheme(prev => ({ ...prev, category: e.target.value as any }))}
                      className="w-full px-3 py-2 border rounded-md"
                    >
                      <option value="dark">Dark</option>
                      <option value="light">Light</option>
                      <option value="high-contrast">High Contrast</option>
                      <option value="custom">Custom</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Author</label>
                    <Input
                      value={editingTheme.author || ''}
                      onChange={(e) => setEditingTheme(prev => ({ ...prev, author: e.target.value }))}
                      placeholder="Author name"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">Colors</h4>
                  <div className="grid grid-cols-2 gap-3">
                    {editingTheme.colors && Object.entries(editingTheme.colors).map(([key, value]) => (
                      <div key={key} className="flex items-center gap-2">
                        <input
                          type="color"
                          value={value}
                          onChange={(e) => setEditingTheme(prev => ({
                            ...prev,
                            colors: { ...prev.colors!, [key]: e.target.value }
                          }))}
                          className="w-8 h-8 rounded border"
                        />
                        <span className="text-sm">{key}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-3">Preview</h4>
                  <div className="border rounded-lg overflow-hidden">
                    {editingTheme.colors && renderThemePreview(editingTheme as TerminalTheme)}
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">Font Settings</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-sm">Font Family</label>
                      <Input
                        value={editingTheme.font?.family || ''}
                        onChange={(e) => setEditingTheme(prev => ({
                          ...prev,
                          font: { ...prev.font!, family: e.target.value }
                        }))}
                        placeholder="Font family"
                      />
                    </div>
                    <div>
                      <label className="text-sm">Font Size</label>
                      <Input
                        type="number"
                        value={editingTheme.font?.size || 14}
                        onChange={(e) => setEditingTheme(prev => ({
                          ...prev,
                          font: { ...prev.font!, size: parseInt(e.target.value) }
                        }))}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">Terminal Settings</h4>
                  <div className="space-y-2">
                    <div>
                      <label className="text-sm">Cursor Style</label>
                      <select
                        value={editingTheme.settings?.cursorStyle || 'block'}
                        onChange={(e) => setEditingTheme(prev => ({
                          ...prev,
                          settings: { ...prev.settings!, cursorStyle: e.target.value as any }
                        }))}
                        className="w-full px-3 py-2 border rounded-md"
                      >
                        <option value="block">Block</option>
                        <option value="line">Line</option>
                        <option value="underline">Underline</option>
                      </select>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={editingTheme.settings?.cursorBlink || false}
                        onChange={(e) => setEditingTheme(prev => ({
                          ...prev,
                          settings: { ...prev.settings!, cursorBlink: e.target.checked }
                        }))}
                        className="rounded"
                      />
                      <span className="text-sm">Cursor blink</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}