import { useState, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Terminal, 
  Plus, 
  X, 
  Settings, 
  Play, 
  Square, 
  RefreshCw, 
  Download, 
  Upload, 
  Folder,
  FileText,
  Clock,
  Activity,
  Monitor,
  Cpu,
  HardDrive,
  Wifi,
  ChevronRight,
  ChevronDown,
  Copy,
  Trash2,
  PanelTop,
  PanelBottom,
  Maximize2,
  Minimize2
} from "lucide-react";

interface MultiTerminalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TerminalSession {
  id: string;
  name: string;
  shell: string;
  workingDirectory: string;
  isActive: boolean;
  isRunning: boolean;
  lastActivity: string;
  history: TerminalCommand[];
  environment: Record<string, string>;
}

interface TerminalCommand {
  id: string;
  command: string;
  output: string;
  timestamp: string;
  duration: number;
  exitCode: number;
}

interface SystemMonitor {
  cpu: number;
  memory: number;
  disk: number;
  network: {
    download: number;
    upload: number;
  };
  processes: ProcessInfo[];
}

interface ProcessInfo {
  pid: number;
  name: string;
  cpu: number;
  memory: number;
  status: string;
}

export default function MultiTerminal({ isOpen, onClose }: MultiTerminalProps) {
  const [activeTab, setActiveTab] = useState("terminals");
  const [currentInput, setCurrentInput] = useState("");
  const [selectedSession, setSelectedSession] = useState("1");
  const [splitMode, setSplitMode] = useState<"none" | "horizontal" | "vertical">("none");
  const inputRef = useRef<HTMLInputElement>(null);

  const [sessions, setSessions] = useState<TerminalSession[]>([
    {
      id: "1",
      name: "Main Terminal",
      shell: "bash",
      workingDirectory: "/workspace",
      isActive: true,
      isRunning: false,
      lastActivity: "2025-01-01 16:05:23",
      history: [
        {
          id: "1",
          command: "npm install",
          output: "✓ Dependencies installed successfully\n📦 Installed 142 packages",
          timestamp: "16:05:20",
          duration: 2.3,
          exitCode: 0
        },
        {
          id: "2", 
          command: "npm run dev",
          output: "🚀 Server running on http://localhost:5000\n📁 Watching for file changes...",
          timestamp: "16:05:23",
          duration: 0.1,
          exitCode: 0
        }
      ],
      environment: { NODE_ENV: "development", PORT: "5000" }
    },
    {
      id: "2",
      name: "Git Operations",
      shell: "bash",
      workingDirectory: "/workspace",
      isActive: false,
      isRunning: false,
      lastActivity: "2025-01-01 16:03:15",
      history: [
        {
          id: "1",
          command: "git status",
          output: "On branch main\nChanges not staged for commit:\n  modified: src/components/ide/top-menu-bar.tsx",
          timestamp: "16:03:15",
          duration: 0.05,
          exitCode: 0
        }
      ],
      environment: { GIT_EDITOR: "code --wait" }
    },
    {
      id: "3",
      name: "Python Environment",
      shell: "python",
      workingDirectory: "/workspace/scripts",
      isActive: false,
      isRunning: true,
      lastActivity: "2025-01-01 16:04:42",
      history: [
        {
          id: "1",
          command: "python --version",
          output: "Python 3.11.7",
          timestamp: "16:04:40",
          duration: 0.02,
          exitCode: 0
        },
        {
          id: "2",
          command: "pip install requests numpy",
          output: "Installing packages...\n✓ Successfully installed requests-2.31.0 numpy-1.24.3",
          timestamp: "16:04:42",
          duration: 1.8,
          exitCode: 0
        }
      ],
      environment: { PYTHONPATH: "/workspace/scripts" }
    }
  ]);

  const [systemMonitor] = useState<SystemMonitor>({
    cpu: 23.5,
    memory: 67.2,
    disk: 45.8,
    network: {
      download: 1.2,
      upload: 0.8
    },
    processes: [
      { pid: 1234, name: "node", cpu: 15.2, memory: 128.5, status: "running" },
      { pid: 5678, name: "typescript", cpu: 8.3, memory: 95.2, status: "running" },
      { pid: 9012, name: "vite", cpu: 5.1, memory: 67.8, status: "running" },
      { pid: 3456, name: "python", cpu: 3.2, memory: 45.6, status: "running" },
      { pid: 7890, name: "git", cpu: 0.1, memory: 12.3, status: "sleeping" }
    ]
  });

  const languages = [
    { id: "bash", name: "Bash", icon: "🐚", description: "Unix shell and command language" },
    { id: "zsh", name: "Zsh", icon: "⚡", description: "Extended Bourne shell with improvements" },
    { id: "powershell", name: "PowerShell", icon: "💻", description: "Microsoft PowerShell" },
    { id: "python", name: "Python", icon: "🐍", description: "Python interactive interpreter" },
    { id: "node", name: "Node.js", icon: "📗", description: "JavaScript runtime environment" },
    { id: "deno", name: "Deno", icon: "🦕", description: "Modern JavaScript/TypeScript runtime" }
  ];

  const currentSession = sessions.find(s => s.id === selectedSession) || sessions[0];

  const createNewSession = (shell: string = "bash") => {
    const newSession: TerminalSession = {
      id: Date.now().toString(),
      name: `${shell.charAt(0).toUpperCase() + shell.slice(1)} Terminal`,
      shell,
      workingDirectory: "/workspace",
      isActive: false,
      isRunning: false,
      lastActivity: new Date().toISOString(),
      history: [],
      environment: {}
    };
    setSessions(prev => [...prev, newSession]);
    setSelectedSession(newSession.id);
  };

  const closeSession = (sessionId: string) => {
    setSessions(prev => prev.filter(s => s.id !== sessionId));
    if (selectedSession === sessionId) {
      const remainingSessions = sessions.filter(s => s.id !== sessionId);
      if (remainingSessions.length > 0) {
        setSelectedSession(remainingSessions[0].id);
      }
    }
  };

  const executeCommand = () => {
    if (!currentInput.trim()) return;

    const command: TerminalCommand = {
      id: Date.now().toString(),
      command: currentInput,
      output: getCommandOutput(currentInput),
      timestamp: new Date().toLocaleTimeString(),
      duration: Math.random() * 0.5 + 0.1,
      exitCode: 0
    };

    setSessions(prev => prev.map(session => 
      session.id === selectedSession
        ? { ...session, history: [...session.history, command], lastActivity: new Date().toISOString() }
        : session
    ));

    setCurrentInput("");
  };

  const getCommandOutput = (command: string): string => {
    const cmd = command.toLowerCase().trim();
    
    if (cmd.startsWith("ls")) {
      return "drizzle.config.ts  package.json  replit.md  server/  shared/\nclient/  node_modules/  src/  tailwind.config.ts  vite.config.ts";
    } else if (cmd.startsWith("pwd")) {
      return "/workspace";
    } else if (cmd.startsWith("whoami")) {
      return "developer";
    } else if (cmd.startsWith("date")) {
      return new Date().toString();
    } else if (cmd.startsWith("git status")) {
      return "On branch main\nYour branch is up to date with 'origin/main'.\n\nChanges not staged for commit:\n  modified: client/src/components/ide/";
    } else if (cmd.startsWith("npm")) {
      return "✓ Command executed successfully";
    } else if (cmd.startsWith("python")) {
      return "Python 3.11.7 (main, Dec  4 2023, 18:10:11) [GCC 11.2.0] on linux\nType \"help\", \"copyright\", \"credits\" or \"license\" for more information.";
    } else if (cmd === "clear") {
      // Handle clear command
      setSessions(prev => prev.map(session => 
        session.id === selectedSession
          ? { ...session, history: [] }
          : session
      ));
      return "";
    } else {
      return `Command '${command}' executed in ${currentSession.shell} environment`;
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      executeCommand();
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "running": return "text-green-400";
      case "sleeping": return "text-yellow-400";
      case "stopped": return "text-red-400";
      default: return "text-gray-400";
    }
  };

  useEffect(() => {
    if (inputRef.current && activeTab === "terminals") {
      inputRef.current.focus();
    }
  }, [activeTab, selectedSession]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Terminal className="h-5 w-5 text-green-500" />
            Multi-Terminal Manager
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="grid grid-cols-4 w-full flex-shrink-0">
            <TabsTrigger value="terminals">Terminals ({sessions.length})</TabsTrigger>
            <TabsTrigger value="system">System Monitor</TabsTrigger>
            <TabsTrigger value="processes">Processes</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="terminals" className="flex-1 overflow-hidden">
            <div className="flex flex-col h-full">
              {/* Terminal Header */}
              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-t-lg border border-border/50 flex-shrink-0">
                <div className="flex items-center gap-2">
                  <Select value={selectedSession} onValueChange={setSelectedSession}>
                    <SelectTrigger className="w-48">
                      <Terminal className="h-4 w-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {sessions.map((session) => (
                        <SelectItem key={session.id} value={session.id}>
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${session.isRunning ? 'bg-green-400' : 'bg-gray-400'}`} />
                            {session.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Badge variant="outline">{currentSession.shell}</Badge>
                  <Badge variant="secondary" className="text-xs">
                    {currentSession.workingDirectory}
                  </Badge>
                </div>

                <div className="flex items-center gap-2">
                  <Button size="sm" variant="outline" onClick={() => createNewSession()}>
                    <Plus className="h-4 w-4 mr-1" />
                    New
                  </Button>
                  <Select onValueChange={(value) => createNewSession(value)}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Language" />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map((lang) => (
                        <SelectItem key={lang.id} value={lang.id}>
                          <div className="flex items-center gap-2">
                            <span>{lang.icon}</span>
                            {lang.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button size="sm" variant="outline">
                    <Settings className="h-4 w-4" />
                  </Button>
                  {sessions.length > 1 && (
                    <Button size="sm" variant="outline" onClick={() => closeSession(selectedSession)}>
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>

              {/* Terminal Content */}
              <div className="flex-1 bg-black text-green-400 font-mono text-sm p-4 overflow-hidden flex flex-col">
                <ScrollArea className="flex-1">
                  <div className="space-y-1">
                    {currentSession.history.map((cmd) => (
                      <div key={cmd.id} className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-blue-400">developer@workspace:</span>
                          <span className="text-purple-400">{currentSession.workingDirectory}</span>
                          <span className="text-gray-400">$</span>
                          <span className="text-white">{cmd.command}</span>
                        </div>
                        {cmd.output && (
                          <div className="text-gray-300 whitespace-pre-wrap pl-4">
                            {cmd.output}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                {/* Command Input */}
                <div className="flex items-center gap-2 mt-2 border-t border-gray-700 pt-2">
                  <span className="text-blue-400">developer@workspace:</span>
                  <span className="text-purple-400">{currentSession.workingDirectory}</span>
                  <span className="text-gray-400">$</span>
                  <Input
                    ref={inputRef}
                    value={currentInput}
                    onChange={(e) => setCurrentInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="flex-1 bg-transparent border-none text-white placeholder-gray-500 focus:ring-0"
                    placeholder="Enter command..."
                  />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="system" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              {/* System Resources */}
              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <CardTitle className="text-base">System Resources</CardTitle>
                  <CardDescription>Real-time system performance monitoring</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Cpu className="h-4 w-4 text-blue-400" />
                          <span>CPU Usage</span>
                        </div>
                        <span className="font-mono">{systemMonitor.cpu}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full transition-all duration-300" 
                          style={{ width: `${systemMonitor.cpu}%` }}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Activity className="h-4 w-4 text-green-400" />
                          <span>Memory Usage</span>
                        </div>
                        <span className="font-mono">{systemMonitor.memory}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full transition-all duration-300" 
                          style={{ width: `${systemMonitor.memory}%` }}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <HardDrive className="h-4 w-4 text-yellow-400" />
                          <span>Disk Usage</span>
                        </div>
                        <span className="font-mono">{systemMonitor.disk}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-yellow-500 h-2 rounded-full transition-all duration-300" 
                          style={{ width: `${systemMonitor.disk}%` }}
                        />
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Wifi className="h-4 w-4 text-purple-400" />
                        <span>Network Activity</span>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Download:</span>
                          <span className="font-mono">{systemMonitor.network.download} MB/s</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Upload:</span>
                          <span className="font-mono">{systemMonitor.network.upload} MB/s</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Active Sessions */}
              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <CardTitle className="text-base">Active Sessions</CardTitle>
                  <CardDescription>Terminal sessions and their status</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden">
                  <ScrollArea className="h-full">
                    <div className="space-y-3">
                      {sessions.map((session) => (
                        <div key={session.id} className="p-3 border rounded hover:bg-accent/50">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <div className={`w-2 h-2 rounded-full ${session.isRunning ? 'bg-green-400' : 'bg-gray-400'}`} />
                              <span className="font-medium">{session.name}</span>
                              {session.id === selectedSession && <Badge variant="default" className="text-xs">Active</Badge>}
                            </div>
                            <Badge variant="outline" className="text-xs">{session.shell}</Badge>
                          </div>
                          <div className="text-sm text-muted-foreground space-y-1">
                            <div className="flex items-center gap-2">
                              <Folder className="h-3 w-3" />
                              {session.workingDirectory}
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="h-3 w-3" />
                              Last activity: {new Date(session.lastActivity).toLocaleTimeString()}
                            </div>
                            <div className="flex items-center gap-2">
                              <FileText className="h-3 w-3" />
                              {session.history.length} commands executed
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="processes" className="flex-1 overflow-hidden">
            <Card className="h-full flex flex-col">
              <CardHeader className="flex-shrink-0">
                <CardTitle className="text-base">Running Processes</CardTitle>
                <CardDescription>Monitor and manage system processes</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 overflow-hidden">
                <ScrollArea className="h-full">
                  <div className="space-y-2">
                    <div className="grid grid-cols-5 gap-4 p-2 bg-muted/50 rounded text-sm font-medium">
                      <span>PID</span>
                      <span>Process</span>
                      <span>CPU %</span>
                      <span>Memory (MB)</span>
                      <span>Status</span>
                    </div>
                    {systemMonitor.processes.map((process) => (
                      <div key={process.pid} className="grid grid-cols-5 gap-4 p-2 hover:bg-accent/50 rounded text-sm">
                        <span className="font-mono">{process.pid}</span>
                        <span>{process.name}</span>
                        <span className="font-mono">{process.cpu}%</span>
                        <span className="font-mono">{process.memory}</span>
                        <Badge variant="outline" className={`text-xs w-fit ${getStatusColor(process.status)}`}>
                          {process.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="flex-1 overflow-hidden">
            <ScrollArea className="h-full">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Terminal Preferences</CardTitle>
                    <CardDescription>Customize terminal appearance and behavior</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Default Shell</label>
                        <Select defaultValue="bash">
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {languages.map((lang) => (
                              <SelectItem key={lang.id} value={lang.id}>
                                <div className="flex items-center gap-2">
                                  <span>{lang.icon}</span>
                                  {lang.name}
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Font Size</label>
                        <Select defaultValue="14">
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="12">12px</SelectItem>
                            <SelectItem value="14">14px</SelectItem>
                            <SelectItem value="16">16px</SelectItem>
                            <SelectItem value="18">18px</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Auto-save command history</span>
                        <p className="text-sm text-muted-foreground">Save terminal command history between sessions</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Show command execution time</span>
                        <p className="text-sm text-muted-foreground">Display how long each command took to execute</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Performance Monitoring</CardTitle>
                    <CardDescription>Configure system monitoring and alerts</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Enable real-time monitoring</span>
                        <p className="text-sm text-muted-foreground">Monitor system resources in real-time</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Update interval</label>
                      <Select defaultValue="1000">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="500">0.5 seconds</SelectItem>
                          <SelectItem value="1000">1 second</SelectItem>
                          <SelectItem value="2000">2 seconds</SelectItem>
                          <SelectItem value="5000">5 seconds</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}