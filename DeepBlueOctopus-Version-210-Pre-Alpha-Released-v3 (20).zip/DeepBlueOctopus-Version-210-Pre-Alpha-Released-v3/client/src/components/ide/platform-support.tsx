import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Monitor, 
  Smartphone, 
  Apple, 
  Download,
  Upload,
  Settings,
  Package,
  PlayCircle,
  CheckCircle,
  AlertCircle,
  Terminal,
  Code,
  Cpu,
  HardDrive,
  Wifi,
  Battery,
  Laptop,
  Server,
  Globe
} from "lucide-react";

interface PlatformSupportProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Platform {
  id: string;
  name: string;
  icon: any;
  category: 'desktop' | 'mobile' | 'embedded';
  supported: boolean;
  buildTime: string;
  packageSize: string;
  requirements: string[];
  features: string[];
}

interface BuildConfiguration {
  platform: string;
  buildType: 'debug' | 'release' | 'distribution';
  architecture: string[];
  optimizations: boolean;
  signing: boolean;
  minVersion: string;
}

export default function PlatformSupport({ isOpen, onClose }: PlatformSupportProps) {
  const [selectedPlatform, setSelectedPlatform] = useState<string>("macos");
  const [buildConfig, setBuildConfig] = useState<BuildConfiguration>({
    platform: "macos",
    buildType: "debug",
    architecture: ["x64"],
    optimizations: false,
    signing: false,
    minVersion: "10.15"
  });
  const [isBuilding, setIsBuilding] = useState(false);
  const [buildProgress, setBuildProgress] = useState(0);
  const [buildLogs, setBuildLogs] = useState<string[]>([]);

  const platforms: Platform[] = [
    {
      id: "macos",
      name: "macOS",
      icon: Apple,
      category: "desktop",
      supported: true,
      buildTime: "3-5 min",
      packageSize: "45-80 MB",
      requirements: ["Xcode Command Line Tools", "macOS 10.15+", "Apple Developer Account"],
      features: ["Native UI", "Touch Bar Support", "Notarization", "App Store Distribution", "Universal Binary"]
    },
    {
      id: "windows",
      name: "Windows",
      icon: Laptop,
      category: "desktop",
      supported: true,
      buildTime: "2-4 min",
      packageSize: "35-65 MB",
      requirements: ["Visual Studio Build Tools", "Windows 10+", "Code Signing Certificate"],
      features: ["Native Win32", "UWP Support", "Microsoft Store", "Auto Updates", "System Integration"]
    },
    {
      id: "linux",
      name: "Linux",
      icon: Server,
      category: "desktop",
      supported: true,
      buildTime: "2-3 min",
      packageSize: "30-55 MB",
      requirements: ["GCC/Clang", "GTK3+", "X11/Wayland", "Package Managers"],
      features: ["AppImage", "Snap Packages", "Flatpak", "DEB/RPM", "Multiple Distros"]
    },
    {
      id: "ios",
      name: "iOS",
      icon: Apple,
      category: "mobile",
      supported: true,
      buildTime: "5-8 min",
      packageSize: "25-45 MB",
      requirements: ["Xcode", "iOS 13+", "Apple Developer Program", "Provisioning Profiles"],
      features: ["Native iOS", "SwiftUI", "App Store", "TestFlight", "Push Notifications"]
    },
    {
      id: "android",
      name: "Android",
      icon: Smartphone,
      category: "mobile",
      supported: true,
      buildTime: "4-7 min",
      packageSize: "20-40 MB",
      requirements: ["Android SDK", "Android 7.0+", "Google Play Console", "Signing Keys"],
      features: ["Native Android", "Material Design", "Play Store", "AAB Support", "Background Tasks"]
    },
    {
      id: "web",
      name: "Web Progressive App",
      icon: Globe,
      category: "desktop",
      supported: true,
      buildTime: "1-2 min",
      packageSize: "10-25 MB",
      requirements: ["Modern Browser", "HTTPS", "Service Worker", "Web Manifest"],
      features: ["PWA", "Offline Support", "Push Notifications", "Install Prompt", "Cross Platform"]
    }
  ];

  const architectures = {
    macos: ["x64", "arm64", "universal"],
    windows: ["x64", "x86", "arm64"],
    linux: ["x64", "x86", "arm64", "armhf"],
    ios: ["arm64"],
    android: ["arm64-v8a", "armeabi-v7a", "x86_64"],
    web: ["universal"]
  };

  const handleBuild = async () => {
    setIsBuilding(true);
    setBuildProgress(0);
    setBuildLogs([]);

    const platform = platforms.find(p => p.id === selectedPlatform);
    if (!platform) return;

    const steps = [
      "Initializing build environment...",
      "Setting up platform toolchain...",
      "Compiling source code...",
      "Optimizing assets...",
      "Linking dependencies...",
      "Creating application bundle...",
      "Code signing (if enabled)...",
      "Packaging for distribution...",
      "Build completed successfully!"
    ];

    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800));
      setBuildLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${steps[i]}`]);
      setBuildProgress((i + 1) / steps.length * 100);
    }

    setIsBuilding(false);
  };

  const handleDeploy = (platform: string) => {
    setBuildLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Deploying to ${platform}...`]);
    // Simulate deployment process
    setTimeout(() => {
      setBuildLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Successfully deployed to ${platform}!`]);
    }, 2000);
  };

  const selectedPlatformData = platforms.find(p => p.id === selectedPlatform);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Cross-Platform Application Builder
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="platforms" className="h-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="platforms">Platforms</TabsTrigger>
            <TabsTrigger value="configuration">Configuration</TabsTrigger>
            <TabsTrigger value="build">Build & Deploy</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="platforms" className="space-y-4 h-[600px]">
            <ScrollArea className="h-full">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {platforms.map((platform) => {
                  const Icon = platform.icon;
                  return (
                    <Card key={platform.id} className={`cursor-pointer transition-all hover:scale-105 ${
                      selectedPlatform === platform.id ? 'ring-2 ring-blue-500' : ''
                    }`} onClick={() => setSelectedPlatform(platform.id)}>
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Icon className="h-8 w-8" />
                            <div>
                              <CardTitle className="text-lg">{platform.name}</CardTitle>
                              <CardDescription className="capitalize">{platform.category}</CardDescription>
                            </div>
                          </div>
                          <Badge variant={platform.supported ? "default" : "secondary"}>
                            {platform.supported ? "Supported" : "Coming Soon"}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <span className="font-medium">Build Time:</span>
                            <p className="text-muted-foreground">{platform.buildTime}</p>
                          </div>
                          <div>
                            <span className="font-medium">Package Size:</span>
                            <p className="text-muted-foreground">{platform.packageSize}</p>
                          </div>
                        </div>
                        
                        <div>
                          <span className="font-medium text-sm">Key Features:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {platform.features.slice(0, 3).map((feature, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {feature}
                              </Badge>
                            ))}
                            {platform.features.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{platform.features.length - 3} more
                              </Badge>
                            )}
                          </div>
                        </div>

                        <div>
                          <span className="font-medium text-sm">Requirements:</span>
                          <ul className="text-xs text-muted-foreground mt-1 space-y-1">
                            {platform.requirements.slice(0, 2).map((req, idx) => (
                              <li key={idx} className="flex items-center gap-1">
                                <CheckCircle className="h-3 w-3 text-green-500" />
                                {req}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="configuration" className="space-y-4 h-[600px]">
            <ScrollArea className="h-full">
              {selectedPlatformData && (
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <selectedPlatformData.icon className="h-5 w-5" />
                        {selectedPlatformData.name} Configuration
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="buildType">Build Type</Label>
                          <Select value={buildConfig.buildType} onValueChange={(value: any) => 
                            setBuildConfig(prev => ({ ...prev, buildType: value }))
                          }>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="debug">Debug</SelectItem>
                              <SelectItem value="release">Release</SelectItem>
                              <SelectItem value="distribution">Distribution</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="minVersion">Minimum Version</Label>
                          <Input 
                            value={buildConfig.minVersion}
                            onChange={(e) => setBuildConfig(prev => ({ ...prev, minVersion: e.target.value }))}
                            placeholder="e.g., 10.15"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Target Architectures</Label>
                        <div className="flex flex-wrap gap-2">
                          {architectures[selectedPlatform as keyof typeof architectures]?.map((arch) => (
                            <Badge 
                              key={arch}
                              variant={buildConfig.architecture.includes(arch) ? "default" : "outline"}
                              className="cursor-pointer"
                              onClick={() => {
                                setBuildConfig(prev => ({
                                  ...prev,
                                  architecture: prev.architecture.includes(arch)
                                    ? prev.architecture.filter(a => a !== arch)
                                    : [...prev.architecture, arch]
                                }));
                              }}
                            >
                              {arch}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <Label htmlFor="optimizations">Enable Optimizations</Label>
                        <Switch
                          checked={buildConfig.optimizations}
                          onCheckedChange={(checked) => 
                            setBuildConfig(prev => ({ ...prev, optimizations: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <Label htmlFor="signing">Code Signing</Label>
                        <Switch
                          checked={buildConfig.signing}
                          onCheckedChange={(checked) => 
                            setBuildConfig(prev => ({ ...prev, signing: checked }))
                          }
                        />
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Platform Requirements</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {selectedPlatformData.requirements.map((req, idx) => (
                          <div key={idx} className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            <span className="text-sm">{req}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Available Features</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-2">
                        {selectedPlatformData.features.map((feature, idx) => (
                          <Badge key={idx} variant="outline">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </ScrollArea>
          </TabsContent>

          <TabsContent value="build" className="space-y-4 h-[600px]">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="h-5 w-5" />
                      Build Controls
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex gap-2">
                      <Button 
                        onClick={handleBuild} 
                        disabled={isBuilding}
                        className="flex-1"
                      >
                        <PlayCircle className="h-4 w-4 mr-2" />
                        {isBuilding ? "Building..." : "Start Build"}
                      </Button>
                      <Button variant="outline" onClick={() => handleDeploy(selectedPlatform)}>
                        <Upload className="h-4 w-4 mr-2" />
                        Deploy
                      </Button>
                    </div>

                    {isBuilding && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Build Progress</span>
                          <span>{Math.round(buildProgress)}%</span>
                        </div>
                        <Progress value={buildProgress} />
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Platform:</span>
                        <p className="text-muted-foreground">{selectedPlatformData?.name}</p>
                      </div>
                      <div>
                        <span className="font-medium">Build Type:</span>
                        <p className="text-muted-foreground capitalize">{buildConfig.buildType}</p>
                      </div>
                      <div>
                        <span className="font-medium">Architectures:</span>
                        <p className="text-muted-foreground">{buildConfig.architecture.join(", ")}</p>
                      </div>
                      <div>
                        <span className="font-medium">Optimizations:</span>
                        <p className="text-muted-foreground">{buildConfig.optimizations ? "Enabled" : "Disabled"}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Quick Deploy</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-2">
                      {platforms.filter(p => p.supported).map((platform) => {
                        const Icon = platform.icon;
                        return (
                          <Button
                            key={platform.id}
                            variant="outline"
                            onClick={() => handleDeploy(platform.name)}
                            className="flex items-center gap-2"
                          >
                            <Icon className="h-4 w-4" />
                            {platform.name}
                          </Button>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Terminal className="h-5 w-5" />
                    Build Logs
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px] w-full border rounded-md p-3 bg-black text-green-400 font-mono text-sm">
                    {buildLogs.length === 0 ? (
                      <p className="text-muted-foreground">Build logs will appear here...</p>
                    ) : (
                      <div className="space-y-1">
                        {buildLogs.map((log, idx) => (
                          <div key={idx}>{log}</div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4 h-[600px]">
            <ScrollArea className="h-full">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Download className="h-5 w-5 text-blue-500" />
                      <div>
                        <p className="text-sm font-medium">Total Downloads</p>
                        <p className="text-2xl font-bold">1,247</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Monitor className="h-5 w-5 text-green-500" />
                      <div>
                        <p className="text-sm font-medium">Active Devices</p>
                        <p className="text-2xl font-bold">892</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-emerald-500" />
                      <div>
                        <p className="text-sm font-medium">Success Rate</p>
                        <p className="text-2xl font-bold">98.5%</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="h-5 w-5 text-orange-500" />
                      <div>
                        <p className="text-sm font-medium">Build Failures</p>
                        <p className="text-2xl font-bold">12</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Platform Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="flex items-center gap-2">
                          <Laptop className="h-4 w-4" />
                          Windows
                        </span>
                        <div className="flex items-center gap-2">
                          <Progress value={45} className="w-20" />
                          <span className="text-sm">45%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="flex items-center gap-2">
                          <Apple className="h-4 w-4" />
                          macOS
                        </span>
                        <div className="flex items-center gap-2">
                          <Progress value={30} className="w-20" />
                          <span className="text-sm">30%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="flex items-center gap-2">
                          <Server className="h-4 w-4" />
                          Linux
                        </span>
                        <div className="flex items-center gap-2">
                          <Progress value={15} className="w-20" />
                          <span className="text-sm">15%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="flex items-center gap-2">
                          <Smartphone className="h-4 w-4" />
                          Mobile
                        </span>
                        <div className="flex items-center gap-2">
                          <Progress value={10} className="w-20" />
                          <span className="text-sm">10%</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>System Performance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="flex items-center gap-2">
                          <Cpu className="h-4 w-4" />
                          CPU Usage
                        </span>
                        <div className="flex items-center gap-2">
                          <Progress value={65} className="w-20" />
                          <span className="text-sm">65%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="flex items-center gap-2">
                          <HardDrive className="h-4 w-4" />
                          Memory
                        </span>
                        <div className="flex items-center gap-2">
                          <Progress value={78} className="w-20" />
                          <span className="text-sm">78%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="flex items-center gap-2">
                          <Wifi className="h-4 w-4" />
                          Network
                        </span>
                        <div className="flex items-center gap-2">
                          <Progress value={92} className="w-20" />
                          <span className="text-sm">92%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="flex items-center gap-2">
                          <Battery className="h-4 w-4" />
                          Build Queue
                        </span>
                        <div className="flex items-center gap-2">
                          <Progress value={34} className="w-20" />
                          <span className="text-sm">34%</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}