import React, { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  GitMerge, ChevronDown, ChevronUp, Copy, 
  CheckCircle, XCircle, AlertTriangle, Download,
  ArrowLeft, ArrowRight, RefreshCw, Save
} from "lucide-react";

interface MergeConflictResolverProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ConflictBlock {
  id: string;
  startLine: number;
  endLine: number;
  currentContent: string[];
  incomingContent: string[];
  baseContent?: string[];
  resolved: boolean;
  resolution: 'current' | 'incoming' | 'both' | 'custom' | null;
  customContent?: string[];
}

interface ConflictFile {
  id: string;
  name: string;
  path: string;
  language: string;
  totalConflicts: number;
  resolvedConflicts: number;
  conflicts: ConflictBlock[];
  originalContent: string[];
  resolvedContent: string[];
}

export default function MergeConflictResolver({ isOpen, onClose }: MergeConflictResolverProps) {
  const [conflictFiles] = useState<ConflictFile[]>([
    {
      id: '1',
      name: 'user-service.ts',
      path: '/src/services/user-service.ts',
      language: 'typescript',
      totalConflicts: 2,
      resolvedConflicts: 0,
      conflicts: [
        {
          id: 'conflict-1',
          startLine: 15,
          endLine: 25,
          currentContent: [
            'export class UserService {',
            '  async getUser(id: string): Promise<User> {',
            '    const response = await fetch(`/api/users/${id}`);',
            '    return response.json();',
            '  }',
            '}'
          ],
          incomingContent: [
            'export class UserService {',
            '  async getUser(id: string): Promise<User | null> {',
            '    try {',
            '      const response = await fetch(`/api/users/${id}`);',
            '      if (!response.ok) return null;',
            '      return response.json();',
            '    } catch (error) {',
            '      console.error("Failed to fetch user:", error);',
            '      return null;',
            '    }',
            '  }',
            '}'
          ],
          baseContent: [
            'export class UserService {',
            '  async getUser(id: string) {',
            '    return fetch(`/api/users/${id}`);',
            '  }',
            '}'
          ],
          resolved: false,
          resolution: null
        },
        {
          id: 'conflict-2',
          startLine: 45,
          endLine: 55,
          currentContent: [
            'const validateEmail = (email: string): boolean => {',
            '  return /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email);',
            '};'
          ],
          incomingContent: [
            'const validateEmail = (email: string): boolean => {',
            '  const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$/;',
            '  return emailRegex.test(email.toLowerCase());',
            '};'
          ],
          resolved: false,
          resolution: null
        }
      ],
      originalContent: [],
      resolvedContent: []
    },
    {
      id: '2',
      name: 'api-client.ts',
      path: '/src/utils/api-client.ts',
      language: 'typescript',
      totalConflicts: 1,
      resolvedConflicts: 1,
      conflicts: [
        {
          id: 'conflict-3',
          startLine: 10,
          endLine: 20,
          currentContent: [
            'const API_BASE_URL = "http://localhost:3000";'
          ],
          incomingContent: [
            'const API_BASE_URL = process.env.REACT_APP_API_URL || "http://localhost:3000";'
          ],
          resolved: true,
          resolution: 'incoming'
        }
      ],
      originalContent: [],
      resolvedContent: []
    }
  ]);

  const [selectedFile, setSelectedFile] = useState<ConflictFile | null>(conflictFiles[0]);
  const [selectedConflict, setSelectedConflict] = useState<ConflictBlock | null>(null);
  const [customResolution, setCustomResolution] = useState('');

  const { updateFileContent } = useIDEState();
  const { toast } = useToast();

  const handleConflictResolution = useCallback((
    conflictId: string, 
    resolution: 'current' | 'incoming' | 'both' | 'custom',
    customContent?: string[]
  ) => {
    if (!selectedFile) return;

    const updatedConflicts = selectedFile.conflicts.map(conflict => {
      if (conflict.id === conflictId) {
        return {
          ...conflict,
          resolved: true,
          resolution,
          customContent: resolution === 'custom' ? customContent : undefined
        };
      }
      return conflict;
    });

    const resolvedCount = updatedConflicts.filter(c => c.resolved).length;
    
    setSelectedFile(prev => prev ? {
      ...prev,
      conflicts: updatedConflicts,
      resolvedConflicts: resolvedCount
    } : null);

    toast({
      title: "Conflict resolved",
      description: `Applied ${resolution} resolution for conflict`,
    });
  }, [selectedFile, toast]);

  const handleCustomResolution = useCallback(() => {
    if (!selectedConflict || !customResolution.trim()) return;

    const customLines = customResolution.split('\n');
    handleConflictResolution(selectedConflict.id, 'custom', customLines);
    setCustomResolution('');
  }, [selectedConflict, customResolution, handleConflictResolution]);

  const generateResolvedContent = useCallback((file: ConflictFile): string[] => {
    let resolvedLines: string[] = [...file.originalContent];
    
    file.conflicts.forEach(conflict => {
      if (!conflict.resolved) return;

      let replacementContent: string[];
      switch (conflict.resolution) {
        case 'current':
          replacementContent = conflict.currentContent;
          break;
        case 'incoming':
          replacementContent = conflict.incomingContent;
          break;
        case 'both':
          replacementContent = [
            ...conflict.currentContent,
            '',
            ...conflict.incomingContent
          ];
          break;
        case 'custom':
          replacementContent = conflict.customContent || conflict.currentContent;
          break;
        default:
          replacementContent = conflict.currentContent;
      }

      // Replace conflict lines with resolution
      resolvedLines.splice(
        conflict.startLine - 1,
        conflict.endLine - conflict.startLine + 1,
        ...replacementContent
      );
    });

    return resolvedLines;
  }, []);

  const saveResolvedFile = useCallback(async (file: ConflictFile) => {
    const unresolvedConflicts = file.conflicts.filter(c => !c.resolved);
    
    if (unresolvedConflicts.length > 0) {
      toast({
        title: "Unresolved conflicts",
        description: `Please resolve all ${unresolvedConflicts.length} remaining conflicts`,
        variant: "destructive",
      });
      return;
    }

    const resolvedContent = generateResolvedContent(file);
    const contentString = resolvedContent.join('\n');

    try {
      // Find the file and update its content
      // This would normally be handled by the file system
      toast({
        title: "File saved",
        description: `${file.name} has been saved with resolved conflicts`,
      });
    } catch (error) {
      toast({
        title: "Save failed",
        description: "Could not save the resolved file",
        variant: "destructive",
      });
    }
  }, [generateResolvedContent, toast]);

  const exportResolution = useCallback(() => {
    if (!selectedFile) return;

    const resolutionData = {
      file: selectedFile.name,
      conflicts: selectedFile.conflicts.map(c => ({
        id: c.id,
        lines: `${c.startLine}-${c.endLine}`,
        resolution: c.resolution,
        resolved: c.resolved
      })),
      exportedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(resolutionData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedFile.name}-conflict-resolution.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Resolution exported",
      description: "Conflict resolution data has been downloaded",
    });
  }, [selectedFile, toast]);

  const resetConflictResolution = useCallback((conflictId: string) => {
    if (!selectedFile) return;

    const updatedConflicts = selectedFile.conflicts.map(conflict => {
      if (conflict.id === conflictId) {
        return {
          ...conflict,
          resolved: false,
          resolution: null,
          customContent: undefined
        };
      }
      return conflict;
    });

    const resolvedCount = updatedConflicts.filter(c => c.resolved).length;
    
    setSelectedFile(prev => prev ? {
      ...prev,
      conflicts: updatedConflicts,
      resolvedConflicts: resolvedCount
    } : null);
  }, [selectedFile]);

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitMerge className="w-5 h-5" />
            Merge Conflict Resolver
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex gap-6">
          {/* File Sidebar */}
          <div className="w-80 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Conflicted Files</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {conflictFiles.map((file) => (
                    <Card
                      key={file.id}
                      className={`cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 ${
                        selectedFile?.id === file.id ? 'ring-2 ring-blue-500' : ''
                      }`}
                      onClick={() => setSelectedFile(file)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-sm">{file.name}</span>
                          <Badge variant="outline">{file.language}</Badge>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-500">{file.path}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-red-500">
                              {file.totalConflicts - file.resolvedConflicts}
                            </span>
                            <span>/</span>
                            <span className="text-green-500">
                              {file.resolvedConflicts}
                            </span>
                          </div>
                        </div>
                        <div className="mt-2 w-full bg-gray-200 rounded-full h-1">
                          <div 
                            className="bg-green-500 h-1 rounded-full transition-all"
                            style={{ 
                              width: `${(file.resolvedConflicts / file.totalConflicts) * 100}%` 
                            }}
                          />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {selectedFile && (
              <Card>
                <CardHeader>
                  <CardTitle>Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Button 
                      onClick={() => saveResolvedFile(selectedFile)}
                      disabled={selectedFile.resolvedConflicts !== selectedFile.totalConflicts}
                      className="w-full"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Resolved File
                    </Button>
                    <Button 
                      onClick={exportResolution}
                      variant="outline" 
                      className="w-full"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export Resolution
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {selectedFile ? (
              <Tabs defaultValue="conflicts">
                <TabsList>
                  <TabsTrigger value="conflicts">Conflicts</TabsTrigger>
                  <TabsTrigger value="preview">Preview</TabsTrigger>
                  <TabsTrigger value="diff">Diff View</TabsTrigger>
                </TabsList>

                <TabsContent value="conflicts" className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">
                      {selectedFile.name} - {selectedFile.totalConflicts} conflicts
                    </h3>
                    <Badge variant={selectedFile.resolvedConflicts === selectedFile.totalConflicts ? "default" : "destructive"}>
                      {selectedFile.resolvedConflicts}/{selectedFile.totalConflicts} resolved
                    </Badge>
                  </div>

                  <ScrollArea className="h-[600px]">
                    <div className="space-y-6">
                      {selectedFile.conflicts.map((conflict, index) => (
                        <Card key={conflict.id}>
                          <CardHeader>
                            <div className="flex items-center justify-between">
                              <CardTitle className="flex items-center gap-2">
                                {conflict.resolved ? (
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                ) : (
                                  <AlertTriangle className="w-4 h-4 text-red-500" />
                                )}
                                Conflict {index + 1} (Lines {conflict.startLine}-{conflict.endLine})
                              </CardTitle>
                              {conflict.resolved && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => resetConflictResolution(conflict.id)}
                                >
                                  <RefreshCw className="w-3 h-3 mr-1" />
                                  Reset
                                </Button>
                              )}
                            </div>
                          </CardHeader>
                          <CardContent>
                            <div className="grid grid-cols-2 gap-4">
                              {/* Current Version */}
                              <div className="space-y-2">
                                <div className="flex items-center justify-between">
                                  <h4 className="font-medium text-sm flex items-center gap-2">
                                    <ArrowLeft className="w-3 h-3 text-blue-500" />
                                    Current (HEAD)
                                  </h4>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleConflictResolution(conflict.id, 'current')}
                                    disabled={conflict.resolved}
                                  >
                                    Accept Current
                                  </Button>
                                </div>
                                <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 rounded p-3 text-xs font-mono">
                                  {conflict.currentContent.map((line, i) => (
                                    <div key={i} className="whitespace-pre">{line}</div>
                                  ))}
                                </div>
                              </div>

                              {/* Incoming Version */}
                              <div className="space-y-2">
                                <div className="flex items-center justify-between">
                                  <h4 className="font-medium text-sm flex items-center gap-2">
                                    <ArrowRight className="w-3 h-3 text-green-500" />
                                    Incoming
                                  </h4>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleConflictResolution(conflict.id, 'incoming')}
                                    disabled={conflict.resolved}
                                  >
                                    Accept Incoming
                                  </Button>
                                </div>
                                <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 rounded p-3 text-xs font-mono">
                                  {conflict.incomingContent.map((line, i) => (
                                    <div key={i} className="whitespace-pre">{line}</div>
                                  ))}
                                </div>
                              </div>
                            </div>

                            {/* Resolution Options */}
                            <div className="mt-4 space-y-3">
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleConflictResolution(conflict.id, 'both')}
                                  disabled={conflict.resolved}
                                >
                                  Accept Both
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => setSelectedConflict(conflict)}
                                  disabled={conflict.resolved}
                                >
                                  Custom Resolution
                                </Button>
                              </div>

                              {conflict.resolved && (
                                <div className="text-sm text-green-600 dark:text-green-400">
                                  ✓ Resolved with: {conflict.resolution}
                                  {conflict.resolution === 'custom' && ' (custom content)'}
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="preview" className="space-y-4">
                  <h3 className="text-lg font-semibold">Resolved File Preview</h3>
                  <ScrollArea className="h-[600px]">
                    <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded border font-mono text-xs">
                      {generateResolvedContent(selectedFile).map((line, index) => (
                        <div key={index} className="flex">
                          <span className="text-gray-400 mr-4 select-none w-8 text-right">
                            {index + 1}
                          </span>
                          <span className="whitespace-pre">{line}</span>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="diff" className="space-y-4">
                  <h3 className="text-lg font-semibold">Unified Diff View</h3>
                  <ScrollArea className="h-[600px]">
                    <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded border font-mono text-xs">
                      <div className="text-gray-500 mb-4">
                        --- a/{selectedFile.path}<br/>
                        +++ b/{selectedFile.path}
                      </div>
                      {selectedFile.conflicts.map((conflict, index) => (
                        <div key={conflict.id} className="mb-4">
                          <div className="text-blue-600">
                            @@ -{conflict.startLine},{conflict.endLine - conflict.startLine + 1} 
                            +{conflict.startLine},{conflict.incomingContent.length} @@
                          </div>
                          {conflict.currentContent.map((line, i) => (
                            <div key={i} className="text-red-600">-{line}</div>
                          ))}
                          {conflict.incomingContent.map((line, i) => (
                            <div key={i} className="text-green-600">+{line}</div>
                          ))}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </TabsContent>
              </Tabs>
            ) : (
              <div className="flex items-center justify-center h-[600px] text-gray-500">
                Select a file to resolve conflicts
              </div>
            )}
          </div>
        </div>

        {/* Custom Resolution Modal */}
        {selectedConflict && (
          <Dialog open={!!selectedConflict} onOpenChange={() => setSelectedConflict(null)}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Custom Resolution</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Custom Content (Lines {selectedConflict.startLine}-{selectedConflict.endLine})
                  </label>
                  <textarea
                    value={customResolution}
                    onChange={(e) => setCustomResolution(e.target.value)}
                    className="w-full h-40 p-3 border rounded font-mono text-xs"
                    placeholder="Enter your custom resolution..."
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setSelectedConflict(null)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCustomResolution} disabled={!customResolution.trim()}>
                    Apply Resolution
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </DialogContent>
    </Dialog>
  );
}