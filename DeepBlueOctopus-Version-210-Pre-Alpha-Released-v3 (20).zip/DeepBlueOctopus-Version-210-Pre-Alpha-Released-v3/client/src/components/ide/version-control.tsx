import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  GitBranch, 
  GitCommit, 
  GitMerge, 
  Plus, 
  Check, 
  X, 
  Clock, 
  User, 
  FileText,
  Download,
  Upload,
  Eye,
  Trash2,
  RefreshCw,
  Settings
} from "lucide-react";

interface VersionControlProps {
  isOpen: boolean;
  onClose: () => void;
}

interface GitFile {
  id: string;
  name: string;
  path: string;
  status: 'modified' | 'added' | 'deleted' | 'renamed' | 'untracked';
  staged: boolean;
}

interface GitCommit {
  id: string;
  hash: string;
  message: string;
  author: string;
  date: string;
  files: number;
  additions: number;
  deletions: number;
}

interface GitBranch {
  name: string;
  current: boolean;
  ahead: number;
  behind: number;
  lastCommit: string;
}

export default function VersionControl({ isOpen, onClose }: VersionControlProps) {
  const [activeTab, setActiveTab] = useState("changes");
  const [commitMessage, setCommitMessage] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());
  const [currentBranch, setCurrentBranch] = useState("main");
  const [newBranchName, setNewBranchName] = useState("");

  // Sample data - in real implementation, this would come from Git API
  const [gitFiles] = useState<GitFile[]>([
    { id: "1", name: "main.js", path: "/src/main.js", status: "modified", staged: false },
    { id: "2", name: "styles.css", path: "/src/styles.css", status: "modified", staged: true },
    { id: "3", name: "new-feature.ts", path: "/src/new-feature.ts", status: "added", staged: false },
    { id: "4", name: "old-component.tsx", path: "/src/old-component.tsx", status: "deleted", staged: false },
  ]);

  const [gitCommits] = useState<GitCommit[]>([
    {
      id: "1",
      hash: "a1b2c3d",
      message: "Add new UI components and styling improvements",
      author: "Developer",
      date: "2025-01-01 15:30",
      files: 5,
      additions: 127,
      deletions: 23
    },
    {
      id: "2", 
      hash: "e4f5g6h",
      message: "Fix responsive layout issues",
      author: "Developer",
      date: "2025-01-01 12:15",
      files: 3,
      additions: 45,
      deletions: 12
    },
    {
      id: "3",
      hash: "i7j8k9l",
      message: "Initial project setup with core functionality",
      author: "Developer", 
      date: "2024-12-31 18:45",
      files: 12,
      additions: 234,
      deletions: 0
    }
  ]);

  const [gitBranches] = useState<GitBranch[]>([
    { name: "main", current: true, ahead: 2, behind: 0, lastCommit: "a1b2c3d" },
    { name: "feature/ui-improvements", current: false, ahead: 0, behind: 3, lastCommit: "m2n3o4p" },
    { name: "bugfix/layout-fixes", current: false, ahead: 1, behind: 1, lastCommit: "q5r6s7t" },
  ]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'modified': return <FileText className="h-4 w-4 text-yellow-500" />;
      case 'added': return <Plus className="h-4 w-4 text-green-500" />;
      case 'deleted': return <X className="h-4 w-4 text-red-500" />;
      case 'renamed': return <RefreshCw className="h-4 w-4 text-blue-500" />;
      default: return <FileText className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'modified': return 'bg-yellow-500/20 text-yellow-300';
      case 'added': return 'bg-green-500/20 text-green-300';
      case 'deleted': return 'bg-red-500/20 text-red-300';
      case 'renamed': return 'bg-blue-500/20 text-blue-300';
      default: return 'bg-gray-500/20 text-gray-300';
    }
  };

  const toggleFileSelection = (fileId: string) => {
    const newSelection = new Set(selectedFiles);
    if (newSelection.has(fileId)) {
      newSelection.delete(fileId);
    } else {
      newSelection.add(fileId);
    }
    setSelectedFiles(newSelection);
  };

  const stageFile = (fileId: string) => {
    // In real implementation, this would call Git API
    console.log("Staging file:", fileId);
  };

  const unstageFile = (fileId: string) => {
    // In real implementation, this would call Git API
    console.log("Unstaging file:", fileId);
  };

  const commitChanges = () => {
    if (!commitMessage.trim()) return;
    // In real implementation, this would call Git API
    console.log("Committing changes:", commitMessage);
    setCommitMessage("");
  };

  const createBranch = () => {
    if (!newBranchName.trim()) return;
    // In real implementation, this would call Git API  
    console.log("Creating branch:", newBranchName);
    setNewBranchName("");
  };

  const switchBranch = (branchName: string) => {
    // In real implementation, this would call Git API
    setCurrentBranch(branchName);
    console.log("Switching to branch:", branchName);
  };

  const stagedFiles = gitFiles.filter(f => f.staged);
  const unstagedFiles = gitFiles.filter(f => !f.staged);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <GitBranch className="h-5 w-5 text-green-500" />
            Version Control - Git Integration
          </DialogTitle>
          <DialogDescription>
            Complete Git workflow with staging, commits, branches, and repository management
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="grid grid-cols-4 w-full flex-shrink-0">
            <TabsTrigger value="changes">Changes</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="branches">Branches</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="changes" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              {/* Changes Panel */}
              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">Working Directory</CardTitle>
                      <CardDescription>
                        Branch: <Badge variant="outline">{currentBranch}</Badge>
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <RefreshCw className="h-4 w-4 mr-1" />
                        Refresh
                      </Button>
                      <Button size="sm" variant="outline">
                        <Settings className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden flex flex-col">
                  <ScrollArea className="flex-1">
                    <div className="space-y-4">
                      {/* Staged Changes */}
                      {stagedFiles.length > 0 && (
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <h4 className="font-medium text-green-400">Staged Changes</h4>
                            <Badge variant="secondary">{stagedFiles.length}</Badge>
                          </div>
                          <div className="space-y-1">
                            {stagedFiles.map((file) => (
                              <div key={file.id} className="flex items-center gap-2 p-2 rounded hover:bg-accent/50">
                                <input
                                  type="checkbox"
                                  checked={selectedFiles.has(file.id)}
                                  onChange={() => toggleFileSelection(file.id)}
                                  className="rounded"
                                />
                                {getStatusIcon(file.status)}
                                <span className="flex-1 truncate">{file.name}</span>
                                <Badge className={getStatusColor(file.status)}>{file.status}</Badge>
                                <Button size="sm" variant="ghost" onClick={() => unstageFile(file.id)}>
                                  <X className="h-3 w-3" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Unstaged Changes */}
                      {unstagedFiles.length > 0 && (
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <h4 className="font-medium text-yellow-400">Changes</h4>
                            <Badge variant="secondary">{unstagedFiles.length}</Badge>
                          </div>
                          <div className="space-y-1">
                            {unstagedFiles.map((file) => (
                              <div key={file.id} className="flex items-center gap-2 p-2 rounded hover:bg-accent/50">
                                <input
                                  type="checkbox"
                                  checked={selectedFiles.has(file.id)}
                                  onChange={() => toggleFileSelection(file.id)}
                                  className="rounded"
                                />
                                {getStatusIcon(file.status)}
                                <span className="flex-1 truncate">{file.name}</span>
                                <Badge className={getStatusColor(file.status)}>{file.status}</Badge>
                                <Button size="sm" variant="ghost" onClick={() => stageFile(file.id)}>
                                  <Plus className="h-3 w-3" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Commit Panel */}
              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <CardTitle className="text-base">Commit Changes</CardTitle>
                  <CardDescription>Create a new commit with staged changes</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Commit Message</label>
                    <Textarea
                      placeholder="Enter commit message..."
                      value={commitMessage}
                      onChange={(e) => setCommitMessage(e.target.value)}
                      rows={3}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-sm text-muted-foreground">
                      {stagedFiles.length} staged files
                    </div>
                    <Button 
                      onClick={commitChanges}
                      disabled={!commitMessage.trim() || stagedFiles.length === 0}
                    >
                      <GitCommit className="h-4 w-4 mr-2" />
                      Commit
                    </Button>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <h4 className="font-medium">Quick Actions</h4>
                    <div className="grid grid-cols-2 gap-2">
                      <Button variant="outline" size="sm">
                        <Upload className="h-4 w-4 mr-1" />
                        Push
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-1" />
                        Pull
                      </Button>
                      <Button variant="outline" size="sm">
                        <GitMerge className="h-4 w-4 mr-1" />
                        Merge
                      </Button>
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4 mr-1" />
                        Diff
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="history" className="flex-1 overflow-hidden">
            <Card className="h-full flex flex-col">
              <CardHeader className="flex-shrink-0">
                <CardTitle className="text-base">Commit History</CardTitle>
                <CardDescription>Recent commits on branch: {currentBranch}</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 overflow-hidden">
                <ScrollArea className="h-full">
                  <div className="space-y-3">
                    {gitCommits.map((commit) => (
                      <div key={commit.id} className="p-4 border rounded hover:bg-accent/50">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <GitCommit className="h-4 w-4 text-blue-400" />
                              <span className="font-medium">{commit.message}</span>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <User className="h-3 w-3" />
                                {commit.author}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {commit.date}
                              </span>
                            </div>
                          </div>
                          <Badge variant="outline" className="ml-2">{commit.hash}</Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm">
                          <span className="text-green-400">+{commit.additions}</span>
                          <span className="text-red-400">-{commit.deletions}</span>
                          <span className="text-muted-foreground">{commit.files} files</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="branches" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              {/* Branch List */}
              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <CardTitle className="text-base">Branches</CardTitle>
                  <CardDescription>Manage project branches</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden">
                  <ScrollArea className="h-full">
                    <div className="space-y-2">
                      {gitBranches.map((branch) => (
                        <div key={branch.name} className="flex items-center justify-between p-3 border rounded hover:bg-accent/50">
                          <div className="flex items-center gap-2">
                            <GitBranch className={`h-4 w-4 ${branch.current ? 'text-green-400' : 'text-gray-400'}`} />
                            <span className={branch.current ? 'font-medium text-green-400' : ''}>{branch.name}</span>
                            {branch.current && <Badge variant="default" className="text-xs">Current</Badge>}
                          </div>
                          <div className="flex items-center gap-2">
                            {branch.ahead > 0 && <Badge variant="outline" className="text-xs">↑{branch.ahead}</Badge>}
                            {branch.behind > 0 && <Badge variant="outline" className="text-xs">↓{branch.behind}</Badge>}
                            {!branch.current && (
                              <Button size="sm" variant="outline" onClick={() => switchBranch(branch.name)}>
                                Switch
                              </Button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Branch Actions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Branch Actions</CardTitle>
                  <CardDescription>Create and manage branches</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Create New Branch</label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Branch name..."
                        value={newBranchName}
                        onChange={(e) => setNewBranchName(e.target.value)}
                      />
                      <Button onClick={createBranch} disabled={!newBranchName.trim()}>
                        <Plus className="h-4 w-4 mr-1" />
                        Create
                      </Button>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <h4 className="font-medium">Branch Operations</h4>
                    <div className="grid grid-cols-1 gap-2">
                      <Button variant="outline" size="sm">
                        <GitMerge className="h-4 w-4 mr-1" />
                        Merge Branch
                      </Button>
                      <Button variant="outline" size="sm">
                        <Trash2 className="h-4 w-4 mr-1" />
                        Delete Branch
                      </Button>
                      <Button variant="outline" size="sm">
                        <RefreshCw className="h-4 w-4 mr-1" />
                        Rebase
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="flex-1 overflow-hidden">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Git Configuration</CardTitle>
                <CardDescription>Configure Git settings and preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">User Name</label>
                    <Input placeholder="Your name..." defaultValue="Developer" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">User Email</label>
                    <Input placeholder="your.email@example.com..." defaultValue="developer@example.com" />
                  </div>
                </div>

                <Separator />

                <div className="space-y-3">
                  <h4 className="font-medium">Repository Settings</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Default Branch</label>
                      <Input defaultValue="main" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Remote Origin</label>
                      <Input placeholder="https://github.com/user/repo.git" />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <Button variant="outline">Reset</Button>
                  <Button>Save Settings</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}