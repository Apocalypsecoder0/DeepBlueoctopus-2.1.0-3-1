import React, { useState, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Network, GitBranch, Database, Code, Users, FileText, 
  Save, Download, Upload, Zap, Settings, Eye, 
  Square, Circle, Diamond, Triangle, ArrowRight,
  Plus, Minus, RefreshCw, ZoomIn, ZoomOut
} from "lucide-react";

interface UMLDesignerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface UMLElement {
  id: string;
  type: 'class' | 'interface' | 'package' | 'actor' | 'usecase' | 'activity';
  x: number;
  y: number;
  width: number;
  height: number;
  title: string;
  properties: string[];
  methods: string[];
}

interface UMLConnection {
  id: string;
  type: 'association' | 'inheritance' | 'dependency' | 'aggregation' | 'composition';
  from: string;
  to: string;
}

export default function UMLDesigner({ isOpen, onClose }: UMLDesignerProps) {
  const [activeTab, setActiveTab] = useState("designer");
  const [diagramType, setDiagramType] = useState("class");
  const [elements, setElements] = useState<UMLElement[]>([]);
  const [connections, setConnections] = useState<UMLConnection[]>([]);
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [zoom, setZoom] = useState(1);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Sample UML templates
  const templates = [
    {
      name: "E-Commerce System",
      description: "Complete e-commerce class diagram with user, product, and order management",
      elements: [
        { id: '1', type: 'class' as const, x: 50, y: 50, width: 200, height: 150, title: 'User', properties: ['id: string', 'username: string', 'email: string'], methods: ['login()', 'logout()', 'updateProfile()'] },
        { id: '2', type: 'class' as const, x: 300, y: 50, width: 200, height: 150, title: 'Product', properties: ['id: string', 'name: string', 'price: number'], methods: ['updatePrice()', 'getDetails()'] },
        { id: '3', type: 'class' as const, x: 175, y: 250, width: 200, height: 150, title: 'Order', properties: ['id: string', 'userId: string', 'total: number'], methods: ['addProduct()', 'calculateTotal()'] }
      ]
    },
    {
      name: "Banking System",
      description: "Banking application with accounts, transactions, and customer management",
      elements: [
        { id: '1', type: 'class' as const, x: 50, y: 50, width: 200, height: 150, title: 'Customer', properties: ['id: string', 'name: string', 'address: string'], methods: ['openAccount()', 'closeAccount()'] },
        { id: '2', type: 'class' as const, x: 300, y: 50, width: 200, height: 150, title: 'Account', properties: ['accountNumber: string', 'balance: number'], methods: ['deposit()', 'withdraw()', 'getBalance()'] },
        { id: '3', type: 'class' as const, x: 175, y: 250, width: 200, height: 150, title: 'Transaction', properties: ['id: string', 'amount: number', 'date: Date'], methods: ['process()', 'rollback()'] }
      ]
    }
  ];

  const drawElement = (ctx: CanvasRenderingContext2D, element: UMLElement) => {
    const { x, y, width, height, title, properties, methods, type } = element;
    
    // Set styles
    ctx.fillStyle = selectedElement === element.id ? '#e3f2fd' : '#ffffff';
    ctx.strokeStyle = '#1976d2';
    ctx.lineWidth = 2;
    
    // Draw main rectangle
    ctx.fillRect(x, y, width, height);
    ctx.strokeRect(x, y, width, height);
    
    // Draw title section
    ctx.fillStyle = '#1976d2';
    ctx.fillRect(x, y, width, 30);
    
    // Draw title text
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 14px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(title, x + width / 2, y + 20);
    
    // Draw properties section
    ctx.fillStyle = '#000000';
    ctx.font = '12px Arial';
    ctx.textAlign = 'left';
    
    let currentY = y + 45;
    properties.forEach((prop, index) => {
      if (currentY < y + height - 20) {
        ctx.fillText(`• ${prop}`, x + 10, currentY);
        currentY += 15;
      }
    });
    
    // Draw separator line
    if (properties.length > 0 && methods.length > 0) {
      ctx.strokeStyle = '#cccccc';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x + 5, currentY + 5);
      ctx.lineTo(x + width - 5, currentY + 5);
      ctx.stroke();
      currentY += 15;
    }
    
    // Draw methods section
    methods.forEach((method, index) => {
      if (currentY < y + height - 10) {
        ctx.fillText(`• ${method}`, x + 10, currentY);
        currentY += 15;
      }
    });
  };

  const redrawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Apply zoom
    ctx.save();
    ctx.scale(zoom, zoom);
    
    // Draw grid
    ctx.strokeStyle = '#f0f0f0';
    ctx.lineWidth = 1;
    for (let i = 0; i < canvas.width / zoom; i += 20) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, canvas.height / zoom);
      ctx.stroke();
    }
    for (let i = 0; i < canvas.height / zoom; i += 20) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(canvas.width / zoom, i);
      ctx.stroke();
    }
    
    // Draw elements
    elements.forEach(element => {
      drawElement(ctx, element);
    });
    
    ctx.restore();
  };

  useEffect(() => {
    redrawCanvas();
  }, [elements, selectedElement, zoom]);

  const addElement = (type: UMLElement['type']) => {
    const newElement: UMLElement = {
      id: Date.now().toString(),
      type,
      x: 50 + elements.length * 30,
      y: 50 + elements.length * 30,
      width: 200,
      height: 150,
      title: `New${type.charAt(0).toUpperCase() + type.slice(1)}`,
      properties: ['property1: string', 'property2: number'],
      methods: ['method1()', 'method2()']
    };
    setElements([...elements, newElement]);
  };

  const loadTemplate = (template: typeof templates[0]) => {
    setElements(template.elements);
    setConnections([]);
    setSelectedElement(null);
  };

  const exportDiagram = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    // Create download link
    const link = document.createElement('a');
    link.download = 'uml-diagram.png';
    link.href = canvas.toDataURL();
    link.click();
  };

  const generateCode = () => {
    const code = elements.map(element => {
      if (element.type === 'class') {
        return `class ${element.title} {
${element.properties.map(prop => `  private ${prop};`).join('\n')}

${element.methods.map(method => `  public ${method} {
    // Implementation
  }`).join('\n\n')}
}`;
      }
      return `// ${element.title}`;
    }).join('\n\n');
    
    return code;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl w-full h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Network className="h-5 w-5" />
            UML Designer & Code Generator
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="designer">Visual Designer</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="code">Code Generation</TabsTrigger>
            <TabsTrigger value="export">Export & Share</TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-hidden">
            <TabsContent value="designer" className="h-full flex gap-4">
              {/* Toolbar */}
              <div className="w-64 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Diagram Type</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Select value={diagramType} onValueChange={setDiagramType}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="class">Class Diagram</SelectItem>
                        <SelectItem value="sequence">Sequence Diagram</SelectItem>
                        <SelectItem value="usecase">Use Case Diagram</SelectItem>
                        <SelectItem value="activity">Activity Diagram</SelectItem>
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Elements</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full justify-start"
                      onClick={() => addElement('class')}
                    >
                      <Square className="h-4 w-4 mr-2" />
                      Add Class
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full justify-start"
                      onClick={() => addElement('interface')}
                    >
                      <Circle className="h-4 w-4 mr-2" />
                      Add Interface
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full justify-start"
                      onClick={() => addElement('actor')}
                    >
                      <Users className="h-4 w-4 mr-2" />
                      Add Actor
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Tools</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="zoom">Zoom</Label>
                      <div className="flex items-center gap-1">
                        <Button size="sm" variant="outline" onClick={() => setZoom(Math.max(0.5, zoom - 0.1))}>
                          <ZoomOut className="h-3 w-3" />
                        </Button>
                        <span className="text-xs w-12 text-center">{Math.round(zoom * 100)}%</span>
                        <Button size="sm" variant="outline" onClick={() => setZoom(Math.min(2, zoom + 0.1))}>
                          <ZoomIn className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => {
                        setElements([]);
                        setConnections([]);
                        setSelectedElement(null);
                      }}
                    >
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Clear All
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Canvas */}
              <div className="flex-1 border rounded-lg overflow-hidden bg-white">
                <canvas
                  ref={canvasRef}
                  width={800}
                  height={600}
                  className="w-full h-full cursor-crosshair"
                  onClick={(e) => {
                    const rect = canvasRef.current?.getBoundingClientRect();
                    if (!rect) return;
                    
                    const x = (e.clientX - rect.left) / zoom;
                    const y = (e.clientY - rect.top) / zoom;
                    
                    // Check if clicked on an element
                    const clickedElement = elements.find(el => 
                      x >= el.x && x <= el.x + el.width &&
                      y >= el.y && y <= el.y + el.height
                    );
                    
                    setSelectedElement(clickedElement?.id || null);
                  }}
                />
              </div>
            </TabsContent>

            <TabsContent value="templates" className="h-full">
              <div className="grid grid-cols-2 gap-4 h-full overflow-auto">
                {templates.map((template, index) => (
                  <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-lg">{template.name}</CardTitle>
                      <CardDescription>{template.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="text-sm text-gray-600">
                          Elements: {template.elements.length} classes
                        </div>
                        <Button 
                          className="w-full"
                          onClick={() => loadTemplate(template)}
                        >
                          Load Template
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="code" className="h-full flex flex-col">
              <div className="mb-4">
                <h3 className="text-lg font-semibold mb-2">Generated Code</h3>
                <p className="text-sm text-gray-600">
                  Automatically generated code from your UML diagram
                </p>
              </div>
              <div className="flex-1 bg-gray-900 text-green-400 p-4 rounded-lg overflow-auto">
                <pre className="text-sm">{generateCode()}</pre>
              </div>
              <div className="mt-4 flex gap-2">
                <Button onClick={() => navigator.clipboard.writeText(generateCode())}>
                  <FileText className="h-4 w-4 mr-2" />
                  Copy Code
                </Button>
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Download Code
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="export" className="h-full">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Export Options</CardTitle>
                    <CardDescription>Save and share your UML diagrams</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Button onClick={exportDiagram}>
                        <Download className="h-4 w-4 mr-2" />
                        Export as PNG
                      </Button>
                      <Button variant="outline">
                        <FileText className="h-4 w-4 mr-2" />
                        Export as SVG
                      </Button>
                      <Button variant="outline">
                        <Code className="h-4 w-4 mr-2" />
                        Export as Code
                      </Button>
                      <Button variant="outline">
                        <Upload className="h-4 w-4 mr-2" />
                        Save to Project
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Share & Collaborate</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Switch id="public" />
                      <Label htmlFor="public">Make diagram public</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="realtime" />
                      <Label htmlFor="realtime">Enable real-time collaboration</Label>
                    </div>
                    <Button className="w-full">
                      <Users className="h-4 w-4 mr-2" />
                      Generate Share Link
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}