import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { 
  Search, 
  Star, 
  Download, 
  Filter, 
  TrendingUp, 
  Clock, 
  Crown,
  Package,
  ExternalLink,
  Heart,
  Shield,
  Zap,
  ChevronRight,
  Settings,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  XCircle,
  User,
  Calendar,
  Globe,
  Github,
  DollarSign
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import pluginSystem, { type PluginManifest, type Plugin } from '@/lib/plugin-system';

interface PluginMarketplaceProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function PluginMarketplace({ isOpen, onClose }: PluginMarketplaceProps) {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'downloads' | 'rating' | 'updated'>('downloads');
  const [marketplacePlugins, setMarketplacePlugins] = useState<PluginManifest[]>([]);
  const [installedPlugins, setInstalledPlugins] = useState<Plugin[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedPlugin, setSelectedPlugin] = useState<PluginManifest | null>(null);
  const [showPluginDetails, setShowPluginDetails] = useState(false);
  const [activeTab, setActiveTab] = useState<'marketplace' | 'installed' | 'updates'>('marketplace');

  const categories = [
    { id: 'all', name: 'All Categories', count: 0 },
    { id: 'editor', name: 'Editor', count: 0 },
    { id: 'theme', name: 'Themes', count: 0 },
    { id: 'language', name: 'Languages', count: 0 },
    { id: 'tool', name: 'Tools', count: 0 },
    { id: 'debugger', name: 'Debuggers', count: 0 },
    { id: 'integration', name: 'Integrations', count: 0 },
    { id: 'ui', name: 'UI Extensions', count: 0 },
    { id: 'productivity', name: 'Productivity', count: 0 }
  ];

  useEffect(() => {
    if (isOpen) {
      loadMarketplacePlugins();
      loadInstalledPlugins();
    }
  }, [isOpen]);

  useEffect(() => {
    if (searchQuery || selectedCategory !== 'all') {
      searchPlugins();
    } else {
      loadMarketplacePlugins();
    }
  }, [searchQuery, selectedCategory, sortBy]);

  const loadMarketplacePlugins = async () => {
    setLoading(true);
    try {
      const plugins = await pluginSystem.searchPlugins('', selectedCategory === 'all' ? undefined : selectedCategory);
      const sortedPlugins = sortPlugins(plugins);
      setMarketplacePlugins(sortedPlugins);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load marketplace plugins",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadInstalledPlugins = () => {
    const plugins = pluginSystem.getInstalledPlugins();
    setInstalledPlugins(plugins);
  };

  const searchPlugins = async () => {
    setLoading(true);
    try {
      const plugins = await pluginSystem.searchPlugins(
        searchQuery, 
        selectedCategory === 'all' ? undefined : selectedCategory
      );
      const sortedPlugins = sortPlugins(plugins);
      setMarketplacePlugins(sortedPlugins);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to search plugins",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const sortPlugins = (plugins: PluginManifest[]): PluginManifest[] => {
    return [...plugins].sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'downloads':
          return (b.downloads || 0) - (a.downloads || 0);
        case 'rating':
          return (b.rating || 0) - (a.rating || 0);
        case 'updated':
          return new Date(b.lastUpdated || 0).getTime() - new Date(a.lastUpdated || 0).getTime();
        default:
          return 0;
      }
    });
  };

  const handleInstallPlugin = async (plugin: PluginManifest) => {
    setLoading(true);
    try {
      const success = await pluginSystem.installPlugin(plugin);
      if (success) {
        toast({
          title: "Plugin Installed",
          description: `${plugin.name} has been installed successfully`
        });
        loadInstalledPlugins();
        
        // Activate the plugin if it's not premium or user has access
        if (!plugin.isPremium || hasPluginAccess(plugin)) {
          await pluginSystem.activatePlugin(plugin.id);
        }
      } else {
        throw new Error('Installation failed');
      }
    } catch (error) {
      toast({
        title: "Installation Failed",
        description: error instanceof Error ? error.message : "Failed to install plugin",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUninstallPlugin = async (pluginId: string) => {
    setLoading(true);
    try {
      const success = await pluginSystem.uninstallPlugin(pluginId);
      if (success) {
        toast({
          title: "Plugin Uninstalled",
          description: "Plugin has been uninstalled successfully"
        });
        loadInstalledPlugins();
      } else {
        throw new Error('Uninstallation failed');
      }
    } catch (error) {
      toast({
        title: "Uninstallation Failed",
        description: error instanceof Error ? error.message : "Failed to uninstall plugin",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleTogglePlugin = async (pluginId: string, isActive: boolean) => {
    try {
      if (isActive) {
        await pluginSystem.deactivatePlugin(pluginId);
      } else {
        await pluginSystem.activatePlugin(pluginId);
      }
      loadInstalledPlugins();
      toast({
        title: `Plugin ${isActive ? 'Deactivated' : 'Activated'}`,
        description: `Plugin has been ${isActive ? 'deactivated' : 'activated'} successfully`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${isActive ? 'deactivate' : 'activate'} plugin`,
        variant: "destructive"
      });
    }
  };

  const hasPluginAccess = (plugin: PluginManifest): boolean => {
    // Mock premium access check
    return !plugin.isPremium || Math.random() > 0.5; // 50% chance for demo
  };

  const isPluginInstalled = (pluginId: string): boolean => {
    return installedPlugins.some(p => p.manifest.id === pluginId);
  };

  const showPluginDetail = (plugin: PluginManifest) => {
    setSelectedPlugin(plugin);
    setShowPluginDetails(true);
  };

  const renderStars = (rating: number = 0) => {
    return (
      <div className="flex items-center gap-1">
        {Array.from({ length: 5 }, (_, i) => (
          <Star
            key={i}
            className={`h-3 w-3 ${
              i < Math.floor(rating) 
                ? 'fill-yellow-400 text-yellow-400' 
                : 'text-gray-300'
            }`}
          />
        ))}
        <span className="text-xs text-muted-foreground ml-1">{rating.toFixed(1)}</span>
      </div>
    );
  };

  const formatDownloads = (downloads: number = 0): string => {
    if (downloads >= 1000000) {
      return `${(downloads / 1000000).toFixed(1)}M`;
    } else if (downloads >= 1000) {
      return `${(downloads / 1000).toFixed(1)}K`;
    }
    return downloads.toString();
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Plugin Marketplace
            </DialogTitle>
            <DialogDescription>
              Discover and manage plugins to extend your IDE capabilities
            </DialogDescription>
          </DialogHeader>

          <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="marketplace" className="flex items-center gap-2">
                <Package className="h-4 w-4" />
                Marketplace
              </TabsTrigger>
              <TabsTrigger value="installed" className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4" />
                Installed ({installedPlugins.length})
              </TabsTrigger>
              <TabsTrigger value="updates" className="flex items-center gap-2">
                <RefreshCw className="h-4 w-4" />
                Updates
              </TabsTrigger>
            </TabsList>

            <TabsContent value="marketplace" className="space-y-4">
              {/* Search and Filters */}
              <div className="flex items-center gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search plugins..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={(value) => setSortBy(value as any)}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="downloads">Downloads</SelectItem>
                    <SelectItem value="rating">Rating</SelectItem>
                    <SelectItem value="name">Name</SelectItem>
                    <SelectItem value="updated">Last Updated</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Plugin Grid */}
              <ScrollArea className="h-[500px]">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-1">
                  {loading ? (
                    Array.from({ length: 6 }, (_, i) => (
                      <Card key={i} className="animate-pulse">
                        <CardHeader>
                          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                        </CardHeader>
                        <CardContent>
                          <div className="h-16 bg-gray-200 rounded"></div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    marketplacePlugins.map((plugin) => (
                      <Card 
                        key={plugin.id} 
                        className="cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => showPluginDetail(plugin)}
                      >
                        <CardHeader className="space-y-2">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-2">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={plugin.icon} />
                                <AvatarFallback>
                                  {plugin.name.substring(0, 2).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <CardTitle className="text-sm flex items-center gap-1">
                                  {plugin.name}
                                  {plugin.isPremium && (
                                    <Crown className="h-3 w-3 text-yellow-500" />
                                  )}
                                </CardTitle>
                                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                  <User className="h-3 w-3" />
                                  {plugin.author}
                                </div>
                              </div>
                            </div>
                            <Badge variant="secondary" className="text-xs">
                              {plugin.category}
                            </Badge>
                          </div>
                          <CardDescription className="text-xs line-clamp-2">
                            {plugin.description}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="flex items-center justify-between text-xs">
                            {renderStars(plugin.rating)}
                            <div className="flex items-center gap-1 text-muted-foreground">
                              <Download className="h-3 w-3" />
                              {formatDownloads(plugin.downloads)}
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            {isPluginInstalled(plugin.id) ? (
                              <Badge variant="default" className="text-xs">
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Installed
                              </Badge>
                            ) : (
                              <Button
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleInstallPlugin(plugin);
                                }}
                                disabled={loading}
                                className="flex-1 h-7 text-xs"
                              >
                                {plugin.isPremium && !hasPluginAccess(plugin) ? (
                                  <>
                                    <Crown className="h-3 w-3 mr-1" />
                                    ${plugin.pricing?.price || 'Premium'}
                                  </>
                                ) : (
                                  <>
                                    <Download className="h-3 w-3 mr-1" />
                                    Install
                                  </>
                                )}
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="installed" className="space-y-4">
              <ScrollArea className="h-[500px]">
                <div className="space-y-3">
                  {installedPlugins.map((plugin) => (
                    <Card key={plugin.manifest.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={plugin.manifest.icon} />
                              <AvatarFallback>
                                {plugin.manifest.name.substring(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="flex items-center gap-2">
                                <h3 className="font-medium text-sm">{plugin.manifest.name}</h3>
                                <Badge 
                                  variant={plugin.isActive ? "default" : "secondary"}
                                  className="text-xs"
                                >
                                  {plugin.isActive ? "Active" : "Inactive"}
                                </Badge>
                                {plugin.manifest.isPremium && (
                                  <Crown className="h-3 w-3 text-yellow-500" />
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground">{plugin.manifest.description}</p>
                              <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                                <span>v{plugin.manifest.version}</span>
                                <span>{plugin.manifest.author}</span>
                                {plugin.activationTime && (
                                  <span>Activated in {plugin.activationTime.toFixed(2)}ms</span>
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              variant={plugin.isActive ? "outline" : "default"}
                              size="sm"
                              onClick={() => handleTogglePlugin(plugin.manifest.id, plugin.isActive)}
                              className="h-7 text-xs"
                            >
                              {plugin.isActive ? "Disable" : "Enable"}
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => showPluginDetail(plugin.manifest)}
                              className="h-7 text-xs"
                            >
                              <Settings className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => handleUninstallPlugin(plugin.manifest.id)}
                              className="h-7 text-xs"
                            >
                              <XCircle className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  
                  {installedPlugins.length === 0 && (
                    <div className="text-center py-12">
                      <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium">No Plugins Installed</h3>
                      <p className="text-muted-foreground">Browse the marketplace to find plugins</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="updates" className="space-y-4">
              <div className="text-center py-12">
                <RefreshCw className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium">No Updates Available</h3>
                <p className="text-muted-foreground">All plugins are up to date</p>
              </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Plugin Details Modal */}
      {selectedPlugin && (
        <Dialog open={showPluginDetails} onOpenChange={setShowPluginDetails}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
            <DialogHeader>
              <div className="flex items-center gap-3">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={selectedPlugin.icon} />
                  <AvatarFallback>
                    {selectedPlugin.name.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <DialogTitle className="flex items-center gap-2">
                    {selectedPlugin.name}
                    {selectedPlugin.isPremium && (
                      <Crown className="h-4 w-4 text-yellow-500" />
                    )}
                  </DialogTitle>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>by {selectedPlugin.author}</span>
                    <span>v{selectedPlugin.version}</span>
                    <Badge variant="secondary">{selectedPlugin.category}</Badge>
                  </div>
                </div>
              </div>
            </DialogHeader>

            <div className="space-y-6">
              <div>
                <h3 className="font-medium mb-2">Description</h3>
                <p className="text-sm text-muted-foreground">{selectedPlugin.description}</p>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h3 className="font-medium mb-2">Statistics</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Downloads:</span>
                      <span>{formatDownloads(selectedPlugin.downloads)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Rating:</span>
                      {renderStars(selectedPlugin.rating)}
                    </div>
                    <div className="flex justify-between">
                      <span>Version:</span>
                      <span>{selectedPlugin.version}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>License:</span>
                      <span>{selectedPlugin.license}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Publisher</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Publisher:</span>
                      <span>{selectedPlugin.publisher}</span>
                    </div>
                    {selectedPlugin.homepage && (
                      <div className="flex justify-between">
                        <span>Website:</span>
                        <Button variant="link" size="sm" className="h-auto p-0 text-xs">
                          <ExternalLink className="h-3 w-3 mr-1" />
                          Visit
                        </Button>
                      </div>
                    )}
                    {selectedPlugin.repository && (
                      <div className="flex justify-between">
                        <span>Repository:</span>
                        <Button variant="link" size="sm" className="h-auto p-0 text-xs">
                          <Github className="h-3 w-3 mr-1" />
                          View Code
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {selectedPlugin.keywords && selectedPlugin.keywords.length > 0 && (
                <div>
                  <h3 className="font-medium mb-2">Keywords</h3>
                  <div className="flex flex-wrap gap-1">
                    {selectedPlugin.keywords.map((keyword) => (
                      <Badge key={keyword} variant="outline" className="text-xs">
                        {keyword}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {selectedPlugin.isPremium && selectedPlugin.pricing && (
                <div>
                  <h3 className="font-medium mb-2">Pricing</h3>
                  <Card className="bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <Crown className="h-4 w-4 text-yellow-600" />
                            <span className="font-medium">Premium Plugin</span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            {selectedPlugin.pricing.trialDays && 
                              `${selectedPlugin.pricing.trialDays}-day free trial available`
                            }
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold">
                            ${selectedPlugin.pricing.price} {selectedPlugin.pricing.currency}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {selectedPlugin.pricing.type}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowPluginDetails(false)}>
                  Close
                </Button>
                {!isPluginInstalled(selectedPlugin.id) && (
                  <Button 
                    onClick={() => {
                      handleInstallPlugin(selectedPlugin);
                      setShowPluginDetails(false);
                    }}
                    disabled={loading}
                  >
                    {selectedPlugin.isPremium && !hasPluginAccess(selectedPlugin) ? (
                      <>
                        <Crown className="h-4 w-4 mr-2" />
                        Purchase & Install
                      </>
                    ) : (
                      <>
                        <Download className="h-4 w-4 mr-2" />
                        Install
                      </>
                    )}
                  </Button>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}