import { useState, useEffect, useRef, useCallback } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import { SoundButton } from "@/components/ui/sound-system";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  Terminal, 
  Play, 
  Square, 
  RefreshCw, 
  Download, 
  Upload, 
  Settings, 
  Clock, 
  Cpu, 
  Memory, 
  HardDrive,
  Network,
  FileText,
  Code,
  Package,
  Database,
  Globe,
  Zap,
  AlertCircle,
  CheckCircle,
  XCircle,
  Info,
  Trash2,
  Copy,
  Plus,
  X,
  ChevronRight,
  History
} from "lucide-react";

interface TerminalSession {
  id: string;
  name: string;
  language: string;
  isActive: boolean;
  output: TerminalOutput[];
  command: string;
  workingDirectory: string;
  environment: Record<string, string>;
  isRunning: boolean;
  pid?: number;
}

interface TerminalOutput {
  id: string;
  type: 'command' | 'output' | 'error' | 'info' | 'warning' | 'success';
  content: string;
  timestamp: Date;
  executionTime?: number;
  exitCode?: number;
}

interface LanguageConfig {
  name: string;
  extension: string;
  command: string;
  args: string[];
  compileCommand?: string;
  compileArgs?: string[];
  interpreter: boolean;
  supportsInput: boolean;
  icon: any;
  color: string;
}

export default function EnhancedTerminal() {
  const { activeTab } = useIDEState();
  const [sessions, setSessions] = useState<TerminalSession[]>([
    {
      id: 'default',
      name: 'Terminal 1',
      language: 'bash',
      isActive: true,
      output: [],
      command: '',
      workingDirectory: '/workspace',
      environment: {},
      isRunning: false
    }
  ]);
  const [activeSessionId, setActiveSessionId] = useState('default');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionProgress, setExecutionProgress] = useState(0);
  const [systemStats, setSystemStats] = useState({
    cpu: 45,
    memory: 62,
    disk: 78,
    network: 12
  });
  const [showStats, setShowStats] = useState(false);
  const [autoScroll, setAutoScroll] = useState(true);
  const terminalRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const languages: Record<string, LanguageConfig> = {
    javascript: {
      name: 'JavaScript',
      extension: '.js',
      command: 'node',
      args: [],
      interpreter: true,
      supportsInput: true,
      icon: Code,
      color: 'text-yellow-400'
    },
    typescript: {
      name: 'TypeScript',
      extension: '.ts',
      command: 'tsx',
      args: [],
      interpreter: true,
      supportsInput: true,
      icon: Code,
      color: 'text-blue-400'
    },
    python: {
      name: 'Python',
      extension: '.py',
      command: 'python3',
      args: [],
      interpreter: true,
      supportsInput: true,
      icon: Code,
      color: 'text-green-400'
    },
    java: {
      name: 'Java',
      extension: '.java',
      command: 'java',
      args: [],
      compileCommand: 'javac',
      compileArgs: [],
      interpreter: false,
      supportsInput: true,
      icon: Package,
      color: 'text-orange-400'
    },
    cpp: {
      name: 'C++',
      extension: '.cpp',
      command: './a.out',
      args: [],
      compileCommand: 'g++',
      compileArgs: ['-o', 'a.out'],
      interpreter: false,
      supportsInput: true,
      icon: Zap,
      color: 'text-purple-400'
    },
    c: {
      name: 'C',
      extension: '.c',
      command: './a.out',
      args: [],
      compileCommand: 'gcc',
      compileArgs: ['-o', 'a.out'],
      interpreter: false,
      supportsInput: true,
      icon: Zap,
      color: 'text-cyan-400'
    },
    rust: {
      name: 'Rust',
      extension: '.rs',
      command: './main',
      args: [],
      compileCommand: 'rustc',
      compileArgs: ['-o', 'main'],
      interpreter: false,
      supportsInput: true,
      icon: Package,
      color: 'text-red-400'
    },
    go: {
      name: 'Go',
      extension: '.go',
      command: 'go',
      args: ['run'],
      interpreter: true,
      supportsInput: true,
      icon: Globe,
      color: 'text-blue-300'
    },
    php: {
      name: 'PHP',
      extension: '.php',
      command: 'php',
      args: [],
      interpreter: true,
      supportsInput: true,
      icon: Code,
      color: 'text-purple-300'
    },
    ruby: {
      name: 'Ruby',
      extension: '.rb',
      command: 'ruby',
      args: [],
      interpreter: true,
      supportsInput: true,
      icon: Code,
      color: 'text-red-300'
    },
    bash: {
      name: 'Bash',
      extension: '.sh',
      command: 'bash',
      args: [],
      interpreter: true,
      supportsInput: true,
      icon: Terminal,
      color: 'text-gray-400'
    }
  };

  const activeSession = sessions.find(s => s.id === activeSessionId) || sessions[0];

  useEffect(() => {
    if (autoScroll && terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [activeSession.output, autoScroll]);

  useEffect(() => {
    // Simulate system stats updates
    const interval = setInterval(() => {
      setSystemStats(prev => ({
        cpu: Math.max(0, Math.min(100, prev.cpu + (Math.random() - 0.5) * 10)),
        memory: Math.max(0, Math.min(100, prev.memory + (Math.random() - 0.5) * 5)),
        disk: Math.max(0, Math.min(100, prev.disk + (Math.random() - 0.5) * 2)),
        network: Math.max(0, Math.min(100, Math.random() * 50))
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const addOutput = useCallback((sessionId: string, output: Omit<TerminalOutput, 'id' | 'timestamp'>) => {
    setSessions(prev => prev.map(session => 
      session.id === sessionId 
        ? {
            ...session,
            output: [...session.output, {
              ...output,
              id: Date.now().toString(),
              timestamp: new Date()
            }]
          }
        : session
    ));
  }, []);

  const executeCommand = async (sessionId: string, command: string) => {
    const session = sessions.find(s => s.id === sessionId);
    if (!session) return;

    setIsExecuting(true);
    setExecutionProgress(0);

    // Add command to output
    addOutput(sessionId, {
      type: 'command',
      content: `${session.workingDirectory}$ ${command}`
    });

    // Add to command history
    setCommandHistory(prev => [...prev.filter(cmd => cmd !== command), command]);
    setHistoryIndex(-1);

    try {
      // Simulate execution progress
      const progressInterval = setInterval(() => {
        setExecutionProgress(prev => Math.min(95, prev + Math.random() * 15));
      }, 100);

      // Process different types of commands
      if (command.startsWith('cd ')) {
        const newDir = command.substring(3).trim();
        setSessions(prev => prev.map(s => 
          s.id === sessionId 
            ? { ...s, workingDirectory: newDir.startsWith('/') ? newDir : `${s.workingDirectory}/${newDir}` }
            : s
        ));
        addOutput(sessionId, {
          type: 'success',
          content: `Changed directory to ${newDir}`
        });
      } else if (command === 'clear') {
        setSessions(prev => prev.map(s => 
          s.id === sessionId ? { ...s, output: [] } : s
        ));
      } else if (command === 'pwd') {
        addOutput(sessionId, {
          type: 'output',
          content: session.workingDirectory
        });
      } else if (command === 'ls' || command === 'dir') {
        addOutput(sessionId, {
          type: 'output',
          content: `src/\npackage.json\nREADME.md\n.gitignore\nnode_modules/\ndist/`
        });
      } else if (command === 'languages') {
        const langList = Object.entries(languages)
          .map(([key, lang]) => `${lang.name} (${key})`)
          .join('\n');
        addOutput(sessionId, {
          type: 'info',
          content: `Supported Languages:\n${langList}`
        });
      } else if (command === 'plugins') {
        addOutput(sessionId, {
          type: 'info',
          content: `Installed Plugins:\n• Language Support Pack\n• Advanced Debugger\n• Git Integration\n• Code Formatter\n• IntelliSense Engine`
        });
      } else if (command.startsWith('run ')) {
        const fileName = command.substring(4).trim();
        await executeFile(sessionId, fileName);
      } else if (command.startsWith('compile ')) {
        const fileName = command.substring(8).trim();
        await compileFile(sessionId, fileName);
      } else if (command === 'npm install' || command === 'npm i') {
        addOutput(sessionId, {
          type: 'info',
          content: 'Installing npm packages...'
        });
        
        // Simulate package installation
        setTimeout(() => {
          addOutput(sessionId, {
            type: 'success',
            content: 'npm packages installed successfully\n✓ Dependencies resolved\n✓ Node modules updated'
          });
        }, 2000);
      } else if (command.startsWith('git ')) {
        await executeGitCommand(sessionId, command);
      } else {
        // Generic command execution
        addOutput(sessionId, {
          type: 'output',
          content: `Command executed: ${command}\nOutput: Operation completed successfully`
        });
      }

      clearInterval(progressInterval);
      setExecutionProgress(100);
      
      setTimeout(() => {
        setExecutionProgress(0);
      }, 1000);

    } catch (error) {
      addOutput(sessionId, {
        type: 'error',
        content: `Error executing command: ${error}`
      });
    } finally {
      setIsExecuting(false);
    }
  };

  const executeFile = async (sessionId: string, fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    const language = Object.entries(languages).find(([_, lang]) => 
      lang.extension === `.${extension}`
    );

    if (!language) {
      addOutput(sessionId, {
        type: 'error',
        content: `Unsupported file type: ${extension}`
      });
      return;
    }

    const [langKey, langConfig] = language;

    addOutput(sessionId, {
      type: 'info',
      content: `Executing ${langConfig.name} file: ${fileName}`
    });

    // Simulate compilation if needed
    if (!langConfig.interpreter && langConfig.compileCommand) {
      addOutput(sessionId, {
        type: 'info',
        content: `Compiling with ${langConfig.compileCommand}...`
      });
      
      // Simulate compilation time
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      addOutput(sessionId, {
        type: 'success',
        content: 'Compilation successful'
      });
    }

    // Simulate execution
    await new Promise(resolve => setTimeout(resolve, 500));

    // Mock execution output based on language
    const outputs = {
      javascript: 'console.log("Hello from JavaScript!");\n"Hello from JavaScript!"',
      typescript: 'console.log("Hello from TypeScript!");\n"Hello from TypeScript!"',
      python: 'print("Hello from Python!")\nHello from Python!',
      java: 'public class Main {\n  public static void main(String[] args) {\n    System.out.println("Hello from Java!");\n  }\n}\nHello from Java!',
      cpp: '#include <iostream>\nint main() {\n  std::cout << "Hello from C++!" << std::endl;\n  return 0;\n}\nHello from C++!',
      c: '#include <stdio.h>\nint main() {\n  printf("Hello from C!\\n");\n  return 0;\n}\nHello from C!',
      rust: 'fn main() {\n  println!("Hello from Rust!");\n}\nHello from Rust!',
      go: 'package main\nimport "fmt"\nfunc main() {\n  fmt.Println("Hello from Go!")\n}\nHello from Go!',
      php: '<?php\necho "Hello from PHP!";\n?>\nHello from PHP!',
      ruby: 'puts "Hello from Ruby!"\nHello from Ruby!'
    };

    addOutput(sessionId, {
      type: 'output',
      content: outputs[langKey as keyof typeof outputs] || 'Program executed successfully',
      executionTime: Math.random() * 1000 + 100,
      exitCode: 0
    });
  };

  const compileFile = async (sessionId: string, fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    const language = Object.entries(languages).find(([_, lang]) => 
      lang.extension === `.${extension}`
    );

    if (!language) {
      addOutput(sessionId, {
        type: 'error',
        content: `Cannot compile: Unsupported file type ${extension}`
      });
      return;
    }

    const [langKey, langConfig] = language;

    if (langConfig.interpreter) {
      addOutput(sessionId, {
        type: 'warning',
        content: `${langConfig.name} is an interpreted language, no compilation needed`
      });
      return;
    }

    if (!langConfig.compileCommand) {
      addOutput(sessionId, {
        type: 'error',
        content: `No compiler configured for ${langConfig.name}`
      });
      return;
    }

    addOutput(sessionId, {
      type: 'info',
      content: `Compiling ${fileName} with ${langConfig.compileCommand}...`
    });

    // Simulate compilation time
    await new Promise(resolve => setTimeout(resolve, 2000));

    addOutput(sessionId, {
      type: 'success',
      content: `Compilation successful\nOutput: ${fileName.replace(/\.[^/.]+$/, "")}${langKey === 'cpp' || langKey === 'c' ? '.out' : '.exe'}`
    });
  };

  const executeGitCommand = async (sessionId: string, command: string) => {
    const gitCmd = command.substring(4).trim();
    
    const gitResponses: Record<string, string> = {
      'status': '# On branch main\n# Your branch is up to date with \'origin/main\'\n# nothing to commit, working tree clean',
      'log --oneline': '1a2b3c4 Fix terminal scrolling issue\n5d6e7f8 Add file manager component\n9g0h1i2 Update theme colors',
      'branch': '* main\n  develop\n  feature/terminal-enhancement',
      'remote -v': 'origin  https://github.com/user/repo.git (fetch)\norigin  https://github.com/user/repo.git (push)',
      'diff': 'diff --git a/src/terminal.tsx b/src/terminal.tsx\nindex 1234567..abcdefg 100644\n--- a/src/terminal.tsx\n+++ b/src/terminal.tsx\n@@ -10,6 +10,7 @@\n+  Enhanced terminal functionality'
    };

    const response = gitResponses[gitCmd] || `git ${gitCmd} executed successfully`;

    addOutput(sessionId, {
      type: 'output',
      content: response
    });
  };

  const createNewSession = () => {
    const newId = `session-${Date.now()}`;
    const newSession: TerminalSession = {
      id: newId,
      name: `Terminal ${sessions.length + 1}`,
      language: 'bash',
      isActive: false,
      output: [],
      command: '',
      workingDirectory: '/workspace',
      environment: {},
      isRunning: false
    };

    setSessions(prev => [...prev, newSession]);
    setActiveSessionId(newId);
  };

  const closeSession = (sessionId: string) => {
    if (sessions.length <= 1) return;
    
    setSessions(prev => prev.filter(s => s.id !== sessionId));
    if (activeSessionId === sessionId) {
      setActiveSessionId(sessions.find(s => s.id !== sessionId)?.id || sessions[0].id);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const command = e.currentTarget.value.trim();
      if (command) {
        executeCommand(activeSessionId, command);
        e.currentTarget.value = '';
        updateSessionCommand(activeSessionId, '');
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.length > 0) {
        const newIndex = Math.min(historyIndex + 1, commandHistory.length - 1);
        setHistoryIndex(newIndex);
        const command = commandHistory[commandHistory.length - 1 - newIndex];
        e.currentTarget.value = command;
        updateSessionCommand(activeSessionId, command);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        const command = commandHistory[commandHistory.length - 1 - newIndex];
        e.currentTarget.value = command;
        updateSessionCommand(activeSessionId, command);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        e.currentTarget.value = '';
        updateSessionCommand(activeSessionId, '');
      }
    } else if (e.key === 'Tab') {
      e.preventDefault();
      // Basic tab completion
      const value = e.currentTarget.value;
      const suggestions = ['ls', 'cd', 'pwd', 'clear', 'run', 'compile', 'git', 'npm', 'languages', 'plugins'];
      const match = suggestions.find(cmd => cmd.startsWith(value));
      if (match) {
        e.currentTarget.value = match;
        updateSessionCommand(activeSessionId, match);
      }
    }
  };

  const updateSessionCommand = (sessionId: string, command: string) => {
    setSessions(prev => prev.map(s => 
      s.id === sessionId ? { ...s, command } : s
    ));
  };

  const formatTimestamp = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    });
  };

  const getOutputIcon = (type: TerminalOutput['type']) => {
    switch (type) {
      case 'command': return <ChevronRight className="h-3 w-3" />;
      case 'error': return <XCircle className="h-3 w-3 text-red-400" />;
      case 'warning': return <AlertCircle className="h-3 w-3 text-yellow-400" />;
      case 'success': return <CheckCircle className="h-3 w-3 text-green-400" />;
      case 'info': return <Info className="h-3 w-3 text-blue-400" />;
      default: return <Terminal className="h-3 w-3 text-gray-400" />;
    }
  };

  const getOutputColor = (type: TerminalOutput['type']) => {
    switch (type) {
      case 'command': return 'text-[var(--ide-text)]';
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'success': return 'text-green-400';
      case 'info': return 'text-blue-400';
      default: return 'text-gray-300';
    }
  };

  return (
    <div className="flex flex-col h-full bg-[var(--ide-surface)] border border-[var(--ide-border)] rounded-lg">
      {/* Terminal Header */}
      <div className="flex items-center justify-between p-3 border-b border-[var(--ide-border)]">
        <div className="flex items-center gap-2">
          <Terminal className="h-4 w-4 text-[var(--ide-accent)]" />
          <span className="text-sm font-medium text-[var(--ide-text)]">Enhanced Terminal</span>
          
          {isExecuting && (
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="text-xs text-green-400">Running</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <TooltipWrapper
            title="System Stats"
            content="View CPU, memory, disk, and network usage"
            type="feature"
          >
            <SoundButton
              variant="ghost"
              size="sm"
              onClick={() => setShowStats(!showStats)}
              className={`h-7 w-7 p-0 ${showStats ? 'bg-[var(--ide-accent)]/20' : ''}`}
            >
              <Cpu className="h-3 w-3" />
            </SoundButton>
          </TooltipWrapper>

          <TooltipWrapper
            title="Command History"
            content="View and search command history"
            type="feature"
          >
            <SoundButton
              variant="ghost"
              size="sm"
              className="h-7 w-7 p-0"
            >
              <History className="h-3 w-3" />
            </SoundButton>
          </TooltipWrapper>

          <TooltipWrapper
            title="New Terminal"
            content="Create a new terminal session"
            type="feature"
          >
            <SoundButton
              variant="ghost"
              size="sm"
              onClick={createNewSession}
              className="h-7 w-7 p-0"
            >
              <Plus className="h-3 w-3" />
            </SoundButton>
          </TooltipWrapper>

          <TooltipWrapper
            title="Clear Terminal"
            content="Clear all output from current session"
            type="feature"
          >
            <SoundButton
              variant="ghost"
              size="sm"
              onClick={() => executeCommand(activeSessionId, 'clear')}
              className="h-7 w-7 p-0"
            >
              <Trash2 className="h-3 w-3" />
            </SoundButton>
          </TooltipWrapper>

          <TooltipWrapper
            title="Terminal Settings"
            content="Configure terminal preferences and environment"
            type="feature"
          >
            <SoundButton
              variant="ghost"
              size="sm"
              className="h-7 w-7 p-0"
            >
              <Settings className="h-3 w-3" />
            </SoundButton>
          </TooltipWrapper>
        </div>
      </div>

      {/* System Stats Panel */}
      {showStats && (
        <div className="p-3 border-b border-[var(--ide-border)] bg-[var(--ide-surface-secondary)]">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Cpu className="h-3 w-3 text-blue-400" />
                <span className="text-xs text-[var(--ide-text-secondary)]">CPU</span>
              </div>
              <Progress value={systemStats.cpu} className="h-1" />
              <span className="text-xs text-[var(--ide-text)]">{systemStats.cpu.toFixed(0)}%</span>
            </div>
            
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Memory className="h-3 w-3 text-green-400" />
                <span className="text-xs text-[var(--ide-text-secondary)]">Memory</span>
              </div>
              <Progress value={systemStats.memory} className="h-1" />
              <span className="text-xs text-[var(--ide-text)]">{systemStats.memory.toFixed(0)}%</span>
            </div>
            
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <HardDrive className="h-3 w-3 text-purple-400" />
                <span className="text-xs text-[var(--ide-text-secondary)]">Disk</span>
              </div>
              <Progress value={systemStats.disk} className="h-1" />
              <span className="text-xs text-[var(--ide-text)]">{systemStats.disk.toFixed(0)}%</span>
            </div>
            
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Network className="h-3 w-3 text-orange-400" />
                <span className="text-xs text-[var(--ide-text-secondary)]">Network</span>
              </div>
              <Progress value={systemStats.network} className="h-1" />
              <span className="text-xs text-[var(--ide-text)]">{systemStats.network.toFixed(0)} KB/s</span>
            </div>
          </div>
        </div>
      )}

      {/* Execution Progress */}
      {isExecuting && executionProgress > 0 && (
        <div className="px-3 py-1 border-b border-[var(--ide-border)]">
          <Progress value={executionProgress} className="h-1" />
        </div>
      )}

      {/* Terminal Tabs */}
      <Tabs value={activeSessionId} onValueChange={setActiveSessionId}>
        <div className="flex items-center border-b border-[var(--ide-border)]">
          <TabsList className="h-auto p-1 bg-transparent">
            {sessions.map((session) => (
              <div key={session.id} className="flex items-center">
                <TabsTrigger
                  value={session.id}
                  className="relative data-[state=active]:bg-[var(--ide-accent)]/20 px-3 py-1"
                >
                  <div className="flex items-center gap-2">
                    <Terminal className="h-3 w-3" />
                    <span className="text-xs">{session.name}</span>
                    {session.isRunning && (
                      <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                    )}
                  </div>
                </TabsTrigger>
                {sessions.length > 1 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => closeSession(session.id)}
                    className="h-6 w-6 p-0 ml-1 opacity-50 hover:opacity-100"
                  >
                    <X className="h-3 w-3" />
                  </Button>
                )}
              </div>
            ))}
          </TabsList>
        </div>

        {/* Terminal Content */}
        {sessions.map((session) => (
          <TabsContent key={session.id} value={session.id} className="flex-1 m-0">
            <div className="flex flex-col h-full">
              {/* Terminal Output */}
              <ScrollArea className="flex-1 p-3" ref={terminalRef}>
                <div className="font-mono text-sm space-y-1">
                  {session.output.map((output) => (
                    <div
                      key={output.id}
                      className={`flex items-start gap-2 ${getOutputColor(output.type)}`}
                    >
                      <span className="text-xs text-[var(--ide-text-secondary)] mt-0.5 min-w-[60px]">
                        {formatTimestamp(output.timestamp)}
                      </span>
                      {getOutputIcon(output.type)}
                      <div className="flex-1">
                        <pre className="whitespace-pre-wrap break-words">
                          {output.content}
                        </pre>
                        {output.executionTime && (
                          <div className="text-xs text-[var(--ide-text-secondary)] mt-1">
                            Execution time: {output.executionTime.toFixed(2)}ms
                            {output.exitCode !== undefined && ` | Exit code: ${output.exitCode}`}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  
                  {session.output.length === 0 && (
                    <div className="text-[var(--ide-text-secondary)] text-center py-8">
                      <Terminal className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">Terminal ready. Type 'languages' to see supported languages.</p>
                      <p className="text-xs mt-1">Use 'run filename.ext' to execute files or 'compile filename.ext' to compile them.</p>
                    </div>
                  )}
                </div>
              </ScrollArea>

              {/* Command Input */}
              <div className="border-t border-[var(--ide-border)] p-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-[var(--ide-text-secondary)] font-mono">
                    {session.workingDirectory}$
                  </span>
                  <Input
                    ref={inputRef}
                    placeholder="Enter command..."
                    onKeyDown={handleKeyDown}
                    onChange={(e) => updateSessionCommand(session.id, e.target.value)}
                    disabled={isExecuting}
                    className="font-mono text-sm bg-transparent border-none focus:ring-0 focus:border-none px-0"
                    autoComplete="off"
                  />
                  <div className="flex items-center gap-1">
                    <Badge variant="outline" className="text-xs">
                      {languages[session.language]?.name || 'Bash'}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}