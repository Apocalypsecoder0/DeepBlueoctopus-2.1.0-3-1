import React, { useState, useCallback, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  Terminal, Plus, X, RefreshCw, Copy, Download,
  Maximize2, Minimize2, Clock, Monitor
} from "lucide-react";

interface MultiTerminalSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TerminalSession {
  id: string;
  name: string;
  shell: 'bash' | 'zsh' | 'nodejs' | 'python';
  workingDirectory: string;
  output: TerminalLine[];
  input: string;
  isRunning: boolean;
  startTime: Date;
  lastActivity: Date;
  history: string[];
  historyIndex: number;
}

interface TerminalLine {
  id: string;
  type: 'command' | 'output' | 'error' | 'system';
  content: string;
  timestamp: Date;
}

interface ShellConfig {
  id: string;
  name: string;
  shell: 'bash' | 'zsh' | 'nodejs' | 'python';
  prompt: string;
  color: string;
}

export default function MultiTerminalSystem({ isOpen, onClose }: MultiTerminalSystemProps) {
  const [terminals, setTerminals] = useState<TerminalSession[]>([
    {
      id: 'default',
      name: 'Terminal 1',
      shell: 'bash',
      workingDirectory: '/workspace',
      output: [
        {
          id: '1',
          type: 'system',
          content: 'Welcome to DeepBlue:Octopus Terminal',
          timestamp: new Date(),
        }
      ],
      input: '',
      isRunning: false,
      startTime: new Date(),
      lastActivity: new Date(),
      history: [],
      historyIndex: -1
    }
  ]);

  const [activeTerminalId, setActiveTerminalId] = useState('default');
  const [isMaximized, setIsMaximized] = useState(false);
  const [shellConfigs] = useState<ShellConfig[]>([
    {
      id: 'bash',
      name: 'Bash',
      shell: 'bash',
      prompt: '$ ',
      color: 'text-green-400'
    },
    {
      id: 'nodejs',
      name: 'Node.js',
      shell: 'nodejs',
      prompt: '> ',
      color: 'text-yellow-400'
    },
    {
      id: 'python',
      name: 'Python',
      shell: 'python',
      prompt: '>>> ',
      color: 'text-blue-400'
    },
    {
      id: 'zsh',
      name: 'Zsh',
      shell: 'zsh',
      prompt: '❯ ',
      color: 'text-purple-400'
    }
  ]);

  const terminalRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const inputRefs = useRef<Record<string, HTMLInputElement | null>>({});
  const { toast } = useToast();

  const activeTerminal = terminals.find(t => t.id === activeTerminalId);

  const scrollToBottom = useCallback((terminalId: string) => {
    const terminalElement = terminalRefs.current[terminalId];
    if (terminalElement) {
      terminalElement.scrollTop = terminalElement.scrollHeight;
    }
  }, []);

  const addOutputLine = useCallback((terminalId: string, line: TerminalLine) => {
    setTerminals(prev => prev.map(terminal => {
      if (terminal.id === terminalId) {
        return {
          ...terminal,
          output: [...terminal.output, line],
          lastActivity: new Date()
        };
      }
      return terminal;
    }));

    setTimeout(() => scrollToBottom(terminalId), 100);
  }, [scrollToBottom]);

  const executeCommand = useCallback(async (terminalId: string, command: string) => {
    const terminal = terminals.find(t => t.id === terminalId);
    if (!terminal) return;

    // Add command to history
    const newHistory = [...terminal.history, command];
    
    // Add command line to output
    const commandLine: TerminalLine = {
      id: Date.now().toString(),
      type: 'command',
      content: `${terminal.workingDirectory} ${getShellPrompt(terminal.shell)}${command}`,
      timestamp: new Date()
    };

    addOutputLine(terminalId, commandLine);

    // Update terminal state
    setTerminals(prev => prev.map(t => {
      if (t.id === terminalId) {
        return {
          ...t,
          isRunning: true,
          history: newHistory,
          historyIndex: -1,
          input: ''
        };
      }
      return t;
    }));

    // Simulate command execution
    await new Promise(resolve => setTimeout(resolve, 300));

    let output = '';
    switch (command.trim()) {
      case 'ls':
        output = 'package.json  src/  public/  node_modules/  README.md';
        break;
      case 'pwd':
        output = terminal.workingDirectory;
        break;
      case 'help':
        output = 'Available commands: ls, pwd, echo, clear, help';
        break;
      case 'clear':
        setTerminals(prev => prev.map(t => {
          if (t.id === terminalId) {
            return {
              ...t,
              output: [{
                id: Date.now().toString(),
                type: 'system',
                content: 'Terminal cleared',
                timestamp: new Date(),
              }]
            };
          }
          return t;
        }));
        break;
      default:
        if (command.startsWith('echo ')) {
          output = command.substring(5);
        } else {
          output = `bash: ${command}: command not found`;
        }
    }

    if (output && command.trim() !== 'clear') {
      const outputLine: TerminalLine = {
        id: (Date.now() + 1).toString(),
        type: 'output',
        content: output,
        timestamp: new Date()
      };
      addOutputLine(terminalId, outputLine);
    }

    // Update running state
    setTerminals(prev => prev.map(t => {
      if (t.id === terminalId) {
        return { ...t, isRunning: false };
      }
      return t;
    }));
  }, [terminals, addOutputLine]);

  const getShellPrompt = (shell: string): string => {
    const config = shellConfigs.find(c => c.shell === shell);
    return config?.prompt || '$ ';
  };

  const getShellColor = (shell: string): string => {
    const config = shellConfigs.find(c => c.shell === shell);
    return config?.color || 'text-green-400';
  };

  const createNewTerminal = useCallback((shell: string = 'bash') => {
    const newTerminal: TerminalSession = {
      id: `terminal-${Date.now()}`,
      name: `Terminal ${terminals.length + 1}`,
      shell: shell as any,
      workingDirectory: '/workspace',
      output: [
        {
          id: Date.now().toString(),
          type: 'system',
          content: `${shell.charAt(0).toUpperCase() + shell.slice(1)} terminal initialized`,
          timestamp: new Date(),
        }
      ],
      input: '',
      isRunning: false,
      startTime: new Date(),
      lastActivity: new Date(),
      history: [],
      historyIndex: -1
    };

    setTerminals(prev => [...prev, newTerminal]);
    setActiveTerminalId(newTerminal.id);

    toast({
      title: "Terminal created",
      description: `New ${shell} terminal session started`,
    });
  }, [terminals, toast]);

  const closeTerminal = useCallback((terminalId: string) => {
    if (terminals.length === 1) {
      toast({
        title: "Cannot close terminal",
        description: "At least one terminal must remain open",
        variant: "destructive",
      });
      return;
    }

    setTerminals(prev => prev.filter(t => t.id !== terminalId));
    
    if (activeTerminalId === terminalId) {
      const remainingTerminals = terminals.filter(t => t.id !== terminalId);
      setActiveTerminalId(remainingTerminals[0]?.id || '');
    }

    toast({
      title: "Terminal closed",
      description: "Terminal session ended",
    });
  }, [terminals, activeTerminalId, toast]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent, terminalId: string) => {
    const terminal = terminals.find(t => t.id === terminalId);
    if (!terminal) return;

    if (e.key === 'Enter') {
      e.preventDefault();
      if (terminal.input.trim()) {
        executeCommand(terminalId, terminal.input.trim());
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (terminal.history.length > 0) {
        const newIndex = Math.max(0, terminal.historyIndex === -1 ? terminal.history.length - 1 : terminal.historyIndex - 1);
        setTerminals(prev => prev.map(t => {
          if (t.id === terminalId) {
            return {
              ...t,
              input: terminal.history[newIndex] || '',
              historyIndex: newIndex
            };
          }
          return t;
        }));
      }
    }
  }, [terminals, executeCommand]);

  useEffect(() => {
    const inputElement = inputRefs.current[activeTerminalId];
    if (inputElement) {
      inputElement.focus();
    }
  }, [activeTerminalId]);

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className={`${isMaximized ? 'max-w-full h-full' : 'max-w-6xl h-[90vh]'}`}>
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <Terminal className="w-5 h-5" />
              Multi-Terminal System
            </DialogTitle>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setIsMaximized(!isMaximized)}
              >
                {isMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 flex flex-col">
          {/* Terminal Tabs */}
          <div className="flex items-center justify-between border-b">
            <div className="flex items-center">
              {terminals.map((terminal) => (
                <div
                  key={terminal.id}
                  className={`flex items-center gap-2 px-3 py-2 border-r cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800 ${
                    activeTerminalId === terminal.id ? 'bg-gray-100 dark:bg-gray-800 border-b-2 border-blue-500' : ''
                  }`}
                  onClick={() => setActiveTerminalId(terminal.id)}
                >
                  <span className="text-sm font-medium">{terminal.name}</span>
                  <Badge variant="outline" className="text-xs">
                    {terminal.shell}
                  </Badge>
                  {terminal.isRunning && (
                    <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse" />
                  )}
                  {terminals.length > 1 && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="w-4 h-4 p-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        closeTerminal(terminal.id);
                      }}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 p-2">
              <Select onValueChange={(value) => createNewTerminal(value)}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="New Terminal" />
                </SelectTrigger>
                <SelectContent>
                  {shellConfigs.map((config) => (
                    <SelectItem key={config.id} value={config.shell}>
                      {config.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button size="sm" onClick={() => createNewTerminal()}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Terminal Content */}
          {activeTerminal && (
            <div className="flex-1 flex flex-col bg-gray-900 text-white">
              {/* Terminal Header */}
              <div className="flex items-center justify-between px-4 py-2 bg-gray-800 border-b border-gray-700">
                <div className="flex items-center gap-4">
                  <span className="text-sm font-medium">{activeTerminal.name}</span>
                  <span className="text-xs text-gray-400">{activeTerminal.workingDirectory}</span>
                  <Badge variant="outline" className={`text-xs ${getShellColor(activeTerminal.shell)}`}>
                    {activeTerminal.shell}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setTerminals(prev => prev.map(terminal => {
                        if (terminal.id === activeTerminal.id) {
                          return {
                            ...terminal,
                            output: [{
                              id: Date.now().toString(),
                              type: 'system',
                              content: 'Terminal cleared',
                              timestamp: new Date(),
                            }]
                          };
                        }
                        return terminal;
                      }));
                    }}
                    className="text-gray-300 hover:text-white"
                  >
                    <RefreshCw className="w-3 h-3" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      const outputText = activeTerminal.output.map(line => line.content).join('\n');
                      navigator.clipboard.writeText(outputText);
                      toast({
                        title: "Output copied",
                        description: "Terminal output copied to clipboard",
                      });
                    }}
                    className="text-gray-300 hover:text-white"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>

              {/* Terminal Output */}
              <div className="flex-1 flex flex-col">
                <ScrollArea className="flex-1">
                  <div 
                    ref={(ref) => { terminalRefs.current[activeTerminal.id] = ref; }}
                    className="p-4 space-y-1 font-mono text-sm"
                  >
                    {activeTerminal.output.map((line) => (
                      <div
                        key={line.id}
                        className={`${
                          line.type === 'command' ? 'text-white' :
                          line.type === 'error' ? 'text-red-400' :
                          line.type === 'system' ? 'text-blue-400' :
                          'text-gray-300'
                        }`}
                      >
                        <span className="whitespace-pre-wrap">{line.content}</span>
                        {line.type === 'command' && (
                          <span className="text-xs text-gray-500 ml-2">
                            {line.timestamp.toLocaleTimeString()}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                {/* Terminal Input */}
                <div className="flex items-center px-4 py-2 bg-gray-800 border-t border-gray-700">
                  <span className={`mr-2 ${getShellColor(activeTerminal.shell)}`}>
                    {activeTerminal.workingDirectory} {getShellPrompt(activeTerminal.shell)}
                  </span>
                  <Input
                    ref={(ref) => { inputRefs.current[activeTerminal.id] = ref; }}
                    value={activeTerminal.input}
                    onChange={(e) => {
                      setTerminals(prev => prev.map(terminal => {
                        if (terminal.id === activeTerminal.id) {
                          return { ...terminal, input: e.target.value };
                        }
                        return terminal;
                      }));
                    }}
                    onKeyDown={(e) => handleKeyDown(e, activeTerminal.id)}
                    className="bg-transparent border-none text-white focus:ring-0 font-mono"
                    placeholder="Enter command..."
                    disabled={activeTerminal.isRunning}
                  />
                  {activeTerminal.isRunning && (
                    <div className="ml-2 flex items-center gap-1">
                      <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse" />
                      <span className="text-xs text-gray-400">Running...</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Terminal Stats */}
          <div className="flex items-center justify-between px-4 py-2 bg-gray-100 dark:bg-gray-800 border-t text-xs text-gray-600 dark:text-gray-400">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <Monitor className="w-3 h-3" />
                {terminals.length} terminal{terminals.length !== 1 ? 's' : ''}
              </span>
              {activeTerminal && (
                <>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    Session: {Math.floor((Date.now() - activeTerminal.startTime.getTime()) / 1000 / 60)}m
                  </span>
                  <span>Commands: {activeTerminal.history.length}</span>
                </>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span>DeepBlue:Octopus Terminal v2.1.0</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}