import React, { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { 
  Layout, Maximize2, Minimize2, Square, RefreshCw, Save,
  Monitor, Smartphone, Tablet, Watch, Tv, Grid3X3,
  Eye, EyeOff, Move, Crop, Palette, Layers,
  Settings, ZoomIn, ZoomOut, Fullscreen,
  Split, SplitSquareHorizontal, SplitSquareVertical,
  PanelTop, PanelBottom, PanelLeft, PanelRight,
  ArrowUp, ArrowDown, ArrowLeft, ArrowRight,
  Lock, Copy
} from "lucide-react";

interface AdvancedViewSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ViewLayout {
  id: string;
  name: string;
  type: 'single' | 'split-horizontal' | 'split-vertical' | 'grid' | 'custom';
  panels: ViewPanel[];
  isActive: boolean;
  isLocked: boolean;
  settings: {
    showTabs: boolean;
    showSidebar: boolean;
    showStatusBar: boolean;
    showMinimap: boolean;
    autoHide: boolean;
  };
}

interface ViewPanel {
  id: string;
  type: 'editor' | 'terminal' | 'explorer' | 'output' | 'debug' | 'preview' | 'custom';
  title: string;
  content: string;
  position: { x: number; y: number; width: number; height: number };
  isVisible: boolean;
  isMinimized: boolean;
  isFloating: boolean;
  zIndex: number;
  settings: {
    background: string;
    opacity: number;
    border: boolean;
    resizable: boolean;
    moveable: boolean;
  };
}

interface ViewMode {
  id: string;
  name: string;
  description: string;
  icon: string;
  viewport: {
    width: number;
    height: number;
    scale: number;
    orientation: 'portrait' | 'landscape';
  };
  device: string;
  settings: {
    touchEnabled: boolean;
    scrollBehavior: 'auto' | 'smooth';
    pixelRatio: number;
  };
}

export default function AdvancedViewSystem({ isOpen, onClose }: AdvancedViewSystemProps) {
  const [activeTab, setActiveTab] = useState("layouts");
  const [currentLayout, setCurrentLayout] = useState("default");
  const [zoomLevel, setZoomLevel] = useState(100);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedPanel, setSelectedPanel] = useState<string | null>(null);

  const [viewModes, setViewModes] = useState<ViewMode[]>([
    {
      id: 'desktop',
      name: 'Desktop',
      description: 'Standard desktop view',
      icon: '🖥️',
      viewport: { width: 1920, height: 1080, scale: 1, orientation: 'landscape' },
      device: 'Desktop Computer',
      settings: { touchEnabled: false, scrollBehavior: 'auto', pixelRatio: 1 }
    },
    {
      id: 'tablet',
      name: 'Tablet',
      description: 'Tablet responsive view',
      icon: '📱',
      viewport: { width: 768, height: 1024, scale: 0.8, orientation: 'portrait' },
      device: 'iPad Pro',
      settings: { touchEnabled: true, scrollBehavior: 'smooth', pixelRatio: 2 }
    },
    {
      id: 'mobile',
      name: 'Mobile',
      description: 'Mobile phone view',
      icon: '📱',
      viewport: { width: 375, height: 667, scale: 0.6, orientation: 'portrait' },
      device: 'iPhone 12',
      settings: { touchEnabled: true, scrollBehavior: 'smooth', pixelRatio: 3 }
    },
    {
      id: 'ultrawide',
      name: 'Ultrawide',
      description: 'Ultrawide monitor view',
      icon: '🖥️',
      viewport: { width: 3440, height: 1440, scale: 1.2, orientation: 'landscape' },
      device: 'Ultrawide Monitor',
      settings: { touchEnabled: false, scrollBehavior: 'auto', pixelRatio: 1 }
    }
  ]);

  const [layouts, setLayouts] = useState<ViewLayout[]>([
    {
      id: 'default',
      name: 'Default Layout',
      type: 'split-horizontal',
      isActive: true,
      isLocked: false,
      settings: {
        showTabs: true,
        showSidebar: true,
        showStatusBar: true,
        showMinimap: true,
        autoHide: false
      },
      panels: [
        {
          id: 'editor',
          type: 'editor',
          title: 'Code Editor',
          content: 'Main editing area',
          position: { x: 0, y: 0, width: 70, height: 100 },
          isVisible: true,
          isMinimized: false,
          isFloating: false,
          zIndex: 1,
          settings: {
            background: '#1e1e1e',
            opacity: 100,
            border: true,
            resizable: true,
            moveable: false
          }
        },
        {
          id: 'sidebar',
          type: 'explorer',
          title: 'File Explorer',
          content: 'File tree and navigation',
          position: { x: 70, y: 0, width: 30, height: 60 },
          isVisible: true,
          isMinimized: false,
          isFloating: false,
          zIndex: 1,
          settings: {
            background: '#252526',
            opacity: 100,
            border: true,
            resizable: true,
            moveable: false
          }
        },
        {
          id: 'terminal',
          type: 'terminal',
          title: 'Terminal',
          content: 'Integrated terminal',
          position: { x: 70, y: 60, width: 30, height: 40 },
          isVisible: true,
          isMinimized: false,
          isFloating: false,
          zIndex: 1,
          settings: {
            background: '#0c0c0c',
            opacity: 100,
            border: true,
            resizable: true,
            moveable: false
          }
        }
      ]
    },
    {
      id: 'development',
      name: 'Development Focus',
      type: 'split-vertical',
      isActive: false,
      isLocked: false,
      settings: {
        showTabs: true,
        showSidebar: false,
        showStatusBar: true,
        showMinimap: false,
        autoHide: true
      },
      panels: [
        {
          id: 'editor-main',
          type: 'editor',
          title: 'Main Editor',
          content: 'Primary code editor',
          position: { x: 0, y: 0, width: 100, height: 70 },
          isVisible: true,
          isMinimized: false,
          isFloating: false,
          zIndex: 1,
          settings: {
            background: '#1e1e1e',
            opacity: 100,
            border: false,
            resizable: true,
            moveable: false
          }
        },
        {
          id: 'debug-panel',
          type: 'debug',
          title: 'Debug Console',
          content: 'Debugging information',
          position: { x: 0, y: 70, width: 100, height: 30 },
          isVisible: true,
          isMinimized: false,
          isFloating: false,
          zIndex: 1,
          settings: {
            background: '#252526',
            opacity: 100,
            border: true,
            resizable: true,
            moveable: false
          }
        }
      ]
    },
    {
      id: 'presentation',
      name: 'Presentation Mode',
      type: 'single',
      isActive: false,
      isLocked: true,
      settings: {
        showTabs: false,
        showSidebar: false,
        showStatusBar: false,
        showMinimap: false,
        autoHide: true
      },
      panels: [
        {
          id: 'fullscreen-editor',
          type: 'editor',
          title: 'Full Screen Editor',
          content: 'Distraction-free editing',
          position: { x: 0, y: 0, width: 100, height: 100 },
          isVisible: true,
          isMinimized: false,
          isFloating: false,
          zIndex: 1,
          settings: {
            background: '#1e1e1e',
            opacity: 100,
            border: false,
            resizable: false,
            moveable: false
          }
        }
      ]
    }
  ]);

  const [customViews, setCustomViews] = useState([
    {
      id: 'custom1',
      name: 'Multi-Monitor Setup',
      description: 'Optimized for dual monitor development',
      layout: 'split-horizontal',
      created: new Date(Date.now() - 86400000)
    },
    {
      id: 'custom2',
      name: 'Mobile Development',
      description: 'Mobile-first responsive design workspace',
      layout: 'grid',
      created: new Date(Date.now() - 172800000)
    }
  ]);

  const getCurrentLayout = () => layouts.find(l => l.id === currentLayout) || layouts[0];

  const switchLayout = (layoutId: string) => {
    setLayouts(prev => prev.map(layout => ({
      ...layout,
      isActive: layout.id === layoutId
    })));
    setCurrentLayout(layoutId);
  };

  const togglePanelVisibility = (panelId: string) => {
    setLayouts(prev => prev.map(layout => 
      layout.id === currentLayout ? {
        ...layout,
        panels: layout.panels.map(panel => 
          panel.id === panelId ? { ...panel, isVisible: !panel.isVisible } : panel
        )
      } : layout
    ));
  };

  const minimizePanel = (panelId: string) => {
    setLayouts(prev => prev.map(layout => 
      layout.id === currentLayout ? {
        ...layout,
        panels: layout.panels.map(panel => 
          panel.id === panelId ? { ...panel, isMinimized: !panel.isMinimized } : panel
        )
      } : layout
    ));
  };

  const updatePanelSettings = (panelId: string, settings: Partial<ViewPanel['settings']>) => {
    setLayouts(prev => prev.map(layout => 
      layout.id === currentLayout ? {
        ...layout,
        panels: layout.panels.map(panel => 
          panel.id === panelId ? { 
            ...panel, 
            settings: { ...panel.settings, ...settings }
          } : panel
        )
      } : layout
    ));
  };

  const createCustomLayout = () => {
    const newLayout: ViewLayout = {
      id: `custom_${Date.now()}`,
      name: 'Custom Layout',
      type: 'custom',
      isActive: false,
      isLocked: false,
      settings: {
        showTabs: true,
        showSidebar: true,
        showStatusBar: true,
        showMinimap: true,
        autoHide: false
      },
      panels: [
        {
          id: 'custom-editor',
          type: 'editor',
          title: 'Editor',
          content: 'Custom editor panel',
          position: { x: 0, y: 0, width: 100, height: 100 },
          isVisible: true,
          isMinimized: false,
          isFloating: false,
          zIndex: 1,
          settings: {
            background: '#1e1e1e',
            opacity: 100,
            border: true,
            resizable: true,
            moveable: true
          }
        }
      ]
    };
    
    setLayouts(prev => [...prev, newLayout]);
  };

  const duplicateLayout = (layoutId: string) => {
    const original = layouts.find(l => l.id === layoutId);
    if (!original) return;
    
    const duplicate: ViewLayout = {
      ...original,
      id: `${layoutId}_copy_${Date.now()}`,
      name: `${original.name} (Copy)`,
      isActive: false
    };
    
    setLayouts(prev => [...prev, duplicate]);
  };

  const exportLayout = (layoutId: string) => {
    const layout = layouts.find(l => l.id === layoutId);
    if (!layout) return;
    
    const data = JSON.stringify(layout, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${layout.name.replace(/\s+/g, '_')}_layout.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getCurrentViewMode = () => viewModes[0];

  const layout = getCurrentLayout();
  const viewMode = getCurrentViewMode();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Layout className="h-5 w-5 text-blue-500" />
            Advanced View System Manager
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-5 flex-shrink-0 mb-4">
            <TabsTrigger value="layouts">Layouts</TabsTrigger>
            <TabsTrigger value="panels">Panels</TabsTrigger>
            <TabsTrigger value="viewport">Viewport</TabsTrigger>
            <TabsTrigger value="custom">Custom Views</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="layouts" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-full">
              <Card className="lg:col-span-1">
                <CardHeader>
                  <CardTitle className="text-base">Available Layouts</CardTitle>
                  <CardDescription>Pre-built and custom layouts</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {layouts.map((layoutItem) => (
                      <div
                        key={layoutItem.id}
                        className={`p-3 border rounded cursor-pointer transition-colors ${
                          layoutItem.isActive ? 'bg-accent border-primary' : 'hover:bg-accent/50'
                        }`}
                        onClick={() => switchLayout(layoutItem.id)}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">{layoutItem.name}</span>
                          <div className="flex items-center gap-1">
                            {layoutItem.isLocked && <Lock className="h-3 w-3 text-yellow-500" />}
                            <Badge variant="outline" className="text-xs">
                              {layoutItem.type}
                            </Badge>
                          </div>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {layoutItem.panels.length} panels
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <div className="space-y-2">
                    <Button size="sm" className="w-full" onClick={createCustomLayout}>
                      <Layout className="h-4 w-4 mr-2" />
                      Create Layout
                    </Button>
                    <Button size="sm" variant="outline" className="w-full" onClick={() => duplicateLayout(currentLayout)}>
                      <Copy className="h-4 w-4 mr-2" />
                      Duplicate Current
                    </Button>
                    <Button size="sm" variant="outline" className="w-full" onClick={() => exportLayout(currentLayout)}>
                      <Save className="h-4 w-4 mr-2" />
                      Export Layout
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="lg:col-span-2">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">{layout.name}</CardTitle>
                      <CardDescription>Layout preview and configuration</CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="outline">
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Save className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border rounded-lg p-4 bg-gray-50 dark:bg-gray-900">
                      <div className="relative h-64 bg-white dark:bg-gray-800 border rounded">
                        {layout.panels.map((panel) => (
                          <div
                            key={panel.id}
                            className={`absolute border rounded transition-all ${
                              selectedPanel === panel.id ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'border-gray-300'
                            } ${panel.isVisible ? 'opacity-100' : 'opacity-50'}`}
                            style={{
                              left: `${panel.position.x}%`,
                              top: `${panel.position.y}%`,
                              width: `${panel.position.width}%`,
                              height: `${panel.position.height}%`,
                              minHeight: panel.isMinimized ? '20px' : 'auto'
                            }}
                            onClick={() => setSelectedPanel(panel.id)}
                          >
                            <div className="p-2 text-xs">
                              <div className="flex items-center justify-between">
                                <span className="font-medium">{panel.title}</span>
                                <div className="flex gap-1">
                                  <Button 
                                    size="sm" 
                                    variant="ghost" 
                                    className="h-4 w-4 p-0"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      minimizePanel(panel.id);
                                    }}
                                  >
                                    {panel.isMinimized ? <Maximize2 className="h-3 w-3" /> : <Minimize2 className="h-3 w-3" />}
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    variant="ghost" 
                                    className="h-4 w-4 p-0"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      togglePanelVisibility(panel.id);
                                    }}
                                  >
                                    {panel.isVisible ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                                  </Button>
                                </div>
                              </div>
                              {!panel.isMinimized && (
                                <div className="text-gray-500 mt-1">{panel.content}</div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="flex items-center justify-between p-3 border rounded">
                        <Label className="text-sm">Show Tabs</Label>
                        <Switch checked={layout.settings.showTabs} />
                      </div>
                      <div className="flex items-center justify-between p-3 border rounded">
                        <Label className="text-sm">Show Sidebar</Label>
                        <Switch checked={layout.settings.showSidebar} />
                      </div>
                      <div className="flex items-center justify-between p-3 border rounded">
                        <Label className="text-sm">Show Status Bar</Label>
                        <Switch checked={layout.settings.showStatusBar} />
                      </div>
                      <div className="flex items-center justify-between p-3 border rounded">
                        <Label className="text-sm">Auto Hide</Label>
                        <Switch checked={layout.settings.autoHide} />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="panels" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Panel Configuration</CardTitle>
                  <CardDescription>Configure individual panels</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-3">
                      {layout.panels.map((panel) => (
                        <div key={panel.id} className={`p-3 border rounded ${
                          selectedPanel === panel.id ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : ''
                        }`}>
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium">{panel.title}</span>
                            <Badge variant="outline">{panel.type}</Badge>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div>
                              <Label className="text-xs">Position</Label>
                              <p>{panel.position.x}%, {panel.position.y}%</p>
                            </div>
                            <div>
                              <Label className="text-xs">Size</Label>
                              <p>{panel.position.width}% × {panel.position.height}%</p>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2 mt-2">
                            <Button 
                              size="sm" 
                              variant={panel.isVisible ? "default" : "outline"}
                              onClick={() => togglePanelVisibility(panel.id)}
                            >
                              {panel.isVisible ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => minimizePanel(panel.id)}
                            >
                              {panel.isMinimized ? <Maximize2 className="h-3 w-3" /> : <Minimize2 className="h-3 w-3" />}
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => setSelectedPanel(panel.id)}
                            >
                              <Settings className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {selectedPanel && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Panel Settings</CardTitle>
                    <CardDescription>
                      {layout.panels.find(p => p.id === selectedPanel)?.title}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {(() => {
                      const panel = layout.panels.find(p => p.id === selectedPanel);
                      if (!panel) return null;
                      
                      return (
                        <div className="space-y-4">
                          <div>
                            <Label>Background Color</Label>
                            <Input 
                              type="color" 
                              value={panel.settings.background}
                              onChange={(e) => updatePanelSettings(selectedPanel, { background: e.target.value })}
                              className="mt-1 h-10"
                            />
                          </div>
                          
                          <div>
                            <Label>Opacity: {panel.settings.opacity}%</Label>
                            <Slider
                              value={[panel.settings.opacity]}
                              onValueChange={([value]) => updatePanelSettings(selectedPanel, { opacity: value })}
                              min={10}
                              max={100}
                              step={5}
                              className="mt-2"
                            />
                          </div>

                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <Label>Show Border</Label>
                              <Switch 
                                checked={panel.settings.border}
                                onCheckedChange={(checked) => updatePanelSettings(selectedPanel, { border: checked })}
                              />
                            </div>
                            
                            <div className="flex items-center justify-between">
                              <Label>Resizable</Label>
                              <Switch 
                                checked={panel.settings.resizable}
                                onCheckedChange={(checked) => updatePanelSettings(selectedPanel, { resizable: checked })}
                              />
                            </div>
                            
                            <div className="flex items-center justify-between">
                              <Label>Moveable</Label>
                              <Switch 
                                checked={panel.settings.moveable}
                                onCheckedChange={(checked) => updatePanelSettings(selectedPanel, { moveable: checked })}
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <Button size="sm" variant="outline">
                              <ArrowUp className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <ArrowDown className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <ArrowLeft className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <ArrowRight className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      );
                    })()}
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="viewport" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">View Modes</CardTitle>
                  <CardDescription>Switch between different viewport configurations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {viewModes.map((mode) => (
                      <div key={mode.id} className="p-4 border rounded hover:bg-accent/50 cursor-pointer">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{mode.icon}</span>
                            <span className="font-medium">{mode.name}</span>
                          </div>
                          <Badge variant="outline">
                            {mode.viewport.width} × {mode.viewport.height}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{mode.description}</p>
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>{mode.device}</span>
                          <span>Scale: {mode.viewport.scale}x</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Viewport Controls</CardTitle>
                  <CardDescription>Adjust current viewport settings</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <Label>Zoom Level: {zoomLevel}%</Label>
                      <div className="flex items-center gap-2 mt-2">
                        <Button size="sm" variant="outline" onClick={() => setZoomLevel(prev => Math.max(25, prev - 25))}>
                          <ZoomOut className="h-4 w-4" />
                        </Button>
                        <Slider
                          value={[zoomLevel]}
                          onValueChange={([value]) => setZoomLevel(value)}
                          min={25}
                          max={200}
                          step={25}
                          className="flex-1"
                        />
                        <Button size="sm" variant="outline" onClick={() => setZoomLevel(prev => Math.min(200, prev + 25))}>
                          <ZoomIn className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Width</Label>
                        <Input type="number" value={viewMode.viewport.width} className="mt-1" />
                      </div>
                      <div>
                        <Label>Height</Label>
                        <Input type="number" value={viewMode.viewport.height} className="mt-1" />
                      </div>
                    </div>

                    <div>
                      <Label>Orientation</Label>
                      <Select value={viewMode.viewport.orientation}>
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="landscape">Landscape</SelectItem>
                          <SelectItem value="portrait">Portrait</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label>Touch Enabled</Label>
                        <Switch checked={viewMode.settings.touchEnabled} />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Smooth Scrolling</Label>
                        <Switch checked={viewMode.settings.scrollBehavior === 'smooth'} />
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="flex-1">
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Reset
                      </Button>
                      <Button 
                        size="sm" 
                        variant={isFullscreen ? "default" : "outline"}
                        className="flex-1"
                        onClick={() => setIsFullscreen(!isFullscreen)}
                      >
                        <Fullscreen className="h-4 w-4 mr-2" />
                        Fullscreen
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="custom" className="flex-1 overflow-hidden">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">Custom Views</CardTitle>
                      <CardDescription>Create and manage custom view configurations</CardDescription>
                    </div>
                    <Button size="sm">
                      <Layout className="h-4 w-4 mr-2" />
                      Create View
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                    {customViews.map((view) => (
                      <Card key={view.id}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium">{view.name}</h4>
                            <Badge variant="outline">{view.layout}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">{view.description}</p>
                          <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                            <span>Created: {view.created.toLocaleDateString()}</span>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" className="flex-1">
                              <Eye className="h-4 w-4 mr-2" />
                              Preview
                            </Button>
                            <Button size="sm" className="flex-1">
                              Apply
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="flex-1 overflow-hidden">
            <ScrollArea className="h-full">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Global View Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center justify-between">
                        <Label>Auto-save Layouts</Label>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Remember Window State</Label>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Smooth Animations</Label>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Snap to Grid</Label>
                        <Switch />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Performance Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Animation Speed</Label>
                      <Select defaultValue="normal">
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="slow">Slow</SelectItem>
                          <SelectItem value="normal">Normal</SelectItem>
                          <SelectItem value="fast">Fast</SelectItem>
                          <SelectItem value="none">No Animations</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Max Panels: 8</Label>
                      <Slider defaultValue={[8]} min={4} max={16} step={1} className="mt-2" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}