import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Volume2, VolumeX, Music, Bell, 
  Zap, Play, Settings
} from "lucide-react";

interface SoundSettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SoundSettings({ isOpen, onClose }: SoundSettingsProps) {
  const [masterVolume, setMasterVolume] = useState([80]);
  const [musicVolume, setMusicVolume] = useState([60]);
  const [sfxVolume, setSfxVolume] = useState([70]);
  const [notificationVolume, setNotificationVolume] = useState([50]);
  const [isMuted, setIsMuted] = useState(false);
  const [enableSpatialAudio, setEnableSpatialAudio] = useState(false);
  const [enableReverb, setEnableReverb] = useState(true);
  const [audioQuality, setAudioQuality] = useState('high');

  const { toast } = useToast();

  const playTestSound = (type: string) => {
    toast({
      title: "Test sound played",
      description: `Playing ${type} test sound`,
    });
  };

  const resetToDefaults = () => {
    setMasterVolume([80]);
    setMusicVolume([60]);
    setSfxVolume([70]);
    setNotificationVolume([50]);
    setIsMuted(false);
    setEnableSpatialAudio(false);
    setEnableReverb(true);
    setAudioQuality('high');
    
    toast({
      title: "Settings reset",
      description: "Audio settings restored to defaults",
    });
  };

  const saveSettings = () => {
    toast({
      title: "Settings saved",
      description: "Audio settings have been saved successfully",
    });
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Volume2 className="w-5 h-5" />
            Sound Settings
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 space-y-6 overflow-y-auto">
          {/* Master Controls */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm flex items-center justify-between">
                Master Controls
                <div className="flex items-center gap-2">
                  <Switch
                    checked={!isMuted}
                    onCheckedChange={(checked) => setIsMuted(!checked)}
                  />
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Master Volume</label>
                  <Badge variant="outline">{masterVolume[0]}%</Badge>
                </div>
                <Slider
                  value={masterVolume}
                  onValueChange={setMasterVolume}
                  max={100}
                  step={1}
                  className="w-full"
                  disabled={isMuted}
                />
              </div>
            </CardContent>
          </Card>

          {/* Individual Volume Controls */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Volume Levels</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Music className="w-4 h-4" />
                    <label className="text-sm font-medium">Background Music</label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{musicVolume[0]}%</Badge>
                    <Button size="sm" variant="outline" onClick={() => playTestSound('music')}>
                      <Play className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
                <Slider
                  value={musicVolume}
                  onValueChange={setMusicVolume}
                  max={100}
                  step={1}
                  className="w-full"
                  disabled={isMuted}
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    <label className="text-sm font-medium">Sound Effects</label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{sfxVolume[0]}%</Badge>
                    <Button size="sm" variant="outline" onClick={() => playTestSound('sfx')}>
                      <Play className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
                <Slider
                  value={sfxVolume}
                  onValueChange={setSfxVolume}
                  max={100}
                  step={1}
                  className="w-full"
                  disabled={isMuted}
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4" />
                    <label className="text-sm font-medium">Notifications</label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{notificationVolume[0]}%</Badge>
                    <Button size="sm" variant="outline" onClick={() => playTestSound('notification')}>
                      <Play className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
                <Slider
                  value={notificationVolume}
                  onValueChange={setNotificationVolume}
                  max={100}
                  step={1}
                  className="w-full"
                  disabled={isMuted}
                />
              </div>
            </CardContent>
          </Card>

          {/* Audio Enhancement */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Audio Enhancement</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium">Spatial Audio</label>
                  <p className="text-xs text-gray-600">3D positional audio effects</p>
                </div>
                <Switch
                  checked={enableSpatialAudio}
                  onCheckedChange={setEnableSpatialAudio}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium">Reverb Effects</label>
                  <p className="text-xs text-gray-600">Environmental audio reverb</p>
                </div>
                <Switch
                  checked={enableReverb}
                  onCheckedChange={setEnableReverb}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Audio Quality</label>
                <div className="grid grid-cols-3 gap-2">
                  {['low', 'medium', 'high'].map((quality) => (
                    <Button
                      key={quality}
                      variant={audioQuality === quality ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setAudioQuality(quality)}
                      className="capitalize"
                    >
                      {quality}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Sound Events */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Sound Events</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="text-xs font-medium text-gray-600">Interface Sounds</h4>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span>Button clicks</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span>Menu hover</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span>File operations</span>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="text-xs font-medium text-gray-600">System Sounds</h4>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span>Error alerts</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span>Success notifications</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span>Background ambience</span>
                      <Switch />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-4 border-t">
          <Button variant="outline" onClick={resetToDefaults}>
            <Settings className="w-4 h-4 mr-2" />
            Reset to Defaults
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={saveSettings}>
              Save Settings
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}