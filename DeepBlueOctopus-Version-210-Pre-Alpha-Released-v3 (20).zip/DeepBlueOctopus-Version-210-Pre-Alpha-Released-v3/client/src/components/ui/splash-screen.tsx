import { useState, useEffect } from "react";
import { Progress } from "@/components/ui/progress";
import OctopusLogo from "@/components/ui/octopus-logo";
import { useSoundSystem } from "@/components/ui/sound-system";

interface SplashScreenProps {
  onComplete: () => void;
  duration?: number;
}

export default function SplashScreen({ onComplete, duration = 4000 }: SplashScreenProps) {
  const { playSound } = useSoundSystem();
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState("");
  const [showFeatures, setShowFeatures] = useState(false);

  const loadingSteps = [
    "Initializing DeepBlue:Octopus Engine...",
    "Loading Monaco Editor...",
    "Connecting to PostgreSQL Database...",
    "Initializing Game Engine Systems...",
    "Loading 25+ Programming Languages...",
    "Starting Audio/Video Processing...",
    "Enabling AI Assistant Agents...",
    "Preparing Mathematics Library...",
    "Finalizing IDE Components...",
    "Ready to Code!"
  ];

  useEffect(() => {
    let stepIndex = 0;
    const interval = setInterval(() => {
      if (stepIndex < loadingSteps.length) {
        setCurrentStep(loadingSteps[stepIndex]);
        setProgress((stepIndex + 1) * 10);
        
        // Play loading sound effect for each step
        playSound('loading');
        
        if (stepIndex === 5) {
          setShowFeatures(true);
        }
        
        stepIndex++;
      } else {
        clearInterval(interval);
        // Play success sound when loading completes
        playSound('success');
        setTimeout(() => onComplete(), 500);
      }
    }, 400);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="splash-screen">
      <div className="splash-content">
        {/* Animated Background */}
        <div className="ocean-waves">
          <div className="wave wave1"></div>
          <div className="wave wave2"></div>
          <div className="wave wave3"></div>
        </div>

        {/* Floating Bubbles */}
        <div className="bubbles">
          {Array.from({ length: 8 }, (_, i) => (
            <div key={i} className={`bubble bubble-${i + 1}`}></div>
          ))}
        </div>

        {/* Main Content */}
        <div className="splash-main">
          <div className="logo-container">
            <OctopusLogo size={120} animated={true} />
          </div>
          
          <h1 className="ide-title">
            DeepBlue:Octopus
            <span className="version-tag">v2.1.0 - Pre Alpha v3 build</span>
          </h1>
          
          <p className="subtitle">
            Professional Web-Based Development Environment
          </p>

          {showFeatures && (
            <div className="features-preview">
              <div className="feature-item">
                <div className="feature-icon">🗄️</div>
                <span>PostgreSQL</span>
              </div>
              <div className="feature-item">
                <div className="feature-icon">🚀</div>
                <span>25+ Languages</span>
              </div>
              <div className="feature-item">
                <div className="feature-icon">🎮</div>
                <span>Game Engine</span>
              </div>
              <div className="feature-item">
                <div className="feature-icon">🎵</div>
                <span>Audio/Video</span>
              </div>
              <div className="feature-item">
                <div className="feature-icon">🤖</div>
                <span>AI Agents</span>
              </div>
            </div>
          )}

          <div className="loading-section">
            <div className="loading-text">
              {currentStep}
            </div>
            <Progress 
              value={progress} 
              className="progress-bar"
            />
            <div className="progress-percentage">
              {progress}%
            </div>
          </div>

          <div className="powered-by">
            Powered by React, TypeScript, Monaco Editor & Advanced AI
          </div>
        </div>
      </div>
    </div>
  );
}