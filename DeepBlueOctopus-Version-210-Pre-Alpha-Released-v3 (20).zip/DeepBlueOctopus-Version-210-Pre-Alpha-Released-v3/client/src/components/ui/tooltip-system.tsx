import { useState, useEffect, useRef, ReactNode, useMemo } from "react";
import { createPortal } from "react-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { X, Lightbulb, Keyboard, Info, Zap } from "lucide-react";

interface TooltipData {
  id: string;
  title: string;
  content: string;
  type: "info" | "tip" | "shortcut" | "warning" | "feature";
  position: { x: number; y: number };
  element?: HTMLElement;
  persistent?: boolean;
  showDelay?: number;
  hideDelay?: number;
}

interface TooltipSystemProps {
  children: ReactNode;
}

class TooltipManager {
  private static instance: TooltipManager;
  private tooltips: Map<string, TooltipData> = new Map();
  private activeTooltip: string | null = null;
  private listeners: Set<(tooltips: TooltipData[]) => void> = new Set();
  private timeouts: Map<string, NodeJS.Timeout> = new Map();

  static getInstance(): TooltipManager {
    if (!TooltipManager.instance) {
      TooltipManager.instance = new TooltipManager();
    }
    return TooltipManager.instance;
  }

  addTooltip(tooltip: TooltipData) {
    this.tooltips.set(tooltip.id, tooltip);
    this.notifyListeners();
  }

  removeTooltip(id: string) {
    this.tooltips.delete(id);
    if (this.activeTooltip === id) {
      this.activeTooltip = null;
    }
    const timeout = this.timeouts.get(id);
    if (timeout) {
      clearTimeout(timeout);
      this.timeouts.delete(id);
    }
    this.notifyListeners();
  }

  showTooltip(id: string, delay: number = 500) {
    const tooltip = this.tooltips.get(id);
    if (!tooltip) return;

    const timeout = setTimeout(() => {
      this.activeTooltip = id;
      this.notifyListeners();
    }, delay);

    this.timeouts.set(id, timeout);
  }

  hideTooltip(id: string, delay: number = 100) {
    const existingTimeout = this.timeouts.get(id);
    if (existingTimeout) {
      clearTimeout(existingTimeout);
    }

    const timeout = setTimeout(() => {
      if (this.activeTooltip === id) {
        this.activeTooltip = null;
        this.notifyListeners();
      }
    }, delay);

    this.timeouts.set(id, timeout);
  }

  getActiveTooltip(): TooltipData | null {
    return this.activeTooltip ? this.tooltips.get(this.activeTooltip) || null : null;
  }

  getAllTooltips(): TooltipData[] {
    return Array.from(this.tooltips.values());
  }

  subscribe(listener: (tooltips: TooltipData[]) => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners() {
    this.listeners.forEach(listener => listener(this.getAllTooltips()));
  }
}

export function useTooltipSystem() {
  const manager = TooltipManager.getInstance();
  const [tooltips, setTooltips] = useState<TooltipData[]>([]);
  const [activeTooltip, setActiveTooltip] = useState<TooltipData | null>(null);

  useEffect(() => {
    const updateTooltips = () => {
      setTooltips(manager.getAllTooltips());
      setActiveTooltip(manager.getActiveTooltip());
    };

    const unsubscribe = manager.subscribe(updateTooltips);
    updateTooltips();

    return () => {
      unsubscribe();
    };
  }, [manager]);

  const addTooltip = (tooltip: Omit<TooltipData, "id">) => {
    const id = `tooltip_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    manager.addTooltip({ ...tooltip, id });
    return id;
  };

  const removeTooltip = (id: string) => {
    manager.removeTooltip(id);
  };

  const showTooltip = (id: string, delay?: number) => {
    manager.showTooltip(id, delay);
  };

  const hideTooltip = (id: string, delay?: number) => {
    manager.hideTooltip(id, delay);
  };

  return {
    tooltips,
    activeTooltip,
    addTooltip,
    removeTooltip,
    showTooltip,
    hideTooltip,
  };
}

export function TooltipOverlay() {
  const { activeTooltip } = useTooltipSystem();

  if (!activeTooltip) return null;

  const getTooltipIcon = (type: TooltipData["type"]) => {
    switch (type) {
      case "tip":
        return <Lightbulb className="w-4 h-4 text-yellow-400" />;
      case "shortcut":
        return <Keyboard className="w-4 h-4 text-blue-400" />;
      case "warning":
        return <X className="w-4 h-4 text-red-400" />;
      case "feature":
        return <Zap className="w-4 h-4 text-purple-400" />;
      default:
        return <Info className="w-4 h-4 text-blue-400" />;
    }
  };

  const getTooltipColor = (type: TooltipData["type"]) => {
    switch (type) {
      case "tip":
        return "border-yellow-400/20 bg-yellow-50/10";
      case "shortcut":
        return "border-blue-400/20 bg-blue-50/10";
      case "warning":
        return "border-red-400/20 bg-red-50/10";
      case "feature":
        return "border-purple-400/20 bg-purple-50/10";
      default:
        return "border-blue-400/20 bg-blue-50/10";
    }
  };

  return createPortal(
    <div
      className="fixed z-[9999] pointer-events-none"
      style={{
        left: activeTooltip.position.x,
        top: activeTooltip.position.y,
        transform: "translate(-50%, -100%)",
      }}
    >
      <Card className={`max-w-xs shadow-lg border-2 ${getTooltipColor(activeTooltip.type)} backdrop-blur-sm`}>
        <CardContent className="p-3">
          <div className="flex items-start gap-2">
            {getTooltipIcon(activeTooltip.type)}
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-sm mb-1 text-foreground">
                {activeTooltip.title}
              </h4>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {activeTooltip.content}
              </p>
              <Badge 
                variant="secondary" 
                className="mt-2 text-xs"
              >
                {activeTooltip.type}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>,
    document.body
  );
}

export function useTooltipTrigger(
  tooltipData: Omit<TooltipData, "id" | "position">,
  enabled: boolean = true
) {
  const { addTooltip, removeTooltip, showTooltip, hideTooltip } = useTooltipSystem();
  const [tooltipId, setTooltipId] = useState<string | null>(null);
  const elementRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!enabled || !elementRef.current) return;

    const element = elementRef.current;
    const manager = TooltipManager.getInstance();
    
    const handleMouseEnter = (e: MouseEvent) => {
      const rect = element.getBoundingClientRect();
      const id = `tooltip_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      manager.addTooltip({
        ...tooltipData,
        id,
        position: {
          x: rect.left + rect.width / 2,
          y: rect.top,
        },
        element,
      });
      setTooltipId(id);
      manager.showTooltip(id, tooltipData.showDelay);
    };

    const handleMouseLeave = () => {
      if (tooltipId) {
        manager.hideTooltip(tooltipId, tooltipData.hideDelay);
        setTimeout(() => {
          manager.removeTooltip(tooltipId);
          setTooltipId(null);
        }, (tooltipData.hideDelay || 100) + 50);
      }
    };

    element.addEventListener("mouseenter", handleMouseEnter);
    element.addEventListener("mouseleave", handleMouseLeave);

    return () => {
      element.removeEventListener("mouseenter", handleMouseEnter);
      element.removeEventListener("mouseleave", handleMouseLeave);
      if (tooltipId) {
        manager.removeTooltip(tooltipId);
      }
    };
  }, [enabled, tooltipData.title, tooltipData.content, tooltipData.type, tooltipId]);

  return elementRef;
}

export function TooltipProvider({ children }: TooltipSystemProps) {
  return (
    <>
      {children}
      <TooltipOverlay />
    </>
  );
}

// Pre-built tooltip components for common IDE elements
export function IDETooltips() {
  const { addTooltip } = useTooltipSystem();

  useEffect(() => {
    // Add global IDE tooltips
    const tooltips = [
      {
        title: "File Explorer",
        content: "Browse and manage your project files. Right-click for context menu options.",
        type: "info" as const,
        position: { x: 100, y: 100 },
      },
      {
        title: "Command Palette",
        content: "Press Ctrl+Shift+P to open the command palette and access all IDE features quickly.",
        type: "shortcut" as const,
        position: { x: 200, y: 100 },
      },
      {
        title: "Game Engine",
        content: "Create interactive games with multiple engine types. Access via Tools > Game Engine.",
        type: "feature" as const,
        position: { x: 300, y: 100 },
      },
    ];

    tooltips.forEach(tooltip => addTooltip(tooltip));
  }, [addTooltip]);

  return null;
}

// Tooltip wrapper component for easy use
interface TooltipWrapperProps {
  title: string;
  content: string;
  type?: TooltipData["type"];
  children: ReactNode;
  className?: string;
}

export function TooltipWrapper({ 
  title, 
  content, 
  type = "info", 
  children, 
  className = "" 
}: TooltipWrapperProps) {
  const tooltipData = useMemo(() => ({
    title,
    content,
    type,
  }), [title, content, type]);

  const tooltipRef = useTooltipTrigger(tooltipData);

  return (
    <div 
      ref={tooltipRef as any}
      className={`tooltip-wrapper ${className}`}
    >
      {children}
    </div>
  );
}