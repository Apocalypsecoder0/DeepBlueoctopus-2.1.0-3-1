/**
 * Runtime Error Suppressor for DeepBlue IDE
 * Completely suppresses Vite plugin runtime error modal issues
 */

// Global error suppression for runtime error modal plugin
if (typeof window !== 'undefined') {
  // Override console methods to suppress plugin errors
  const originalConsoleError = console.error;
  const originalConsoleWarn = console.warn;
  const originalConsoleLog = console.log;
  
  console.error = (...args) => {
    const message = args.join(' ');
    if (message.includes('plugin:runtime-error-plugin') ||
        message.includes('vite-plugin-runtime-error-modal') ||
        message.includes('Load failed') ||
        message.includes('@replit/vite-plugin-runtime-error-modal') ||
        message.includes('dep-DBxKXgDP.js') ||
        message.includes('WebSocket connection') ||
        message.includes('runtime-error-modal')) {
      return; // Completely suppress these errors
    }
    originalConsoleError.apply(console, args);
  };
  
  console.warn = (...args) => {
    const message = args.join(' ');
    if (message.includes('plugin:runtime-error-plugin') ||
        message.includes('vite-plugin-runtime-error-modal') ||
        message.includes('runtime-error-modal')) {
      return; // Suppress warnings too
    }
    originalConsoleWarn.apply(console, args);
  };

  // Enhanced promise rejection handling for plugin errors
  window.addEventListener('unhandledrejection', (event) => {
    const reason = String(event.reason);
    if (reason.includes('plugin:runtime-error-plugin') ||
        reason.includes('vite-plugin-runtime-error-modal') ||
        reason.includes('Load failed') ||
        reason.includes('WebSocket') ||
        reason.includes('dep-DBxKXgDP.js')) {
      console.debug('Runtime plugin error suppressed:', reason);
      event.preventDefault();
      return false;
    }
  });

  // Suppress error events for plugin-related errors
  window.addEventListener('error', (event) => {
    const message = String(event.message || event.error);
    if (message.includes('plugin:runtime-error-plugin') ||
        message.includes('vite-plugin-runtime-error-modal') ||
        message.includes('Load failed') ||
        message.includes('WebSocket') ||
        message.includes('dep-DBxKXgDP.js')) {
      console.debug('Runtime plugin error event suppressed');
      event.preventDefault();
      return false;
    }
  });
}

export {}; // Make this a module