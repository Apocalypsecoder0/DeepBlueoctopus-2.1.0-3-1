/**
 * WebSocket Error Handler for Development Environment
 * Handles WebSocket connection errors from Vite HMR and runtime error modal
 */

interface WebSocketErrorHandler {
  initialize(): void;
  cleanup(): void;
}

class ViteWebSocketErrorHandler implements WebSocketErrorHandler {
  private originalWebSocket: typeof WebSocket;
  private errorInterceptor: ((event: Event) => void) | null = null;

  constructor() {
    this.originalWebSocket = window.WebSocket;
  }

  initialize(): void {
    // Intercept WebSocket creation to add error handling
    const self = this;
    
    // Override WebSocket constructor
    window.WebSocket = class extends self.originalWebSocket {
      constructor(url: string | URL, protocols?: string | string[]) {
        super(url, protocols);
        
        // Add comprehensive error handling
        this.addEventListener('error', (event) => {
          // Silently handle Vite HMR WebSocket errors
          if (url.toString().includes('vite') || 
              url.toString().includes('ws://') ||
              url.toString().includes('runtime-error-modal')) {
            console.debug('Vite WebSocket error suppressed:', event);
            return;
          }
        });

        this.addEventListener('close', (event) => {
          // Handle WebSocket close events gracefully
          if (event.code === 1006 || event.code === 1001) {
            console.debug('WebSocket connection closed (expected for HMR)');
            return;
          }
        });
      }
    };

    // Global error handler for WebSocket-related errors
    this.errorInterceptor = (event: Event | ErrorEvent) => {
      if ('error' in event && event.error) {
        const errorMessage = event.error.message || '';
        const errorStack = event.error.stack || '';
        
        if (errorMessage.includes('WebSocket') || 
            errorMessage.includes('runtime-error-modal') ||
            errorStack.includes('vite-plugin-runtime-error-modal')) {
          event.preventDefault();
          console.debug('WebSocket error intercepted and suppressed');
          return false;
        }
      }
    };

    window.addEventListener('error', this.errorInterceptor, true);
    window.addEventListener('unhandledrejection', this.errorInterceptor, true);
  }

  cleanup(): void {
    // Restore original WebSocket
    window.WebSocket = this.originalWebSocket;
    
    // Remove error interceptor
    if (this.errorInterceptor) {
      window.removeEventListener('error', this.errorInterceptor, true);
      window.removeEventListener('unhandledrejection', this.errorInterceptor, true);
      this.errorInterceptor = null;
    }
  }
}

// Global process error handling for Node.js-like environments
if (typeof process !== 'undefined' && process.on) {
  process.on('uncaughtException', (error) => {
    if (error.message && (
        error.message.includes('WebSocket') ||
        error.message.includes('runtime-error-modal') ||
        error.message.includes('vite-plugin')
    )) {
      console.debug('Node.js WebSocket error suppressed:', error.message);
      return;
    }
    console.error('Uncaught Exception:', error);
  });

  process.on('unhandledRejection', (reason, promise) => {
    if (reason && typeof reason === 'object' && 
        (JSON.stringify(reason).includes('WebSocket') || 
         Object.keys(reason).length === 0)) {
      console.debug('Node.js unhandled rejection suppressed');
      return;
    }
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  });
}

// Initialize the WebSocket error handler
export const webSocketErrorHandler = new ViteWebSocketErrorHandler();

// Auto-initialize in development
if (process.env.NODE_ENV === 'development') {
  webSocketErrorHandler.initialize();
}

export default webSocketErrorHandler;