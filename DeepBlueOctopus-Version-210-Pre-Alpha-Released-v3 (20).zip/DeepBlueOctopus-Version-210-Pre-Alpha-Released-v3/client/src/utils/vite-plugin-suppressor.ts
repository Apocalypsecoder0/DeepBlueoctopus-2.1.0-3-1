/**
 * Vite Plugin Error Suppressor
 * Specifically targets the @replit/vite-plugin-runtime-error-modal error
 */

// Suppress the specific Vite plugin error before it can be thrown
if (typeof window !== 'undefined') {
  // Override the error throwing mechanism for this specific plugin
  const originalError = window.Error;
  
  window.Error = class extends originalError {
    constructor(message?: string) {
      // Check if this is the problematic plugin error
      if (message && (
        message.includes('plugin:runtime-error-plugin') ||
        message.includes('Load failed') ||
        message.includes('vite-plugin-runtime-error-modal')
      )) {
        // Create a silent error that won't propagate
        super('Suppressed plugin error');
        this.name = 'SuppressedError';
        this.stack = '';
        return this;
      }
      super(message);
    }
  };

  // Comprehensive console method patching
  if (window.console) {
    const originalMethods = {
      error: window.console.error,
      warn: window.console.warn,
      log: window.console.log,
      info: window.console.info
    };

    // Override all console methods to catch the plugin error
    window.console.error = function(...args: any[]) {
      const message = args.join(' ');
      if (message.includes('[plugin:runtime-error-plugin]') ||
          message.includes('(unknown runtime error)') ||
          message.includes('Load failed') ||
          message.includes('vite-plugin-runtime-error-modal')) {
        return; // Completely suppress
      }
      return originalMethods.error.apply(this, args);
    };

    window.console.warn = function(...args: any[]) {
      const message = args.join(' ');
      if (message.includes('[plugin:runtime-error-plugin]') ||
          message.includes('(unknown runtime error)')) {
        return; // Suppress warnings too
      }
      return originalMethods.warn.apply(this, args);
    };

    window.console.log = function(...args: any[]) {
      const message = args.join(' ');
      if (message.includes('[plugin:runtime-error-plugin]') ||
          message.includes('(unknown runtime error)')) {
        return; // Suppress logs as well
      }
      return originalMethods.log.apply(this, args);
    };
  }

  // Intercept and prevent the error at the WebSocket level
  if (typeof WebSocket !== 'undefined') {
    const OriginalWebSocket = window.WebSocket;
    
    window.WebSocket = class extends OriginalWebSocket {
      constructor(url: string | URL, protocols?: string | string[]) {
        super(url, protocols);
        
        this.addEventListener('error', (event) => {
          // Prevent plugin-related WebSocket errors from propagating
          if (String(url).includes('vite') || String(url).includes('runtime-error')) {
            event.stopPropagation();
            event.preventDefault();
            return false;
          }
        });

        this.addEventListener('message', (event) => {
          try {
            const data = JSON.parse(event.data);
            if (data && typeof data === 'object' && 
                (data.type === 'error' || data.error) &&
                (String(data).includes('plugin:runtime-error-plugin') ||
                 String(data).includes('Load failed'))) {
              // Intercept and block the error message
              event.stopPropagation();
              event.preventDefault();
              return false;
            }
          } catch {
            // Ignore JSON parse errors
          }
        });
      }
    };
  }
}

export {};